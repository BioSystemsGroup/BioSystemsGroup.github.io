def configureSimulation(sim):
   import CompuCell
   import CompuCellSetup
   
   ppd=CompuCell.PottsParseData()
   ppd.DebugOutputFrequency(40)
   ppd.Steps(20000)
   ppd.Anneal(10)
   ppd.Temperature(15)
   ppd.Flip2DimRatio(1.0)
   ppd.Dimensions(CompuCell.Dim3D(100,100,1))
   
   
   ctpd=CompuCell.CellTypeParseData()
   ctpd.CellType("Medium",0)
   ctpd.CellType("Bacterium",1)
   ctpd.CellType("Macrophage",2)
   ctpd.CellType("Wall",3,True)
   
   cpd=CompuCell.ContactParseData()
   cpd.Energy("Medium","Medium",0)
   cpd.Energy("Macrophage","Macrophage",15)
   cpd.Energy("Macrophage","Medium",8)
   cpd.Energy("Bacterium","Bacterium",15)
   cpd.Energy("Bacterium","Macrophage",15)
   cpd.Energy("Bacterium","Medium",8)
   cpd.Energy("Wall","Wall",0)
   cpd.Energy("Wall","Medium",0)
   cpd.Energy("Wall","Bacterium",50)
   cpd.Energy("Wall","Macrophage",50)
      
   vpd=CompuCell.VolumeParseData()
   vpd.LambdaVolume(15.0)
   vpd.TargetVolume(25.0)
   
   spd=CompuCell.SurfaceParseData()
   spd.LambdaSurface(4.0)
   spd.TargetSurface(20.0)

   chpd=CompuCell.ChemotaxisParseData()
   chfield=chpd.ChemicalField()
   chfield.Source("FastDiffusionSolver2DFE")
   chfield.Name("ATTR")
   chbt=chfield.ChemotaxisByType()
   chbt.Type("Macrophage")
   chbt.Lambda(2.0)

   ufpd=CompuCell.UniformInitializerParseData()
   region=ufpd.Region()
   region.BoxMin(CompuCell.Dim3D(20,20,0))
   region.BoxMax(CompuCell.Dim3D(30,30,1))
   region.Types("Bacterium")
   region.Width(5)
   
   
   #fdspd=CompuCell.FlexibleDiffusionSolverFEParseData()
   fdspd=CompuCell.FastDiffusionSolver2DFEParseData()
   df=fdspd.DiffusionField()
   diffData=df.DiffusionData()
   secrData=df.SecretionData()
   #dsfft=CompuCell.DiffusionSecretionFlexFieldTupple()
   diffData.DiffusionConstant(0.1)
   diffData.FieldName("ATTR")
   diffData.DoNotDiffuseTo("Wall")
   secrData.Secretion("Bacterium",200)
   #secrData.SecretionOnContact("Wall","Medium",200)
   #secrData.SecretionOnContact("Macrophage","Medium",500)
   pscpd=CompuCell.PDESolverCallerParseData()
   sd=pscpd.CallPDE("FastDiffusionSolver2DFE",1)

   
   pifpd=CompuCell.PIFInitializerParseData()
   pifpd.PIFName("bacterium_macrophage_2D_wall.pif")
   

   CompuCellSetup.registerPotts(sim,ppd)
   CompuCellSetup.registerPlugin(sim,ctpd)
   CompuCellSetup.registerPlugin(sim,vpd)
   CompuCellSetup.registerPlugin(sim,spd)
   CompuCellSetup.registerPlugin(sim,chpd)
   CompuCellSetup.registerPlugin(sim,pscpd)
   
   CompuCellSetup.registerSteppable(sim,pifpd)
   CompuCellSetup.registerSteppable(sim,fdspd)

import sys
from os import environ
import string
sys.path.append(environ["PYTHON_MODULE_PATH"])
   
import CompuCellSetup

sim,simthread = CompuCellSetup.getCoreSimulationObjects()

configureSimulation(sim)

CompuCellSetup.initializeSimulationObjects(sim,simthread)


from PySteppables import SteppableRegistry
steppableRegistry=SteppableRegistry()

#from steering_steppables_examples import DiffusionSolverSteering
#dss=DiffusionSolverSteering(sim,100)
#steppableRegistry.registerSteppable(dss)

#from steering_steppables_examples import PottsSteering
#ps=PottsSteering(sim,100)
#steppableRegistry.registerSteppable(ps)

from steering_steppables_examples import ChemotaxisSteering
cs=ChemotaxisSteering(sim,100)
steppableRegistry.registerSteppable(cs)


#from steering_steppables_examples import PDESolverCallerSteering
#pscs=PDESolverCallerSteering(sim,100)
#steppableRegistry.registerSteppable(pscs)



CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)
