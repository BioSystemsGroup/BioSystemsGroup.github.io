class EnergyFunctionPy:
   def __init__(self):pass
   def changeEnergy(self):pass

class Field3DChangeWatcherPy:
   def __init__(self,_changeWatcher):
      self.changeWatcher=_changeWatcher
   def field3DChange(self):pass


class TypeChangeWatcherPy:
   def __init__(self):pass
   def typeChange(self):pass

class StepperPy:
   def __init__(self):pass
   def step(self):pass
            