def configureSimulation(sim):
   import CompuCell
   import CompuCellSetup
   ppd=CompuCell.PottsParseData()
   ppd.DebugOutputFrequency(40)
   ppd.Steps(20000)
   ppd.Anneal(10)
   ppd.Temperature(5)
   ppd.Flip2DimRatio(1.0)
   ppd.NeighborOrder(2)
   ppd.Dimensions(CompuCell.Dim3D(100,100,1))
   ppd.Boundary_x("Periodic")
   
   ctpd=CompuCell.CellTypeParseData()   
   ctpd.CellType("Medium",0)
   ctpd.CellType("Body1",1)
   ctpd.CellType("Body2",2)
   ctpd.CellType("Body3",3)   

   cpd=CompuCell.ContactParseData()
   cpd.Energy("Medium" ,"Medium",0)
   cpd.Energy("Body1" ,"Body1",16)
   cpd.Energy("Body1" ,"Medium",4)
   cpd.Energy("Body2" ,"Body2",16)
   cpd.Energy("Body2" ,"Medium",4)
   cpd.Energy("Body3" ,"Body3",16)
   cpd.Energy("Body3" ,"Medium",4)
   cpd.Energy("Body1" ,"Body2",16)   
   cpd.Energy("Body1" ,"Body3",16)
   cpd.Energy("Body2" ,"Body3",16)   
   cpd.NeighborOrder(2)
   
   vpd=CompuCell.VolumeParseData()
   vpd.LambdaVolume(4.0)
   vpd.TargetVolume(25.0)
   
   comtpd=CompuCell.CenterOfMassTrackerParseData()
   ptpd=CompuCell.PlasticityTrackerParseData()
   ptpd.IncludeType("Body1")
   ptpd.IncludeType("Body2")
   ptpd.IncludeType("Body3")
   
   plastpd=CompuCell.PlasticityParseData()
   #plastpd.Local(True)
   plastpd.LambdaPlasticity(200.0)
   plastpd.TargetLengthPlasticity(6.0)
   eppd=CompuCell.ExternalPotentialParseData()
   eppd.Lambda(-10,0,0)
   
   pifpd=CompuCell.PIFInitializerParseData()
   pifpd.PIFName("plasticitytest.pif")
   
   
   CompuCellSetup.registerPotts(sim,ppd)
   CompuCellSetup.registerPlugin(sim,ctpd)
   CompuCellSetup.registerPlugin(sim,cpd)
   CompuCellSetup.registerPlugin(sim,vpd)
   CompuCellSetup.registerPlugin(sim,comtpd)
   CompuCellSetup.registerPlugin(sim,ptpd)
   CompuCellSetup.registerPlugin(sim,plastpd)
   CompuCellSetup.registerPlugin(sim,eppd)
   
   CompuCellSetup.registerSteppable(sim,pifpd)
   
   
import sys
from os import environ
import string
sys.path.append(environ["PYTHON_MODULE_PATH"])
   
import CompuCellSetup

sim,simthread = CompuCellSetup.getCoreSimulationObjects()

configureSimulation(sim)

CompuCellSetup.initializeSimulationObjects(sim,simthread)

from PySteppables import SteppableRegistry
steppableRegistry=SteppableRegistry()

#from plasticitytestSteppables import PlasticityLocalSteppable
#plasticitySteppable=PlasticityLocalSteppable(_simulator=sim,_frequency=50)
#steppableRegistry.registerSteppable(plasticitySteppable)

from steering_steppables_examples import PlasticitySteering
ps=PlasticitySteering(sim,100)
steppableRegistry.registerSteppable(ps)


CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)

