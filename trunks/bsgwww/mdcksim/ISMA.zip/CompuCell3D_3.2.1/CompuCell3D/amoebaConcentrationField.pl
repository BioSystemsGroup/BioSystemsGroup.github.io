#!/usr/bin/perl -w

use strict;

my $i_max=0;
my $j_max=0;
my $k_max=0;


my $i=0;
my $j=0;
my $k=0;

my $filename="amoebaeChemotactingField.txt";

    foreach(@ARGV){
            if(/^-i(.+)/){$i_max=$1;}
	    if(/^-j(.+)/){$j_max=$1;}
	    if(/^-k(.+)/){$k_max=$1;}
	    if(/^-o(.+)/){$filename=$1;}
    }

open(FILE,">$filename");
my $concentration;


for($i=0 ; $i<$i_max; ++$i){
    for($j=0 ; $j<$j_max; ++$j){
	for($k=0 ; $k<$k_max; ++$k){
	
	    $concentration = $i*$j*$k;
	    print FILE "$i $j $k $concentration\n";
	    
	}
    }
}