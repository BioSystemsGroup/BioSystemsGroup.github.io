def configureSimulation(sim):
   import CompuCell
   import CompuCellSetup
   
   ppd=CompuCell.PottsParseData()
   ppd.DebugOutputFrequency(40)
   ppd.Steps(20000)
   ppd.Anneal(10)
   ppd.Temperature(5)
   ppd.Flip2DimRatio(1.0)
   ppd.NeighborOrder(2)
   ppd.Dimensions(CompuCell.Dim3D(100,100,1))
   ppd.LatticeType("Hexagonal")

   
   
   ctpd=CompuCell.CellTypeParseData()

   ctpd.CellType("Medium",0)
   ctpd.CellType("Condensing",1)
   ctpd.CellType("NonCondensing",2)
   
   cpd=CompuCell.ContactParseData()
   cpd.Energy("Medium","Medium",0)
   cpd.Energy("NonCondensing","NonCondensing",16)
   cpd.Energy("Condensing","Condensing",2)
   cpd.Energy("NonCondensing","Condensing",11)
   cpd.Energy("NonCondensing","Medium",16)
   cpd.Energy("Condensing","Medium",16)
   
   #vpd=CompuCell.VolumeParseData()
   #vpd.LambdaVolume(1.0)
   #vpd.TargetVolume(25.0)
   
   vfpd=CompuCell.VolumeFlexParseData()
   vfpd.VolumeEnergyParameters("Condensing",25.0,1.0)
   vfpd.VolumeEnergyParameters("NonCondensing",25.0,1.0)

   #spd=CompuCell.SurfaceParseData()
   #spd.LambdaSurface(1.0)
   #spd.TargetSurface(25.0)
   
   sfpd=CompuCell.SurfaceFlexParseData()
   sfpd.SurfaceEnergyParameters("Condensing",25.0,1.0)
   sfpd.SurfaceEnergyParameters("NonCondensing",25.0,1.0)
      
      
   bipd=CompuCell.BlobInitializerParseData()
   region=bipd.Region()
   region.Center(CompuCell.Point3D(50,50,0))
   region.Radius(30)
   region.Types("Condensing")
   region.Types("NonCondensing")
   region.Width(5)
   

   CompuCellSetup.registerPotts(sim,ppd)
   CompuCellSetup.registerPlugin(sim,ctpd)
   CompuCellSetup.registerPlugin(sim,cpd)
   CompuCellSetup.registerPlugin(sim,vfpd)
   CompuCellSetup.registerPlugin(sim,sfpd)      
   
   CompuCellSetup.registerSteppable(sim,bipd)
   
import sys
from os import environ
import string
sys.path.append(environ["PYTHON_MODULE_PATH"])
   
import CompuCellSetup

sim,simthread = CompuCellSetup.getCoreSimulationObjects()

configureSimulation(sim)

CompuCellSetup.initializeSimulationObjects(sim,simthread)


from PySteppables import SteppableRegistry
steppableRegistry=SteppableRegistry()

from steering_steppables_examples import PottsSteering
ps=PottsSteering(sim,100)
steppableRegistry.registerSteppable(ps)

from steering_steppables_examples import ContactSteering
cs=ContactSteering(sim,100)
steppableRegistry.registerSteppable(cs)


CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)

