"This module contains definitions of basic classes that are used to construct Python based Steppables"

#steppables

class SimObjectPy:
   def __init__(self):pass
   def init(self,_simulator):
      self.simulator=_simulator
   def extraInit(self,_simulator):
      self.simulator=_simulator

class SteppablePy(SimObjectPy):
   def __init__(self,_frequency=1):
      self.frequency=_frequency
   #def __name__(self):
      #self.name="Steppable"
   def setFrequency(self,_freq):
      self.frequency=_freq
   def start(self):pass
   def step(self,_mcs):pass
   def finish(self):pass


class SteppableBasePy(SteppablePy):
   def __init__(self,_simulator,_frequency=1):
      SteppablePy.__init__(self,_frequency)
      self.simulator=_simulator
      self.potts=_simulator.getPotts()
      self.cellField=self.potts.getCellFieldG()
      self.dim=self.cellField.getDim()
      self.inventory=self.simulator.getPotts().getCellInventory()
      self.cellList=CellList(self.inventory)



class SteppableRegistry(SteppablePy):
   def __init__(self):
      self.steppableList=[]

   def registerSteppable(self,_steppable):
      self.steppableList.append(_steppable)

   def init(self,_simulator):
      for steppable in self.steppableList:
         steppable.init(_simulator)

   def extraInit(self,_simulator):
      for steppable in self.steppableList:
         steppable.extraInit(_simulator)

   def start(self):
      for steppable in self.steppableList:
         steppable.start()

   def step(self,_mcs):
      for steppable in self.steppableList:
         if not _mcs % steppable.frequency: #this executes given steppable every "frequency" Monte Carlo Steps
            steppable.step(_mcs)

   def finish(self):
      for steppable in self.steppableList:
         steppable.finish()


#this is used to iterate more easily over cells

class CellList:
   def __init__(self,_inventory):
      self.inventory = _inventory
   def __iter__(self):
      return CellListIterator(self)

class CellListIterator:
   def __init__(self, _cellList):
      import CompuCell
      self.inventory = _cellList.inventory
      self.invItr=CompuCell.STLPyIteratorCINV()
      self.invItr.initialize(self.inventory.getContainer())
      self.invItr.setToBegin()
   def next(self):
      if not self.invItr.isEnd():
         self.cell = self.invItr.getCurrentRef()
         self.invItr.next()
         return self.cell
      else:
         raise StopIteration
   def __iter__(self):
         return self

class CellNeighborList:
   def __init__(self,_neighborTrackerAccessor,_cell):
      self.neighborTrackerAccessor = _neighborTrackerAccessor
      self.cell=_cell
   def __iter__(self):
      return CellNeighborIterator(self)


class CellNeighborIterator:
   def __init__(self, _cellNeighborList):
      import CompuCell
      self.neighborTrackerAccessor = _cellNeighborList.neighborTrackerAccessor
      self.cell=_cellNeighborList.cell
      self.nsdItr=CompuCell.nsdSetPyItr()
      self.nTracker=self.neighborTrackerAccessor.get(self.cell.extraAttribPtr)
      self.nsdItr.initialize(self.nTracker.cellNeighbors)
      self.nsdItr.setToBegin()
      
   def next(self):
      if not self.nsdItr.isEnd():
         self.neighborCell = self.nsdItr.getCurrentRef().neighborAddress
         self.nsdItr.next()
         return self.neighborCell
      else:
         raise StopIteration
   def __iter__(self):
         return self


class CellNeighborListAuto:
   def __init__(self,_neighborPlugin,_cell):
      self.neighborPlugin=_neighborPlugin
      self.neighborTrackerAccessor=self.neighborPlugin.getNeighborTrackerAccessorPtr()
      self.cell=_cell
   def __iter__(self):
      return CellNeighborIteratorAuto(self)
   


class CellNeighborIteratorAuto:
   def __init__(self, _cellNeighborList):
      import CompuCell   
      self.neighborTrackerAccessor = _cellNeighborList.neighborTrackerAccessor
      self.cell=_cellNeighborList.cell
      self.nsdItr=CompuCell.nsdSetPyItr()
      self.nTracker=self.neighborTrackerAccessor.get(self.cell.extraAttribPtr)
      self.nsdItr.initialize(self.nTracker.cellNeighbors)
      self.nsdItr.setToBegin()
      
      
   def next(self):
      if not self.nsdItr.isEnd():
         self.neighborCell = self.nsdItr.getCurrentRef().neighborAddress
         self.currentNsdItr = self.nsdItr.current
         self.currentNeighborSurfaceData=self.nsdItr.getCurrentRef()
         self.nsdItr.next()         
         return self.currentNeighborSurfaceData
      else:
         raise StopIteration
   
   def __iter__(self):
         return self

class PlasticityDataList:
   def __init__(self,_plasticityTrackerPlugin,_cell):
      self.plasticityTrackerPlugin=_plasticityTrackerPlugin
      self.plasticityTrackerAccessor=self.plasticityTrackerPlugin.getPlasticityTrackerAccessorPtr()
      self.cell=_cell
   def __iter__(self):
      return PlasticityDataIterator(self)


class PlasticityDataIterator:
   def __init__(self, _plasticityDataList):
      import CompuCell
      self.plasticityTrackerAccessor = _plasticityDataList.plasticityTrackerAccessor
      self.cell=_plasticityDataList.cell
      self.plasticityTracker=self.plasticityTrackerAccessor.get(self.cell.extraAttribPtr)
      self.plasticityDataSetItr=CompuCell.plasticitySetPyItr()
      self.plasticityDataSetItr.initialize(self.plasticityTracker.plasticityNeighbors)
      self.plasticityDataSetItr.setToBegin()

   def next(self):
      if not self.plasticityDataSetItr.isEnd():
         self.currentPlasticityDataSetItr = self.plasticityDataSetItr.current
         self.plasticityData=self.plasticityDataSetItr.getCurrentRef()
         self.plasticityDataSetItr.next()

         return self.plasticityData
      else:
         raise StopIteration
   
   def __iter__(self):
         return self



# forEachCellInInventory function takes as arguments inventory of cells and a function that will operate on a single cell
# It will run singleCellOperation on each cell from cell inventory
def forEachCellInInventory(inventory,singleCellOperation):
   import CompuCell
   invItr=CompuCell.STLPyIteratorCINV()
   invItr.initialize(inventory.getContainer())
   invItr.setToBegin()
   cell=invItr.getCurrentRef()
   while (not invItr.isEnd()):
      cell=invItr.getCurrentRef()
      singleCellOperation(cell)
      invItr.next()
