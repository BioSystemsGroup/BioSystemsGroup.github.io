import sys
from os import environ
import string
sys.path.append(environ["PYTHON_MODULE_PATH"])
   
import CompuCellSetup

sim,simthread = CompuCellSetup.getCoreSimulationObjects()
CompuCellSetup.initializeSimulationObjects(sim,simthread)
#Create extra player fields here or add attributes
pyAttributeAdder,listAdder=CompuCellSetup.attachListToCells(sim)




#Add Python steppables here
steppableRegistry=CompuCellSetup.getSteppableRegistry()

from PySteppablesExamples import ModifyAttribute
modifyAttribute=ModifyAttribute(sim)
steppableRegistry.registerSteppable(modifyAttribute)


CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)


