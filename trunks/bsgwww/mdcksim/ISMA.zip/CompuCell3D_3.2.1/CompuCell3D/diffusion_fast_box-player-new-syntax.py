def configureSimulation(sim):
   import CompuCell
   import CompuCellSetup
   
   ppd=CompuCell.PottsParseData()
   ppd.DebugOutputFrequency(40)   
   ppd.Steps(1000)
   ppd.Anneal(10)
   ppd.Temperature(15)
   ppd.Flip2DimRatio(1.0)
   ppd.NeighborOrder(2)
   ppd.Dimensions(CompuCell.Dim3D(55,55,1))
   
   
   CompuCell.assignParseDataPtr(ppd,sim.ps.pottsParseData)
   
   ctpd=CompuCell.CellTypeParseData()
   
   ctpd.CellType("Medium",0)
   ctpd.CellType("Amoeba",1)
   ctpd.CellType("Bacteria",2)
   
   
   vpd=CompuCell.VolumeParseData()
   vpd.LambdaVolume(1.0)
   vpd.TargetVolume(25.0)

   spd=CompuCell.SurfaceParseData()
   spd.LambdaSurface(0.5)
   spd.TargetSurface(20.0)
      

   pscpd=CompuCell.PDESolverCallerParseData()
   sd=pscpd.CallPDE("FlexibleDiffusionSolverFE",10)
   
   plset=CompuCell.PlayerSettings()
   plset.advancedSettingsOn=True
   plset.numberOfLegendBoxes=7
   plset.numberOfLegendBoxesFlag=True
   plset.legendEnable=True
   plset.legendEnableFlag=True
   
   bwpd=CompuCell.BoxWatcherParseData()
   bwpd.XMargin(1)
   bwpd.YMargin(1)
   bwpd.ZMargin(1)
   
   
   fdspd=CompuCell.FastDiffusionSolver2DFEParseData()
   df=fdspd.DiffusionField()
   diffData=df.DiffusionData()
   secrData=df.SecretionData()
   diffData.UseBoxWatcher(True)
   diffData.DiffusionConstant(0.1)
   diffData.FieldName("FGF")
   diffData.ConcentrationFileName("diffusion_2D_fast_box.pulse.txt")
      
   ufpd=CompuCell.UniformInitializerParseData()
   region=ufpd.Region()
   region.BoxMin(CompuCell.Dim3D(20,20,0))
   region.BoxMax(CompuCell.Dim3D(30,30,1))
   region.Types("Amoeba")
   region.Width(5)


   CompuCellSetup.registerPotts(sim,ppd)
   CompuCellSetup.registerPlugin(sim,ctpd)
   CompuCellSetup.registerPlugin(sim,vpd)
   CompuCellSetup.registerPlugin(sim,spd)
   
   CompuCellSetup.registerSteppable(sim,ufpd)
   CompuCellSetup.registerSteppable(sim,bwpd)
   CompuCellSetup.registerSteppable(sim,fdspd)
   
import sys
from os import environ
import string
sys.path.append(environ["PYTHON_MODULE_PATH"])
   
import CompuCellSetup

sim,simthread = CompuCellSetup.getCoreSimulationObjects()

configureSimulation(sim)

CompuCellSetup.initializeSimulationObjects(sim,simthread)


from PySteppables import SteppableRegistry
steppableRegistry=SteppableRegistry()

CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)

