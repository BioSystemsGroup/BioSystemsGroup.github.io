#!/usr/bin/perl -w

use strict;

sub usage{
    print "./BlobInitializerWendy.pl -s<cube_size> -r<radius -in units of number of cells> -m<margin - units number of cells> -t<max_type_number> -o<pif filename> -g<gap size>"
    print "Example : ./BlobInitializerWendy.pl -s3 -r5 -m3 -ocellsort_wendy.pif\n";
}

my $i_max=0;
my $j_max=0;
my $k_max=0;

my $sq_size=3;

my $i=0;
my $j=0;
my $k=0;

my $x_0=0;
my $y_0=0;
my $z_0=0;
my $gap=0;
my $type_max=5;
my $radius=2;
my $margin=5;

my $blobDim;

my $filename="blob_wendy.pif";
my @typeName=qw(D1 D2 D3 D4 D5) ; #type name array

    foreach(@ARGV){
	    if(/^-s(.+)/){$sq_size=$1;}
	    if(/^-g(.+)/){$gap=$1;}
            if(/^-r(.+)/){$radius=$1;}
	    if(/^-m(.+)/){$margin=$1;}
	    if(/^-t(.+)/){$type_max=$1;}
	    if(/^-o(.+)/){$filename=$1;}
	    if(/^--help/)
	    {
		usage();
		exit(0);
	    }
	    
    }

open(FILE,">$filename");


$blobDim=2+2*$radius+2*$margin; #dimension in terms of units of cells

print "margin=$margin radius=$radius\n";
print "blobDim=$blobDim\n";


my $cell_counter=0;
my $cell_type=1;

my $x_min=0;
my $y_min=0;
my $z_min=0;

my $x_max=0;
my $y_max=0;
my $z_max=0;
my $x_cent;
my $y_cent;
my $z_cent;


$y_max = $y_0+($j_max-1+$gap)*$sq_size+$sq_size;
$z_max = $z_0+($k_max-1+$gap)*$sq_size+$sq_size;

$x_cent=int($blobDim/2);
$y_cent=int($blobDim/2);
$z_cent=int($blobDim/2);

my $current_type_index;


for($i=0 ; $i<$blobDim; ++$i){
    for($j=0 ; $j<$blobDim; ++$j){
	for($k=0 ; $k<$blobDim; ++$k){
	    $x_min=$x_0+$i*($sq_size+$gap);
	    $y_min=$y_0+$j*($sq_size+$gap);
	    $z_min=$z_0+$k*($sq_size+$gap);
	    $x_max=$x_min+$sq_size-1;
	    $y_max=$y_min+$sq_size-1;
	    $z_max=$z_min+$sq_size-1;

	    if( sqrt( (($i-$x_cent+0.5)*$sq_size)**2+(($j-$y_cent+0.5)*$sq_size)**2+(($k-$z_cent+0.5)*$sq_size)**2 ) < ($radius+1)*$sq_size ){
		$current_type_index=int(rand($type_max));
		#print "index=$current_type_index type=$typeName[$current_type_index]\n";
		print FILE "$cell_counter ".$typeName[$current_type_index]." $x_min $x_max $y_min $y_max $z_min $z_max \n";
		++$cell_counter;
	    }    
	    
	}
    }
}

print "x_dim=".($blobDim)*$sq_size." y_dim=".($blobDim)*$sq_size." z_dim=".($blobDim)*$sq_size."\n";
exit 0;

for($i=0 ; $i<$i_max; ++$i){
    for($j=0 ; $j<$j_max; ++$j){
	for($k=0 ; $k<$k_max; ++$k){
	    
	    $x_min=$x_0+$i*($sq_size+$gap);
	    $y_min=$y_0+$j*($sq_size+$gap);
	    $z_min=$z_0+$k*($sq_size+$gap);
	    $x_max=$x_min+$sq_size;
	    $y_max=$y_min+$sq_size;
	    $z_max=$z_min+$sq_size;
	    if( sqrt(($y_min+0.5*$sq_size-$y_cent)**2+($z_min+0.5*$sq_size-$z_cent)**2)<($radius+$sq_size)){
		print "i=$i j=$j k=$k\n";	    	
		
		print "dist=".sqrt(($y_min+0.5*$sq_size-$y_cent)**2+($z_min+0.5*$sq_size-$z_cent)**2)."\n";
		print "y_max=$y_max z_max=$z_max y_min=$y_min z_min=$z_min\n";
		#print FILE "$cell_counter ".eval(1+int(rand($type_max)))." $x_min $x_max $y_min $y_max $z_min $z_max \n";
		print FILE "$cell_counter ".$typeName[0]." $x_min $x_max $y_min $y_max $z_min $z_max \n";
		++$cell_counter;
	    }else{
		print FILE "$cell_counter ".$typeName[1]." $x_min $x_max $y_min $y_max $z_min $z_max \n";
		++$cell_counter;
	    }
#	    elsif((sqrt(($y_max-$y_cent)**2 + ($z_max-$z_cent)**2)>=$radius) && (sqrt(($y_min-$y_cent)**2+($z_min-$z_cent)**2)<$radius)){
#	    elsif((sqrt(($y_min+0.5*$sq_size-$y_cent)**2 + ($z_min+0.5*$sq_size-$z_cent)**2)>=$radius) ){
#		print FILE "$cell_counter ".$typeName[1]." $x_min $x_max $y_min $y_max $z_min $z_max \n";
#		++$cell_counter;
#	    }
	
	    
	}
    }
}
print "x_dim=".($x_max+1)." y_dim=".($y_max+1)." z_dim=".$z_max."\n";