/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/


#include <CompuCell3D/Automaton/Automaton.h>

#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Simulator.h>

using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <string>


using namespace std;

#define EXP_STL
#include "LengthConstraintLocalFlexEnergy.h"

double LengthConstraintLocalFlexEnergy::localEnergy(const Point3D &pt) {
  return 0;
}

LengthConstraintLocalFlexEnergy::LengthConstraintLocalFlexEnergy():lclfpdPtr(0){
   lengthConstraintLocalFlexPluginPtr=0;
   changeEnergyFcnPtr=0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
double LengthConstraintLocalFlexEnergy::changeEnergy(const Point3D &pt,
				  const CellG *newCell,
				  const CellG *oldCell) {

  /// E = lambda * (length - targetLength) ^ 2 
  return (this->*changeEnergyFcnPtr)(pt,newCell,oldCell);

}

double LengthConstraintLocalFlexEnergy::changeEnergy_xz(const Point3D &pt,
				  const CellG *newCell,
				  const CellG *oldCell) {

  /// E = lambda * (length - targetLength) ^ 2 
  
  double energy = 0;

  if (oldCell == newCell) return 0;
    
   //as in the original version 
  if (newCell){
    double lambdaLength=lcAccessorPtr->get(newCell->extraAttribPtr)->lambdaLength;
    double targetLength=lcAccessorPtr->get(newCell->extraAttribPtr)->targetLength;
	
    double xPtSum = newCell->xCM;
    double zPtSum = newCell->zCM;
    double xcm = (newCell->xCM / (float) newCell->volume);
    double zcm = (newCell->zCM / (float) newCell->volume);
    double zPtSumSQ = newCell->iXX - newCell->volume*zcm*zcm + 2*zcm*zPtSum;
    double xPtSumSQ = newCell->iZZ - newCell->volume*xcm*xcm + 2*xcm*xPtSum;
    double xzSum = (newCell->iXZ - xcm*zPtSum - zcm*xPtSum + newCell->volume*xcm*zcm) / -1.0; 
    double newXCM = (newCell->xCM + pt.x)/((float)newCell->volume + 1);
    double newZCM = (newCell->zCM + pt.z)/((float)newCell->volume + 1);
    xPtSum += pt.x;
    zPtSum += pt.z;
    xPtSumSQ += pt.x*pt.x;
    zPtSumSQ += pt.z*pt.z;
    xzSum += pt.x*pt.z;
    double newIxx = zPtSumSQ - 2*newZCM*zPtSum + (newCell->volume+1)*newZCM*newZCM;
    double newIzz = xPtSumSQ - 2*newXCM*xPtSum + (newCell->volume+1)*newXCM*newXCM;
    double newIxz = -xzSum + newXCM*zPtSum + newZCM*xPtSum - (newCell->volume+1)*newXCM*newZCM;
    double currLength = 4.0*sqrt(((float)((0.5*(newCell->iXX + newCell->iZZ)) + .5*sqrt((float)((newCell->iXX - newCell->iZZ)*(newCell->iXX - newCell->iZZ) + 4*(newCell->iXZ)*(newCell->iXZ)))))/(float)(newCell->volume));
    double currEnergy = lambdaLength * (currLength - targetLength)*(currLength - targetLength);
    double newLength = 4.0*sqrt(((float)((0.5*(newIxx + newIzz)) + .5*sqrt((float)((newIxx - newIzz)*(newIxx - newIzz) + 4*newIxz*newIxz))))/(float)(newCell->volume));
    double newEnergy = lambdaLength * (newLength - targetLength)*(newLength - targetLength);
    energy += newEnergy - currEnergy;
  }
  if (oldCell) {
    double lambdaLength=lcAccessorPtr->get(oldCell->extraAttribPtr)->lambdaLength;
    double targetLength=lcAccessorPtr->get(oldCell->extraAttribPtr)->targetLength;

    double xPtSum = oldCell->xCM;
    double zPtSum = oldCell->zCM;
    double xcm = (oldCell->xCM / (float) oldCell->volume);
    double zcm = (oldCell->zCM / (float) oldCell->volume);
    double zPtSumSQ = oldCell->iXX - oldCell->volume*zcm*zcm + 2*zcm*zPtSum;
    double xPtSumSQ = oldCell->iZZ - oldCell->volume*xcm*xcm + 2*xcm*xPtSum;
    double xzSum = (oldCell->iXZ - xcm*zPtSum - zcm*xPtSum + oldCell->volume*xcm*zcm) / -1.0; 
    double newXCM = (oldCell->xCM - pt.x)/((float)oldCell->volume - 1);
    double newZCM = (oldCell->zCM - pt.z)/((float)oldCell->volume - 1);
    xPtSum -= pt.x;
    zPtSum -= pt.z;
    xPtSumSQ -= pt.x*pt.x;
    zPtSumSQ -= pt.z*pt.z;
    xzSum -= pt.x*pt.z;
    double newIxx = zPtSumSQ - 2*newZCM*zPtSum + (oldCell->volume-1)*newZCM*newZCM;
    double newIzz = xPtSumSQ - 2*newXCM*xPtSum + (oldCell->volume-1)*newXCM*newXCM;
    double newIxz = -xzSum + newXCM*zPtSum + newZCM*xPtSum - (oldCell->volume-1)*newXCM*newZCM;
    
    double currLength = 4.0*sqrt(((float)((0.5*(oldCell->iXX + oldCell->iZZ)) + .5*sqrt((float)((oldCell->iXX - oldCell->iZZ)*(oldCell->iXX - oldCell->iZZ) + 4*(oldCell->iXZ)*(oldCell->iXZ)))))/(float)(oldCell->volume));
    double currEnergy = lambdaLength * (currLength - targetLength)*(currLength - targetLength);
    double newLength = 4.0*sqrt(((float)((0.5*(newIxx + newIzz)) + .5*sqrt((float)((newIxx - newIzz)*(newIxx - newIzz) + 4*newIxz*newIxz))))/(float)(oldCell->volume));
    double newEnergy = lambdaLength * (newLength - targetLength) * (newLength - targetLength);
    energy += newEnergy - currEnergy;
  }
  return energy;
}


double LengthConstraintLocalFlexEnergy::changeEnergy_xy(const Point3D &pt,
				  const CellG *newCell,
				  const CellG *oldCell) {

  /// E = lambda * (length - targetLength) ^ 2 
  
  double energy = 0;

  if (oldCell == newCell) return 0;
    
   //as in the original version 
  if (newCell){
    double lambdaLength=lcAccessorPtr->get(newCell->extraAttribPtr)->lambdaLength;
    double targetLength=lcAccessorPtr->get(newCell->extraAttribPtr)->targetLength;
	
    double xPtSum = newCell->xCM;
    double yPtSum = newCell->yCM;
    double xcm = (newCell->xCM / (float) newCell->volume);
    double ycm = (newCell->yCM / (float) newCell->volume);
    double yPtSumSQ = newCell->iXX - newCell->volume*ycm*ycm + 2*ycm*yPtSum;
    double xPtSumSQ = newCell->iYY - newCell->volume*xcm*xcm + 2*xcm*xPtSum;
    double xySum = (newCell->iXY - xcm*yPtSum - ycm*xPtSum + newCell->volume*xcm*ycm) / -1.0; 
    double newXCM = (newCell->xCM + pt.x)/((float)newCell->volume + 1);
    double newYCM = (newCell->yCM + pt.y)/((float)newCell->volume + 1);
    xPtSum += pt.x;
    yPtSum += pt.y;
    xPtSumSQ += pt.x*pt.x;
    yPtSumSQ += pt.y*pt.y;
    xySum += pt.x*pt.y;
    double newIxx = yPtSumSQ - 2*newYCM*yPtSum + (newCell->volume+1)*newYCM*newYCM;
    double newIyy = xPtSumSQ - 2*newXCM*xPtSum + (newCell->volume+1)*newXCM*newXCM;
    double newIxy = -xySum + newXCM*yPtSum + newYCM*xPtSum - (newCell->volume+1)*newXCM*newYCM;
    double currLength = 4.0*sqrt(((float)((0.5*(newCell->iXX + newCell->iYY)) + .5*sqrt((float)((newCell->iXX - newCell->iYY)*(newCell->iXX - newCell->iYY) + 4*(newCell->iXY)*(newCell->iXY)))))/(float)(newCell->volume));
    double currEnergy = lambdaLength * (currLength - targetLength)*(currLength - targetLength);
    double newLength = 4.0*sqrt(((float)((0.5*(newIxx + newIyy)) + .5*sqrt((float)((newIxx - newIyy)*(newIxx - newIyy) + 4*newIxy*newIxy))))/(float)(newCell->volume));
    double newEnergy = lambdaLength * (newLength - targetLength)*(newLength - targetLength);
    energy += newEnergy - currEnergy;
  }
  if (oldCell) {
    double lambdaLength=lcAccessorPtr->get(oldCell->extraAttribPtr)->lambdaLength;
    double targetLength=lcAccessorPtr->get(oldCell->extraAttribPtr)->targetLength;

    double xPtSum = oldCell->xCM;
    double yPtSum = oldCell->yCM;
    double xcm = (oldCell->xCM / (float) oldCell->volume);
    double ycm = (oldCell->yCM / (float) oldCell->volume);
    double yPtSumSQ = oldCell->iXX - oldCell->volume*ycm*ycm + 2*ycm*yPtSum;
    double xPtSumSQ = oldCell->iYY - oldCell->volume*xcm*xcm + 2*xcm*xPtSum;
    double xySum = (oldCell->iXY - xcm*yPtSum - ycm*xPtSum + oldCell->volume*xcm*ycm) / -1.0; 
    double newXCM = (oldCell->xCM - pt.x)/((float)oldCell->volume - 1);
    double newYCM = (oldCell->yCM - pt.y)/((float)oldCell->volume - 1);
    xPtSum -= pt.x;
    yPtSum -= pt.y;
    xPtSumSQ -= pt.x*pt.x;
    yPtSumSQ -= pt.y*pt.y;
    xySum -= pt.x*pt.y;
    double newIxx = yPtSumSQ - 2*newYCM*yPtSum + (oldCell->volume-1)*newYCM*newYCM;
    double newIyy = xPtSumSQ - 2*newXCM*xPtSum + (oldCell->volume-1)*newXCM*newXCM;
    double newIxy = -xySum + newXCM*yPtSum + newYCM*xPtSum - (oldCell->volume-1)*newXCM*newYCM;
    
    double currLength = 4.0*sqrt(((float)((0.5*(oldCell->iXX + oldCell->iYY)) + .5*sqrt((float)((oldCell->iXX - oldCell->iYY)*(oldCell->iXX - oldCell->iYY) + 4*(oldCell->iXY)*(oldCell->iXY)))))/(float)(oldCell->volume));
    double currEnergy = lambdaLength * (currLength - targetLength)*(currLength - targetLength);
    double newLength = 4.0*sqrt(((float)((0.5*(newIxx + newIyy)) + .5*sqrt((float)((newIxx - newIyy)*(newIxx - newIyy) + 4*newIxy*newIxy))))/(float)(oldCell->volume));
    double newEnergy = lambdaLength * (newLength - targetLength) * (newLength - targetLength);
    energy += newEnergy - currEnergy;
  }
  return energy;
}

double LengthConstraintLocalFlexEnergy::changeEnergy_yz(const Point3D &pt,
				  const CellG *newCell,
				  const CellG *oldCell) {

  /// E = lambda * (length - targetLength) ^ 2 
  
  double energy = 0;

  if (oldCell == newCell) return 0;
    
   //as in the original version 
  if (newCell){
    double lambdaLength=lcAccessorPtr->get(newCell->extraAttribPtr)->lambdaLength;
    double targetLength=lcAccessorPtr->get(newCell->extraAttribPtr)->targetLength;
	
    double yPtSum = newCell->yCM;
    double zPtSum = newCell->zCM;
    double ycm = (newCell->yCM / (float) newCell->volume);
    double zcm = (newCell->zCM / (float) newCell->volume);
    double zPtSumSQ = newCell->iYY - newCell->volume*zcm*zcm + 2*zcm*zPtSum;
    double yPtSumSQ = newCell->iZZ - newCell->volume*ycm*ycm + 2*ycm*yPtSum;
    double yzSum = (newCell->iYZ - ycm*zPtSum - zcm*yPtSum + newCell->volume*ycm*zcm) / -1.0; 
    double newYCM = (newCell->yCM + pt.y)/((float)newCell->volume + 1);
    double newZCM = (newCell->zCM + pt.z)/((float)newCell->volume + 1);
    yPtSum += pt.y;
    zPtSum += pt.z;
    yPtSumSQ += pt.y*pt.y;
    zPtSumSQ += pt.z*pt.z;
    yzSum += pt.y*pt.z;
    double newIyy = zPtSumSQ - 2*newZCM*zPtSum + (newCell->volume+1)*newZCM*newZCM;
    double newIzz = yPtSumSQ - 2*newYCM*yPtSum + (newCell->volume+1)*newYCM*newYCM;
    double newIyz = -yzSum + newYCM*zPtSum + newZCM*yPtSum - (newCell->volume+1)*newYCM*newZCM;
    double currLength = 4.0*sqrt(((float)((0.5*(newCell->iYY + newCell->iZZ)) + .5*sqrt((float)((newCell->iYY - newCell->iZZ)*(newCell->iYY - newCell->iZZ) + 4*(newCell->iYZ)*(newCell->iYZ)))))/(float)(newCell->volume));
    double currEnergy = lambdaLength * (currLength - targetLength)*(currLength - targetLength);
    double newLength = 4.0*sqrt(((float)((0.5*(newIyy + newIzz)) + .5*sqrt((float)((newIyy - newIzz)*(newIyy - newIzz) + 4*newIyz*newIyz))))/(float)(newCell->volume));
    double newEnergy = lambdaLength * (newLength - targetLength)*(newLength - targetLength);
    energy += newEnergy - currEnergy;
  }
  if (oldCell) {
    double lambdaLength=lcAccessorPtr->get(oldCell->extraAttribPtr)->lambdaLength;
    double targetLength=lcAccessorPtr->get(oldCell->extraAttribPtr)->targetLength;

    double yPtSum = oldCell->yCM;
    double zPtSum = oldCell->zCM;
    double ycm = (oldCell->yCM / (float) oldCell->volume);
    double zcm = (oldCell->zCM / (float) oldCell->volume);
    double zPtSumSQ = oldCell->iYY - oldCell->volume*zcm*zcm + 2*zcm*zPtSum;
    double yPtSumSQ = oldCell->iZZ - oldCell->volume*ycm*ycm + 2*ycm*yPtSum;
    double yzSum = (oldCell->iYZ - ycm*zPtSum - zcm*yPtSum + oldCell->volume*ycm*zcm) / -1.0; 
    double newYCM = (oldCell->yCM - pt.y)/((float)oldCell->volume - 1);
    double newZCM = (oldCell->zCM - pt.z)/((float)oldCell->volume - 1);
    yPtSum -= pt.y;
    zPtSum -= pt.z;
    yPtSumSQ -= pt.y*pt.y;
    zPtSumSQ -= pt.z*pt.z;
    yzSum -= pt.y*pt.z;
    double newIyy = zPtSumSQ - 2*newZCM*zPtSum + (oldCell->volume-1)*newZCM*newZCM;
    double newIzz = yPtSumSQ - 2*newYCM*yPtSum + (oldCell->volume-1)*newYCM*newYCM;
    double newIyz = -yzSum + newYCM*zPtSum + newZCM*yPtSum - (oldCell->volume-1)*newYCM*newZCM;
    

    double currLength = 4.0*sqrt(((float)((0.5*(oldCell->iYY + oldCell->iZZ)) + .5*sqrt((float)((oldCell->iYY - oldCell->iZZ)*(oldCell->iYY - oldCell->iZZ) + 4*(oldCell->iYZ)*(oldCell->iYZ)))))/(float)(oldCell->volume));
    double currEnergy = lambdaLength * (currLength - targetLength)*(currLength - targetLength);
    double newLength = 4.0*sqrt(((float)((0.5*(newIyy + newIzz)) + .5*sqrt((float)((newIyy - newIzz)*(newIyy - newIzz) + 4*newIyz*newIyz))))/(float)(oldCell->volume));
    double newEnergy = lambdaLength * (newLength - targetLength) * (newLength - targetLength);
    energy += newEnergy - currEnergy;
  }
  return energy;
}


void LengthConstraintLocalFlexEnergy::init(Simulator * simulator){
   Potts3D *potts=simulator->getPotts();
   Dim3D fieldDim=potts->getCellFieldG()->getDim();
   if(fieldDim.x==1){
      changeEnergyFcnPtr=&LengthConstraintLocalFlexEnergy::changeEnergy_yz;
      lengthConstraintLocalFlexPluginPtr->field3DChangeFcnPtr=&LengthConstraintLocalFlexPlugin::field3DChange_yz;
   }else if(fieldDim.y==1){
      changeEnergyFcnPtr=&LengthConstraintLocalFlexEnergy::changeEnergy_xz;
      lengthConstraintLocalFlexPluginPtr->field3DChangeFcnPtr=&LengthConstraintLocalFlexPlugin::field3DChange_xz;

   }else if (fieldDim.z==1){
      changeEnergyFcnPtr=&LengthConstraintLocalFlexEnergy::changeEnergy_xy;
      lengthConstraintLocalFlexPluginPtr->field3DChangeFcnPtr=&LengthConstraintLocalFlexPlugin::field3DChange_xy;

   }else{
      ASSERT_OR_THROW("Currently LengthConstraint plugin can only be used in 2D",0);
   }
   
}

void LengthConstraintLocalFlexEnergy::readXML(XMLPullParser &in) {
  in.skip(TEXT);
}

void LengthConstraintLocalFlexEnergy::writeXML(XMLSerializer &out) {
}


std::string LengthConstraintLocalFlexEnergy::toString(){
   return string("LengthConstraintLocalFlex");
}

