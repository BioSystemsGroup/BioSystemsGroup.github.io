/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR1 PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef LENGTHCONSTRAINTLOCALFLEXENERGY_H
#define LENGTHCONSTRAINTLOCALFLEXENERGY_H

#include <CompuCell3D/Potts3D/EnergyFunction.h>

#include <BasicUtils/BasicClassAccessor.h>
#include <BasicUtils/BasicClassGroup.h> //had to include it to avoid problems with template instantiation
#include "LengthConstraintLocalFlexPlugin.h"

#include <XMLCereal/XMLSerializable.h>
#include <CompuCell3D/Potts3D/Cell.h>
#include <vector>
#include "LengthConstraintLocalFlexParseData.h"
//#include <string>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {
   class Simulator;
   class LengthConstraintLocalFlexPlugin;
  /** 
   * Calculates length energy based on a target length and
   * lambda length.
   */
   
  class DECLSPECIFIER LengthConstraintLocalFlexEnergy: public EnergyFunction, public virtual XMLSerializable {
       
	BasicClassAccessor<LengthConstraintLocalFlexData> *lcAccessorPtr;
  public:
    typedef double (LengthConstraintLocalFlexEnergy::*changeEnergyFcnPtr_t)(const Point3D &pt, const CellG *newCell,
                               const CellG *oldCell);

    LengthConstraintLocalFlexParseData lclfpd;
    LengthConstraintLocalFlexParseData * lclfpdPtr;
    LengthConstraintLocalFlexPlugin *lengthConstraintLocalFlexPluginPtr;
    LengthConstraintLocalFlexEnergy();

   
    void setLengthConstraintLocalFlexPluginPtr(LengthConstraintLocalFlexPlugin *_lengthConstraintLocalFlexPluginPtr)
    {lengthConstraintLocalFlexPluginPtr=_lengthConstraintLocalFlexPluginPtr;}

    virtual double localEnergy(const Point3D &pt);
    virtual double changeEnergy(const Point3D &pt, const CellG *newCell,
				const CellG *oldCell);

    virtual double changeEnergy_xy(const Point3D &pt, const CellG *newCell,
				const CellG *oldCell);

    virtual double changeEnergy_xz(const Point3D &pt, const CellG *newCell,
				const CellG *oldCell);

    virtual double changeEnergy_yz(const Point3D &pt, const CellG *newCell,
				const CellG *oldCell);

   changeEnergyFcnPtr_t changeEnergyFcnPtr;

   void  setLengthConstraintLocalFlexDataAccessorPtr(BasicClassAccessor<LengthConstraintLocalFlexData> * _lcAccessorPtr){lcAccessorPtr=_lcAccessorPtr;}
    void init(Simulator * simulator);
    void update(ParseData * _pd){}
   // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    virtual std::string toString();
    
    // End XMLSerializable interface
    
  };
};
#endif
