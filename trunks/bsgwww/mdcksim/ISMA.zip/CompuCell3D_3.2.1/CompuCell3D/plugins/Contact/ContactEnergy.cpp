/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/Potts3D/Cell.h>
#include <CompuCell3D/Automaton/Automaton.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <CompuCell3D/Potts3D/Cell.h>

#include <algorithm>



#include <string>
using namespace std;

#define EXP_STL
#include "ContactEnergy.h"

std::string ContactEnergy::toString(){
  return cpd.ModuleName();
}


std::string ContactEnergy::steerableName(){
    cerr<<"This is steerable "<<cpd.ModuleName()<<endl;
    return cpd.ModuleName();
}

ContactEnergy::ContactEnergy() :depth(1.1),weightDistance(false), cpdPtr(0)
{}


ContactEnergy::~ContactEnergy(){}


void ContactEnergy::setPotts(Potts3D *_potts){potts=_potts;}	


double ContactEnergy::localEnergy(const Point3D &pt) {
  return 0;
}

double ContactEnergy::changeEnergy(const Point3D &pt,
                                  const CellG *newCell,
                                  const CellG *oldCell) {
   //cerr<<"ChangeEnergy"<<endl;
   
   
  double energy = 0;
  unsigned int token = 0;
  double distance = 0;
  Point3D n;
  
  CellG *nCell=0;
  WatchableField3D<CellG *> *fieldG =(WatchableField3D<CellG *> *) potts->getCellFieldG();
  Neighbor neighbor;

   

   if(weightDistance){
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         nCell = fieldG->get(neighbor.pt);
         if(nCell!=oldCell){
            energy -= contactEnergy(oldCell, nCell) / neighbor.distance;
         }
         if(nCell!=newCell){
            energy += contactEnergy(newCell, nCell) / neighbor.distance;
         }
   
   
      }
   }else{
//       cerr<<"maxNeighborIndex="<<maxNeighborIndex<<endl;
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         
         nCell = fieldG->get(neighbor.pt);
         if(nCell!=oldCell){
            energy -= contactEnergy(oldCell, nCell);
/*            if(pt.x==25 && pt.y==74 && pt.z==0)
            cerr<<"!=oldCell neighbor.pt="<<neighbor.pt<<" contactEnergy(oldCell, nCell)="<<contactEnergy(oldCell, nCell)<<endl;*/
         }
         if(nCell!=newCell){
            energy += contactEnergy(newCell, nCell);
//             if(pt.x==25 && pt.y==74 && pt.z==0)
//             cerr<<"!=newCell neighbor.pt="<<neighbor.pt<<" contactEnergy(oldCell, nCell)="<<contactEnergy(newCell, nCell)<<endl;

//             cerr<<"!=newCell neighbor.pt="<<neighbor.pt<<" energyTmp="<<energy<<endl;
         }
   
   
      }
   
   
   }


   
//   cout<<"pt="<<pt<<" energy="<<energy<<endl;
  return energy;
}

double ContactEnergy::contactEnergy(const CellG *cell1, const CellG *cell2) {
   
   return contactEnergyArray[cell1 ? cell1->type : 0][cell2? cell2->type : 0];


}

void ContactEnergy::update(ParseData *_pd, bool _fullInitFlag){
   initializeContactEnergy(_pd);
}



void ContactEnergy::initializeContactEnergy(ParseData *_pd){
   cpdPtr=(ContactParseData*)_pd;

   automaton = potts->getAutomaton();
   ASSERT_OR_THROW("CELL TYPE PLUGIN WAS NOT PROPERLY INITIALIZED YET. MAKE SURE THIS IS THE FIRST PLUGIN THAT YOU SET", automaton)
   set<unsigned char> cellTypesSet;
   contactEnergies.clear();

   cerr<<"automaton="<<automaton<<endl;
   cerr<<"cpdPtr->contactEnergyTuppleVec.size()="<<cpdPtr->contactEnergyTuppleVec.size()<<endl;


   for ( int i=0 ; i < cpdPtr->contactEnergyTuppleVec.size() ; ++ i){
     
      setContactEnergy(cpdPtr->contactEnergyTuppleVec[i].type1Name, cpdPtr->contactEnergyTuppleVec[i].type2Name, cpdPtr->contactEnergyTuppleVec[i].energy);

      //inserting all the types to the set (duplicate are automatically eleminated) to figure out max value of type Id
      cellTypesSet.insert(automaton->getTypeId(cpdPtr->contactEnergyTuppleVec[i].type1Name));
      cellTypesSet.insert(automaton->getTypeId(cpdPtr->contactEnergyTuppleVec[i].type2Name));
   }

  //Now that we know all the types used in the simulation we will find size of the contactEnergyArray
  vector<unsigned char> cellTypesVector(cellTypesSet.begin(),cellTypesSet.end());//coping set to the vector

  int size= * max_element(cellTypesVector.begin(),cellTypesVector.end());
  size+=1;//if max element is e.g. 5 then size has to be 6 for an array to be properly allocated
  
  int index ;
  contactEnergyArray.clear();
  contactEnergyArray.assign(size,vector<double>(size,0.0));

  for(int i = 0 ; i < size ; ++i)
   for(int j = 0 ; j < size ; ++j){
   
      index = getIndex(cellTypesVector[i],cellTypesVector[j]);
      
      contactEnergyArray[i][j] = contactEnergies[index];
      
   }
   cerr<<"size="<<size<<endl;
   
  for(int i = 0 ; i < size ; ++i)
   for(int j = 0 ; j < size ; ++j){
   
      cerr<<"contact["<<i<<"]["<<j<<"]="<<contactEnergyArray[i][j]<<endl;
      
   }
   
   //Here I initialize max neighbor index for direct acces to the list of neighbors 
   boundaryStrategy=BoundaryStrategy::getInstance();
   maxNeighborIndex=0;

   if(cpdPtr->depthFlag){
      maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromDepth(cpdPtr->depth);
//       cerr<<"got here will do depth"<<endl;
   }else{
//       cerr<<"got here will do neighbor order"<<endl;
      maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(cpdPtr->neighborOrder);
   }
   
//    exit(0);
}


void ContactEnergy::setContactEnergy(const string typeName1,
				     const string typeName2,
				     const double energy) {
                    
  char type1 = automaton->getTypeId(typeName1);
  char type2 = automaton->getTypeId(typeName2);
    
  int index = getIndex(type1, type2);

  contactEnergies_t::iterator it = contactEnergies.find(index);
  ASSERT_OR_THROW(string("Contact energy for ") + typeName1 + " " + typeName2 +
		  " already set!", it == contactEnergies.end());

  contactEnergies[index] = energy;
}

int ContactEnergy::getIndex(const int type1, const int type2) const {
  if (type1 < type2) return ((type1 + 1) | ((type2 + 1) << 16));
  else return ((type2 + 1) | ((type1 + 1) << 16));
}


void ContactEnergy::readXML(XMLPullParser &in) 
{
	cpd.contactEnergyTuppleVec.clear(); // Empty "contactEnergyTuppleVec" vector
	in.skip(TEXT);

	while (in.check(START_ELEMENT)) 
	{
		if (in.getName() == "Energy") 
		{
			string type1 = in.getAttribute("Type1").value;
			string type2 = in.getAttribute("Type2").value;

			double energy = BasicString::parseDouble(in.matchSimple());

			ContactEnergyTupple tupple(type1,type2,energy);
			cpd.contactEnergyTuppleVec.push_back(tupple);
		} 
		else if (in.getName() == "Depth") 
		{
			cpd.Depth(BasicString::parseDouble(in.matchSimple()));
		}
		else if (in.getName() == "NeighborOrder") 
		{
			cpd.NeighborOrder( BasicString::parseUInteger(in.matchSimple()));
		}
		else if (in.getName() == "Weight") 
		{
			cpd.weightDistance=true;
			in.matchSimple();
		}
		else 
		{
			throw BasicException(string("Unexpected element '") + in.getName() + "'!", in.getLocation());
		}

		in.skip(TEXT);
	}
}

void ContactEnergy::writeXML(XMLSerializer &out) {
}

