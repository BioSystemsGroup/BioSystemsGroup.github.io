#ifndef MDCKPARSEDATA_H
#define MDCKPARSEDATA_H

/*

This file is copyright Jesse Engelberg 2010 according to the GNU GPL.

 */

#include <CompuCell3D/ParseData.h>
#include <CompuCell3D/dllDeclarationSpecifier.h>
namespace CompuCell3D {

   class DECLSPECIFIER MdckParseData:public ParseData{
      public:
      MdckParseData():ParseData("Mdck"),checkFreq(0),checkSanity(false),polarDelay(20),shiftDelay(20),lgrSubtract(30),doublingVol(30), shiftTargetVolume(20), cellCycle(20), spindleRandom(100), divisionReg(0), targetVolume(40),lambdaVolume(2.0),shiftedCycleDelay(.82),lambdaSurface(2.0), multiplier(1.0), randomSeed(0), dyingShrinkRate(0)
      {}
      unsigned int checkFreq;
      int polarDelay;
      int shiftDelay;
      int lgrSubtract;
      int doublingVol;
      double shiftTargetVolume;
      double lumenGrowthRate;
      int cellCycle;
      bool checkSanity;
      int spindleRandom;
      int divisionReg;
      int targetVolume;
      double lambdaVolume;
      double shiftedCycleDelay;
      double lambdaSurface;
      double multiplier;
      int randomSeed;
      double deathRateLumen;
      double deathRateEpi;
      double dyingShrinkRate;
      double clusterProb;
      double shiftRatio;
      void CheckLatticeSanityFrequency(unsigned int _checkFreq){
         checkFreq=_checkFreq;
         checkSanity=true;
      }
      void PolarDelay(int _polarDelay) {polarDelay = _polarDelay; }
      void ShiftDelay(int _shiftDelay) {shiftDelay = _shiftDelay; }
      void LgrSubtract(int _lgrSubtract) {lgrSubtract = _lgrSubtract; }
      void DoublingVol(int _doublingVol) { doublingVol = _doublingVol; }
      void ShiftTargetVolume(double _shiftTargetVolume) { shiftTargetVolume = _shiftTargetVolume; }
      void LumenGrowthRate(double _lumenGrowthRate) { lumenGrowthRate = _lumenGrowthRate; }
      void CellCycle(int _cellCycle) { cellCycle = _cellCycle; }
      void TargetVolume(int _targetVolume) { targetVolume = _targetVolume; }
      void LambdaVolume(double _lambdaVolume) { lambdaVolume = _lambdaVolume; }
      void ShiftedCycleDelay(double _shiftedCycleDelay) { shiftedCycleDelay = _shiftedCycleDelay; }
      void LambdaSurface(double _lambdaSurface) { lambdaSurface = _lambdaSurface; }
      void SpindleRandom(int _spindleRandom) { spindleRandom = _spindleRandom; }
      void DivisionReg(int _divisionReg) { divisionReg = _divisionReg; }
      void Multiplier(double _multiplier) { multiplier = _multiplier; }
      void RandomSeed(int _randomSeed) { randomSeed = _randomSeed; }
      void DeathRateLumen(double _deathRateLumen) { deathRateLumen = _deathRateLumen; }
      void DeathRateEpi(double _deathRateEpi) { deathRateEpi = _deathRateEpi; }
      void DyingShrinkRate(double _dyingShrinkRate) { dyingShrinkRate = _dyingShrinkRate; }
      void ClusterProb(double _clusterProb) { clusterProb = _clusterProb; }
      void ShiftRatio(double _shiftRatio) { shiftRatio = _shiftRatio; }
      

   };
};
#endif
