#ifndef STOCK_H
#define STOCK_H

/***********************************************************************
 stock.h - Declares the stock SSQLS used by several of the examples.

 * Modifications copyright Jesse Engelberg, 2010 under the GSL.

 Copyright (c) 1998 by Kevin Atkinson, (c) 1999-2001 by MySQL AB, and
 (c) 2004-2008 by Educational Technology Resources, Inc.  Others may
 also hold copyrights on code in this file.  See the CREDITS.txt file
 in the top directory of the distribution for details.

 This file is part of MySQL++.

 MySQL++ is free software; you can redistribute it and/or modify it
 under the terms of the GNU Lesser General Public License as published
 by the Free Software Foundation; either version 2.1 of the License, or
 (at your option) any later version.

 MySQL++ is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with MySQL++; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301
 USA
***********************************************************************/

#include <mysql++.h>
#include <ssqls.h>

// The following is calling a very complex macro which will create
// "struct stock", which has the member variables:
//
//   sql_char item;
//   ...
//   Null<sql_mediumtext> description;
//
// plus methods to help populate the class from a MySQL row.  See the
// SSQLS sections in the user manual for further details.
sql_create_9(pottsParameters,
	1, 9, // The meaning of these values is covered in the user manual
	mysqlpp::sql_int, simnumber,
	mysqlpp::sql_varchar, foldername,
	mysqlpp::sql_int, dimx,
	mysqlpp::sql_int, dimy,
	mysqlpp::sql_int, anneal,
	mysqlpp::sql_int, steps,
	mysqlpp::sql_double, temperature,
	mysqlpp::sql_double, flip2dimratio,
	mysqlpp::sql_int, neighbororder
	)

sql_create_18(contactParameters,
    1,18,
	mysqlpp::sql_int, simnumber,
	mysqlpp::sql_varchar, foldername,
	mysqlpp::sql_double, stablecell_stablecell,
	mysqlpp::sql_double, stablecell_cell,
	mysqlpp::sql_double, stablecell_lumen,		
	mysqlpp::sql_double, stablecell_matrix,
	mysqlpp::sql_double, stablecell_shiftedcell,
	mysqlpp::sql_double, cell_cell,
	mysqlpp::sql_double, cell_lumen,
	mysqlpp::sql_double, cell_matrix,
	mysqlpp::sql_double, cell_shiftedcell,	
	mysqlpp::sql_double, lumen_lumen,
	mysqlpp::sql_double, lumen_matrix,
	mysqlpp::sql_double, lumen_shiftedcell,	
	mysqlpp::sql_double, matrix_matrix,
	mysqlpp::sql_double, matrix_shiftedcell,
	mysqlpp::sql_double, shiftedcell_shiftedcell,
	mysqlpp::sql_int, contactneighbororder
	)

sql_create_22(mdckParameters,
    1,22,
	mysqlpp::sql_int, simnumber,
	mysqlpp::sql_varchar, foldername,
	mysqlpp::sql_int, targetvolume,
	mysqlpp::sql_int, lambdavolume,
	mysqlpp::sql_double, shifttargetvolume,
	mysqlpp::sql_int, cellcycle,
	mysqlpp::sql_double, shiftedcycledelay,
	mysqlpp::sql_double, lambdasurface,
	mysqlpp::sql_int, polarizationdelay,
	mysqlpp::sql_int, shiftdelay,
	mysqlpp::sql_int, lgrsubtract,
	mysqlpp::sql_int, doublingvolume,
	mysqlpp::sql_int, spindlerandomess,
	mysqlpp::sql_int, divisionreg,
	mysqlpp::sql_double, multiplier,
	mysqlpp::sql_double, lumengrowthrate,
	mysqlpp::sql_int, randomseed,
	mysqlpp::sql_double, deathratelumen,
	mysqlpp::sql_double, deathrateepi,
	mysqlpp::sql_double, dyingshrinkrate,
	mysqlpp::sql_double, clusterprob,
	mysqlpp::sql_double, shiftratio
	)

sql_create_20(countData,
    1,20,
  	mysqlpp::sql_int, simnumber,
	mysqlpp::sql_varchar, foldername,
    mysqlpp::sql_int, simulationcycle,
    mysqlpp::sql_int, cellnumber,
    mysqlpp::sql_int, stablecellnumber,
    mysqlpp::sql_int, lumennumber,
    mysqlpp::sql_int, totalnumber,
    mysqlpp::sql_int, shiftedcellnumber,
    mysqlpp::sql_int, livingcellnumber,
    mysqlpp::sql_int, separatedlumen,
    mysqlpp::sql_int, dyingcellnumber,
    mysqlpp::sql_int, dyingepicellnumber,
    mysqlpp::sql_int, dyinglumencellnumber,
    mysqlpp::sql_int, deadcellnumber,
    mysqlpp::sql_int, deadepicellnumber,
    mysqlpp::sql_int, deadlumencellnumber,
    mysqlpp::sql_int, newcellnumber,
    mysqlpp::sql_int, totalnewcellnumber,
    mysqlpp::sql_int, newlumennumber,
    mysqlpp::sql_int, totalnewlumennumber
    )
    

sql_create_16(measureData,
    1,16,
  	mysqlpp::sql_int, simnumber,
	mysqlpp::sql_varchar, foldername,
    mysqlpp::sql_int, simulationcycle,
    mysqlpp::sql_int, totalvolume,
    mysqlpp::sql_int, totalsurfacearea,
    mysqlpp::sql_int, totalcellvolume,
    mysqlpp::sql_int, totalcellsurface,
    mysqlpp::sql_int, cystoutersurface,
    mysqlpp::sql_int, cystinnersurface,
    mysqlpp::sql_double, meancellvolume,
    mysqlpp::sql_double, meancellsurface,
    mysqlpp::sql_int, totallumenvolume,
    mysqlpp::sql_int, totallumensurface,
    mysqlpp::sql_double, meanlumenvolume,
    mysqlpp::sql_double, meandivisionangle,
    mysqlpp::sql_double, cumulativemeandivisionangle
    )
    
sql_create_16(contactData,
    1,16,
  	mysqlpp::sql_int, simnumber,
	mysqlpp::sql_varchar, foldername,
    mysqlpp::sql_int, simulationcycle,
    mysqlpp::sql_int, newlumentwocells,
    mysqlpp::sql_int, newlumenthreecells,
    mysqlpp::sql_int, newlumenfourcells,
    mysqlpp::sql_int, newlumenfivepluscells,
    mysqlpp::sql_int, lumencreatedmulticell,
    mysqlpp::sql_int, cellscontactcell,
    mysqlpp::sql_int, cellscontactmatrix,
    mysqlpp::sql_int, cellscontactlumen,
    mysqlpp::sql_int, lumenscontactmatrix,
    mysqlpp::sql_int, cellscontactmultiplelumens,
    mysqlpp::sql_int, cellscontactonlymatrix,
    mysqlpp::sql_int, cellscontactonlycells,
    mysqlpp::sql_int, cellscontactonlylumen
    )

#endif
