/*************************************************************************
 * Copyright Jesse Engelberg, 2010 under the GPL.
 *                             
 *                                                                       *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************

 */

#ifndef PI
#define PI           3.14159265358979323846
#endif

#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/PottsParseData.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/plugins/Volume/VolumePlugin.h>
#include <CompuCell3D/plugins/Volume/VolumeEnergy.h>
#include <CompuCell3D/plugins/Contact/ContactPlugin.h>
#include <CompuCell3D/plugins/Contact/ContactEnergy.h>
#include <CompuCell3D/plugins/Contact/ContactParseData.h>
#include <CompuCell3D/Potts3D/CellInventory.h>
#include <CompuCell3D/Potts3D/EnergyFunctionCalculator.h>
#include <CompuCell3D/Potts3D/AcceptanceFunction.h>
#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>
#include <CompuCell3D/Boundary/BoundaryStrategy.h>
#include <BasicUtils/BasicRandomNumberGenerator.h>

using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <iostream>
#include <cmath>
#include <algorithm>

using namespace std;

#include "MdckPlugin.h"
#include "DBManager.h"

// Initialize legacy counter variables
int MCell::staticPCounter = COUNTER_NULL;
int MCell::originalShift = 0;
int MCell::originalPCounter = 0;

// Create the MdckPlugin
MdckPlugin::MdckPlugin() :
   cellFieldG(0),
   periodicX(false),
   periodicY(false),
   periodicZ(false),
   simCycle(0),
   maxNeighborIndex(0),
   boundaryStrategy(0),
   paramsWritten(false)
   
{
   
}

MdckPlugin::~MdckPlugin() {
}

void MdckPlugin::init(Simulator *_simulator,ParseData * _pd) {

    // test code
    testVar = 80;
    
    //cerr << "testVar is " << testVar << endl;
    

    // initialize parse data
  pd=_pd;
  if(_pd){
      ntpdPtr=(MdckParseData *)pd;
  }else{
     ntpdPtr=&ntpd;
  }
  
  // initialize random number generator
  randGen = BasicRandomNumberGenerator::getInstance();
  cerr << "seed is " << randGen->getSeed() << endl;

  int rSeed = ntpdPtr->randomSeed;
  if (rSeed > 0) {
      randGen->setSeed(rSeed);
      cerr << "setting random seed to " << rSeed << endl;
  }
  else {
      randGen->Randomize();
      cerr << "randomizing seed" << endl;
  }
  cerr << "seed is " << randGen->getSeed() << endl;
 
  cout<<"INITIALIZING MDCK PLUGIN"<<endl;
  simulator=_simulator;
  simCycle = simulator->getStep();
  potts = simulator->getPotts();
  cellFieldG = (WatchableField3D<CellG *> *)potts->getCellFieldG();
 
  ///getting cell inventory
  cellInventoryPtr=& potts->getCellInventory(); 

  // cellMap maps cells to their equivalent MCells
  cellMap = new CellMap();
  createdCellMap = true;

  ///will register Mdck here  
  BasicClassAccessorBase * cellBTAPtr=&mdckAccessor;
  potts->getCellFactoryGroupPtr()->registerClass(cellBTAPtr);
  potts->registerCellGChangeWatcher(this);
  
  fieldDim=cellFieldG->getDim();
  
  // Set up boundaries around the field
  adjNeighbor = AdjacentNeighbor(fieldDim);
  if(potts->getBoundaryXName()=="Periodic"){ 
      adjNeighbor.setPeriodicX();
      periodicX=true;
  }
  if(potts->getBoundaryYName()=="Periodic"){
      adjNeighbor.setPeriodicY();
      periodicY=true;
  }
  if(potts->getBoundaryZName()=="Periodic"){
      adjNeighbor.setPeriodicZ();
      periodicZ=true;
  }
  
  // set up boundary strategy and check the lattice (hex in this case) type
  boundaryStrategy=BoundaryStrategy::getInstance();
  maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(1);//1st nearest neighbor
  cout << "the lattice type of the boundary strategy in mdck is " << boundaryStrategy->getLatticeType() << endl;

  // load the neighbor tracker plugin
  bool pluginAlreadyRegisteredFlag;
  NeighborTrackerPlugin * nTrackerPlug =(NeighborTrackerPlugin *) Simulator::pluginManager.get("NeighborTracker",&pluginAlreadyRegisteredFlag); 
  //this will load NeighborTracker plugin if it si not already loaded 
  if(!pluginAlreadyRegisteredFlag)
      nTrackerPlug->init(simulator,0);
  neighborTrackerAccessorPtr = nTrackerPlug->getNeighborTrackerAccessorPtr();
  
  pluginAlreadyRegisteredFlag = false;
  
  // record the original values so that MCells can access them without referencing ntpdPtr
  MCell::originalShift = ntpdPtr->shiftDelay;
  MCell::originalPCounter = ntpdPtr->polarDelay;
    
  
}

/*
 * This method is the central MDCK method.  It will execute all cell actions that are stepped through.
 * It is called by the stepper located within the CC3D class.
 */
bool MdckPlugin::executeActions() {

    /* **** IMPORTANT ****
     * The order of events is as follows:
     * 1. MdckPlugin::executeActions()
     * 2. Update CPM, including volume change and cell death
     * 3. Take image
     * 4. Increment cell cycle
     *
     * That means that in order to get accurate cell counts and volume measurements
     * we need to count cells and measure volume and the beginning of the execute step
     * and then enter that data into the results for the _previous_ time step.
     *
     * Then we can record all events that take place during the current time step as happening
     * during the current time step and we'll have an accurate count.
     */

    simCycle = simulator->getStep();
    dataManager->simCycle = simCycle;
    if (simCycle == 0) {
        return 0;
    }

    // Initialize the databases
    if (! paramsWritten) {
        initPottsParamsDB();
        initContactParamsDB();
        initMdckParamsDB();
        
        cerr << "about to write params" << endl;
        dbManager->writeParams();
   
        cerr << "wrote params" << endl;
        paramsWritten = true;
    }
    
    
    
    cerr  << " in execute actions. simCycle is " << simCycle << endl;
    cerr << " and dataManager->simCycle is " << dataManager->simCycle  << endl;

    // decrement the static pCounter.  This is legacy code.
    if (MCell::staticPCounter > 0)
        MCell::staticPCounter--;
    
    // the first thing we need to do is get the list of cells
    CellInventory::cellInventoryIterator cInvItr;
    CellG * cell;
    
    // first, get the dimensions of the cell field.
    Dim3D dim = cellFieldG->getDim();
    
    // xmax and ymax are one larger than the dimensions of the field, which include 0.
    int xmax = dim.x;
    int ymax = dim.y;
    
    // record the extents of the cyst to figure out how big it is
    int smallestX = xmax/2;
    int smallestY = ymax/2;
    int largestX = smallestX;
    int largestY = smallestY;
    
    cerr << " the max x is " << xmax << " and the max y is " << ymax << endl;
    
    int outerSurfaceData = 0;

    // Cells have no way to record which points are indexed within them, so we created MCells, which
    // contain a list of points.  However, they're not automatically updated, so at the beginning
    // of the cell execution step we go through the cell field and assign all points to the MCell
    // which holds them.  The MCell holds a dirty bit that allows the program to check if it's been
    // updated yet this turn.  This prevents us from having to clear the MCell each time.

    //A couple of additional steps are done as well.
    // They include engulfing isolated points and calculating the outer surface of the cyst.

    for (int curx=0;curx<xmax;curx++) {
        for (int cury=0;cury<ymax;cury++) {
            Point3D curPoint = Point3D(curx,cury,0);
            CellG* curCell = cellFieldG->get(curPoint);
            
            //            cerr << "Point " << curx << ", " << cury << " is inside a ";
            if (curCell) {
                //cerr << "Point " << curx << ", " << cury << " is inside a ";
                //cerr << "valid cell" << endl;   
                
                if (curx < smallestX)
                    smallestX = curx;
                else if (curx > largestX)
                    largestX = curx;
                if (cury < smallestY)
                    smallestY = cury;
                else if (cury > largestY)
                    largestY = cury;
                
                //check if this cell has been detected before:
                MCell* curMCell = cellMap->get(curCell);
                
                // create a vector to hold the neighboring points.
                std::vector<Point3D> n;
                n.assign(6,Point3D(0,0,0));
                                
                for(int i=0 ; i < 6; i++ ){
                    int* offsetsIndex = getOffsetsIndex(curPoint);
                    Neighbor neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(curPoint),offsetsIndex[i]);
                    if(!neighbor.distance){
                        //if distance is 0 then the neighbor returned is invalid
                        continue;
                    } 
                    n[i]=neighbor.pt;
                    //cerr << "setting n[" << i << "] to " << n[i] << endl;
                }
                // Count the number of points touching ECM: the border of the cyst.  This is recorded as outerSurfaceData.
                //cerr << "Checking if this cell touches the matrix." << endl;
                    int touchesMatrix = false;
                    
                    if (curCell->type != 2) {
                        
                        for (unsigned int i=0;i<6;i++) {
                            CellG* curNCell = cellFieldG->get(n[i]);
                            if (!curNCell) {
                                touchesMatrix = true;
                                //cerr << "The current point borders the ECM at point " << n[i] << endl;
                                outerSurfaceData++;
                            }                                         
                        }
                    }
            
                    // If this point is in an MCell, check if this is the first time a point has been added this turn.
                if (curMCell) {
                    //cerr << " MCell exists, id is " << curCell->id << " and pCounter is " << curMCell->pCounter << endl;

                    // has this MCell been updated this turn?
                    int curTCounter = curMCell->turnCounter;
                    //cerr << "current MCell turn counter is " << curTCounter << " and current turn is " << simCycle << endl;
                    //cerr << "current simulator step is " << simulator->getStep() << endl;
                    if (curTCounter < simCycle) {
                        //cerr << " resetting points" << endl;
                        curMCell->clearPoints();
                        // set the turnCounter on this MCell to the same, so it won't be cleared again
                        curMCell->turnCounter = simCycle;
                    }
                    // add this point to the mCell list
                    curMCell->addPoint(curPoint);


                    //
                    // If this point is completely surrounded by another cell, engulf it
                    //
                    bool isolated = true;
                    CellG* cellToBecome = NULL;
                                        
                    // if a lumen is completely surrounded by another cell, that cell engulfs it
                    // if a cell point is isolated, it randomly becomes part of another cell
                    
                    // if a location has a lumen neighbor that touches a non-lumen neighbor, the non-lumen
                    // neighbor is stored as the cell that will engulf this location.
                    
                    
                    
                    
                    // first do this for the lumen.
                    // only engulf a lumen point if it's surrounded by a single cell
                    if (curCell->type == 2) {
                        //cerr << "Checking isolation for point " << curPoint << " in lumen cell " << curCell->id << endl;
                        // only iterate through five neighbors because we're checking the next one too.                                                
                        for (unsigned int i=0;i<6;i++) {
                            CellG* curNCell = cellFieldG->get(n[i]);
                            CellG* nextNCell = cellFieldG->get(n[i+1]);
                            
                            // if both neighbors are valid and are equal and not equal to the current cell
                            if (curNCell && nextNCell && curNCell == nextNCell && curNCell != curCell) {
                                //cerr << "Cell could become " << curNCell->id << endl;
                                cellToBecome = curNCell;
                                isolated = true;
                            }
                            else {
                                //cerr << "But some neighbors are not identical, so it won't" << endl;
                                isolated = false;
                                break;
                            }                                
                        }
                    }
                    else {
                        // Now we check what happens if this point is a stable or unstable cell
                        
                        // for unstable cells, if any neighboring cells are equal to you, you're not isolated
                        if (curCell->type == 1) {
                            for (unsigned int i=0;i<6;i++) {
                                CellG* curNCell = cellFieldG->get(n[i]);
                                if (curNCell == curCell) {
                                    isolated = false;
                                    break;
                                }
                                else {
                                    cellToBecome = curNCell;
                                }
                            }
                        }
                        
                        // for stable cells, check if the cell is isolated, but if it is, only let cells
                        // that touch the same lumen engulf it
                        else if (curCell->type > 2) {
                            for (unsigned int i=0;i<6;i++) {
                                CellG* curNCell = cellFieldG->get(n[i]);
                                if (curNCell == curCell) {
                                    isolated = false;
                                    break;
                                }
                                else {
                                    CellG* nextNCell = cellFieldG->get(n[(i+1)%6]);
                                    // this will only happen when the current neighbor is a lumen
                                    if (curNCell && curNCell->type == 2) {
                                        if (nextNCell && nextNCell->type > 2) {
                                            cellToBecome = nextNCell;
                                        }
                                    }
                                }                   
                            }                            
                        }
                    }
//                    if (cellToBecome) {
//                        cerr << "Isolated is " << isolated << " and cellToBecome is " << cellToBecome->id << endl;
//                    }
                    
                    
                    // now subsume that point into the neighboring cell
                    if (isolated) {
                        if (cellToBecome) {
                            cerr << "cell " << curCell->id << " being engulfed by cell " << cellToBecome->id << endl;                       MCell* nMCell = cellMap->get(cellToBecome);
                            cellFieldG->set(curPoint, cellToBecome);
                            nMCell->addPoint(curPoint);
                            curMCell->removePoint(curPoint);  
                        }
                        else {
                            cellFieldG->set(curPoint, NULL);
                            curMCell->removePoint(curPoint);
                        }                       
                    }


                    // Debugging code to list the points that this cell is in
                   // cerr << " and so far, covers points:";
                    list<Point3D> pointList = curMCell->getPoints();
                    list<Point3D>::iterator theIterator;
                    for( theIterator = pointList.begin(); theIterator != pointList.end(); theIterator++ ) {
                        Point3D curPoint = *theIterator;
                        //cerr << " " << curPoint.x << "," << curPoint.y;
                    }
//                    cerr << endl;
                    
                }
                else {
                    // create a new MCell and set it to this cell, with the current point in its point list
                    //cerr << "Creating a new MCell" << endl;
                    curMCell = new MCell(curCell,Point3D(curx,cury,0),this);
                    cellMap->insert(curCell,curMCell);
                    initializedCellMap = true;
                    curMCell->doublingVolume = ntpdPtr->doublingVol;
                    
                    //cerr << "inserting a new Mcell for cell " << curCell->id << " with doubling volume " << curMCell->doublingVolume << endl;
                }                
            }
            else { // This will be called if the point is not in a cell
                int x = 1;
                //cerr << "medium" << endl;
            }
        }
    } // end of the initialization for all cells
 
    cerr << "cyst goes from " << smallestX << ", " << smallestY << " to " << largestX << ", " << largestY << endl;
    double avgDiam = double(largestX - smallestX + largestY - smallestY) / 2.0;
    cerr << "diameter is " << avgDiam << endl;
    cerr << "outerSurfaceData is " << outerSurfaceData << endl;
 
    // Record data about the system to write out to the database.

    int dyingCellCountData = 0;
    int dyingEpiCellCountData = 0;
    int dyingLumenCellCountData = 0;
    int deadEpiCellCountData = 0;
    int deadLumenCellCountData = 0;
    
    int newlyDyingCellCountData = 0;
    
    int newCellCountData = 0;
    int newLumenCountData = 0;
    
//    int previousLiveCellNumber = dataManager->cellNumber + dataManager->stableCellNumber;
    int previousDeadCellNumber = dataManager->deadCellNumber;
    int previousDeadEpiCellNumber = dataManager->deadEpiCellNumber;        
    int previousDeadLumenCellNumber = dataManager->deadLumenCellNumber;
    int previousDyingCellNumber = dataManager->dyingCellNumber;
    int previousTotalNewCellNumber = dataManager->totalNewCellNumber;
    int previousTotalNewLumenNumber = dataManager->totalNewLumenNumber;
 
    int totalVolume = 0; // for calculating cellular area
    int cellularVolume = 0;
    
    for(cInvItr=cellInventoryPtr->cellInventoryBegin() ; cInvItr !=cellInventoryPtr->cellInventoryEnd() ;++cInvItr ) {
                
        cell=*cInvItr;
        MCell* mCell = cellMap->get(cell);
                
        if(mCell == NULL) {
            cerr << "Removed cell.  No mCell" << endl;
            continue;
        }
        totalVolume += cell->volume;
        if (cell->type != 2) {
            cellularVolume += cell->volume;
        }
    }
 

    // CELL MAIN LOOP
    // this is the execution code for the cells   
    for(cInvItr=cellInventoryPtr->cellInventoryBegin() ; cInvItr !=cellInventoryPtr->cellInventoryEnd() ;++cInvItr ) {
        
        
        cell=*cInvItr;
        MCell* mCell = cellMap->get(cell);
        
        if(mCell == NULL) {
            cerr << "This cell has been removed. Continuing to next cell." << endl;
            continue;
        }

        if(cell->volume == 0) {
            cerr << "This cell is a ghost.  Continuing" << endl;
            continue;
        }

        std::stringstream prefixStream;
        prefixStream << "SC " << simCycle << ", cell " << cell->id << ":  ";  
        std::string prefix = prefixStream.str();

        cerr << prefix << "In cell execution code." << endl;
        
        // calculate center of mass of this cell
        Coordinates3D<double> com = mCell->calcHexCom();

        // only do this on the first turn
        if (simCycle == 1) {
            cerr << prefix << prefix << "Performing first turn set tasks" << endl;
//            cell->targetVolume = ntpdPtr->targetVolume;
            cell->targetVolume = cell->volume;
            cell->lambdaVolume = ntpdPtr->lambdaVolume;            
//            cell->targetSurface = ntpdPtr->targetSurface;
            cell->targetSurface = cell->surface;
            cell->lambdaSurface = ntpdPtr->lambdaSurface;   
            
            // To replicate collagen.
//            int initCycle = randGen->getInteger(1,ntpdPtr->cellCycle*3);

            // In order to allow the simulation to begin with the same number of cells as the in vitro data,
            // begin with two cells by lowering the cycleCounter of the first cell to 1 during the first cell cycle.
            // See insilico_graphing.xls sheet Initial cell calc.  
            mCell->cycleCounter = 1;
            cerr << prefix << "Setting cycleCounter to 1 to simulate clumping." << endl;

/*
            // % chance of starting with two cells.
            if (randGen->getRatio() < ntpdPtr->clusterProb) {
                mCell->cycleCounter = 1;
                cerr << prefix << "Setting cycleCounter to 1 to simulate clumping." << endl;
            }
            else {
                int initCycle = randGen->getInteger(int(ntpdPtr->cellCycle/4),int(ntpdPtr->cellCycle));
                mCell->cycleCounter = initCycle;
            }

            cerr << prefix << "setting cycleCounter to " << mCell->cycleCounter << endl;
*/
            if (ntpdPtr->divisionReg == 1 || ntpdPtr->divisionReg == 3) {
                mCell->divisionReg = true;
            }
        }

        // Set the cycleCounter for the two cells at simCycle == 5.
        // This depends on clusterProb, which can influence the number of cells near the beginning of the simulation.
        if(simCycle == 5) {
            int lowLimit = int( (1 - ntpdPtr->clusterProb) * ntpdPtr->cellCycle);
            cerr << prefix << "lowLimit is " << lowLimit << endl;

            mCell->cycleCounter = randGen->getInteger(lowLimit,ntpdPtr->cellCycle);
        }
        
        // Older ways of doing this.
        /*        // This is a very simple way to increase clustering.
        if (simCycle == 6 && cell->id == 1) {
            if (randGen->getRatio() < ntpdPtr->clusterProb) {
                mCell->cycleCounter = 1;
                cerr << prefix << "reducing cycleCounter to 1" << endl;
            }
        }
        
        // Another older way of doing this.
        // Now adjusting cellCycles of cells
        if (simCycle == 10) {
            mCell->cycleCounter = randGen->getInteger(int(ntpdPtr->cellCycle/4),ntpdPtr->cellCycle);
            }*/
	  
        	
        int cellType = (int)(cell->type);
        
        cerr << prefix << prefix << "Volume: " << cell->volume << "  Surface: " << cell->surface << endl;
        
        cerr << prefix << prefix << " The type of the current cell is " << cellType << endl;
        // TYPES
        // 0 = matrix (but no formal type designation
        // 1 = cell (unpolarized)
        // 2 = lumen
        // 3 = stable cell (polarized)
        // 4 = shifted cell

 
        // if it's a lumen
        if (cellType == 2) {
            // count the type of the cells neighboring the lumen
            int polarNeighbors = 0;
            int shiftedNeighbors = 0;
            int stretchedNeighbors = 0;
            int totalNeighbors = 0;
            double totalPerim = 0;
            double totalNVolume = 0;

            NeighborTracker *nTracker = neighborTrackerAccessorPtr->get(cell->extraAttribPtr);
            cerr << prefix << prefix << "LM: Initialized neighbor tracker" << endl;
            
            // We want to iterate through the cell neighbors.
            // *nTracker->cellNeighbors will give us a set<NeighborSurfaceData>, which we should iterate through.
            
            cerr << prefix << prefix << "LM: Getting neighbors from nTracker" << endl;
            set<NeighborSurfaceData> neighbors = nTracker->cellNeighbors;
            cerr << prefix << "LM: Creating iterator" << endl;
            set<NeighborSurfaceData>::iterator theIterator;
            
            cerr << prefix << "LM: Moving into for loop" << endl;
            for( theIterator = neighbors.begin(); theIterator != neighbors.end(); theIterator++ ) {
                cerr << prefix << " LM in for loop " << endl;
                CellG * nCell = theIterator->neighborAddress;

                // csa is the common surface area between this neighbor and the cell
                int csa = theIterator->commonSurfaceArea;
                
                if (nCell) {
                    // LM is for lumen
                    cerr << prefix << " LM there is at least one neighbor" << endl;
                    cerr << prefix << " LM cell " << cell->id << " is bordered by cell " << nCell->id << endl;
                    cerr << prefix << " And has surface area of " << csa << " with it" << endl;
                    
                    int cellType = (int) (cell->type);
                    int nType = (int) (nCell->type);
                    
                    MCell* nMCell = cellMap->get(nCell);
                    
                    if (nType != 2) {
                        totalPerim += nCell->surface;
                        totalNVolume += nCell->volume;
                    }
                    
                    cerr << prefix << "For cell " << nMCell->cell->id << "type is " << nCell->type << endl;
                    if (nType == 1) {
                        totalNeighbors++;
                    }
                    else if (nType == 3) {
                        cerr << prefix << "nCell->surface is " << nCell->surface << " and volume is " << nCell->volume << endl;
                        polarNeighbors++;
                        totalNeighbors++;        
                    }
                    else if (nType == 4) {
                        cerr << prefix << "Found shifted cell." << endl;
                        shiftedNeighbors++;
                        totalNeighbors++;
                    }
                    // If this lumen encounters another lumen, merge the two lumens into one.
                    else if (nType == 2) {
                        cerr << prefix << " LM attempting to merge two lumen cells" << endl; 
                        
                        // if both cells have MCells in cellMap, which they should
                        if (mCell && nMCell) {
                            
                            list<Point3D> nPoints = nMCell->getPoints();
                            list<Point3D>::iterator theIterator;
                      
                            // the target volume will equal the sum of the old target volumes.
                            cell->targetVolume = cell->targetVolume + nCell->targetVolume;
                            
                            // iterate through all the neighbor points and set them to the original cell
                            // and to the MCell cellPoints.
                            for( theIterator = nPoints.begin(); theIterator != nPoints.end(); theIterator++ ) {
                                Point3D curPoint = *theIterator;
                                cellFieldG->set(curPoint,cell);
                                mCell->addPoint(curPoint);
                            }
                            // remove the neighbor cell from the cellMap
                            cellMap->erase(nCell);
                        }
                    }
                }
                else 
                    cerr << prefix << " LM there are no neighbors" << endl;
            }

            /*
             * Calculating target volume for an expanding lumen
             * 
             * We want to calculate the target volume for a given cell.  tv - v will be the effective
             * force that cells feel as they expand.  So in order to calculate that we need to find
             * the force that the lumen pushes out with.  
             * 
             * Because we're dealing with liquid rather than gas we have a very high lambda volume for the lumen
             * As long as the target volume is larger than the volume it'll expand.
             *
             * We increase the lumen's targetVolume by the lumenGrowthRate, but modify it by a number of factors,
             * including the estimated size of the cells surrounding this lumen, the area of the lumen, and the
             * number of cells contacting the lumen.
             */

            /* Calculating the volume increase of an expanding lumen.
             * 
             * First, the lumen will expand faster the larger the outer surface of the cells that are in contact with 
             * it have.  However, it will expand slower the more those cells are stretched out.
             * 
             * So first we'll just deal with the outer cell surface.  To calculate the outer surface of cells, do the following:
             * Estimated area:  A = lumen area + neighbor cell area
             * Perimeter of that area: P = 2PI * SQRT(A/PI)
             */

            double summedVolume = cell->volume + totalNVolume;
            double estArea = 2 * PI * sqrt(summedVolume / PI);
            cerr << prefix << "summedVolume is " << summedVolume << " and estArea is " << estArea << endl;


            // When the cell wall gets too thin, cells are too stretched out.
            // We can calculate something analogous to the cell wall by comparing the cyst and lumen perimeter,
            // which scale with the radius.  The difference between them will also scale with the difference
            // between the radius of the lumen and the radius of the cyst as a whole.
            // So just say that if the value of lumenPerim/cystPerim falls below a certain value,
            // then start adding lgr.  According to the graph of lumenPerim/cystPerim  over time for in silico experiment 486,
            // the lumen size gets too large when that value goes above 0.8.
            double surfaceCutoff = 0.8;
            double surfaceRatio = cell->surface / estArea;
            double lgrSubtract = 0.0;

            cerr << prefix << "surfaceRatio is " << surfaceRatio << endl;
            if (surfaceRatio > surfaceCutoff) {
                cerr << prefix << "surfaceRatio is above cutoff" << endl;
                lgrSubtract = (surfaceRatio - surfaceCutoff) * ntpdPtr->lgrSubtract;
                cerr << prefix << "calculated value of lgrSubtract is " << lgrSubtract << endl;
            }

            // Actually change the target volume of the lumen
            double oldTV = cell->targetVolume;
            cell->targetVolume += ntpdPtr->lumenGrowthRate * estArea * totalNeighbors - lgrSubtract;
            if(cell->targetVolume < oldTV) {
                cell->targetVolume = oldTV;
            }
            cerr << prefix << "increasing lumen tv from " << oldTV << " to " << cell->targetVolume << endl;

        }

        // NON LUMEN CELLS
        else if (cellType != 2) {
            cerr << prefix << "Cell " << cell->id << " midbody: " << MathUtil::ps(mCell->midBody) << endl;
                
            mCell->countNeighbors(neighborTrackerAccessorPtr);
            int matrixCount = mCell->matrixCount;
            int lumenCount = mCell->lumenCount;
            int cellCount = mCell->cellCount;
            int shiftedCount = mCell->shiftedCount;

            cerr << prefix << "After counting cells, we have the following result:\n"
                 << "matrixCount: " << matrixCount
                 << ", lumenCount: " << lumenCount
                 << ", cellCount: " << cellCount
                 << ", shiftedCount: " << shiftedCount
                 << endl;

            // If more than one neighbor of this cell has changed to the shifted state, this cell will also change.
            if (cell->type == 3 && shiftedCount > 1) {
                cerr << prefix << "Shifting because multiple neighbors have shifted." << endl;
                cell->type = 4;
            }

            // First assess if this cell will die or not.  Cells can only die once, so
            // if they're already dying then don't check their current state.
            if (! mCell->cellDying) { 
                if (matrixCount == 0 && cellType == 1) {
                    cerr << prefix << "***Unpolarized cell entering apoptosis because it doesn't contact matrix" << endl;
                    mCell->cellDying = true;
                }                
                else if (matrixCount == 0 && cellCount == 0) {
                   cerr << prefix << "Isolation death!" << endl;
                   mCell->cellDying = true;

                }
                else if (matrixCount == 0) {
                    cerr << prefix << "Testing probabalistic cell death in the lumen" << endl;
                    double deathPercent = ntpdPtr->deathRateLumen;
                    if (shiftedCount > 0) {
                        //                                                deathPercent = deathPercent * 2;
                        cerr << prefix << "Increasing death rate for cell touching shifted cells in the lumen." << endl;
                    }
                        
                    if (randGen->getRatio() < deathPercent) {
                        cerr << prefix << "Lumen death!" << endl;
                        deadLumenCellCountData++;
                        mCell->cellDying = true;
                    }
                }
                else {
                    cerr << prefix << "Testing probabalistic cell death in the epithelia" << endl;
                    if (randGen->getRatio() < ntpdPtr->deathRateEpi) {
                        cerr << prefix << "Epithelial death!" << endl;
                        deadEpiCellCountData++;
                        mCell->cellDying = true;
                    }                
                }
                
                if (mCell->cellDying) {
                    newlyDyingCellCountData++;
                }
            }
            
            cerr << prefix << "Cell death lumen: " << deadLumenCellCountData << ", epithelia: " << deadEpiCellCountData << endl;

            // It's important to note that deadLumenCellCountData and deadEpiCellCountData refer to the number of cells
            // that underwent initial dying events in the lumen or the epithelia.  dyingEpiCellCountData and dyingLumenCellCoundData
            // refer to the number of cells currently shrinking in those locations.  If a cell dies while touching the matrix and
            // then loses contact with the matrix deadEpiCellCountData will be incremented and at that turn dyingLumenCellCountData
            // will also be incremented.
            if (mCell->cellDying) {            
                cerr << prefix << "cell shrinking because of apoptosis" << endl;    
                if (cell->targetVolume > -15) {
                    cell->targetVolume = cell->targetVolume - ntpdPtr->dyingShrinkRate;
                }
                mCell->pCounter = MCell::COUNTER_NULL;
                if (matrixCount > 0) {
                    cerr << prefix << "adding to epithelial death counter" << endl;
                    dyingEpiCellCountData++;
                }
                else {
                    cerr << prefix << "adding to luminal death counter" << endl;
                    dyingLumenCellCountData++;
                }
                dyingCellCountData++;
//                cell->type = 1;
                
                // See below for how to calculate minimalSurface
                LatticeMultiplicativeFactors lmf = boundaryStrategy->getLatticeMultiplicativeFactors();
                double minimalSurface = 2 * sqrt(3) * sqrt(double(cell->volume) * 4 - 1 ) * lmf.surfaceMF;
                cell->targetSurface = ntpdPtr->multiplier * minimalSurface;

                cerr << prefix << "Volume: " << cell->volume << ", Surface: " << cell->surface << ", TV: " << cell->targetVolume
                    << ", TS: " << cell->targetSurface << endl;
                continue;
            }
           

            // Calculate targetVolume.
            // Biologically, I'm going to assume that cells expand at a rate proportional to the surface
            // that touches the medium.  So the targetVolume will be larger than the current volume.
            // We should be aware that cells already grow in proportion to the amount of free surface.
            // This is because each location that the cell touches can flip, and the more locations a
            // cell touches, the more opportunities there are for flipping.  targetVolume - volume represents
            // the _likelihood_ that a single location will flip.  So in order to keep the volume increase
            // proportional to the size of the cell, this would just be constant.  In addition, since other
            // cells are already growing, as is the lumen, then the growth of the cell is _also_ likely
            // to be proportional to the area that's exposed to the matrix.  But this refers to the actual
            // growth of the cell, not the motivation to grow, which is decided by the difference between
            // targetVolume and volume.

            // Cells that contact the matrix but not the lumen
            if (matrixCount > 0 && lumenCount == 0) { 
                // unpolarized cells will grow to the ideal volume
                if (cell->type == 1) {
                    cell->targetVolume = ntpdPtr->targetVolume;
                    cerr << prefix << "Unpolarized cell contacts matrix, not lumen. Setting tv to " << cell->targetVolume << endl;
                }
                else {
                // polarized cells will not grow
                    cell->targetVolume = cell->targetVolume;
                    if (cell->targetVolume < ntpdPtr->doublingVol) {
                        cell->targetVolume = ntpdPtr->doublingVol;
                    }
                    cerr << prefix << "Polarized cell contacts matrix, not lumen. Setting tv to " << cell->targetVolume << endl;
                }
                
                // This is an older way of causing cells to shift.
                // Cells that don't touch the lumen will shift when the entire cyst is stretched out enough.
                double cystVolume = totalVolume;
                double cellVolume = cellularVolume;
                if (cellVolume / cystVolume < 0.5) {
                    //                    cerr << "Cell touching matrix but not lumen. Shifting because overall cellular volume is small" << endl;
                    //                    mCell->reachedShift = true;
                }
                
            }
            // If the cell doesn't contact the matrix, it will just be at doublingVolume
            else if (matrixCount == 0 ) {
                cell->targetVolume = ntpdPtr->doublingVol;
                cerr << prefix << "Polarized cell not touching matrix, but possibly touching lumen. Setting tv to " << cell->targetVolume << endl;
                
                // This is an older way of causing cells to shift.
                // Cells that don't touch the matrix will shift when the entire cyst is stretched out enough.
                double cystVolume = totalVolume;
                double cellVolume = cellularVolume;
                if (cellVolume / cystVolume < 0.5) {
                    //                    cerr << "Cell not touching matrix shifting because overall cellular volume is small" << endl;
                    //                    mCell->reachedShift = true;
                }
                
            }
            // If a cell has shifted its target volume will be calculated from the amount of lumen surface
            else if(cell->type == 4) {
                cell->targetVolume = ntpdPtr->doublingVol;
                
                // Shifted cells used to be called differentiated cells, which explains the "DC" in these comments.
                NeighborTracker *nTracker = neighborTrackerAccessorPtr->get(cell->extraAttribPtr);
                cerr << prefix << prefix << "DC: Initialized neighbor tracker" << endl;

                // We want to iterate through the cell neighbors.

                // *nTracker->cellNeighbors will give us a set<NeighborSurfaceData>, which we should iterate through.

                cerr << prefix << "DC: Getting neighbors from nTracker" << endl;
                set<NeighborSurfaceData> neighbors = nTracker->cellNeighbors;
                cerr << prefix << "DC: Creating iterator" << endl;
                set<NeighborSurfaceData>::iterator theIterator;

                cerr << prefix << "DC: Moving into for loop" << endl;
                for( theIterator = neighbors.begin(); theIterator != neighbors.end(); theIterator++ ) {
                    cerr << prefix << "DC: in for loop " << endl;
                    CellG * nCell = theIterator->neighborAddress;
                    int csa = theIterator->commonSurfaceArea;
                    
                    // If the neighbor cell is a lumen
                    if (nCell && nCell->type == 2) {
                        cerr << prefix << "Found lumen neighbor.  Cell has csa of " << csa << " with it." << endl;
                        
                        // To calculate the volume of the cell we want the following:
                        // The TV area starts relatively small, say at doublingVolume - something.
                        // It will grow as the area that the cell contacts the lumen increases.
                        // The range should be from 95 to 110, say
                        // Which scales to 42 to 49.
                        // Now, if shiftTargetVolume is 42, we can say from dv to dv + 9.
                        // What does the apical surface area of the cell range from?
                        // They range from 8 to 10, which scales to 5.33 to 6.66.
                        // But if we have a 2:1 csa to real volume then that's 10.6 to 13.3
                        // So how do we map 10.6 to shiftTargetVolume and 13.3 to dv +9?  Well, we could just add 2x and
                        // cap on either end.
                        // So if less than 10.6 it's shiftTargetVolume then from 10.6 to 13.3 it's shiftTargetVolume + (x-10.6) * 2 and if
                        // the result is great than shiftTargetVolume + 9 it's capped.
                        if (csa < 10.6) {
                            cell->targetVolume = ntpdPtr->shiftTargetVolume;
                            cerr << prefix << "Cell has a small csa with the lumen.  Setting tv to shiftTargetVolume: " << cell->targetVolume << endl;
                        }
                        else {
                            int newTV = ntpdPtr->shiftTargetVolume + ((csa - 10.6) * 2);
                            if (newTV < ntpdPtr->shiftTargetVolume + 9) {
                                cell->targetVolume = newTV;
                                cerr << prefix << "Cell has medium csa with lumen.  Setting tv to " << newTV << endl;
                            }
                            else {
                                cell->targetVolume = ntpdPtr->shiftTargetVolume + 9;
                                cerr << prefix << "Cell has large csa with lumen.  Setting tv to shiftTargetVolume + 9: " << cell->targetVolume << endl;
                            }
                        }
                        break;
                    }
                }
                // If the cell isn't in contact with the lumen, its targetVolume will be equal to the shiftTargetVolume
                cell->targetVolume = ntpdPtr->shiftTargetVolume;
                
            }
            // If the cell contacts a matrix and a lumen it will calculate its desired area 
            else if (matrixCount == 1 && lumenCount == 1) { 
                // Calculate the hypothetical volume based on the fraction of the area the cell represents.
                // Ah = Ccell / Ccyst * Acyst
                // Get Ccell and Ccyst by iterating through neighbors and saving the amount of area touching the
                // matrix.
                int cystVolume = totalVolume;

                NeighborTracker *nTracker = neighborTrackerAccessorPtr->get(cell->extraAttribPtr);
                cerr << prefix << prefix << "TV: Initialized neighbor tracker" << endl;

                // We want to iterate through the cell neighbors.

                // *nTracker->cellNeighbors will give us a set<NeighborSurfaceData>, which we should iterate through.

                cerr << prefix << "TM: Getting neighbors from nTracker" << endl;
                set<NeighborSurfaceData> neighbors = nTracker->cellNeighbors;
                cerr << prefix << "TM: Creating iterator" << endl;
                set<NeighborSurfaceData>::iterator theIterator;

                cerr << prefix << "TM: Moving into for loop" << endl;
                int lsa = 0;
                int msa = 0;
                int csa = 0;
                double lumenVolume = 0;

                for( theIterator = neighbors.begin(); theIterator != neighbors.end(); theIterator++ ) {
                    cerr << prefix << "TM: in for loop " << endl;
                    CellG * nCell = theIterator->neighborAddress;
                    csa = theIterator->commonSurfaceArea;

                    if (nCell) {
                        cerr << prefix << " TM there is at least one neighbor" << endl;
                        cerr << prefix << " TM cell " << cell->id << " is bordered by cell " << nCell->id << endl;
                        if (nCell->type == 2) {
                            lsa = csa;
                            lumenVolume = nCell->volume;
                            cerr << prefix << "Found a lumen neighbor with common surface area of " << lsa << endl;
                        }
                        else {
                            cerr << prefix << " And has surface area of " << csa << " with it" << endl; 
                        }

                    }
                    else {
                        cerr << prefix << " TM borders the matrix " << endl;
                        cerr << prefix << " and has common surface area of " << csa << " with it." << endl;
                        msa = csa;
                    }
                }

                // This is the old way of calculating hypVol.  I'll use it as a comparator to make sure I'm in the ballpark with my new method.
                double areaRatio = double(csa) / double(outerSurfaceData);
                
                double oldHypVol = areaRatio * cystVolume;
                double hypVol = 0;

                /* The new way of calculating hypVol relies on the formula:
                 * H = C + B^2*C / ( (A+B)(A-B) )
                 * With the following representations:
                 * H = hypVol
                 * A = 1/2 the matrix contact area 
                 * B = 1/2 the lumen contact area
                 * C = the volume of the cell
                 *
                 */
                double Aval = double(msa)/2.0;
                double Bval = double(lsa)/2.0;
                double Cval = cell->volume;
                
                hypVol = Cval + (Bval*Bval) * Cval / ( (Aval+Bval) * (Aval-Bval) );
                
                cerr << prefix << "oldHypVol is " << oldHypVol << " and hypVol is " << hypVol << endl;

                cerr << prefix << "areaRatio is " << areaRatio << " and hypVol is " << hypVol << " while actual vol is " << cell->volume << endl;
                // If hypVol < ideal, get bigger.  Otherwise get smaller.
                cerr << prefix << "cell->targetVolume is " << cell->targetVolume << endl;
                

                // Find the ratio of the cell's volume to that of its hypothetical volume.  If that ratio falls below 0.6 then shift.
                
                // Here the cell may shift, if its hypothetical volume is greater than the ideal
                // AND if its actual volume is less than doublingVolume + a constant (5).
                
                //                        if (cell->volume / hypVol < 0.5) {
                //    cerr << prefix << "setting reachedShift to true because cell has high hypVol and low actual vol" << endl;
                //    mCell->reachedShift = true;
                //}

                //  We use the minimal value of targetVolume or hypVol so that large cells with large hypVols will still shift.
                double shiftRatio = ntpdPtr->shiftRatio;
                //double shiftRatio = 0.38;
                // Now that we have a better way to calculate hypVol, let's use it to cause cell shifting.
                // Adding a restriction that only cells that are normally configured can shift this way.

                double hypRatio = double(cell->volume) / min(double(ntpdPtr->targetVolume),hypVol);

                // This is an old way of doing cell shifting
                //                if (cellCount == 2 && double(cell->volume) / min(double(ntpdPtr->targetVolume),hypVol) < shiftRatio) {
                /*                if (hypRatio < shiftRatio && cell->volume < ntpdPtr->doublingVol) {
                    cerr << prefix << "Cell volume is less than shiftRatio (" << shiftRatio << ") of hypVol or tv so shift." << endl;
                    mCell->reachedShift = true;
                    }*/
                

                // This is another way of calculating cell shifting
                // the way this works is that we try to guess the amount that the system is stretched out through information about the
                // individual cell and the lumen it neighbors.  The ideal is that we can guess the correct ratio of cell are to cyst area.
                // before we do this, however, let's revert back to having the system use the ratio of the whole cyst and see 
                // if we can get the right numbers.
                // After some trial and error, it works with a shiftRatio of 0.75.  Let's keep that for now and try to guess the correct size.

                /*
                 * 1.  Calculate h for the cell.  This is equal to 2 * C/(A+B)
                 * 2.  Estimate radius of the cyst.  This involves getting the lumen size, which is not strictly global, but reasonable.
                 *     radius = sqrt(L/PI) + h
                 * 3.  Estimate area of the cysts from the radius.  A = PI r^2.
                 * 4.  Find ratio of cell are to cyst area:  shiftRatio = (cystA-lumenA)/cystA
                 */
                double cellHeight = 2 * double(cell->volume) / double(msa+lsa);
                double cystRadius = sqrt(double(lumenVolume)/PI) + cellHeight;
                double cystArea = PI * cystRadius*cystRadius;
                double estimatedRatio = double(cystArea-lumenVolume)/cystArea;

                double cellVolume = cellularVolume;
                
                double realRatio = cellVolume / cystVolume;

                cerr << prefix << "cellVolume is " << cellVolume << " and cystVolume is "  << cystVolume << " so ratio is " << realRatio
                     << " and shiftRatio is " << shiftRatio << endl;
                cerr << prefix << "estimatedRatio ise " << estimatedRatio << " and error is " << estimatedRatio - realRatio << endl;
                /*
                // I commented the actual shifting out.
                if(realRatio < shiftRatio) {
                //                if (estimatedRatio < shiftRatio) {
                    cerr << prefix << "cellVolume/cystVolume < shiftRatio so shift." << endl;
                    cell->type = 4;
                }
*/
                // This is the actual way that cells shift, by which they simply query the lumen for its size.
                double lumenValue = lumenVolume / 1000;
                if (lumenValue > shiftRatio) {
                    cerr << prefix << "lumenValue is greater than shiftRatio, so shift" << endl;
                    cell->type = 4;
                }

                cell->targetVolume = cell->targetVolume + ntpdPtr->targetVolume - hypVol;
                cerr << prefix << "cell->targetVolume is now " << cell->targetVolume << endl;
                // Target volume can be no larger than ideal volume.
                if (cell->targetVolume > ntpdPtr->targetVolume) {
                    cell->targetVolume = ntpdPtr->targetVolume;
                    cerr << prefix << "Actual volume is larger than maximal. Setting tv to " << cell->targetVolume << endl;
                }
                // Target volume can be no smaller than the doubling volume - 10.
                if (cell->targetVolume < ntpdPtr->doublingVol-10) {
                    cell->targetVolume = ntpdPtr -> doublingVol - 10;
                    cerr << prefix << "Actual volume is smaller than minimal. Setting tv to " << cell->targetVolume << endl;
                }
            }

            
            // Our cells want to have a shape roughly equal to a circle.
            // In order to do that in a continuous space, the area would be equal to 2 PI sqrt(V/PI)
            // But, because we are working in a hexagonal space, the formula is a little different.
            // If r is the radius of a hexagon of hexagons, where r of 0 is a one-sided hexagon,
            // then A = 6 + 12r
            // and V = 3r^2 + 3r + 1
            // If you solve for A you get A= 2 sqrt(3) * sqrt(4 * V - 1)
            
            // (It's also important to remember that the sides are scaled such that they're 0.62 long.
            
            // A regular hexagon with an edge length of 1 has an area of 3 * sqrt(3) / 2 * l^2.

            // As a result, a hexagon with an area of 1 has an edge length of:
            // l = sqrt(2 / (3 * sqrt(3))), which equals 0.62.  So each edge of our hexagons is 0.62 long.)
            
            // However, this will always mean the target surface area is relatively close to the actual
            // surface, which means that there will be relatively little constriction.  To adjust for that
            // we'll set the value to be slightly less than it would otherwise be, providing more constriction.
            
            // the target surface will be a function of the volume, up to a maximum stretching point
            // defined by the user defined parameter multiplier

            // lmf is an internal scaling constant in this case equal to 0.82.
            LatticeMultiplicativeFactors lmf = boundaryStrategy->getLatticeMultiplicativeFactors();
            
            double minimalSurface = 2 * sqrt(3) * sqrt(double(cell->volume) * 4 - 1 ) * lmf.surfaceMF;
            
            
            cell->targetSurface = ntpdPtr->multiplier * minimalSurface;
            
            cerr << prefix << "ntpd->multiplier is " << ntpdPtr->multiplier << " and surfaceMF is " << lmf.surfaceMF << endl;
            // I don't need this as long as the multiplier doesn't get too high...
            
            cerr << prefix << "For cell " << cell->id << " target surface is " << cell->targetSurface << endl;
            cerr << prefix << "actual surface is " << cell->surface << " target volume is " << cell->targetVolume << endl;
            cerr << prefix << "actual volume is " << cell->volume << endl;
            
            if (cell->type == 4)
                cerr << prefix << "cell " << cell->id << " has reached shift" << endl;
            else
                cerr << prefix << "cell " << cell->id << " not shifted" << endl;

            Coordinates3D<double> midBody;
            
            // LUMEN CREATION
            // Cells will create a lumen if they're polarized, not shifted, contact the matrix and other cells, but don't
            // contact the lumen.  They will attempt to create a new lumen at the location of their midbody.  If that location
            // contacts another cell that already has a lumen, the new lumen will not be created.
            if (matrixCount > 0 && cellCount > 0 && lumenCount == 0) {
            
                if (cell->type==3 ) { //cell is stable but not shifted
                    
                    cerr << prefix << "attempting to create lumen for cell" << cell->id << endl;
                    
                    Coordinates3D<double> com = mCell->calcHexCom();
                    midBody = mCell->calcMidBody(com, mCell->midBody);
                    
                    cerr << prefix << "com is " << MathUtil::ps(com) << endl;
                    cerr << prefix << "midbody is " << MathUtil::ps(midBody) << endl;
                    
                    // The returned value of the midBody is in actual coordinates.  The lattice midBody is
                    // the point that's closest to the continuous point given to the method
                    Point3D latticeMidBody = MathUtil::getApproxLattice(midBody);
                    
                    cerr << prefix << "lattice midBody is " << latticeMidBody << endl;
                    
                    CellG* midCell = cellFieldG->get(latticeMidBody);
                    if (midCell)
                        cerr << prefix << " and is in cell " << midCell->id << endl;
                    
                   
                    if (midCell == cell) {
                        if (isBoundaryPixel(latticeMidBody,cell)) {
                            cerr << prefix << "for cell " << cell->id << " the lattice midBody is on the boundary" << endl;
                            
                            
                            // Now we have to make sure that any cells adjacent to this point are not contacting lumens.
                            int maxFromOrder = boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(1);
                            // iterate through the neighboring points
                            bool createLumen = false;
                            
                            // go through all the points neighboring this one, looking for a point in another cell
                            // that is not touching the lumen
                            for (unsigned int nIdx=0;nIdx<=maxFromOrder;nIdx++) {
                                cerr << prefix << "neighbor point nIdx is " << nIdx << endl;
                                // get the neighboring point in question
                                Neighbor neighbor=boundaryStrategy->getNeighborDirect(latticeMidBody, nIdx);
                                Point3D nPt = neighbor.pt;
                                cerr << prefix << "neighbor point is " << nPt << endl;
                                // get the cell for the neighboring point and the current point
                                CellG* nCell = cellFieldG->get(nPt);
                                
                                cerr << prefix << "nCell is " << nCell << endl;
                                cerr << prefix << "original cell is " << cell << endl;
                                
                                
                                // check whether this neighbor point is touching lumen.
                                // neighboring cell must be polarized.
                                if (nCell && nCell->type > 2) {
                                    cerr << prefix << "nCell->type is " << int(nCell->type) << endl;
                                    MCell* nMCell = cellMap->get(nCell);
                                    nMCell->countNeighbors(neighborTrackerAccessorPtr);
                                    cerr << prefix << "nMCell lumenCount is " << nMCell->lumenCount << endl;
                                    if (nMCell->lumenCount == 0) {
                                        createLumen = true;
                                    }
                                    else {
                                        cerr << prefix << "neighbor cell already touching lumen" << endl;
                                        createLumen = false;
                                        break;
                                    }
                                }
                                else {
                                    cerr << prefix << "Neighboring matrix or unpolarized cell.  Not creating a lumen." << endl;
                                    createLumen = false;
                                    break;
                                }
                            }
                            if (createLumen) {
                                cerr << prefix << "create lumen is true, so making a lumen" << endl;
                                MCell* newLumenMCell = createCell(latticeMidBody, cell, 2);
                                CellG* newLumenCell = newLumenMCell->cell;
                                newLumenCountData++;
                                cerr << prefix << "increasing newLumenCountData to " << newLumenCountData << endl;
                            }
                            
                            
                        }
                        else {
                            cerr << prefix << "for cell " << cell->id << " the lattice midBody is within the cell" << endl;
                        }
                    }
                    else {
                        cerr << prefix <<  "for cell " << cell->id << " the lattice midbody is outside the cell" << endl;
                    }
                }
            } // END LUMEN CREATION
            
            // now we finally shift based on cell type
            // first, the case of unpolarized cells
            
            // This code is primarily concerned with the transition from unpolarized to polarized cells.
            // There's a legacy variable called staticPCounter that no longer does anything.  It used to allow
            // ALL cells to polarize at the same time.
            if (cellType == 1) {    

                int pc = mCell->pCounter;
                
                cerr << prefix << "pcounter for this cell is " << pc << endl;
                
                // the cell hasn't yet polarized
                if (pc == MCell::COUNTER_NULL) {
                    // if the cell has matrix neighbors.  Currently this will always be true,
                    // but just in case I'm leaving it here.
                    if (matrixCount && cellCount > 0) {
                        // start the polarizing process
                        
                        mCell->pCounter = randGen->getInteger(ntpdPtr->polarDelay * 3/4,ntpdPtr->polarDelay * 5/4);
                        cerr << prefix << "beginning pCounter for cell " << cell->id << " at " << mCell->pCounter << endl;
//                        mCell->pCounter = ntpdPtr->polarDelay;
                        if (MCell::staticPCounter == MCell::COUNTER_NULL) {
                            cerr << prefix << "beginning the static pcounter process" << endl;
                            MCell::staticPCounter = 150000000;//ntpdPtr->systemPolarDelay;
                            cerr << prefix << "staticPCounter is now " << MCell::staticPCounter << endl;
                        }
                        
                    }
                }
                // the cell is in the process of polarizing, which is short-circuited by staticPCounter
                else if (pc > 0 && MCell::staticPCounter > 0) {
                    (mCell->pCounter)--;
                    cerr << prefix << "lowering pCounter for cell " << cell->id << " to " << mCell->pCounter << endl;
                    cerr << prefix << "static pCounter is " << MCell::staticPCounter << endl;
                }
                // pCounter is done
                else  if (pc < 1){
                    // if the cell has matrix neighbors.  Currently this will always be true,
                    // but just in case I'm leaving it here.
                    if (matrixCount > 0 && cellCount > 0) {
                        cell->type = 3;
                        mCell->doublingVolume = ntpdPtr->doublingVol;
                        
                        // setting shift delay to a random value between shiftDelay*3/4 and shiftDelay*5/4
                        int shiftVal = ntpdPtr->shiftDelay;
 
                        mCell->shiftCounter = ntpdPtr->shiftDelay;
                        //                        mCell->shiftCounter = randGen->getInteger(shiftVal * 3/4,shiftVal * 5/4);
                        cerr << prefix << "setting shiftCounter for cell " << cell->id << " to " << mCell->shiftCounter << endl;
                        //mCell->shiftCounter = ntpdPtr->shiftDelay;
                        // If the simulation is using divisionRegulation that changes when cells polarize, then
                        // set the divisionReg for this cell to true now.
                        if (ntpdPtr->divisionReg == 2) {
                            cerr << prefix << "cell polarizing.  setting divisionReg to be true" << endl;
                            mCell->divisionReg = true;
                        }
                        cerr << prefix << "changing doubling volume to " << mCell->doublingVolume << endl;
                    }
                }
                // staticPCounter has reached 0
                else { // This won't generally be reached.
                    cerr << prefix << "Setting reachedShift to true because staticPCounter has expired in the early clause." << endl;
                    cell->type = 4;
                
                }
            cerr << prefix << "end of if type 1" << endl;
            }
            /* shifted code added below */
            // then the case of stable cells
            // cells within the simulation have the option to use a counter and or a 
            else if (cellType == 3) {
                cerr << prefix << "found a stable cell with id " << cell->id << endl;
                
                if (mCell->shiftCounter > 0) {
                    mCell->shiftCounter--;
                    cerr << prefix << "shiftCounter  for cell " << cell->id << " is now " << mCell->shiftCounter << endl;
                }
                else {
                    cell->type = 4;
                    cerr << prefix << "Setting cell>type to 4 because shiftCounter has reached zero. " << endl;
                }
                if (MCell::staticPCounter < 1) {
                    cell->type = 4;
                    cerr << prefix << "Setting cell>type to 4 because staticPCounter has expired. " << endl;
                }

            }
            
            cerr << prefix << "checking volume of cell for possible mitosis" << endl;
            cerr << prefix << "cell->volume is " << cell->volume << " and doublingVolume is " << mCell->doublingVolume << endl;
            cerr << prefix << "mCell->cycleCounter is " << mCell->cycleCounter << endl;
            
            // Cells gain volume relatively quickly, so there's no need to use cell volume as a limiting factor
            if (cell->volume > mCell->doublingVolume / 2) {
                if (mCell->cycleCounter == MCell::COUNTER_NULL) {
                
                    mCell->cycleCounter = randGen->getInteger(ntpdPtr->cellCycle * 3/4, ntpdPtr->cellCycle * 5/4);
//                    mCell->cycleCounter = ntpdPtr->cellCycle;
//                    if (lumenCount > 0)
//                        mCell->cycleCounter = ntpdPtr->cellCycle;
//                    else
//                        mCell->cycleCounter = ntpdPtr->cellCycle;
                        
                    cerr << prefix << "starting mitosis counter at " << mCell->cycleCounter << endl;
                }
                // The next set of code deals with cells entering mitosis
                else if (mCell->cycleCounter > 0) {
                    // If the cell has shifted then the cycleCounter only decreases with a certain probability
                    if (cell->type == 1 || cell->type == 3) {
                        mCell->cycleCounter--;
                        cerr << prefix << "decrementing cycleCounter to " << mCell->cycleCounter << endl;
                    }
                    // Shifted cells will be less likely to decrement cycleCounter, effectively slowing their rate of division
                    else {
                        double cycleRatio = 1 - ntpdPtr->shiftedCycleDelay;
                        cerr << prefix << "shiftedCycleDelay is " << ntpdPtr->shiftedCycleDelay
                             << " and cycleRatio is " << cycleRatio << endl;
                        if (randGen->getRatio() < cycleRatio) {
                       
                            mCell->cycleCounter--;
                            cerr << prefix << "shiftedCell decrementing cycleCounter to " << mCell->cycleCounter << endl;
                        }
                        else {
                            cerr << prefix << "shiftedCell not reducing cycleCounter, which stays at " << mCell->cycleCounter << endl;
                        }
                    }
                }
                else {
                    cerr << prefix << "going to perform mitosis" << endl;
                    mCell->cycleCounter = MCell::COUNTER_NULL;
                    bool didMitosis = doMitosis(cell);
                    if (didMitosis)
                        newCellCountData++;
                }
            }
            
        } // end of cell type 1 or 3
    } // end of for each cell
    
    // The next set of code has to do with tight junction creation and maintenance.
    // This code cycles through the cells and...........

    Dim3D tDim = cellFieldG->getDim();
    WatchableField3D<CellG*> *tjWatcher = new WatchableField3D<CellG*>(Dim3D(tDim.x,tDim.y,tDim.z), NULL);
    vector<Point3D>* tjList = new vector<Point3D>();
     
    for(cInvItr=cellInventoryPtr->cellInventoryBegin() ; cInvItr !=cellInventoryPtr->cellInventoryEnd() ;++cInvItr ) {
                
        cell=*cInvItr;
        MCell* mCell = cellMap->get(cell);
                
        if(mCell == NULL) {
            cerr << "Removed cell.  No mCell" << endl;
            continue;
        }
        
        if (cell->volume == 0) {
            cerr << "This cell is a ghost. Also continuing." << endl;
            continue;
        }

        std::stringstream prefixStream;
        prefixStream << "SC " << simCycle << ", cell " << cell->id << ":  ";  
        std::string prefix = prefixStream.str();
        
        int cellType = (int)(cell->type);
        
        // we're going to find TJs by checking points on the border of the lumen cells.
        if (cellType ==2) {
            list<Point3D> cellPoints = mCell->getPoints();
            
            list<Point3D>::iterator theIterator;
            for( theIterator = cellPoints.begin(); theIterator != cellPoints.end(); theIterator++ ) {
                Point3D curPoint = *theIterator;
                
                std::vector<Point3D> n;
                n.assign(6,Point3D(0,0,0));
                
                // if the point is on the boundary of the luminal cell, then evaluate its immediate neighbors.
                // Each TJ will only be found once by this technique.
                if (isBoundaryPixel(curPoint,cell)) {
                    cerr << prefix << "Evaluating point " << curPoint << " for TJ neighbors" << endl;
                    
                    for(int i=0 ; i < 6; ++i ){
                        int* offsetsIndex = getOffsetsIndex(curPoint);
                        Neighbor neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(curPoint),offsetsIndex[i]);
                        if(!neighbor.distance){
                            //if distance is 0 then the neighbor returned is invalid
                            continue;
                        } 
                        n[i]=neighbor.pt;
                        cerr << prefix << "setting n[" << i << "] to " << n[i] << endl;
                    }
                    
                    // Now that we have the ordered neighbors we can detect if there are TJs.
                    for (unsigned int i = 0; i < 6; i++) {  
//                        cerr << prefix << "for " << i << " tjMap size is " << tjMap->size() << endl;
                        Point3D *curPoint = &(n[i]);
                        Point3D *nextPoint = &(n[(i+1)%6]);
                        cerr << prefix << "n[0] address is " << &(n[0]) << " n[" << i << "] address is " << &(n[i]) << endl;
                        cerr << prefix << "curPoint address is " << curPoint << endl;
                        CellG* curCell = cellFieldG->get(*curPoint);
                        CellG* nextCell = cellFieldG->get(*nextPoint);
                        if (!curCell || !nextCell) {
                            cerr << prefix << "Found matrix neighbor so can't be a TJ" << endl;
                            break;
                        }
                        cerr << prefix << "n[" << i << "], which is point " << *curPoint << " and is in a cell with type " << int(curCell->type) << " and id " << curCell->id << endl;
                        // this is to find the number of TJ surrounding the new lumen
                        // if two different cells are adjacent to each other and the center cell is a lumen
                        // then that's a TJ.
                        if (curCell != nextCell && curCell->type !=2 && nextCell->type != 2) {
                            cerr << prefix << "Cell " << curCell->id << " not equal to cell " << nextCell->id << " so this is a tight junction" << endl;
                            cerr << prefix << "inserting point " << *curPoint << " with address " << curPoint << endl;
                            cerr << prefix << "inserting point " << *nextPoint << " with address " << nextPoint << endl;
//                            tjMap->insert(curPoint,cell);
//                            tjMap->insert(nextPoint,cell);
    
                            // Only insert a given point once, even if it's part of multiple tight junctions
                            if (tjWatcher->get(*curPoint) == NULL) {
                                tjWatcher->set(*curPoint,cell);
                                tjList->push_back(*curPoint);
                            }
                            if (tjWatcher->get(*nextPoint) == NULL) {
                                tjWatcher->set(*nextPoint,cell);
                                tjList->push_back(*nextPoint);    
                            }
                            
//                            CellG* testCell = tjWatcher->get(tjList->at(0));
//                            cerr << prefix << "testCell id is " << testCell->id << endl;
                            cerr << prefix << "tjList size is now " << tjList->size() << endl;

                        }
                    } // end for
                } // end if boundary
            }// end for each point     
        }// end if lumen        
    }// end for each cell
//    cerr << prefix << "TJMap size is " << tjMap->size() << endl;
    
    bool merged = false;
    bool matrixNeighbor = false;
    
    // Shuffle the tjList
    random_shuffle( tjList->begin(), tjList->end() );

    
    // First attempt to merge TJs, then attempt to expand them.
    
    // Iterate through each point in the TJ list
    for (int i=0;i<tjList->size();i++) {
    
        // we'll only do one TJ merge in a given step.
        if (merged) 
            break;
    
        Point3D curPoint = tjList->at(i);
        CellG* curCell = cellFieldG->get(curPoint);
        MCell* mCell = cellMap->get(curCell);
        
        std::stringstream prefixStream;
        prefixStream << "SC " << simCycle << ", cell " << curCell->id << ":  ";  
        std::string prefix = prefixStream.str();
        
        CellG* lumenCell = tjWatcher->get(curPoint);
        cerr << prefix << "Merge.  Iterating through TJList for point " << curPoint << " touching lumen " << lumenCell->id << endl;
        
        int maxFromOrder = boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(1);
        
        // iterate through the neighboring points to make sure none are matrix or unpolarized cells
        for (unsigned int nIdx=0;nIdx<=maxFromOrder;nIdx++) {
            Neighbor neighbor=boundaryStrategy->getNeighborDirect(curPoint, nIdx);
            Point3D nPt = neighbor.pt;
            CellG* nCell = cellFieldG->get(nPt);
            if (nCell == NULL || nCell->type == 1) {
                cerr << prefix << "Point " << nPt << " is matrix or unpolarized so this TJ can't change" << endl;
                matrixNeighbor = true;
            }
                
        }
        if (matrixNeighbor) {
            matrixNeighbor = false;
            cerr << prefix << "Skipping point " << curPoint << " because it neighbors a matrix or an unpolarized cell" << endl;
            continue;
        }

        // iterate to see if this TJ can merge with another TJ
        cerr << prefix << "Checking for merging TJs" << endl;
        
        for (unsigned int nIdx=0;nIdx<=maxFromOrder;nIdx++) {

            // get the neighboring point in question
            Neighbor neighbor=boundaryStrategy->getNeighborDirect(curPoint, nIdx);
            Point3D nPt = neighbor.pt;
            CellG* nCell = cellFieldG->get(nPt);
            cerr << prefix << "Merge check: Neighbor point is " << nPt << endl;
            
            CellG* nLumen = tjWatcher->get(nPt);
            
            // If the point next to us is in the TJList AND touches a different lumen, try to merge with it
            if (nLumen && nLumen != lumenCell) {
                cerr << prefix << "Found a place where we can merge two TJs!  Point " << curPoint << " in cell " << 
                cellFieldG->get(curPoint) << " and point " << nPt << " in cell " << cellFieldG->get(nPt) << endl;
                
                cerr << prefix << "Merging TJs and lumens!" << endl;
                // code to transition points and merge lumen
                // if both cells have MCells in cellMap, which they should
                MCell* lumenMCell = cellMap->get(lumenCell);
                MCell* nLumenMCell = cellMap->get(nLumen);
                MCell* nMCell = cellMap->get(nCell);
                
                if (lumenMCell && nLumenMCell) {
                // First add the two points in the TJ:
                    cellFieldG->set(curPoint,lumenCell);
                    lumenMCell->addPoint(curPoint);
                    mCell->removePoint(curPoint);
                    cellFieldG->set(nPt,lumenCell);
                    lumenMCell->addPoint(nPt);
                    nMCell->removePoint(nPt);
                    
                    // Then merge the two now-touching lumens
                    
                    list<Point3D> nPoints = nLumenMCell->getPoints();
                    list<Point3D>::iterator theIterator;
              
                    // the target volume will equal the sum of the old target volumes.
                    lumenCell->targetVolume = lumenCell->targetVolume + nLumen->targetVolume;
                                        
                    // iterate through all the neighbor points and set them to the original lumen cell
                    // and to the MCell cellPoints.
                    for( theIterator = nPoints.begin(); theIterator != nPoints.end(); theIterator++ ) {
                        Point3D curLPoint = *theIterator;
                        cellFieldG->set(curLPoint,lumenCell);
                        lumenMCell->addPoint(curLPoint);
                    }
                    // remove the neighbor cell from the cellMap
                    cellMap->erase(nLumen);
                    
                    merged = true; 
                    // Once a TJ has merged, the list is different, so we just break
                    break;      
                }        
            }
        } // end for each neighboring point
    } // end for each TJ
        
        
        

        
    // Iterate through each point in the TJ list, checking for expanding TJs
    for (int i=0;i<tjList->size();i++) {
    
        // we'll only do one TJ merge in a given step.
        if (merged) 
            break;
    
        Point3D curPoint = tjList->at(i);
        CellG* curCell = cellFieldG->get(curPoint);
        MCell* mCell = cellMap->get(curCell);
        
        std::stringstream prefixStream;
        prefixStream << "SC " << simCycle << ", cell " << curCell->id << ":  ";  
        std::string prefix = prefixStream.str();
        
        CellG* lumenCell = tjWatcher->get(curPoint);
        cerr << prefix << "Expand.  Iterating through tjList for point " << curPoint << " touching lumen " << lumenCell->id << endl;
        
        int maxFromOrder = boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(1);
        
        // iterate through the neighboring points to make sure none are matrix
        for (unsigned int nIdx=0;nIdx<=maxFromOrder;nIdx++) {
            Neighbor neighbor=boundaryStrategy->getNeighborDirect(curPoint, nIdx);
            Point3D nPt = neighbor.pt;
            CellG* nCell = cellFieldG->get(nPt);
            if (nCell == NULL|| nCell->type == 1) {
                cerr << prefix << "Point " << nPt << " is matrix or unpolarized cell so this TJ can't change" << endl;
                matrixNeighbor = true;
            }
                
        }
        if (matrixNeighbor) {
            matrixNeighbor = false;
            cerr << prefix << "Skipping point " << curPoint << " because it neighbors a matrix or unpolarized cell" << endl;
            continue;
        }
        
        // iterate to see if this TJ can expand into its neighbors
        
        // This can only happen under very exact circumstances.
        // 1.  If any neighboring point is in a cell that touches a lumen, then that point must either be:
        //     -in the same cell as the point in question
        //     -a TJ that touches the same lumen
        // 2.  At least one neighboring point must be in a different cell and not a TJ
        //
        // So first iterate through all neighbors and make sure that none are in cells that touch other lumens
        // To do this:
        // 1.  See if the point has a lumen count > 0
        // 2.  If it does, see if it's not in the TJ list OR it is but it touches a different lumen
         
        
        cerr << prefix << "Checking for expanding this TJ" << endl;
        
        bool expand = true;
        
        // First make sure none of the neighbors touch a different lumen
        for (unsigned int nIdx=0;nIdx<=maxFromOrder;nIdx++) {

            // get the neighboring point in question
            Neighbor neighbor=boundaryStrategy->getNeighborDirect(curPoint, nIdx);
            Point3D nPt = neighbor.pt;
            CellG* nCell = cellFieldG->get(nPt);
            cerr << prefix << "Expand check: Neighbor point is " << nPt << endl;
            
            // First see if the neighbor is in a cell.
            if (nCell || nCell->type == 1) {
                MCell* nMCell = cellMap->get(nCell);
                nMCell->countNeighbors(neighborTrackerAccessorPtr);
                int lumenCount = nMCell->lumenCount;
                // Then see if it touches a lumen.
                if (lumenCount > 0 ) {
                    // This point is in a cell that touches a lumen.
                    // Now you have to see if the point is in a different cell
                    if (nCell != curCell) {
                        // It is, so now you have to check if it's in the TJ list
                        CellG* nLumen = tjWatcher->get(nPt);
            
                        if (nLumen) {
                            // This point is a TJ, but now we need to check if it touches the same lumen or a different one
                            if (nLumen == lumenCell) {
                                cerr << prefix << "nPoint " << nPt << " is a TJ touching the same lumen cell, so continuing." << endl;
                            }
                            else {
                                cerr << prefix << "nPoint " << nPt << " is a TJ touching another lumen cell, so can't expand." << endl;
                                expand = false;
                                break;                                
                            }
                        }
                        else {
                            // This point is not in the TJ list, so we can't expand here.
                            cerr << prefix << "nPoint " << nPt 
                                << " is in a cell that touches a lumen and isn't a TJ, so can't expand." << endl;
                            expand = false;
                            break;
                        }
                    }
                    else {
                        // This point is in the same cell, so it's OK, but we need to check the other neighbors.
                        cerr << prefix << "nPoint " << nPt << "is in the same cell, so continuing." << endl;
                    }

                }
                // If this cell doesn't touch a lumen, you can continue.
                else {
                    cerr << prefix << "nPoint " << nPt << " doesn't touch a lumen, so continuing." << endl;
                }
            }
            else {
                cerr << prefix << "nPoint " << nPt 
                    << " is in a matrix cell or an unpolarized cell, so can't expand." << endl;
                expand = false;
                break;
            }
        } // for each neighboring point
            
        // Now that we know that none of the points strictly forbid expansion, we can iterate through all of them again
        // to see if any points satisfy the conditions FOR expansion.
        // These conditions are:
        // 1.  One of the neighbors is 
        //     -In a different cell
        //     -Not a TJ
        
        if (expand && !merged) {
            cerr << prefix << "curPoint " << curPoint << " might be able to expand." << endl;
            // Now iterate through all its neighbors.
            for (unsigned int nIdx=0;nIdx<=maxFromOrder;nIdx++) {

                // get the neighboring point in question
                Neighbor neighbor=boundaryStrategy->getNeighborDirect(curPoint, nIdx);
                Point3D nPt = neighbor.pt;
                CellG* nCell = cellFieldG->get(nPt);
                cerr << prefix << "Expand check 2: Neighbor point is " << nPt << endl;
            
                // If this neighbor is:
                // -in a polarized cell
                // -that cell is different than this one
                // -and its not in the TJ list
                // -then expand
                if (nCell && nCell != curCell && nCell->type > 2) {
                    CellG* nLumen = tjWatcher->get(nPt);
                    if (nLumen == NULL) {
                    
                        cerr << prefix << "nPoint " << nPt << " is in a cell that's not a TJ. Possibly expanding." << endl;

                        EnergyFunctionCalculator* eFuncCalc = potts->getEnergyFunctionCalculator();
                        double temperature = simulator->ppdPtr->temperature;
                        double change = eFuncCalc->changeEnergy(curPoint, lumenCell, curCell,0); 
                        cerr << prefix << "Energy change for point " << curPoint << " to go from cell " << curCell->id 
                            << " to lumen cell " << lumenCell->id << " is " << change << endl;
                        
                        // Connectivity will return a penalty if we're going to change the number of TJs.
                        // However we want to ignore this penalty so we subtract if we receive it.
                        if (change > 250000) {
                            change -= 500000;
                            cerr << prefix << "Penalty received for changing TJ number.  Ignoring and subtracting 500000 from energy." << endl;
                        }
                        
                        // new stuff below //    
                        AcceptanceFunction* acceptanceFunction = potts->getAcceptanceFunction();
                        double prob = acceptanceFunction->accept(temperature, change);
    
                        cerr << prefix << "Acceptance probability for that energy change is " << prob << endl;

                        if (prob >= 1 || randGen->getRatio() < prob) {
                            cerr << prefix << "Expanding!  Accepting change. Point " << curPoint << " is going from cell " << curCell->id 
                            << " to lumen cell " << lumenCell->id << endl;
                            
                            // Accept the change
                            double firstEnergy = potts->totalEnergy();
                            cerr << prefix << "Energy before change is " << firstEnergy << endl;

                            MCell* lumenMCell = cellMap->get(lumenCell);
                            cellFieldG->set(curPoint,lumenCell);
                            lumenMCell->addPoint(curPoint);
                            mCell->removePoint(curPoint);
                            eFuncCalc->setLastFlipAccepted(true);
                            
                            double lastEnergy = potts->totalEnergy();
                            cerr << prefix << "Energy after change is " << lastEnergy << endl;
                   
                            merged = true;
                            break;

                        }
                        else   {
                            eFuncCalc->setLastFlipAccepted(false);
                            cerr << prefix << "nPoint " << nPt << " failed random test.  Not expanding!" << endl;                            
                        }
                    }
                    else {
                        cerr << prefix << "nPoint " << nPt << " is in the TJ list, continuing." << endl;
                    }
                }
                else {
                    cerr << prefix << "nPoint " << nPt << " might be in the same cell, continuing." << endl;                
                }
            } // end of for each neighbor
              
        } // end if expand
          
    } // end of for each TJ
                  
    if (! merged) {
        cerr << "SC " << simCycle << ": We didn't merge." << endl;
    }
    

    // counting variables
    int cellCountData = 0;
    int stableCellCountData = 0;
    int lumenCountData = 0;
    int shiftedCellCountData = 0;
    
    int cellsContactCellCount = 0;
    int cellsContactLumenCount = 0;
    int cellsContactMatrixCount = 0;
    
    // measure variables
    int totalVolumeData = 0;
    int totalSurfaceAreaData = 0;
    int totalCellVolumeData = 0;
    int totalCellSurfaceData = 0;
    int totalLumenVolumeData = 0;
    int totalLumenSurfaceData = 0;
    
    for(cInvItr=cellInventoryPtr->cellInventoryBegin() ; cInvItr !=cellInventoryPtr->cellInventoryEnd() ;++cInvItr ) {
                
        cell=*cInvItr;
        MCell* mCell = cellMap->get(cell);
                
        if(mCell == NULL) {
            cerr << "Removed cell.  No mCell" << endl;
            continue;
        }
        
        if (cell->volume == 0) {
            cerr << "This cell is still also a ghost.  Continuing" << endl;
            continue;
        }

        std::stringstream prefixStream;
        prefixStream << "SC " << simCycle << ", cell " << cell->id << ":  ";  
        std::string prefix = prefixStream.str();
        
        int cellType = (int)(cell->type);
        
        // TYPES
        // 0 = matrix (but no formal type designation
        // 1 = cell
        // 2 = lumen
        // 3 = stable cell
        // 4 = shifted cell

        cerr << prefix << "Cell " << cell->id << " has type " << cellType << " and volume " << cell->volume << endl;
        // count cells
        if (cellType == 1)
            cellCountData++;
        else if (cellType == 2)
            lumenCountData++;
        else if (cellType == 3)
            stableCellCountData++;
        else if (cellType == 4)
            shiftedCellCountData++;

        cerr << prefix << "Before: cellsContactCellCount is " << cellsContactCellCount << endl;
        cerr << prefix << "Before: cellsContactMatrixCount is " << cellsContactMatrixCount << endl;
        cerr << prefix << "Before: cellsContactLumenCount is " << cellsContactLumenCount << endl;

        // Count the neighbors of these cells
        if (cellType != 2) {    
            cerr << prefix << "Changing cell contact values" << endl;
            mCell->countNeighbors(neighborTrackerAccessorPtr);
            int matrixCount = mCell->matrixCount;
            int lumenCount = mCell->lumenCount;
            int cellCount = mCell->cellCount;        
            
            // set contact variables
            if (cellCount>0)
                cellsContactCellCount++;
            if (matrixCount>0)
                cellsContactMatrixCount++;
            if (lumenCount>0)
                cellsContactLumenCount++;
        }
    

        cerr << prefix << "After: cellsContactCellCount is " << cellsContactCellCount << endl;
        cerr << prefix << "After: cellsContactMatrixCount is " << cellsContactMatrixCount << endl;
        cerr << prefix << "After: cellsContactLumenCount is " << cellsContactLumenCount << endl;

        // measure volume and surface of cells
        totalVolumeData += cell->volume;
        totalSurfaceAreaData += cell->surface;
        if (cellType != 2) {
            totalCellVolumeData += cell->volume;
            totalCellSurfaceData += cell->surface;
        }
        else {
            totalLumenVolumeData += cell->volume;
            totalLumenSurfaceData += cell->surface;    
        }
    }
    cerr << "totalVolumeData is " << totalVolumeData << endl;
    
    /* 3/31/10  Figured out a simpler way to figure out how many newly dead cells there are.
     * Just count the number of cells that have started dying, add it to the previously
     * dying population, and subtract the currently dying population.
     */
     
    int newlyDeadCellCount = previousDyingCellNumber + newlyDyingCellCountData - dyingCellCountData;
    
    
    /*
    // The number of cells that died since the last simulation cycle is equal
    // to the number of cells at the end of the last simulation cycle + the number of
    // cells created in this cell cycle subtracted from the number of cells present now.
    int newlyDeadCellCount = previousLiveCellNumber + newCellCountData - cellCountData - stableCellCountData; 
    if (previousLiveCellNumber == 0)
        newlyDeadCellCount = 0;
//    cerr << prefix << "previousDeadCellNumber: " << previousDeadCellNumber << endl;
    cerr << prefix << "previousLiveCellNumber: " << previousLiveCellNumber << ", newCellCountData: " << newCellCountData 
         << ", cellCountData: " << cellCountData << ", newlyDeadCellCount: " << newlyDeadCellCount << endl;
    cerr << prefix << "previousDead + newlyDead: " << previousDeadCellNumber + newlyDeadCellCount << endl;
*/

   
            
    
    
    // count variables
    dataManager->cellNumber = cellCountData;
    dataManager->stableCellNumber = stableCellCountData;
    dataManager->lumenNumber = lumenCountData;
    dataManager->totalNumber = cellCountData + stableCellCountData + lumenCountData + shiftedCellCountData;
    dataManager->shiftedCellNumber = shiftedCellCountData;
    dataManager->livingCellNumber = cellCountData + stableCellCountData + shiftedCellCountData - dyingCellCountData;
    dataManager->separatedLumen = lumenCountData;
    dataManager->dyingCellNumber = dyingCellCountData;
    dataManager->dyingEpiCellNumber = dyingEpiCellCountData;
    dataManager->dyingLumenCellNumber = dyingLumenCellCountData;
    dataManager->deadCellNumber = previousDeadCellNumber + newlyDeadCellCount;
    dataManager->deadEpiCellNumber = previousDeadEpiCellNumber + deadEpiCellCountData;
    dataManager->deadLumenCellNumber = previousDeadLumenCellNumber + deadLumenCellCountData;
    dataManager->newCellNumber = newCellCountData;
    dataManager->totalNewCellNumber = previousTotalNewCellNumber + newCellCountData;
    dataManager->newLumenNumber = newLumenCountData;
    dataManager->totalNewLumenNumber = previousTotalNewLumenNumber + newLumenCountData;
    
    cerr << "previousDyingCellNumber: " << previousDyingCellNumber 
    << ", newlyDyingCellCountData: " << newlyDyingCellCountData 
    << ", dyingCellCountData: " << dyingCellCountData 
    << ", newlyDeadCellCount: " << newlyDeadCellCount 
    << ", previousDeadCellNumber: " << previousDeadCellNumber
    << ", deadCellNumber: " << dataManager->deadCellNumber << endl;
    
    // contact variables
    dataManager->cellsContactCells = cellsContactCellCount;
    dataManager->cellsContactMatrix = cellsContactMatrixCount;
    dataManager->cellsContactLumen = cellsContactLumenCount;
    
    // measure variables
    dataManager->totalVolume = totalVolumeData;
    dataManager->totalSurfaceArea = totalSurfaceAreaData;
    dataManager->totalCellVolume = totalCellVolumeData;
    dataManager->totalCellSurface = totalCellSurfaceData;
    dataManager->totalLumenVolume = totalLumenVolumeData;
    dataManager->totalLumenSurface = totalLumenSurfaceData;
    dataManager->cystOuterSurface = outerSurfaceData;
    if (cellCountData + stableCellCountData + shiftedCellCountData > 0) {
        dataManager->meanCellVolume = double(totalCellVolumeData) / double(dataManager->livingCellNumber + dataManager->dyingCellNumber);
        dataManager->meanCellSurface = double(totalCellSurfaceData) / double(dataManager->livingCellNumber + dataManager->dyingCellNumber);
    }
    if (lumenCountData > 0)
        dataManager->meanLumenVolume = double(totalLumenVolumeData) / (double(lumenCountData));

    cerr << "newLumenCountData is " << newLumenCountData << endl;    
    cerr << "about to write data and simCycle is " << dataManager->simCycle << endl;
    dbManager->writeData();
} // end of execute actions

 /*
 void MdckPlugin::collectCountData(int recordSimCycle) {
 
    // counting variables
    int cellCountData = 0;
    int stableCellCountData = 0;
    int lumenCountData = 0;
    int shiftedCellCountData = 0;
 
    for(cInvItr=cellInventoryPtr->cellInventoryBegin() ; cInvItr !=cellInventoryPtr->cellInventoryEnd() ;++cInvItr ) {
                
        cell=*cInvItr;
        // Can't trust that MCells will be correct! MCell* mCell = cellMap->get(cell);
                
        if(mCell == NULL) {
            cerr << prefix << "Removed cell.  No mCell" << endl;
            continue;
        }
        
        int cellType = (int)(cell->type);
        
        // TYPES
        // 0 = matrix (but no formal type designation
        // 1 = cell
        // 2 = lumen
        // 3 = stable cell

        // count cells
        if (cellType == 1)
            cellCountData++;
        else if (cellType == 2)
            lumenCountData++;
        else if (cellType == 3)
            stableCellCountData++;
        if (mCell->reachedShift)
            shiftedCellCountData++;
            
        
    
    }
 
 }*/
 
/*
 *
 * This method will split the cell randomly along one of the axis.  It will only work for a hexagonal grid representation and in 2D at the moment. It will crash if you don't specify a child and parent cell.
 */
bool MdckPlugin::doMitosis(CellG* cell) {

    cerr << "in Mitosis in mdck" << endl;

 /*
  *  *** Rewriting mitosis ***
  * - Get the rough COM of the cell
  * - Get a rough bounding box around the cell
  * - Find the real COM
  * - If no midBody
  * -- Divide randomly
  * -- Store old COM as midbody of cells
  * - If midBody
  * -- Find line between COM and midbody
  * -- Divide on that line
  * -- Store the closest point in each cell to the COM as the new midBody

  */

    cout <<"**** In New mitosis algorithm ****" << endl;
    
    CellG* childCell=0;
    CellG* parentCell=0;

    parentCell=cell;
    childCell=cell; // this is wrong! :-)
    
    MCell* curMCell = cellMap->get(cell);
    Coordinates3D<double> com = curMCell->calcHexCom();
    
    ASSERT_OR_THROW("Cell should not be NULL at mitosis point!", cell);
 
    Coordinates3D<double> midBody = curMCell->midBody;
    
    cout << "the mcellcom is " << MathUtil::ps(com) << endl;
    cerr << "and the mcell midBody is " << MathUtil::ps(midBody) << endl;
    
    // these are the values that define the line that will be used as the axis of
    // division
    double slope;
    double intercept;
 
    double comX = com.x;
    double comY = com.y;
 
    cerr << "divisionReg is " << curMCell->divisionReg << endl;
 

    // NEW: if the cell has a lumen then use the COM of the lumen as the midbody for the next division.
    curMCell->countNeighbors(neighborTrackerAccessorPtr);
    int lumenCount = curMCell->lumenCount;
    if (lumenCount == 1) {
        cerr << "This cell neighbors a lumen, so changing the midBody" << endl;
        if (midBody.z==0) {
            cerr << "old midbody is " << MathUtil::ps(midBody) << endl;
        }

        // create an mCell for the neighboring cell and get its com.
        MCell* nMCell = cellMap->get(curMCell->lumenNeighbor);
        Coordinates3D<double> ncom = nMCell->calcHexCom();
        midBody = ncom;
        cerr << "new midBody is " << MathUtil::ps(midBody) << endl;
    }        
        
    // if the cell is under regulated division and has a midBody, then find the line between the com and MB for division
    if (curMCell->divisionReg && midBody.z == 0) {
        cerr << "Found a midbody" << endl;
        
        cerr << MathUtil::ps(midBody) << endl;

        pair<double,double> lineEq = MathUtil::getLine(com,midBody);
  
        slope = lineEq.first;
        intercept = lineEq.second;
              
        cerr << "the hex slope is " << slope << " and intercept is " << intercept << endl;
        
        int spindleRandom = ntpdPtr->spindleRandom;
        
        cerr << "the spindle randomness is " << spindleRandom << endl;
        
        double angle = atan(slope);
    
        cerr << "the initial angle is " << angle << endl;        
 
        double randAngle = randGen->getRatio() * PI/2 * spindleRandom/100;
        double newAngle = angle + randAngle;
        
        if (ntpdPtr->divisionReg == 3) {
            cerr << "divisionReg is 3" << endl;
            cerr << "angle was " << newAngle << endl;
            newAngle = newAngle + PI/2;
            cerr << "now angle is " << newAngle << endl;
        }
        slope = tan(newAngle);
        
        cerr << "the angle " << randAngle << " is added to the angle" << angle << " resulting in a slope of " << slope << endl;
        intercept = com.y - slope * com.x;
        cerr << " the new intercept is " << intercept << endl;
        
    }

    // otherwise, divide randomly and set the midBody for the future
    else {
        cerr << "no midbody" << endl;

        double randAngle = randGen->getRatio() * PI/2;
        slope = tan(randAngle);
        intercept = comY - slope * comX;
        
        // set the midbody to the com
        curMCell->midBody = com;
        midBody=com;
        cerr << "set the midBody to " << MathUtil::ps(midBody) << endl;
        cerr << "the random hex slope is " << slope << " and intercept is " << intercept << endl;
 
    }
 
 // Insert *2* Transition checking code
        

    // survey all the points in this cell and see which side of the line they're on
    // if they're above the line they go in one box, below it another

    CellG* splitCell = 0;
    MCell* splitMCell;
    list<Point3D> cellPoints = curMCell->getPoints();
    list<Point3D>::iterator theIterator;
    for( theIterator = cellPoints.begin(); theIterator != cellPoints.end(); theIterator++ ) {
        Point3D curPoint = *theIterator;
        Coordinates3D<double> curCoord = MathUtil::HexCoord(curPoint);
                
        double curX = curCoord.x;
        double curY = curCoord.y;
        
        // value of equation
        // Y = mx + b
        // f(x,y) = mx + b - Y
        double value = slope * curX + intercept - curY;
        if (value < 0) {
            cerr << "1";
        }
        else if (value == 0) {
            cerr << "0";
        }
        else {
            cerr << "2";
                        
            if (splitCell){ // if the second cell has been initialized:
                // set the neighbor point to be part of the new cell 
                cellFieldG->set(curPoint, splitCell);
                splitMCell->addPoint(curPoint);
                curMCell->removePoint(curPoint);
            }
            else{ // if it hasn't been initialized:
                splitMCell = createCell(curPoint, cell, 1);
                splitCell = splitMCell->cell;
                
//                cerr << "midBody is " << MathUtil::ps(midBody) << endl;
                
                // set the midBody for the new cell
                splitMCell->midBody = midBody;
            }
        }
    }
    cerr << endl;
    
    return true;
}

MCell* MdckPlugin::createCell(Point3D firstPoint, CellG* parentCell, int cellType) {

    CellG* childCell = potts->createCellG(firstPoint);
    MCell* childMCell = new MCell(childCell,firstPoint, this);
    cellMap->insert(childCell,childMCell);
    
    MCell* parentMCell = cellMap->get(parentCell);
    parentMCell->removePoint(firstPoint);


    // if we're creating a new cell through mitosis
    if (cellType == 1) {

        childCell->type = parentCell->type;
        
        childCell->targetVolume = parentCell->targetVolume / 2;
        childCell->lambdaVolume = parentCell->lambdaVolume;
        childCell->targetSurface = parentCell->targetSurface / 2;
        childCell->lambdaSurface = parentCell->lambdaSurface;
        
        childMCell->doublingVolume = ntpdPtr->doublingVol;
        childMCell->pCounter = (parentMCell->pCounter);
        
        int parPCount = parentMCell->pCounter;
        if (parPCount <= 0 || parPCount == MCell::COUNTER_NULL) {
	        childMCell->pCounter = parPCount;
        }
        else {
            int pCounterVal = MCell::originalPCounter;
            int estimatedPElapsed = pCounterVal - parPCount;
            int randValue = randGen->getInteger(pCounterVal * 1/2, pCounterVal * 3/2);
            childMCell->pCounter = randValue - estimatedPElapsed;
            cerr << "setting new pCounter for cell " << childCell->id << " to " << childMCell->pCounter << endl;
        }	

        int parentShift = parentMCell->shiftCounter;
        
        if ( parentCell->type == 3 ) {
            // Adding a little bit of delay to make it so all cells don't shift at the same time.
            childMCell->shiftCounter = parentMCell->shiftCounter;
            //            childMCell->shiftCounter = parentMCell->shiftCounter + randGen->getInteger(0,ntpdPtr->shiftDelay/5);
            cerr << "setting new shiftCounter for cell " << childCell->id << " to " << childMCell->shiftCounter << endl;
        }

        /*
        else {
            int shiftCounterVal = MCell::originalShift;
            int estimatedElapsed = shiftCounterVal - parentShift;            
            int randValue = randGen->getInteger(shiftCounterVal * 1/2, shiftCounterVal * 3/2);
            childMCell->shiftCounter = randValue - estimatedElapsed;
            cerr << "setting new shiftCounter for cell " << childCell->id << " to " << childMCell->shiftCounter << endl;
            }*/
        
        childMCell->divisionReg = parentMCell->divisionReg;
        
        cerr << "set doublingVolume to" << childMCell->doublingVolume << endl;
        
    }
    // this is a lumen.
    else {  
        childCell->type = 2;
        
        childCell->targetVolume = 5;
        childCell->lambdaVolume = 20.0;
        //childCell->lambdaVolume = 17.0;
        childCell->targetSurface = 30;
        childCell->lambdaSurface = 0;
    }

    return childMCell;
}

bool MdckPlugin::isBoundaryPixel(Point3D pt) {
    return isBoundaryPixel(pt, cellFieldG->get(pt));
}

bool MdckPlugin::isBoundaryPixel(Point3D pt, CellG* inCell) {

//    cerr << "in isBoundaryPixel. Test if pt " << pt << " is on the boundary of cell " << inCell->id << endl;

    CellG* cell = inCell;
    CellG* nCell;
    Point3D nPt;
    
    bool result = false;
    
    int maxFromOrder = boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(1);
                
//    cerr << "maxFromOrder is " << maxFromOrder << endl;
    
    // iterate through the neighboring points

    for (unsigned int nIdx=0;nIdx<=maxFromOrder;nIdx++) {
//        cerr << "neighbor point nIdx is " << nIdx << endl;
        // get the neighboring point in question
        Neighbor neighbor=boundaryStrategy->getNeighborDirect(pt, nIdx);
        nPt = neighbor.pt;
//        cerr << "neighbor point is " << nPt << endl;
        nCell = cellFieldG->get(nPt);
        if (nCell) {
//            cerr << "checking if neighbor cell " << nCell->id << " is the same as our cell " << cell->id << endl;
//            cerr << "nCell is " << nCell << " and cell is " << cell << endl;
            MCell* curMCell = cellMap->get(cell);
            MCell* curNMCell = cellMap->get(nCell);
//            cerr << "curMCell->id is " << curMCell->id << endl;
//            cerr << "curNMCell->id is " << curNMCell->id << endl;
        }
        if (nCell != cell) {
//            cerr << "It's different! Setting result to true" << endl;
            result = true;
        }
    }
    return result;
    
//    cerr << "done with for statement.  Going to return false" << endl;
//    return false;
}

/*
 * This function will set the hex offsets, depending on whether curPoint has an even or odd
 * y coordinate.
 *
 */
int* MdckPlugin::getOffsetsIndex(const Point3D & curPoint) {

    int* offsetsIndex = new int[6];
    
//    cerr << "in setHexOffsets" << endl;
    
//    cerr << "curPoint is " << curPoint << endl;
    
    /* This code relies on the offsets appearing in different ways
      depending on whether y is even or odd.
      
      Even:
      
         3   5
     1   x   0
         2   4   
    
      Odd:
      
      5   3
      1   x   0
      4   2   
      
      And the desired ordering will be:
      
        5   0
      4   x   1
        3   2
    
    */
    

    // Even:
    if (curPoint.y % 2 == 0) {
//        cerr << "creating offsetsIndex assignments" << endl;
        offsetsIndex[0] = 5;
        offsetsIndex[1] = 0;
        offsetsIndex[2] = 4;
        offsetsIndex[3] = 2;
        offsetsIndex[4] = 1;
        offsetsIndex[5] = 3;
    } // Odd:
    else {
        offsetsIndex[0] = 3;
        offsetsIndex[1] = 0;
        offsetsIndex[2] = 2;
        offsetsIndex[3] = 4;
        offsetsIndex[4] = 1;
        offsetsIndex[5] = 5;
    }

    return offsetsIndex;
//    cerr << "done with setHexOffSets " << endl;
}


// This method assume the dbManager has already been initialized
void MdckPlugin::initPottsParamsDB() {
    ParamManager* pManager = dbManager->paramManager;
    
    PottsParseData* pottsData = simulator->ppdPtr;
    pManager->dimX = pottsData->dim.x;
    pManager->dimY = pottsData->dim.y;
    pManager->anneal = pottsData->anneal;
    pManager->steps = pottsData->numSteps;
    pManager->temp = pottsData->temperature;
    pManager->flip2DimRatio = pottsData->flip2DimRatio;
    pManager->neighborOrder = pottsData->neighborOrder;

    cerr << "dimX is " << pManager->dimX << " and dimY is " << pManager->dimY << endl;
}

void MdckPlugin::initMdckParamsDB() {
    ParamManager* pManager = dbManager->paramManager;

    pManager->targetVolume = ntpdPtr->targetVolume;
    pManager->lambdaVolume = ntpdPtr->lambdaVolume;
    pManager->shiftTargetVolume = ntpdPtr->shiftTargetVolume;
    pManager->cellCycle = ntpdPtr->cellCycle;
    pManager->shiftedCycleDelay = ntpdPtr->shiftedCycleDelay;
    pManager->lambdaSurface = ntpdPtr->lambdaSurface;
    pManager->polarDelay = ntpdPtr->polarDelay;
    pManager->lgrSubtract = ntpdPtr->lgrSubtract;
    pManager->shiftDelay = ntpdPtr->shiftDelay;
    pManager->doublingVol= ntpdPtr->doublingVol;
    pManager->spindleRandom = ntpdPtr->spindleRandom;
    pManager->divisionReg = ntpdPtr->divisionReg;
    pManager->multiplier = ntpdPtr->multiplier;
    pManager->lumenGrowthRate = ntpdPtr->lumenGrowthRate;
    pManager->randomSeed = ntpdPtr->randomSeed;
    pManager->deathRateLumen = ntpdPtr->deathRateLumen;
    pManager->deathRateEpi = ntpdPtr->deathRateEpi;
    pManager->dyingShrinkRate = ntpdPtr->dyingShrinkRate;
    pManager->clusterProb = ntpdPtr->clusterProb;
    pManager->shiftRatio = ntpdPtr->shiftRatio;
    
    
}

void MdckPlugin::initContactParamsDB() {
    ParamManager* pManager = dbManager->paramManager;

    bool pluginAlreadyRegisteredFlag = false;
    
    ContactPlugin * contactPlug = (ContactPlugin *) Simulator::pluginManager.get("Contact",&pluginAlreadyRegisteredFlag);
    cerr << "pluginAlreadyRegisteredFlag = " << pluginAlreadyRegisteredFlag << endl;
    
    ContactEnergy contactEnergy = contactPlug->contactEnergy;
  
    ContactParseData * cpdPtr = contactEnergy.cpdPtr;
    cerr << "contact parse data->neighborOrder is " << cpdPtr->neighborOrder << endl;
    
    cerr <<"cpdPtr->contactEnergyTuppleVec.size()="<<cpdPtr->contactEnergyTuppleVec.size()<<endl;

    pManager->contactNeighborOrder = cpdPtr->neighborOrder;    
    cerr <<"pManager->neighborOrder = " << pManager->contactNeighborOrder << endl;


    std::map<std::string,double> * contactEnergies = pManager->contactEnergies;

    for ( int i=0 ; i < cpdPtr->contactEnergyTuppleVec.size() ; ++ i){
        std::string curName = cpdPtr->contactEnergyTuppleVec[i].type1Name + "_" + cpdPtr->contactEnergyTuppleVec[i].type2Name;
        contactEnergies->insert(pair<std::string,double>(curName,cpdPtr->contactEnergyTuppleVec[i].energy));  
    }      

}

void MdckPlugin::readXML(XMLPullParser &in) {

    dbManager = new DBManager();
    dbManager->init();
    dataManager = dbManager->dataManager;
   
   cerr << "about to initialize params" << endl;
//   dbManager->folderName = "test folder name";
   cerr << "reall about to initialize params" << endl;
   dbManager->initFolderName();
   cerr << "folder name is " << dbManager->folderName << endl;
   
   
   
   
   in.skip(TEXT);
   
   pd=&ntpd;

   while (in.check(START_ELEMENT)) {
      if (in.getName() == "CheckLatticeSanityFrequency") {
      
         ntpd.checkFreq = BasicString::parseUInteger(in.matchSimple());
         ntpd.checkSanity=true;
   
      }
      else if (in.getName() == "PolarizationDelay") {
          ntpd.polarDelay = BasicString::parseUInteger(in.matchSimple());
      }
      else if (in.getName() == "ShiftDelay") {
          ntpd.shiftDelay = BasicString::parseUInteger(in.matchSimple());
      }
      else if (in.getName() == "LgrSubtract") {
          ntpd.lgrSubtract = BasicString::parseUInteger(in.matchSimple());
      }
      else if (in.getName() == "DoublingVolume") {
          ntpd.doublingVol = BasicString::parseUInteger(in.matchSimple());
      }
      else if (in.getName() == "ShiftTargetVolume") {
          ntpd.shiftTargetVolume = BasicString::parseDouble(in.matchSimple());
      }
      else if (in.getName() == "LumenGrowthRate") {
          ntpd.lumenGrowthRate = BasicString::parseDouble(in.matchSimple());
      }
      else if (in.getName() == "CellCycle") {
          ntpd.cellCycle = BasicString::parseUInteger(in.matchSimple());
      }
      else if (in.getName() == "TargetVolume") {
          ntpd.targetVolume = BasicString::parseUInteger(in.matchSimple());
      }
      else if (in.getName() == "LambdaVolume") {
          ntpd.lambdaVolume = BasicString::parseDouble(in.matchSimple());
      }
      else if (in.getName() == "ShiftedCycleDelay") {
          ntpd.shiftedCycleDelay = BasicString::parseDouble(in.matchSimple());
      }
      else if (in.getName() == "LambdaSurface") {
          ntpd.lambdaSurface = BasicString::parseDouble(in.matchSimple());
      }
      else if (in.getName() == "SpindleRandomness") {
          ntpd.spindleRandom = BasicString::parseUInteger(in.matchSimple());
      }
      else if (in.getName() == "DivisionReg") {
          ntpd.divisionReg = BasicString::parseUInteger(in.matchSimple());
      }
      else if (in.getName() == "Multiplier") {
          ntpd.multiplier = BasicString::parseDouble(in.matchSimple());
      }
      else if (in.getName() == "RandomSeed") {
          ntpd.randomSeed = BasicString::parseUInteger(in.matchSimple());
      }
      else if (in.getName() == "DeathRateLumen") {
          ntpd.deathRateLumen = BasicString::parseDouble(in.matchSimple());
      }
      else if (in.getName() == "DeathRateEpi") {
          ntpd.deathRateEpi = BasicString::parseDouble(in.matchSimple());
      }
      else if (in.getName() == "DyingShrinkRate") {
          ntpd.dyingShrinkRate = BasicString::parseDouble(in.matchSimple());
      }
      else if (in.getName() == "ClusterProb") {
          ntpd.clusterProb = BasicString::parseDouble(in.matchSimple());
      }
      else if (in.getName() == "ShiftRatio") {
          ntpd.shiftRatio = BasicString::parseDouble(in.matchSimple());
      }

      else {
          cerr << "Not expecting the param: " << in.getName() << " at location " << in.getLocation() << endl;
         throw BasicException(string("Unexpected element '") + in.getName() +
                              "'!", in.getLocation());
      }
   
      in.skip(TEXT);
   }
}





void MdckPlugin::writeXML(XMLSerializer &out) {
  
}





















































































///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void MdckPlugin::field3DChange(const Point3D &pt, CellG *newCell,
				  CellG *oldCell) {

   
    if(newCell==oldCell){//happens during multiple calls to se fcn on the same pixel woth current cell - should be avoided
      return;
    }

   const Field3DIndex & field3DIndex=adjNeighbor.getField3DIndex();
   
   long currentPtIndex=0;
   long adjNeighborIndex=0;
   long adjFace2FaceNeighborIndex=0;
   
   CellG * currentCellPtr=0;
   CellG * adjCellPtr=0;

  unsigned int token = 0;
  double distance;
  int oldShift = 0;
  int newShift = 0;
  Point3D n;
  Point3D ptAdj;
  CellG *nCell=0;
  Neighbor neighbor;
  
   set<MdckData> * oldCellMdckDataSetPtr=0;
   set<MdckData> * newCellMdckDataSetPtr=0;
   pair<set<MdckData>::iterator,bool > set_NSD_itr_OK_Pair;
   set<MdckData>::iterator set_NSD_itr;

      
   if(newCell){

      newCellMdckDataSetPtr =  &mdckAccessor.get(newCell->extraAttribPtr)->cellNeighbors;
   }

   if(oldCell){

      oldCellMdckDataSetPtr =  &mdckAccessor.get(oldCell->extraAttribPtr)->cellNeighbors;
   }

   
   currentPtIndex=field3DIndex.index(pt);
   currentCellPtr=cellFieldG->getByIndex(currentPtIndex);

         
   if(oldCell){
      
      /// Now will adjust common surface area with cell neighbors
      long temp_index;
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         adjCellPtr=cellFieldG->get(neighbor.pt);
   
               if( adjCellPtr != oldCell ){ /// will decrement commSurfArea with all face 2 face neighbors
/*                  cerr << prefix<<"adjCellPtr="<<adjCellPtr<<" oldCell="<<oldCell<<endl;
                  cerr << prefix<<"ptAdj="<<ptAdj<<" pt="<<pt<<endl;*/
                  set_NSD_itr = oldCellMdckDataSetPtr->find(MdckData(adjCellPtr));
                  if( set_NSD_itr != oldCellMdckDataSetPtr->end() ){
                     set_NSD_itr->decrementCommonSurfaceArea(*set_NSD_itr); ///decrement commonSurfArea with adj cell
                     if(set_NSD_itr->OKToRemove()) ///if commSurfArea reaches 0 I remove this entry from cell neighbor set
                        oldCellMdckDataSetPtr->erase(set_NSD_itr);
   
                  }else{
                     cerr <<"Could not find cell address in the boundary - set of cellNeighbors is corrupted. Exiting ..."<<endl;
                     exit(0);
                  }
   
   
                  if(adjCellPtr){ ///now process common area for adj cell provided it is not the oldCell
                     set<MdckData> &set_NSD_ref = mdckAccessor.get(adjCellPtr->extraAttribPtr)->cellNeighbors;
                     set<MdckData>::iterator sitr;
                     sitr=set_NSD_ref.find(oldCell);
                     if(sitr!=set_NSD_ref.end()){
                        sitr->decrementCommonSurfaceArea(*sitr); ///decrement common area
                        if(sitr->OKToRemove()) ///if commSurfArea reaches 0 I remove this entry from cell neighbor set
                           set_NSD_ref.erase(sitr);
   
                     }
                  }
               }
            


      }
   }
   
   if(newCell){
      
      
      /// Now will adjust common surface area with cell neighbors      
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         adjCellPtr=cellFieldG->get(neighbor.pt);


            if( adjCellPtr != newCell ){ ///if adjCellPtr denotes foreign cell we increase common area and insert set entry if necessary
//                cerr << prefix<<"inserting adjCellPtr="<<adjCellPtr <<" ptAdj="<<ptAdj<<" into newCell="<<newCell<<" pt="<<pt<<endl;
               set_NSD_itr_OK_Pair=newCellMdckDataSetPtr->insert(MdckData(adjCellPtr));/// OK to insert even if
               ///duplicate, in such a case an iterator to existing MdckData(adjCellPtr) obj is returned

               set_NSD_itr=set_NSD_itr_OK_Pair.first;
               set_NSD_itr->incrementCommonSurfaceArea(*set_NSD_itr); ///increment commonSurfArea with adj cell

               if(adjCellPtr){ ///now process common area for adj cell
                  set<MdckData> &set_NSD_ref  = mdckAccessor.get(adjCellPtr->extraAttribPtr)->cellNeighbors;
                  pair<set<MdckData>::iterator,bool> sitr_OK_pair=set_NSD_ref.insert(newCell);
                  set<MdckData>::iterator sitr=sitr_OK_pair.first;
                  sitr->incrementCommonSurfaceArea(*sitr); ///increment commonSurfArea of adj cell with current cell
               }

            }

         


      }
   }

   token = 0;
   distance = 0;

   

   if(!oldCell){ ///this special case is required in updating common Surface Area with medium
                 ///in this case we update surface of adjCell only (we do not update medium's neighbors list or its contact surfaces)

      /// Now will adjust common surface area with cell neighbors
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         adjCellPtr=cellFieldG->get(neighbor.pt);

      
            if( adjCellPtr != oldCell && !(ptAdj == pt)){ /// will decrement commSurfArea with all face 2 face neighbors
//                cerr << prefix<<"!old cell section  adjCellPtr="<<adjCellPtr <<" ptAdj="<<ptAdj<<"  oldCell="<<oldCell<<" pt="<<pt<<endl;
               if(adjCellPtr){ ///now process common area for adj cell provided it is not the oldCell
                  set<MdckData> &set_NSD_ref = mdckAccessor.get(adjCellPtr->extraAttribPtr)->cellNeighbors;
                  set<MdckData>::iterator sitr;
                  sitr=set_NSD_ref.find(oldCell);
                  if(sitr!=set_NSD_ref.end()){
                     sitr->decrementCommonSurfaceArea(*sitr); ///decrement common area
                     if(sitr->OKToRemove()){ ///if commSurfArea reaches 0 I remove this entry from cell neighbor set
                        set_NSD_ref.erase(sitr);
//                         cerr << prefix<<"removing from boundary"<<endl;
                        
                     }
                     
                  }
               }
            }
         
         

      }

   
   }

   token = 0;
   distance = 0;

      
   if(!newCell){  ///this special case is required in updating common Surface Area with medium
                  ///in this case we update surface of adjCell only (we do not update medium's neighbors list or its contact surfaces)
                  
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }

         if(cellFieldG->isValid(neighbor.pt)){

            adjCellPtr=cellFieldG->get(neighbor.pt);

            if( adjCellPtr != newCell ){ ///if adjCellPtr denotes foreign cell we increase common area and insert set entry if necessary

               if(adjCellPtr){ ///now process common area of adj cell with medium in this case
                  set<MdckData> &set_NSD_ref  = mdckAccessor.get(adjCellPtr->extraAttribPtr)->cellNeighbors;
                  pair<set<MdckData>::iterator,bool> sitr_OK_pair=set_NSD_ref.insert(newCell);
                  set<MdckData>::iterator sitr=sitr_OK_pair.first;
                  sitr->incrementCommonSurfaceArea(*sitr); ///increment commonSurfArea of adj cell with current cell
               }

            }

         }


      }

   }

   
   ///temporarily for testing purposes I set 
   
   if(ntpdPtr->checkSanity){
   
      ++changeCounter;

      if(!(changeCounter % ntpdPtr->checkFreq)){
         //cerr << prefix<<"OLD CELL ADR: "<<oldCell<<" NEW CELL ADR: "<<newCell<<endl;
         cerr <<"ChangeCounter:"<<changeCounter<<endl;
         testLatticeSanityFull();
   
      }
   }
   
   
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

double distance(double x1,double y1,double z1,double x2,double y2,double z2){
   return sqrt (
                  (x1-x2)*(x1-x2)+
                  (y1-y2)*(y1-y2)+
                  (z1-z2)*(z1-z2)
               );
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void MdckPlugin::testLatticeSanityFull(){



   Dim3D fieldDim=cellFieldG->getDim();

   Point3D pt(0,0,0);
   Point3D ptAdj;
   Neighbor neighbor;



   ///Now will have to get access to the pointers stored in cellFieldG from Potts3D


   CellG * currentCellPtr;
   CellG * adjCellPtr;

   map<CellG*,set<MdckData> > mapCellMdckData;
   map<CellG*,set<MdckData> >::iterator mitr;
   
   /// check neighbors of each cell - will loop over each lattice point and check if point belongs to boundary, then will examine neighbors

   unsigned int token = 0;
   double distance;

   set<MdckData> * set_NSD_ptr;
   
   pair<set<MdckData>::iterator,bool > set_NSD_itr_OK_Pair;
   set<MdckData>::iterator set_NSD_itr;

      
   for(int z=0 ; z < fieldDim.z ; ++z)
      for(int y=0 ; y < fieldDim.y ; ++y)
         for(int x=0 ; x < fieldDim.x ; ++x){
            pt.x=x;
            pt.y=y;
            pt.z=z;

            token=0;
            distance=0;
            
//             currentPtIndex=field3DIndex.index(pt);
            //currentCellPtr=cellFieldG->getByIndex(currentPtIndex);
            currentCellPtr=cellFieldG->get(pt);
            if(!currentCellPtr)
               continue; //skip the loop if the current latice site does not belong to any cell
            if(!isBoundaryPixel(pt))
               continue; //inner pixel does not bring new neighbors
               
            mitr=mapCellMdckData.find(currentCellPtr);
            if(mitr != mapCellMdckData.end() ){
               set_NSD_ptr = & (mitr->second) ;
            }else{
               mapCellMdckData.insert(make_pair(currentCellPtr,set<MdckData>()));
               mitr=mapCellMdckData.find(currentCellPtr);
               set_NSD_ptr = &(mitr->second);
            }

         for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
            neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
            if(!neighbor.distance){
            //if distance is 0 then the neighbor returned is invalid
            continue;
            }
            adjCellPtr=cellFieldG->get(neighbor.pt);
               
               if(adjCellPtr != currentCellPtr){
                  set_NSD_itr_OK_Pair = set_NSD_ptr->insert(MdckData(adjCellPtr));/// OK to insert even if
                  ///duplicate, in such a case an iterator to existing MdckData(adjCellPtr) obj is returned
   
                  set_NSD_itr=set_NSD_itr_OK_Pair.first;
                  set_NSD_itr->incrementCommonSurfaceArea(*set_NSD_itr); ///increment commonSurfArea with adj cell

               }
               
            }

         }

         
      //Now do lattice sanity checks
      if(mapCellMdckData.size() != cellInventoryPtr->getCellInventorySize()){
         cerr <<"Number of cells in the mapCellMdckData = "<<mapCellMdckData.size()
         <<" is different than in cell inventory:  "<< cellInventoryPtr->getCellInventorySize()<<endl;
         exit(0);
      }
      CellInventory::cellInventoryIterator cInvItr;
      CellG * cell;
      int counter=0;
      
      for(cInvItr=cellInventoryPtr->cellInventoryBegin() ; cInvItr !=cellInventoryPtr->cellInventoryEnd() ;++cInvItr ){
         
         cell=*cInvItr;
         mitr = mapCellMdckData.find(cell);
         if(mitr==mapCellMdckData.end()){
            cerr <<"Cell "<<cell<<" does not appear in the just initialized mapCellMdckData"<<endl;
            exit(0);
            
         }
         set_NSD_ptr=&(mitr->second);
         
         if(! (*set_NSD_ptr == mdckAccessor.get(cell->extraAttribPtr)->cellNeighbors)){
            cerr <<"Have checked "<<counter<<" cells"<<endl;
            cerr <<"set of MdckData do not match for cell: "<<cell<<endl;
            exit(0);
         }
         
         ++counter;
      }
   
     cerr <<"FULL TEST: LATTICE IS SANE!!!!!"<<endl;

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*bool MdckPlugin::isBoundaryPixel(Point3D pt){
   
    //     const vector<Point3D> & adjNeighborOffsetsVec=adjNeighbor.getAdjFace2FaceNeighborOffsetVec(pt);
        CellG * currentCellPtr=cellFieldG->get(pt);
    //     CellG * adjCellPtr;
        CellG * nCell;
        unsigned int token = 0;
        double distance = 0;
        Point3D n;

        
        cerr << "point " << pt << " has the following neighbors:" << endl;
          while (true) {
             n = cellFieldG->getNeighbor(pt, token, distance, false);
             cerr << n << endl;
             cerr << " distance is " << distance << endl;
             if (distance > 1) break;//only nearest neighbors
             nCell = cellFieldG->get(n);
             if(nCell != currentCellPtr)
                return true;
          }
          
       return false;
   }
  */
   

        


// *2* Transition checking code
   //**** FOR THE TIME BEING, IGNORE TRANSITIONS ****
    
    // now that we have our slope and intercept, we need to figure out a way
    // to move along that line and make sure that there aren't too many transitions
    
    // to do this we'll do the following:
    // -figure out if the line intersects with the left boundary of the bounding box
    // --if so, move in the x direction
    // --if not, move in the y direction
    // -move from the smaller value of x or y to the larger, in the real value plane,
    //  by increasing x/y by 0.5 or 1 each time.
    // -check the neighbors of the current cell and pick the one that's closest to the line at that
    //  value of x or y
    // -then run the already existing algorithm on that neighbor
    
    // THIS IS WHERE THE MAJOR DIFFERENCES SHOULD BEGIN.
    // pick one of the three hexagonal axes at random
    // 0 = Y axis
    // 1 = +X+Y axis
    // 2 = -X+Y axis


    //int axisType = randGen->getInteger(0,2);  

    //cout << " we've chosen the following axis: " << axisType << endl;
    
    // Travel along the points within that define the equation of the line,
    // checking whether the points are inside or outside the cell.  If the number of transitions
    // is equal to two, then the cell doesn't loop back on itself and this is a valid axis.  If the number
    // of transitions is less than two then the bounding box was incorrectly chosen and we should fail.
    // If the number is greater than two then this axis is invalid and we should choose a new one and recheck.
    
    /*
    int numTrans = 0;
    CellG *lastCell = NULL;
        
    // figure out if we're moving along the x axis or the y axis
    // find the X value if Y is equal to the minimum value
    // Y = mx + b
    // x = (Y-b) / m
    double xAtYMin = (double(yMin) - intercept) / slope;
    if (xAtYMin => xMin && xAtMin <= xMax) {
        cerr << " the line intersects the minimum Y value of the box at x " << xAtYMin << endl;
        
        // move along the line from the 
        for(int i=0;i<maxExtent*2+1;i++) {
            

    }
    
    
    
        
    for (int i=0;i<maxExtent*2+1;i++) {
        Point3D curPoint;
    
        if (axisType == 0) {
            int curX = minX + i;
            curPoint = Point3D(curX,ycm,0);
        }
        else if (axisType == 1) {
            int curY = minY + i;
            int curX = solveEforX(double(curY),double(xcm),double(ycm),1);
            curPoint = Point3D(curX,curY,0);
            cout << " axis 1, curPoint " << curPoint.x << ", " << curPoint.y << endl;
        }
        else if (axisType == 2) {
            int curY = minY + i;
            int curX = solveEforX(double(curY),double(xcm),double(ycm),2);
            curPoint = Point3D(curX,curY,0);
            cout << " axis 2, curPoint " << curPoint.x << ", " << curPoint.y << endl;
        }                
        
        cout << " evaluating point " << curPoint.x << ", " << curPoint.y << endl;
        
        // Get cell this point resides in
        CellG *curCell =cellFieldG->get(curPoint);
        
        cout << " curPoint is " << curPoint << endl;
        
        if (curCell == NULL) 
            cout << " no cell yet" << endl;
        else {
            cout << " it resides in cell " << curCell << endl;
        }
        
        // if the current cell is the same as the last cell we have not transitioned.
        // if it's different then we have
        if (curCell != lastCell && (
            curCell == cell || lastCell == cell)) {
            numTrans++;
            cout << " found a transition" << endl;
        }
        lastCell = curCell;
    }

    cout << " total transitions " << numTrans << endl;
        
    */

