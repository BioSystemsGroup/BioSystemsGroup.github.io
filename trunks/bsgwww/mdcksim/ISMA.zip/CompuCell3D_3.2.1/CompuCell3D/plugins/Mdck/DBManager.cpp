/***********************************************************************

Copyright (c) Jesse Engelberg.

 Others may
 also hold copyrights on code in this file.  See the CREDITS.txt file
 in the top directory of the distribution for details.


This is free software; you can redistribute it and/or modify it
 under the terms of the GNU Lesser General Public License as published
 by the Free Software Foundation; either version 2.1 of the License, or
 (at your option) any later version.

This is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this code; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301
 USA
***********************************************************************/
#include "DBManager.h"

#include <iostream>
#include <iomanip>
#include <sstream>
#include <stdio.h>
#include "stock.h"
//#include "printdata.h"

using namespace std;

DBManager::DBManager(): db("mdckdb"),server(0),user("testuser"),pass("dbpassword"),folderName("mdck_"){

    simNumber = 1;
    paramManager = new ParamManager(simNumber,folderName);
    dataManager = new DataManager(simNumber,folderName);
    
}

int DBManager::init() {
    cerr << "In DBManager init()" << endl;
    bool dbExists = false;
    bool paramTablesExist = false;
    bool dataTablesExist = false;
    
    const char* pottsParamTableName = paramManager->pottsParamTableName;
    const char* contactParamTableName = paramManager->contactParamTableName;
    const char* mdckParamTableName = paramManager->mdckParamTableName;    
    
    const char* countDataTableName = dataManager->countDataTableName;
    const char* measureDataTableName = dataManager->measureDataTableName;
    const char* contactDataTableName = dataManager->contactDataTableName;
    

    try {
	    // Establish the connection to the database server, checking if the database exists as you go
	    con = new mysqlpp::Connection(db, server, user, pass);
	    dbExists = true;
	    
	    // Test if the parameter tables exist
	    try{
    	    int pottsParamRowCount = con->count_rows(pottsParamTableName);
    	    int contactParamRowCount = con->count_rows(contactParamTableName);
    	    int mdckParamRowCount = con->count_rows(mdckParamTableName);
    	    if (pottsParamRowCount > 0) {
    	        
    	        // verify that all three param tables have the same number of rows.
    	        if (pottsParamRowCount == contactParamRowCount && pottsParamRowCount == mdckParamRowCount)
            	    initSimNumber();
        	    else {
        	        cerr << "Database is corrupted.  Params tables have different numbers of rows.  Please repair." << endl;
    	            exit(-1);
	            }
        	        
    	    }
        	else
        	    simNumber = 1;
            cerr << "pottsParamsRowCount is " << pottsParamRowCount << endl;
            cerr << "simNumber is " << simNumber << endl;
            paramTablesExist = true;

        }
        catch (const mysqlpp::BadQuery& er) {
    	    // Handle any query errors
    	    cerr << "Params table doesn't exist: " << er.what() << endl;
    	    paramTablesExist = false;
	    }

	    // Test if the data tables exist
	    try{
    	    int countDataRowCount = con->count_rows(countDataTableName);
    	    int measureDataRowCount = con->count_rows(measureDataTableName);
    	    int contactDataRowCount = con->count_rows(contactDataTableName);
    	    if (countDataRowCount > 0) {
    	        
    	        // verify that all three param tables have the same number of rows.
    	        if (countDataRowCount == measureDataRowCount && countDataRowCount == contactDataRowCount)
                    cerr << "Data tables have the correct number of rows." << endl;
        	    else {
        	        cerr << "Database is corrupted.  Data tables have different numbers of rows.  Please repair." << endl;
    	            exit(-1);
	            }
        	        
    	    }
        	else
                cerr << "Data table exist but have no data." << endl;
            cerr << "countDataRowCount is " << countDataRowCount << endl;
            cerr << "simNumber is " << simNumber << endl;
            dataTablesExist = true;

        }
        catch (const mysqlpp::BadQuery& er) {
    	    // Handle any query errors
    	    cerr << "Data tables don't exist: " << er.what() << endl;
    	    dataTablesExist = false;
	    }
    } // if the database doesn't exist, we can't connect to it at all!
    catch (const mysqlpp::Exception& er) {
        // Catch-all for any other MySQL++ exceptions, specifically that the database doesn't exist.
        cerr << "Database doesn't exist: " << er.what() << endl;
        dbExists = false;
    }

    // Now do the work.
    	    
    try {	    
        // If db doesn't exist, create it and the table
        if (!dbExists) {
            createDB(); // note that createDB also establishes a connection to the database.
            createTable(pottsParamTableName,paramManager->pottsParamTableCreateQuery);
            createTable(contactParamTableName,paramManager->contactParamTableCreateQuery);
            createTable(mdckParamTableName,paramManager->mdckParamTableCreateQuery);
            createTable(countDataTableName,dataManager->countDataTableCreateQuery);
            createTable(measureDataTableName,dataManager->measureDataTableCreateQuery);
            createTable(contactDataTableName,dataManager->contactDataTableCreateQuery);
               
            return 0;
        }
        else {  
            if (paramTablesExist && dataTablesExist) {
                cerr << "Tables both exist, continuing" << endl;
            }
            else if (!paramTablesExist && !dataTablesExist) {
                cerr << "Param and data tables do not exist.  Creating both." << endl;
                createTable(pottsParamTableName,paramManager->pottsParamTableCreateQuery);
                createTable(contactParamTableName,paramManager->contactParamTableCreateQuery);
                createTable(mdckParamTableName,paramManager->mdckParamTableCreateQuery);
                createTable(countDataTableName,dataManager->countDataTableCreateQuery);
                createTable(measureDataTableName,dataManager->measureDataTableCreateQuery);
                createTable(contactDataTableName,dataManager->contactDataTableCreateQuery);
            }
            else {
                cerr << "Tables are not in sync.  Check database." << endl;
                exit(-1);
            }
            return 0;
        }
    }
    catch (const mysqlpp::Exception& er) {
        // Database or table creation failed.  
        cerr << "Datbase or table creation failed. Check DB!" << er.what() << endl;
        exit(-1);
    }
    
 
    
}    

// Note that this does not catch SQL Exceptions, which must be handled by surrounding code.
int DBManager::createDB() {
    cerr << "In the create DB code" << endl;
    
    cerr << "Connecting to server " << (server ? server : "localhost") << " as " << user << " with password " << pass << endl;
    // connect to the server
    con = new mysqlpp::Connection(0, server, user, pass);
    
    // create the new database
    if (con->create_db(db) && con->select_db(db)) {
        cerr << "Database " << db << " created and selected" << endl;
	}
	else {
    	cerr << "Error creating DB: " << con->error() << endl;
    	throw mysqlpp::BadQuery(con->error(), con->errnum());
	}

    return 0;
}

// Note that this does not catch SQL Exceptions, which must be handled by surrounding code.
int DBManager::createTable(const char* tableName, const char* tableQuery) {
    cerr << "In create table code" << endl;
    
	// Send the query to create the stock table and execute it.
	cerr << "Creating table " << tableName << " and query end is " << tableQuery << endl;
	mysqlpp::Query query = con->query();
	query << "CREATE TABLE " << tableName << tableQuery;
	query.execute();
    
    cerr << "Created table " << tableName << endl;
    return 0;
}    

/*
 * This method will query the database for the sim number and then set the simNumber variable to
 * that value + 1, which will be the current simulation simNumber.  It does not handle exceptions,
 * and assumes the connection to the DB has already been established and that the table mdckParmeters exists.
 */
int DBManager::initSimNumber() {

    mysqlpp::Query query = con->query();
    query << "select max(simnumber) from " << paramManager->pottsParamTableName;
    cerr << "about to store query: " << query << endl;
    mysqlpp::StoreQueryResult res = query.store();
    cerr << "stored query with result size of " << res.size() << endl;
        
    mysqlpp::Row simNumRow = res[0];
    simNumber = simNumRow[0]+1;
    paramManager->simNumber = simNumber;
    dataManager->simNumber = simNumber;
    
    return 0;
}

string DBManager::initFolderName() {
    cerr << "in initFolderName" << endl;
    string temp;
    stringstream stream;
    stream << setfill('0') << setw(7) << simNumber;
    stream >> temp;
    cerr << "temp = " << temp << endl;
    folderName += temp;
    cerr << "folderName = " << folderName << endl;
    
    paramManager->folderName = folderName;
    dataManager->folderName = folderName;
    
    return folderName;
}

int DBManager::writeParams() {

    paramManager->writeParams(con->query());
    
    

}

int DBManager::writeData() {
    dataManager->writeData(con->query());
}

ParamManager::ParamManager(int _simNumber, string _folderName) : pottsParamTableName("pottsParameters"),contactParamTableName("contactParameters"),mdckParamTableName("mdckParameters"),dimX(0),dimY(0),anneal(0),steps(0),temp(0.0),flip2DimRatio(0.0),neighborOrder(0),polarDelay(0),shiftDelay(0),lgrSubtract(0),doublingVol(0), shiftTargetVolume(0), cellCycle(0), spindleRandom(0), divisionReg(0), targetVolume(0),lambdaVolume(0),shiftedCycleDelay(0),lambdaSurface(0), multiplier(0), lumenGrowthRate(0), randomSeed(0), deathRateLumen(0),deathRateEpi(0),dyingShrinkRate(0),clusterProb(0) {

 contactEnergies = new std::map<std::string,double>();
    
    simNumber = _simNumber;
    folderName = _folderName;
    
//    mdckParams = new mdckParameters();
    

	
	pottsParamTableCreateQuery = "(" 
	    "  simnumber INT NOT NULL, " 
	    "  foldername VARCHAR(100), " 
	    "  dimx INT, " 
	    "  dimy INT, "
	    "  anneal INT, "
        "  steps INT, "	    
        "  temperature DOUBLE, "
        "  flip2dimratio DOUBLE, "
        "  neighbororder INT, "
	    "  primary key (simnumber) )" 
	    "ENGINE = InnoDB " 
	    "CHARACTER SET utf8 COLLATE utf8_general_ci";
	    
    contactParamTableCreateQuery = "(" 
	    "  simnumber INT NOT NULL, " 
	    "  foldername VARCHAR(100), " 
        "  stablecell_stablecell DOUBLE, "
        "  stablecell_cell DOUBLE, "
        "  stablecell_lumen DOUBLE, "
        "  stablecell_matrix DOUBLE, "
        "  stablecell_shiftedcell DOUBLE, "
        "  cell_cell DOUBLE, "
        "  cell_lumen DOUBLE, "
        "  cell_matrix DOUBLE, "
        "  cell_shiftedcell DOUBLE, "
        "  lumen_lumen DOUBLE, "
        "  lumen_matrix DOUBLE, "
        "  lumen_shiftedcell DOUBLE, "
        "  matrix_matrix DOUBLE, "
        "  matrix_shiftedcell DOUBLE, "
        "  shiftedcell_shiftedcell DOUBLE, "
        "  contactneighbororder INT, "
	    "  primary key (simnumber) )" 
	    "ENGINE = InnoDB " 
	    "CHARACTER SET utf8 COLLATE utf8_general_ci";
	    
    mdckParamTableCreateQuery = "(" 
	    "  simnumber INT NOT NULL, " 
	    "  foldername VARCHAR(100), " 
        "  targetvolume INT, "
        "  lambdavolume INT, "
        "  shifttargetvolume DOUBLE, "
        "  cellcycle INT, "
        "  shiftedcycledelay DOUBLE, "
        "  lambdasurface DOUBLE, "
        "  polarizationdelay INT, "
        "  shiftdelay INT, "
        "  lgrsubtract INT, "
        "  doublingvolume INT, "
        "  spindlerandomess INT, "
        "  divisionreg INT, "
        "  multiplier DOUBLE, "
        "  lumengrowthrate DOUBLE, "
        "  randomseed INT, "
        "  deathratelumen DOUBLE, "
        "  deathrateepi DOUBLE, "
        "  dyingshrinkrate DOUBLE, "
        "  clusterprob DOUBLE, "
        "  shiftratio DOUBLE, "
	    "  primary key (simnumber) )" 
	    "ENGINE = InnoDB " 
	    "CHARACTER SET utf8 COLLATE utf8_general_ci";	
    }
    
int ParamManager::writeParams(mysqlpp::Query query) {
    cerr << "About to create mdckParameters" << endl;
    
    cerr << "Matrix_Matrix is " << (*contactEnergies)["Matrix_Matrix"] << endl;
    pottsParameters pottsRow(simNumber, folderName, dimX, dimY, anneal, steps, temp, flip2DimRatio, neighborOrder);
    contactParameters contactRow(
        simNumber, folderName,
        (*contactEnergies)["StableCell_StableCell"],
        (*contactEnergies)["StableCell_Cell"],
        (*contactEnergies)["StableCell_Lumen"],
        (*contactEnergies)["StableCell_Matrix"],
        (*contactEnergies)["StableCell_ShiftedCell"],
        (*contactEnergies)["Cell_Cell"],
        (*contactEnergies)["Cell_Lumen"],
        (*contactEnergies)["Cell_Matrix"],
        (*contactEnergies)["Cell_ShiftedCell"],
        (*contactEnergies)["Lumen_Lumen"],
        (*contactEnergies)["Lumen_Matrix"], 
        (*contactEnergies)["Lumen_ShiftedCell"],            
        (*contactEnergies)["Matrix_Matrix"],
        (*contactEnergies)["Matrix_ShiftedCell"],        
        (*contactEnergies)["ShiftedCell_ShiftedCell"],
                
        contactNeighborOrder
        );
    mdckParameters mdckRow(
        simNumber,folderName,targetVolume,lambdaVolume,shiftTargetVolume,cellCycle,
        shiftedCycleDelay,lambdaSurface,polarDelay,shiftDelay,lgrSubtract,doublingVol,
        spindleRandom,divisionReg,multiplier,lumenGrowthRate,randomSeed,deathRateLumen,deathRateEpi,dyingShrinkRate,clusterProb,shiftRatio);
    

    cerr << "About to create query" << endl;
    // Form the query to insert the row into the stock table.
    query.insert(pottsRow);

    // Show the query about to be executed.
    cerr << "Insert query: " << query << endl;
    query.execute();
    
    query.insert(contactRow);
    cerr << "Insert query: " << query << endl;
    query.execute();
    
    query.insert(mdckRow);
    cerr << "Insert query: " << query << endl;    
    query.execute();
    
    return 0;
}

DataManager::DataManager(int _simNumber, string _folderName) : countDataTableName("countData"),measureDataTableName("measureData"),contactDataTableName("contactData"),simCycle(0),cellNumber(0),stableCellNumber(0),lumenNumber(0),totalNumber(0),shiftedCellNumber(0),livingCellNumber(0),separatedLumen(0),dyingCellNumber(0),dyingEpiCellNumber(0),dyingLumenCellNumber(0),deadCellNumber(0),deadEpiCellNumber(0),deadLumenCellNumber(0),newCellNumber(0),totalNewCellNumber(0),newLumenNumber(0),totalNewLumenNumber(0),totalVolume(0),totalSurfaceArea(0),totalCellVolume(0),totalCellSurface(0),cystOuterSurface(0),cystInnerSurface(0),meanCellVolume(0.0),meanCellSurface(0.0),totalLumenVolume(0),meanLumenVolume(0),meanDivisionAngle(0),cumulativeMeanDivisionAngle(0),newLumenTwoCells(0),newLumenThreeCells(0),newLumenFourCells(0),newLumenFivePlusCells(0),lumenCreatedMultiCell(0),cellsContactCells(0),cellsContactMatrix(0),cellsContactLumen(0),lumensContactMatrix(0),cellsContactMultipleLumens(0),cellsContactOnlyMatrix(0),cellsContactOnlyCells(0),cellsContactOnlyLumen(0) {


    simNumber = _simNumber;
    folderName = _folderName;
	
	countDataTableCreateQuery = "(" 
	    "  simnumber INT NOT NULL, " 
	    "  foldername VARCHAR(100), " 
        "  simulationcycle INT NOT NULL, "
        "  cellnumber INT, "
        "  stablecellnumber INT, "
        "  lumennumber INT, "
        "  totalnumber INT, "
        "  shiftedcellnumber INT, "
        "  livingcellnumber INT, "
        "  separatedlumen INT, "
        "  dyingcellnumber INT, "
        "  dyingepicellnumber INT, "
        "  dyinglumencellnumber INT, "
        "  deadcellnumber INT, "
        "  deadepicellnumber INT, "
        "  deadlumencellnumber INT, "
        "  newcellnumber INT, "
        "  totalnewcellnumber INT, "
        "  newlumennumber INT, "
        "  totalnewlumennumber INT, "
	    "  primary key (simnumber,simulationcycle) )" 
	    "ENGINE = InnoDB " 
	    "CHARACTER SET utf8 COLLATE utf8_general_ci";	
    
    measureDataTableCreateQuery = "(" 
	    "  simnumber INT NOT NULL, " 
	    "  foldername VARCHAR(100), " 
        "  simulationcycle INT NOT NULL, "
        "  totalvolume INT, "
        "  totalsurfacearea INT, "
        "  totalcellvolume INT, "
        "  totalcellsurface INT, "
        "  cystoutersurface INT, "
        "  cystinnersurface INT, "
        "  meancellvolume DOUBLE, "
        "  meancellsurface DOUBLE, "
        "  totallumenvolume INT, "
        "  totallumensurface INT, "
        "  meanlumenvolume DOUBLE, "
        "  meandivisionangle DOUBLE, "
        "  cumulativemeandivisionangle DOUBLE, "
	    "  primary key (simnumber,simulationcycle) )" 
	    "ENGINE = InnoDB " 
	    "CHARACTER SET utf8 COLLATE utf8_general_ci";	
    
    contactDataTableCreateQuery = "("
        "  simnumber INT NOT NULL, " 
	    "  foldername VARCHAR(100), "
        "  simulationcycle INT NOT NULL, "
	    "  newlumentwocells INT, "
	    "  newlumenthreecells INT, "
	    "  newlumenfourcells INT, "
	    "  newlumenfivepluscells INT, "
	    "  lumencreatedmulticell INT, "
	    "  cellscontactcell INT, "
	    "  cellscontactmatrix INT, "
	    "  cellscontactlumen INT, "
	    "  lumenscontactmatrix INT, "
	    "  cellscontactmultiplelumens INT, "
	    "  cellscontactonlymatrix INT, "
	    "  cellscontactonlycells INT, "
	    "  cellscontactonlylumen INT, "
	    "  primary key (simnumber,simulationcycle) )" 
	    "ENGINE = InnoDB " 
	    "CHARACTER SET utf8 COLLATE utf8_general_ci";	
    }
    
	
 int DataManager::writeData(mysqlpp::Query query) {
    cerr << "About to write data" << endl;
        
    countData countDataRow(simNumber, folderName, simCycle, cellNumber, stableCellNumber, lumenNumber, totalNumber, shiftedCellNumber, livingCellNumber, separatedLumen, dyingCellNumber, dyingEpiCellNumber, dyingLumenCellNumber, deadCellNumber, deadEpiCellNumber, deadLumenCellNumber, newCellNumber, totalNewCellNumber, newLumenNumber, totalNewLumenNumber);

    measureData measureDataRow(simNumber, folderName, simCycle, totalVolume, totalSurfaceArea, totalCellVolume, totalCellSurface, cystOuterSurface, cystInnerSurface, meanCellVolume, meanCellSurface, totalLumenVolume, totalLumenSurface, meanLumenVolume, meanDivisionAngle, cumulativeMeanDivisionAngle);
    
    contactData contactDataRow(simNumber, folderName, simCycle, newLumenTwoCells, newLumenThreeCells, newLumenFourCells, newLumenFivePlusCells, lumenCreatedMultiCell, cellsContactCells, cellsContactMatrix, cellsContactLumen, lumensContactMatrix, cellsContactMultipleLumens, cellsContactOnlyMatrix, cellsContactOnlyCells, cellsContactOnlyLumen);
        
    cerr << "About to create query" << endl;
    // Form the query to insert the row into the stock table.
    query.insert(countDataRow);

    // Show the query about to be executed.
    cerr << "Data Insert query: " << query << endl;
    query.execute();
    
    query.insert(measureDataRow);
    cerr << "Measure insert query: " << query << endl;
    query.execute();
  
    query.insert(contactDataRow);
    cerr << "Contact insert query: " << query << endl;    
    query.execute();
    
    return 0;
}

    


