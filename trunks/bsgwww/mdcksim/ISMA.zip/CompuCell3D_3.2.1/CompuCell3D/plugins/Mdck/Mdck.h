#ifndef MDCK_H
#define MDCK_H


/**
@author Jesse Engelberg.  Copyright 2010 Jesse Engelberg according to the GNU GPL.
*/
#include <set>
#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class CellG;
   
   //common surface area is expressed in unitsa of elementary surfaces not actual physical units. If necessary it may 
   //need to be transformed to physical units by multiplying it by surface latticemultiplicative factor 
   class DECLSPECIFIER MdckData{
      public:
         
         MdckData(CellG * _neighborAddress=0,short _commonSurfaceArea=0)
         :neighborAddress(_neighborAddress),
          commonSurfaceArea(_commonSurfaceArea)
          {}
         
         ///have to define < operator if using a class in the set and no < operator is defined for this class
         bool operator<(const MdckData & _rhs) const{
            return neighborAddress < _rhs.neighborAddress;
         }
         
         ///had to do this dirty trick to work around a problem that iterators of a set give access in read-only mode
         ///Note : You should NEVER change this way class members that are used in <operator this will corrupt set container
         ///CAUTION: DO NOT TRY TO MODIFY pixelIndex - you will corrupt set container
         void incrementCommonSurfaceArea(const MdckData & _mdckData )const
         {
            ++( (const_cast<MdckData&>(_mdckData)).commonSurfaceArea);
         }

         ///Note : You should NEVER change this way class members that are used in <operator this will corrupt set container
         void decrementCommonSurfaceArea(const MdckData & _mdckData )const
         {
            --( (const_cast<MdckData&>(_mdckData)).commonSurfaceArea);
         }
         
         bool OKToRemove()const{return commonSurfaceArea==0;}
         bool operator==(const MdckData & _rhs)const{
            return (neighborAddress==_rhs.neighborAddress) && (commonSurfaceArea==_rhs.commonSurfaceArea);
         }
         
         ///members
         
         CellG * neighborAddress;
         short commonSurfaceArea;

                  
   };

   
   
   class DECLSPECIFIER Mdck{
      public:
         Mdck(){};
         int trackerNumber(){return 1234321;}
         ~Mdck(){};
         std::set<MdckData > cellNeighbors; //stores ptrs to cell neighbors i.e. each cell keeps track of its neighbors
         
   };
};
#endif
