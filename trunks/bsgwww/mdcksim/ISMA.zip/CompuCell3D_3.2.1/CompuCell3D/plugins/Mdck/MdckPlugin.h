/*************************************************************************
 * Code copyright Jesse Engelberg, 2010, under the GPL
 *                                                                       *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef MDCKPLUGIN_H
#define MDCKPLUGIN_H

#include <CompuCell3D/Plugin.h>

#include <CompuCell3D/Potts3D/Cell.h>
#include <CompuCell3D/Potts3D/CellGChangeWatcher.h>
#include <CompuCell3D/plugins/NeighborTracker/NeighborTrackerPlugin.h>
#include <CompuCell3D/plugins/NeighborTracker/NeighborTracker.h>

#include <BasicUtils/BasicClassAccessor.h>
#include <BasicUtils/BasicClassGroup.h> //had to include it to avoid problems with template instantiation
#include <BasicUtils/BasicRandomNumberGenerator.h>
#include "Mdck.h"
#include "MdckParseData.h"

#include <CompuCell3D/Field3D/AdjacentNeighbor.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>
#include <Utils/Coordinates3D.h>

#include <map>
#include <iostream>
#include <cmath>

using namespace std;
template<typename Y>
class BasicClassAccessor;
class Potts3D;
class DBManager;
class DataManager;

namespace CompuCell3D {

  class Cell;
  class Field3DIndex;
  template <class T> class Field3D;
  template <class T> class WatchableField3D;

  class CellInventory;
  class BoundaryStrategy;
  class NeighborTracker;
  class MCell;
//  class Edge;
  class CellMap;


class DECLSPECIFIER MdckPlugin : public Plugin, public CellGChangeWatcher {

      Potts3D *potts;
      BasicRandomNumberGenerator * randGen;
      WatchableField3D<CellG *> *cellFieldG;
      Dim3D fieldDim;
      BasicClassAccessor<Mdck> mdckAccessor;
      BasicClassAccessor<NeighborTracker> * neighborTrackerAccessorPtr;
      Simulator *simulator;
      bool periodicX,periodicY,periodicZ;
      bool paramsWritten;
      CellInventory * cellInventoryPtr;



//       bool checkSanity;
//       unsigned int checkFreq;
      unsigned int maxNeighborIndex;
      BoundaryStrategy *boundaryStrategy;

    
   public:
      int testVar;
      int simCycle;
      CellMap* cellMap;
      MdckParseData ntpd;
      MdckParseData * ntpdPtr;
      MdckPlugin();
      DBManager* dbManager;
      DataManager* dataManager;

      bool createdCellMap;
      bool initializedCellMap;


      virtual ~MdckPlugin();
      
      // SimObject interface
      virtual void init(Simulator *_simulator, ParseData * _pd);
      
      // BCGChangeWatcher interface
      virtual void field3DChange(const Point3D &pt, CellG *newCell,
                                 CellG *oldCell);
      
      virtual bool doMitosis(CellG* cell);
      virtual MCell* createCell(Point3D firstPoint, CellG* parentCell, int cellType);
//      virtual int lineEquation(double X, double Y, double xcm, double ycm, int axis);
//      virtual int solveEforX(double Y, double xcm, double ycm, int axis);
//      virtual Point3D drawCell(CellG* cell, int minX, int maxX, int minY, int maxY);
       
       
      virtual void initPottsParamsDB();
      virtual void initMdckParamsDB();
      virtual void initContactParamsDB();
      
      // Begin XMLSerializable interface
      virtual void readXML(XMLPullParser &in);
      virtual void writeXML(XMLSerializer &out);
      BasicClassAccessor<Mdck> * getMdckAccessorPtr(){return & mdckAccessor;}
//      virtual bool doCellStuff(CellG *newCell);
      virtual bool executeActions();
      // End XMLSerializable interface
      int returnNumber(){return 55555;} 
      bool isBoundaryPixel(Point3D pt);
      bool isBoundaryPixel(Point3D pt, CellG* inCell);
      int* getOffsetsIndex(const Point3D & curPoint);
      
    
 
      
     
     

   protected:
//      double distance(double,double,double,double,double,double);
      
      virtual void testLatticeSanityFull();
      
      bool watchingAllowed;
      AdjacentNeighbor adjNeighbor;
      long maxIndex; //maximum field index
      long changeCounter;
  };

class MathUtil {

      public:
      
    /*
     * This function will get the approximate value of a coordinates 3D in regular coordinates.  It will
     * do this by dividing the y plane into strips, finding the strip the point is in, and then finding the closest
     * x coord to that point.
     *
     */

    static Point3D getApproxLattice(Coordinates3D<double> coord) {
        // originally, if a point had an even y coordinate it was given a + 0.5 x coordinate
        // so the first thing to do is to calculate the y coordinate by scaling it back up.
        int latX;
        int latY = round(coord.y * 2.0 / sqrt(3.0)); 
        
        // then find the correct x value
        if (latY%2) { // odd y, stays the same
            latX = round(coord.x);
        }
        else { // even y, scale back
            latX = round(coord.x - 0.5);
        }
        
        return Point3D(latX,latY,0);


    }
    
    /*
     * Copied from BoundaryStrategy.cpp
     *
     */
    static Coordinates3D<double> HexCoord(const Point3D & _pt){
        //the transformations formulas for hex latice are written in such a way that distance between pixels is set to 1
        if(_pt.z%2){//odd z
           if(_pt.y%2)//odd
              return Coordinates3D<double>(_pt.x , sqrt(3.0)/2.0*(_pt.y+2.0/3.0), _pt.z*sqrt(6.0)/3.0 );
           else//#even
              return Coordinates3D<double>( _pt.x+0.5 ,  sqrt(3.0)/2.0*(_pt.y+2.0/3.0) , _pt.z*sqrt(6.0)/3.0);
        }
        else{
           if(_pt.y%2)//#odd
              return Coordinates3D<double>(_pt.x , sqrt(3.0)/2.0*_pt.y, _pt.z*sqrt(6.0)/3.0 );
           else//even
              return Coordinates3D<double>( _pt.x+0.5 ,  sqrt(3.0)/2.0*_pt.y , _pt.z*sqrt(6.0)/3.0);
        }
    }

/*
      //
      // round the value of Y to the nearest int, then either round x to the nearest int or 
      static int getIntX(double x, double y) {
        if ((int)round(y) % 2==0)
            return round(x);
        else
            return floor(x);
      }
  */
      static double distanceLinePoint(Point3D _p1, Point3D _p2, Point3D _p3) {
      
          return distanceLinePoint(MathUtil::HexCoord(_p1), MathUtil::HexCoord(_p2), MathUtil::HexCoord(_p3) );
      
      }
  
      // finds the distance between a line defined by two points p1 and p2, and a point p3
      static double distanceLinePoint(Coordinates3D<double> p1, Coordinates3D<double> p2, Coordinates3D<double> p3) {
        
          double A = p3.x - p1.x;
          double B = p3.y - p1.y;
          double C = p2.x - p1.x;
          double D = p2.y - p1.y;
 
          double dist = abs(A * D - C * B) / sqrt(C * C + D * D);
          
          return dist;
      }
      
      
      
      static pair<double,double> getLine(Point3D _A, Point3D _B) {

        Coordinates3D<double> A = MathUtil::HexCoord(_A);
        Coordinates3D<double> B = MathUtil::HexCoord(_B);
        
        return getLine(A,B);
        
      }
      
      static pair<double,double> getLine(Coordinates3D<double> A, Coordinates3D<double> B) {
          double ax = A.x;      
          double ay = A.y;
          double bx = B.x;
          double by = B.y;
          
          double slope = (by - ay) / (bx - ax);
          double intercept = ay - slope * ax;
      
          return pair<double,double>(slope,intercept);
      }
      
      static double dist(Point3D _A, Point3D _B) {
      
          Coordinates3D<double> A = MathUtil::HexCoord(_A);
          Coordinates3D<double> B = MathUtil::HexCoord(_B);
        
          return dist(A,B);
      }
      
      static double dist(Coordinates3D<double> A, Coordinates3D<double> B) {
          return sqrt( (B.x - A.x) * (B.x - A.x) + (B.y - A.y) * (B.y - A.y) );
      
      }
      
      static std::string ps(Coordinates3D<double> pt) {
          char buffer[200];
          
          sprintf(buffer, "( %f, %f, %f )", pt.x, pt.y, pt.z );
          string result = string(buffer,200);
          int end = result.find(")");
          
          result.resize(end+1);

          return result;
      }

};

class MCell {

public:
    static const int COUNTER_NULL = -99;
    int id;
    int pCounter;
    int shiftCounter;
    int turnCounter;
    int cycleCounter;
    int doublingVolume;
//    static int staticTurnCounter;
    static int staticPCounter;
    static int originalShift;
    static int originalPCounter;
    Coordinates3D<double> midBody;
    
    int matrixCount;
    int matrixSurface;
    int lumenCount;
    int cellCount;
    int shiftedCount;
        
    std::list<Point3D> cellPoints;
//    std::list<Edge> cellBoundary;
    CellG* cell;
    CellG* lumenNeighbor; // May not be current. Updated by calling countNeighbors().
    bool reachedShift;
    bool divisionReg;
    bool cellDying;
    
    static const Point3D nullPoint() { return *(new Point3D(-1,-1,-1)); }
    
    static const Coordinates3D<double> nullCoord() { return *(new Coordinates3D<double>(-1,-1,-1)); }
    
    MdckPlugin* mdckPlugin;

    ~MCell() {
        
    }

    MCell(CellG* inCell, std::list<Point3D> inPoints, MdckPlugin* inPlug) {
        cellPoints = inPoints;
        init(inCell, inPlug);
    }
    
    MCell(CellG* inCell, MdckPlugin* inPlug) {
        init(inCell, inPlug);
    }
    
    MCell(CellG* inCell, Point3D firstPoint, MdckPlugin* inPlug) {
        cellPoints = std::list<Point3D>();
        cellPoints.push_back(firstPoint);
        init(inCell, inPlug);
    }

    
    void init(CellG* inCell, MdckPlugin* inPlug) {
        mdckPlugin = inPlug;
        turnCounter = mdckPlugin->simCycle;
        id = inCell->id;
        cell = inCell;
        pCounter = COUNTER_NULL;
        cycleCounter = COUNTER_NULL;
        shiftCounter = COUNTER_NULL;
        midBody = MCell::nullCoord();
        reachedShift = false;
        divisionReg = false;
        cellDying = false;
    }
    
    
    
    void clearPoints() {
        cellPoints.clear();
    }
    
    std::list<Point3D> getPoints() {
        return cellPoints;
    }
    
    void setPoints(std::list<Point3D> newPoints) {
        cellPoints = newPoints;
    }
    
    void addPoint(Point3D pt) {
        cellPoints.push_back(pt);
    }
    
    void removePoint(Point3D pt) {
        cellPoints.remove(pt);
    }
    
    void addPoints(std::list<Point3D> newPoints) {
        cellPoints.splice(cellPoints.end(),newPoints);
    }
    
    // this function will count the number of matrix, lumen, and cell neighbors and store them.
    // be aware that these may change and must be recounted
    
    void countNeighbors(BasicClassAccessor<NeighborTracker> * nTrackerPtr) {
    
        // get neighbors of the cell, count the matrix
        NeighborTracker *nTracker = nTrackerPtr->get(cell->extraAttribPtr);
        cerr << "Initialized neighbor tracker" << endl;

        // We want to iterate through the cell neighbors.
        // *nTracker->cellNeighbors will give us a set<NeighborSurfaceData>, which we should iterate through.

        cerr << "Getting neighbors from nTracker" << endl;
        set<NeighborSurfaceData> neighbors = nTracker->cellNeighbors;
        cerr << "Creating iterator" << endl;
        set<NeighborSurfaceData>::iterator theIterator;
        cerr << "Moving into for loop" << endl;

        
        matrixCount = 0;
        matrixSurface = 0;
        lumenCount = 0;
        cellCount = 0;
        shiftedCount = 0;
        

        std::vector<CellG*> neighborList;
                        
        for( theIterator = neighbors.begin(); theIterator != neighbors.end(); theIterator++ ) {
            cerr << " in for loop" << endl;
            CellG * nCell = theIterator->neighborAddress;
            neighborList.push_back(nCell);
            // put this in the list of neighbors.  Hopefully it'll include the matrix as well.
    //                neighborList.push_back(nCell);
            
            if (nCell) {
                cerr << "neighbor cell is valid: " << nCell << endl;
                // The cell has at least one valid neighbor
                // We now have to count the neighbors and take an action based onthe results.
                int nType = (int)(nCell->type);
                if (nType !=2) {
                    cerr << " found cell neighbor with id " << nCell->id << endl;
                    cellCount++;
                    if (nType == 4) {
                        cerr << " cell is shifted" << endl;
                        shiftedCount++;
                    }
                }
                else if (nType == 2) {
                    cerr << " found lumen neighbor with id " << nCell-> id << endl;
                    lumenCount++;
                    lumenNeighbor = nCell;
                }
                else {
                    cerr << " found something will id " << nCell->id << endl;
                }
            }
            else {
                cerr << " found matrix neighbor" << endl;
                matrixCount++;
    //                    matrixSurface+=theIterator->commonSurfaceArea;
            }
        }
    }
    
    /*
     * This function will calculate the center of mass of the cell.
     * in order to do this, it will convert all the square values into hex values
     * then it will sum and average them.
     *
     */
    Coordinates3D<double> calcHexCom() {
        cerr << "calculating HexCOM" << endl;
        
        list<Point3D>::iterator theIterator;
        double xTotal = 0;
        double yTotal = 0;
        double zTotal = 0;

        double vTotal = 0;
        
        for( theIterator = cellPoints.begin(); theIterator != cellPoints.end(); theIterator++ ) {
            Point3D curPoint = *theIterator;
//            cerr << "com: curPoint is " << curPoint << endl;
            
            xTotal+=(MathUtil::HexCoord(curPoint)).x;
            yTotal+=(MathUtil::HexCoord(curPoint)).y;
            vTotal++;
        }

        cerr << "xTotal is " << xTotal << endl;
        cerr << "yTotal is " << yTotal << endl;
        cerr << "vTotal is " << vTotal << endl;
        
        cerr << "x, y is " << (xTotal/vTotal) << ", " << (yTotal/vTotal) << endl;
        return Coordinates3D<double>(xTotal/vTotal,yTotal/vTotal,0);
    }
    
    Coordinates3D<double> calcMidBody(Coordinates3D<double> com) {
        return calcMidBody(com, midBody);
    }

    // This method relies on having an accurate com, so recalculate it if you're not sure.
    Coordinates3D<double> calcMidBody(Coordinates3D<double> com, Coordinates3D<double> mbSeed) {
        
//        Coordinates3D<double> com = calcHexCom();
        
        cerr << "for cell " << cell->id << " the com is " << MathUtil::ps(com) << endl;
        cerr << "the mbSeed is " << MathUtil::ps(mbSeed) << endl;
        
        // cycle through each point in the cell
        // 1. check if it's between the mbSeed and the com
        // 2. check if it's on the border
        // 3. check if it has the closest distance to the line
        //    between the mbSeed and the com.
        
        //
        // *** There are three conditions.  In the first, the midBody seed is
        // on the border of the cell.  In this case we simply return that value, doing no 
        // work.  
        // In the second, the midBody seed is outside the cell, which uses the current algorithm.
        // In the third, it's inside the cell, which will require a modified algorithm, likely by finding the 
        // point that's in the same direction along a vector from the com to the midbody seed.  When you
        // find the point closest to the line on the border you're left with two points, the right and the wrong.
        // In all cases the right point lies roughly on a line moving from the com to the midBody.
        // 
        // So if the value of midBody.x is greater than com.x, then pt.x must be greater than com.x as well.
        // This will account for all three conditions.
        //
        //
        
        double shortestDistance = 10000000;
        Coordinates3D<double> closestCoord;
        
        list<Point3D> cellPoints = getPoints();
        list<Point3D>::iterator theIterator;
        for( theIterator = cellPoints.begin(); theIterator != cellPoints.end(); theIterator++ ) {
            Point3D curPoint = *theIterator;
            Coordinates3D<double> curCoord = MathUtil::HexCoord(curPoint);
            
            cerr << "curPoint is " << curPoint << endl;
            cerr << "curCoord is " << MathUtil::ps(curCoord) << endl;
            cerr << "which is equivalent to " << MathUtil::getApproxLattice(curCoord) << endl;
            
            Point3D newPoint = MathUtil::getApproxLattice(curCoord);
            if (! (curPoint == newPoint)) {
                cerr << " Oh no!  curPoint and newPoint are not equal!" << endl;
            }
            
            // 1. check if C is between the mbSeed(A) and the com(B)
            // this will occur under the following circumstances:
            // Ax <= Cx <= Bx || Bx <= Cx <= Ax
            // && 
            // Ay <= Cy <= By || By <= Cy <= Ay
            double ax = mbSeed.x;
            double ay = mbSeed.y;
            double bx = com.x;
            double by = com.y;
            double cx = curCoord.x;
            double cy = curCoord.y;
            
//            if ( (ax <= cx && cx <= bx) || (bx <= cx && cx <= ax) ) {
//                if ( (ay <= cy && cy <= by) || (by <= cy && cy <= ay) ) {

            // if both the midbody and the point are greater or less than the com
            if ( (ax >= bx && cx >= bx) || (ax <= bx && cx <= bx) ) {
                if ( (ay >= by && cy >= by) || (ay <= by && cy <= by) ) {
                    cerr << "which is on the same side of the com as the midbody" << endl;
                    // 2. check if the pixel is on the border
                    if (mdckPlugin->isBoundaryPixel(curPoint,cell)) {
                        cerr << "and is on the boundary" << endl;
                    
                        // 3. check if this point is the closest point to the line between
                        // the midBody and the com
                        
                        double distance = MathUtil::distanceLinePoint(com,mbSeed,curCoord);
                        
                        cerr << " and has a distance to the line of " << distance << endl;;
                        if (distance <= shortestDistance) {
                            cerr << "which is the shortest so far, so we're using it " << endl;
                            shortestDistance = distance;
                            closestCoord = curCoord;
                        }
                        else {
                            cerr << " which is longer than the distance of " << shortestDistance << endl;
                        }
                    }
                }
            }
        } // end for each point
        
        cerr << "the closest coord is " << MathUtil::ps(closestCoord) << endl;
        return closestCoord;
        
        
    } // end method       
                
                
    

    
    /*
     * This function will return the lattice coordinates of the hexagon that represents the
     * closest hexagon to the point given by hexPoint.  It will do this through the following algorithm:
     * 
     *   x0     x1      x2
     * y0 ................
     *    .  /   .   \   .
     * y1 ................
     *    .      o       .
     * y2 ................
     *    .  \   .   /   .
     * y3 ................   
     *
     * x,y are the coordinates of a point
     * 
     * if x0 < x < x2
     *   if y1 < y < y2 then x,y in cell
     *   else if y < y1
     *       
     * 
     * how do we find these x, y values?
     */
    Point3D getLatticeCoords( Coordinates3D<double> hexPoint) {
        
    
    }
        
    /*pair<double,double> calcRealCom() {
        cerr << "*calculating COM" << endl;
        
        list<Point3D>::iterator theIterator;
        double xTotal = 0;
        double yTotal = 0;
        double zTotal = 0;
        double vTotal = 0;
        
        for( theIterator = cellPoints.begin(); theIterator != cellPoints.end(); theIterator++ ) {
            Point3D curPoint = *theIterator;
            cerr << "com: curPoint is " << curPoint << endl;
            
            xTotal+=MathUtil::getDoubleX(curPoint.x,curPoint.y);
            yTotal+=curPoint.y;
            vTotal++;
        }

        cerr << "xTotal is " << xTotal << endl;
        cerr << "yTotal is " << yTotal << endl;
        cerr << "vTotal is " << vTotal << endl;
        
        cerr << "x, y is " << (xTotal/vTotal) << ", " << (yTotal/vTotal) << endl;
        return pair<double,double>(xTotal/vTotal,yTotal/vTotal);

    }*/
    
/*    Point3D getCOM() {
        return COM;
    }
  */
    
    
};

/*
class Edge {

public:

    Edge() { 
    }
    
    Edge(MCell* _first, MCell* _second) {
        edge.first = _first;
        edge.second = _second;
    }
    
    ~Edge() { }
    
    MCell* first() {
        return edge.first;
    }
    
    MCell* second() {
        return edge.second;
    }
    
    void set(MCell* _first, MCell* _second) {
        setInside(_first);
        setOutisde(_second);
    }
    
    void setInside(MCell* inside) {
        edge.first = inside;
    }
    
    void setOutside(MCell* outside) {
        edge.second = outside;
    }
}
        
    
private:

    pair<MCell*,MCell*> edge;
    
}
*/
class CellMap {

public:
    
    
    CellMap() {
    }
    
    ~CellMap() {  
    }
    
    // get an element without adding it
    MCell* get(CellG* curCell) {
        std::map<CellG*,MCell*>::iterator it = cellMap.find(curCell);        
        if (it!=cellMap.end()) {
            return it->second;
        }
        else {
            return NULL;
        }
    }

    // insert an element
    void insert(CellG* curCellG, MCell* curMCell) {
        cellMap.insert(pair<CellG*,MCell*>(curCellG,curMCell));
    }
    
    // remove an element
    void erase(CellG* cellToErase) {
        cellMap.erase(cellToErase);
    }
    
    int size() {
        return cellMap.size();
    }
    
private:
    std::map<CellG*,MCell*> cellMap; 
    
};
    
    
class TJMap {

public:
    
    
    TJMap() {
    }
    
    ~TJMap() {  
    }
    
    // get an element without adding it
    CellG* get(Point3D* pt) {
        std::map<Point3D*,CellG*>::iterator it = tjMap.find(pt);        
        if (it!=tjMap.end()) {
            return it->second;
        }
        else {
            return NULL;
        }
    }

    // insert an element
    void insert(Point3D* curPoint, CellG* curCellG) {
        tjMap.insert(pair<Point3D*,CellG*>(curPoint,curCellG));
    }
    
    // remove an element
    void erase(Point3D* ptToErase) {
        tjMap.erase(ptToErase);
    }
    
    int size() {
        return tjMap.size();
    }
    
    std::map<Point3D*,CellG*>::iterator begin() {
        return tjMap.begin();
    }
    
    std::map<Point3D*,CellG*>::iterator end() {
        return tjMap.end();
    }
    
    
private:
    std::map<Point3D*, CellG*> tjMap; 
    
};

};
#endif
