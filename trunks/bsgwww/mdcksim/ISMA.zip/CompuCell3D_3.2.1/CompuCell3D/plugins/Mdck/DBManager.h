#ifndef DBMANAGER_H
#define DBMANAGER_H

/***********************************************************************
Copyright Jesse Engelberg 2010.

This+ is free software; you can redistribute it and/or modify it
 under the terms of the GNU Lesser General Public License as published
 by the Free Software Foundation; either version 2.1 of the License, or
 (at your option) any later version.

This+ is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this code; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301
 USA
***********************************************************************/



//#include "cmdline.h"
//#include "printdata.h"
#include <mysql++.h>
//#include "stock.h"

using namespace std;

class ParamManager;
class DataManager;

class DBManager {

    public:
        mysqlpp::Connection* con;
        const char* db, *server, *user, *pass;        
		ParamManager* paramManager;
		DataManager* dataManager;
		
   		int simNumber;
        string folderName;
        
        DBManager();
    
        ~DBManager() {};

        virtual int init();
        virtual int createDB();
        virtual int createTable(const char* tableName, const char* tableQuery);
        virtual int initSimNumber();
        string initFolderName();
        virtual int writeParams();
        virtual int writeData();
//        virtual int executeInsert();

};

class DataManager {

    public:
        const char *countDataTableName, *measureDataTableName, *contactDataTableName;
        const char *countDataTableCreateQuery, *measureDataTableCreateQuery, *contactDataTableCreateQuery;
        
        int simNumber;
        string folderName;
        int simCycle;
        
        // count variables
        int cellNumber; // CPM cells with type "Cell"
        int stableCellNumber; // CPM cells with type "StableCell"
        int lumenNumber; // CPM cells with type "Lumen"
        int totalNumber; // Total number of CPM cells
        int shiftedCellNumber; // Number of Cells and StableCells that have shifted
        int livingCellNumber;  // Total cells, stable cells, and shifted cells
        int separatedLumen; // *Number of unique lumen cells that are separated by Matrix or Cells. Same as lumenNumber!
        int dyingCellNumber; // Number of cells that are currently shrinking because they died
        int dyingEpiCellNumber; // Number of cells that are shrinking and touching the ECM
        int dyingLumenCellNumber; // Number of cells that are shrinking and not touching the ECM
        int deadCellNumber; // Total number of cells that have died through apoptosis.
        int deadEpiCellNumber; // Total number of cells that BEGAN dying in the epithelia in this turn
        int deadLumenCellNumber; // Total number of cells that BEGAN dying in the lumen in this turn        
        int newCellNumber; // Number of new cells created in the current simulation cycle.
        int totalNewCellNumber; // Total number of new cells created in the simulation
        int newLumenNumber; // Number of new lumens created in this simulation cycle
        int totalNewLumenNumber; // Total number of lumens created in the simulation
        
        
        // measure variables
        int totalVolume; // The total volume of all cells, stablecells, and lumen
        int totalSurfaceArea; // The sum of the surface areas of all cells, including lumen
        int totalCellVolume; // The sum of all Cell and StableCell volumes
        int totalCellSurface;  // The sum of all Cell and StableCell surfaces
        int cystOuterSurface; // The sum of all surface areas of cells contacting matrix
        int cystInnerSurface; // The sum of all surface areas of cells contacting lumen
        double meanCellVolume; // The average volume of cells and stable cells
        double meanCellSurface; // The average surface of cells and stable cells
        int totalLumenVolume; // The total volume of lumen
        int totalLumenSurface; // The total surface area of lumen
        double meanLumenVolume; // The average volume of lumen cells
        double meanDivisionAngle; // The mean value of the angle between the axis of division and the 
                                  // line between the COM of the dividing cell and the COM of the cyst, 
                                  // found for each division event this turn.
        double cumulativeMeanDivisionAngle; // The cumulative average of the MeanDivisionAngle.                              

        
        
        // contact variables
        int newLumenTwoCells; // The number of lumens created this turn that neighbor two cells.
        int newLumenThreeCells; // The number of lumens created this turn that neighbor three cells.
        int newLumenFourCells; // The number of lumens created this turn that neighbor four cells.
        int newLumenFivePlusCells; // The number of lumens created this turn that neighbor five or more cells.
        int lumenCreatedMultiCell; // The number of newly created lumens that contact cells that are touching other lumens.
        int cellsContactCells; // The number of cells that have at least one cell or stablecell neighbor
        int cellsContactMatrix; // The number of cells that have at least one matrix neighbor
        int cellsContactLumen;  // The number of cells that have at least one lumen neighbor
        int lumensContactMatrix; // The number of lumen cells that contact at least one matrix neighbor
        int cellsContactMultipleLumens; // The number of cells that are in contact with multiple lumen cells
        int cellsContactOnlyMatrix;  // The number of cells only in contact with matrix
        int cellsContactOnlyCells;  // The number of cells only in contact with other cells
        int cellsContactOnlyLumen; // The number of cells only in contact with lumen
        
        DataManager(int _simNumber, string _folderName);
        virtual int writeData(mysqlpp::Query query);

};

class ParamManager {

    public:
        const char *pottsParamTableName, *contactParamTableName, *mdckParamTableName;
    	const char* pottsParamTableCreateQuery;
		const char* contactParamTableCreateQuery;
		const char* mdckParamTableCreateQuery;

    
    // variables that will be stored in the parameter table
		int simNumber;
        string folderName;
        int dimX;
        int dimY;
        int anneal;
        int steps;
        double temp;
        double flip2DimRatio;
        int neighborOrder;
        
        // Contact parameters
        std::map<std::string,double>* contactEnergies;
        int contactNeighborOrder;

        // Mdck parameters
        int polarDelay;
        int shiftDelay;
        int lgrSubtract;
        int doublingVol;
        double shiftTargetVolume;
        int cellCycle;
        int spindleRandom;
        int divisionReg;
        int targetVolume;
        double lambdaVolume;
        double shiftedCycleDelay;
        double lambdaSurface;
        double multiplier;
        double lumenGrowthRate;
        int randomSeed;
        double deathRateLumen;
        double deathRateEpi;
        double dyingShrinkRate;
        double clusterProb;
        double shiftRatio;
      
        ParamManager(int _simNumber, string _folderName);
        virtual int writeParams(mysqlpp::Query query);
};
    
#endif
