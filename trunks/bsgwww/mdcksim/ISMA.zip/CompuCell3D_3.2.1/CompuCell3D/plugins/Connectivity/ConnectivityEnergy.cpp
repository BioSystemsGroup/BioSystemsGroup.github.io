/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/Potts3D/Cell.h>
#include <CompuCell3D/Automaton/Automaton.h>
#include <CompuCell3D/Boundary/BoundaryStrategy.h>

using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <CompuCell3D/Potts3D/Cell.h>
#include <CompuCell3D/Simulator.h>

#include <algorithm>

#include <string>
#include <iostream>
using namespace std;

#define EXP_STL
#include "ConnectivityEnergy.h"

ConnectivityEnergy::ConnectivityEnergy() :
            potts(0) ,numberOfNeighbors(8),cpdPtr(0)
{
   cerr << "in ConnectivityEnergy constructor" << endl;

//   Moved this to init JAE 11/22
//   n.assign(numberOfNeighbors,Point3D(0,0,0)); //allocates memory for vector of neighbors points
//   offsetsIndex.assign(numberOfNeighbors,0);//allocates memory for vector of offsetsIndexes
}

void ConnectivityEnergy::init(Simulator *simulator){
//   cerr << "in ConnectivityEnergy::init" << endl;
   
   potts=simulator->getPotts();
//   cerr << "the latticeType in CE::init is " << int(potts->getLatticeType()) << endl;
  
   // Added lattice dectection 
   if (potts->getLatticeType() == 2) {
     hexLattice = true;
     numberOfNeighbors = 6;
   }

//   cerr << "about to do assigns" << endl;
   n.assign(numberOfNeighbors,Point3D(0,0,0)); //allocates memory for vector of neighbors points
   offsetsIndex.assign(numberOfNeighbors,0);//allocates memory for vector of offsetsIndexes
   
//   cerr << "about to update pointer" << endl;
   update(cpdPtr);

   if (! hexLattice) {
      //here we initialize offsets for neighbors (up to second nearest) in 2D
//      cerr << "about to initialize offsets" << endl;
      initializeNeighborsOffsets();
//      cerr << "initialized offsets" << endl;
   }

//   BasicClassAccessor<Mdck> * mdckAccessorPtr;
      
   // Adding this code to see if we can access the MdckPlugin within this code.
   // This is necessary to prevent cells from coming into contact with multiple lumens   
   bool pluginAlreadyRegisteredFlag;
   mdckPlugin =(MdckPlugin *) Simulator::pluginManager.get("Mdck",&pluginAlreadyRegisteredFlag); 
   //this will load NeighborTracker plugin if it si not already loaded 
   if(!pluginAlreadyRegisteredFlag)
       mdckPlugin->init(simulator,0);
   //mdckAccessorPtr = mdckPlugin->getMdckAccessorPtr();
   
   //cerr << "FOUND MDCK PLUGIN, returnNumber is " << mdckPlugin->returnNumber() << " and testVar is " << mdckPlugin->testVar << endl;
      
   boundaryStrategy=BoundaryStrategy::getInstance();
}

void ConnectivityEnergy::update(ParseData *_pd, bool _fullInitFlag){

   cpdPtr=(ConnectivityParseData*)_pd;
   penalty=cpdPtr->penalty;

}

void ConnectivityEnergy::addUnique(CellG* cell)
{
   if (!cell) mediumFlag = true;
   //if (!cell) return;  
   // Medium does not count
   for (unsigned int i = 0; i < uniqueCells.size(); i++)
   {
      if (uniqueCells[i] == cell)
          return;
   }
   uniqueCells.push_back(cell);
}

double ConnectivityEnergy::localEnergy(const Point3D &pt) {
  return 0;
}




//modified version of connectivity algorithm - Tinri Aegerter
// further modified to account for Hex Lattice - JAE 11/22/08

double ConnectivityEnergy::changeEnergy(const Point3D &pt,
                                  const CellG *newCell,
                                   const CellG *oldCell) {
                                   
    Neighbor neighbor;

//    cerr << "FOUND MDCK PLUGIN, returnNumber is " << mdckPlugin->returnNumber() << " and testVar is " << mdckPlugin->testVar << endl;

    if (hexLattice) {          
//        cerr << "calling setHexOffsets" << endl;   
        setHexOffsets(pt);                         
    }

//    cerr << "calling changeEnergy in connectivityEnergy" << endl;
//    cerr << "numberOfNeighbors is " << numberOfNeighbors << endl;
    
//    cerr << "with point " << pt << "points are: " << endl;
    

/*    // Test display code
    for(int i=0 ; i < numberOfNeighbors ; ++i ){
        cerr << "in for loop" << endl;
        cerr << "i:" << i << " ";
        neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),i);
        cerr << neighbor.pt << endl;
        
        if(!neighbor.distance){
        //if distance is 0 then the neighbor returned is invalid
        continue;
        }

        n[i]=neighbor.pt;
    }
    
    cerr << "reordered points with point " << pt << "points are: " << endl;
    
    for(int i=0 ; i < numberOfNeighbors ; ++i ){
        neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),offsetsIndex[i]);
        cerr << "i:" << i << " " << "offsetsIndex" << offsetsIndex[i] << " " << neighbor.pt << endl;
        
        if(!neighbor.distance){
        //if distance is 0 then the neighbor returned is invalid
        continue;
        }

        n[i]=neighbor.pt;
    }
*/
   
   if (!oldCell) return 0;
   uniqueCells.clear();
   

   //rule 1: go over first nearest neighbors and check if newCell has 1st nearest neighbor belonging to the same cell
   // the ordering is unimportant at this point.  In hex this is 6 in square it's 4.
   bool firstFlag=false;
   unsigned int firstMaxIndex=boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(1);
   if (hexLattice)
      firstMaxIndex = numberOfNeighbors;
      
   for(int i=0 ; i <=firstMaxIndex; ++i ){
      neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),i);
      if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
      }
      if(potts->getCellFieldG()->get(neighbor.pt)==newCell){
         firstFlag=true;
         break;
      }
   }  
   
   if(!firstFlag){
      cerr << "1: rejecting spin flip because it would isolate a point" << endl;
      return penalty;
   }

   // Immediate neighbors
      for(int i=0 ; i < numberOfNeighbors ; ++i ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),offsetsIndex[i]);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }

         n[i]=neighbor.pt;
//         cerr << "neighbor " << i << " is " << neighbor.pt << endl;
      }

   //rule 2: Count collisions between pixels belonging to different cells. If the collision count is greater than 2 reject the spin flip
   // a collision is when you're moving in a clockwise direction from one cell to the next. Just places where two cells touch.
   mediumFlag = false;
   int collisioncount = 0;
   for (unsigned int i = 0; i < numberOfNeighbors; i++)
   {
      if (
            ((potts->getCellFieldG()->get(n[i]) == oldCell) || (potts->getCellFieldG()->get(n[(i+1) % numberOfNeighbors]) == oldCell))
              &&
            (potts->getCellFieldG()->get(n[i]) !=potts->getCellFieldG()->get(n[(i+1) % numberOfNeighbors]))
         )
      {
        //addUnique was used for the old version, and is no longer needed.
        addUnique(potts->getCellFieldG()->get(n[i]));
        addUnique(potts->getCellFieldG()->get(n[(i+1)%numberOfNeighbors]));
    	collisioncount++;
      }
   }

   if (collisioncount != 2) { // Conditional rejection
      cerr << "2: rejecting spin flip because it would separate a cell" << endl;

      return penalty;  // Reject
   }
   
  /* JAE 7/15/09
   * 
   * New rules for doing multiple lumen contacting.
   *
   * This will be tight junction (TJ) specific.
   * The first thing to do is to count the tight junctions.
   *
   * If the location being counted is a cell, then go around the list of neighbors, 0->1, 1->2, 2->3, 3->4, 4->5, 5->0
   * and see if there are any lumen to cell or cell to lumen transitions.  If they are, and the cell in question is
   * a different type of cell than the current cell, then that's a TJ.  Count it.
   *
   * If the space is a lumen, then do a similar sweep, but just count any cells that are not identical as TJs.
   *
   * Once you've counted TJs, then if the TJ number will be the same before and after the move, then you can do it.
   * If not, then you send a penalty.
   *
   * Later we're going to have to work out how to merge lumens, which will involve changing TJ numbers.
   *
   */
 
    if (oldCell && newCell && (oldCell->type != 2) ) {
     
        Field3D<CellG *> *cellField = potts->getCellFieldG();
        
        // count the number of tight junctions
        int oldTJCount = 0;
        int newTJCount = 0;
        
        // If location changing from stable cell to lumen.
        if (newCell->type == 2 && oldCell->type > 2) {
            cerr << "Connectivity: cell changing to lumen.  Checking. " << endl;
            cerr << "Old cell id=" << oldCell->id << " and type=" << int(oldCell->type) << endl;
            
            // we now need to count the number of TJs that existed when the cell was a cell
            // as well as the number that would exist if the cell changed to lumen
                        
            // n[i] is in order from 0 (North) to 5 (NE) in clockwise order
            for (unsigned int i = 0; i < numberOfNeighbors; i++) {  
                cerr << "Connectivity: in for loop for neighbors" << endl;  
                CellG* curCell = cellField->get(n[i]);
                CellG* nextCell = cellField->get(n[(i+1)%6]);
                if (!curCell || !nextCell) {
                    cerr << "Found matrix neighbor so returning penalty" << endl;
                    return penalty;
                }
                cerr << "n[" << i << "] has type " << int(curCell->type) << " and id " << curCell->id << endl;
                // this is to find the number of TJ surrounding the new lumen
                // if two different cells are adjacent to each other and the center cell is a lumen
                // then that's a TJ.
                if (curCell != nextCell && curCell->type !=2 && nextCell->type != 2) {
                    cerr << "Cell " << curCell->id << " not equal to cell " << nextCell->id << " so this is a tight junction" << endl;
                    newTJCount++;
                }
                // if a cell that's different from the center cell is also adjacent to a lumen, then that's
                // a TJ. Count it.
                // 

                // Then either curCell is a lumen and nextCell is a different cell of type 1 or 3
                if (curCell->type == 2 && nextCell->type != 2 && oldCell != nextCell) {
                    cerr << "Old cell tight junction type 1" << endl;
                    oldTJCount++;
                }
                // Or curCell is a different cell and nextCell is a lumen   
                else if (curCell->type != 2 && oldCell != curCell && nextCell->type ==2) {
                    cerr << "Old cell tight junction type 2" << endl;
                    oldTJCount++;
                }

            } // end for loop
        } // end if location changing from cell to lumen
        else if (oldCell->type >2 && newCell->type >2) { // if location changing from stable cell to stable cell
            cerr << "Connectivity: cell changing to cell.  Checking. " << endl;
            cerr << "Old cell id=" << oldCell->id << " and type=" << int(oldCell->type) << endl;
            cerr << "New cell id=" << newCell->id << " and type=" << int(newCell->type) << endl;
            
            // we now need to count the number of TJs that existed when the cell was a cell
            // as well as the number that would exist if the cell changed to lumen
                        
            // n[i] is in order from 0 (North) to 5 (NE) in clockwise order
            for (unsigned int i = 0; i < numberOfNeighbors; i++) {  
                cerr << "Connectivity: in for loop for neighbors" << endl;  
                CellG* curCell = cellField->get(n[i]);
                CellG* nextCell = cellField->get(n[(i+1)%6]);
                if (!curCell || !nextCell) {
                    cerr << "Matrix: no TJ, so continuing" << endl;
                    continue;
                }
                cerr << "n[" << i << "] has type " << int(curCell->type) << " and id " << curCell->id << endl;
                
                
                // if a cell that's different from the center cell is also adjacent to a lumen, then that's
                // a TJ. Count it.
                // 
                
                // First count TJs for old cell configuration:
                // Either curCell is a lumen and nextCell is a different cell of type 1 or 3
                if (curCell->type == 2 && nextCell->type != 2 && oldCell != nextCell) {
                    cerr << "Old cell tight junction type 1" << endl;
                    oldTJCount++;
                }
                // Or curCell is a different cell and nextCell is a lumen   
                else if (curCell->type != 2 && oldCell != curCell && nextCell->type ==2) {
                    cerr << "Old cell tight junction type 2" << endl;
                    oldTJCount++;
                }
                // Then count TJs for new cell configuration:
                if (curCell->type == 2 && nextCell->type != 2 && newCell != nextCell) {
                    cerr << "New cell tight junction type 1" << endl;
                    newTJCount++;
                }
                // Or curCell is a different cell and nextCell is a lumen   
                else if (curCell->type != 2 && newCell != curCell && nextCell->type ==2) {
                    cerr << "New cell tight junction type 2" << endl;
                    newTJCount++;
                }
            }
            cerr << "Cell to cell tight junction count: old: " << oldTJCount << ", new: " << newTJCount << endl;
            if (oldTJCount != newTJCount) {
                cerr << "cell to cell TJ count is different!" << endl;
            }                
        }
        cerr << "Tight junction count: old: " << oldTJCount << ", new: " << newTJCount << endl;
        if (oldTJCount == 2 && newTJCount == 2) {
            cerr << "Found 2 to 2 transition in cell to cell" << endl;
            return penalty;
        }
        if (oldTJCount != newTJCount) {
            cerr << "TJ count is different!" << endl;
            return penalty;
        }
    }
    else if (oldCell && newCell && oldCell->type == 2 && newCell->type > 2) { // cell changing from lumen to stable cell
        Field3D<CellG *> *cellField = potts->getCellFieldG();
        
        // count the number of tight junctions
        int oldTJCount = 0;
        int newTJCount = 0;
        
        // cell is changing from lumen to cell
        cerr << "Found a point where a cell could change from lumen to cell."  << endl;
        
        cerr << "Connectivity: lumen changing to cell.  Checking. " << endl;
        
            cerr << "Old cell id=" << oldCell->id << " and type=" << int(oldCell->type) << endl;
            
            // we now need to count the number of TJs that existed when the cell was a cell
            // as well as the number that would exist if the cell changed to lumen
                        
            // n[i] is in order from 0 (North) to 5 (NE) in clockwise order
            for (unsigned int i = 0; i < numberOfNeighbors; i++) {  
                cerr << "Connectivity: in for loop for neighbors" << endl;  
                CellG* curCell = cellField->get(n[i]);
                CellG* nextCell = cellField->get(n[(i+1)%6]);
                if (!curCell || !nextCell) {
                    cerr << "Found matrix neighbor so returning penalty" << endl;
                    return penalty;
                }
                cerr << "n[" << i << "] has type " << int(curCell->type) << " and id " << curCell->id << endl;
                // this is to find the number of TJ surrounding the old lumen
                // if two different cells are adjacent to each other and the center cell is a lumen
                // then that's a TJ.
                if (curCell != nextCell && curCell->type !=2 && nextCell->type != 2) {
                    cerr << "Cell " << curCell->id << " not equal to cell " << nextCell->id << " so this is a tight junction" << endl;
                    oldTJCount++;
                }
                // if a cell that's different from the center cell is also adjacent to a lumen, then that's
                // a TJ. Count it.
                // 

                // Then either curCell is a lumen and nextCell is a different cell of type 1 or 3
                if (curCell->type == 2 && nextCell->type != 2 && newCell != nextCell) {
                    cerr << "New cell tight junction type 1" << endl;
                    newTJCount++;
                }
                // Or curCell is a different cell and nextCell is a lumen   
                else if (curCell->type != 2 && newCell != curCell && nextCell->type ==2) {
                    cerr << "New cell tight junction type 2" << endl;
                    newTJCount++;
                }

            } // end for loop
        
            
            cerr << "For point that is changing from lumen to cell, oldTJCount is " << oldTJCount << " and newTJCount is " << newTJCount << endl;
            if (oldTJCount != newTJCount) {
                cerr << "Found a place where lumen changes to cell and TJCount changes." << endl;
            }
            if (newTJCount < oldTJCount) {
               cerr << "Found a place where lumen changes to cell and TJCount decreases. Returning penalty." << endl;
               return penalty;
            }
        
    }

 /* JAE 7/10/09
    * This code detects if the change will result in a cell being in contact with multiple lumens.
    * The rough idea is this:
    * There are two scenarios that result in cells contacting multiple lumens.
    * 1.  A location turns from cell to lumen and that lumen contacts other cells contacting other lumens.
    * 2.  A location touching lumen turns from one cell to another, resulting in the new cell contacting mulitple lumens.
    *
    * The solutions for the two situations are different:
    * 1.  If a cell is going to become lumen, then it can only have lumen or that type of cell neighbors.
    * 2.  If the cell is touching lumen, it cannot become another type of cell.
    */
    
    /* 
    
    
    // Rule 1: location changing from cell to lumen
 
    if (oldCell && newCell && (oldCell->type == 1 || oldCell->type == 3)) {
     
        Field3D<CellG *> *cellField = potts->getCellFieldG();
        if (newCell->type == 2) {
            cerr << "Connectivity: cell changing to lumen.  Checking. " << endl;
            
            // All neighbors must either be lumen or the same cell as the old cell.
            
            for (unsigned int i = 0; i < numberOfNeighbors; i++) {  
                cerr << "Connectivity: in for loop for neighbors" << endl;  
                CellG* curCell = cellField->get(n[i]);
                if (!curCell) {
                    cerr << "Found matrix neighbor so returning penalty" << endl;
                    return penalty;
                }
                cerr << "Connectivity: curCell has id " << curCell->id << endl;
                int cellType = curCell->type;
                cerr << "Connectivity: curCell has type " << cellType << endl;                
                
                switch (cellType) {
                    case 0:
                        return penalty;
                    case 1:
                    case 3:
                        if (curCell == oldCell) {
                            cerr << "Connectivity: cell neighbor is not new, so OK" << endl;
                            break;
                        }
                        else {
                            cerr << "Connectivity: location neighbors other cells, so returning penalty" << endl;                    
                            return penalty;
                        }
                        break;
                    case 2:
                        cerr << "Connectivity: cur neighbor is lumen, so OK" << endl;
                        break;  
                    }
                }        
            } // end if new location lumen
            else { // if new location is a cell
                cerr << " new location is a cell.  working on this for later..." << endl;
                
                for (unsigned int i = 0; i < numberOfNeighbors; i++) {  
                    cerr << "Connectivity: in for loop for neighbors" << endl;  
                    CellG* curCell = cellField->get(n[i]);
                    if (!curCell) {
                        cerr << "Found matrix neighbor so returning penalty" << endl;
                        return penalty;
                    }
                    cerr << "Connectivity: curCell has id " << curCell->id << endl;
                    int cellType = curCell->type;
                    cerr << "Connectivity: curCell has type " << cellType << endl;
                    
                    // If this location is changing from one cell to another
                    // then none of its current neighbors can be lumen.
                    if (cellType == 2) {
                        return penalty;
                    }
                }
                
            
            } // end if location is a cell
        } // end if old location is a cell
*/
        return 0;
    }    


/* old version.. should probably incorporate a lattice check somewhere.
// may do it, may not.
//modified version of connectivity algorithm - Tinri Aegerter
double ConnectivityEnergy::changeEnergy(const Point3D &pt,
                                  const CellG *newCell,
                                   const CellG *oldCell) {
                                   
                                   
   cerr << "calling changeEnergy in connectivityEnergy" << endl;
   cerr << "numberOfNeighbors is " << numberOfNeighbors << endl;
   
   if (!oldCell) return 0;
   uniqueCells.clear();
   Neighbor neighbor;

   //rule 1: go over first neighrest neighbors and check if newCell has 1st neighrest neioghbotsbelongin to the same cell   
   bool firstFlag=false;
   unsigned int firstMaxIndex=boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(1);
   for(int i=0 ; i <=firstMaxIndex ; ++i ){
      neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),i);
      if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
      }
      if(potts->getCellFieldG()->get(neighbor.pt)==newCell){
         firstFlag=true;
         break;
      }
   }  
   
   if(!firstFlag){
      return penalty;
   }


   // Immediate neighbors
      
      for(int i=0 ; i < numberOfNeighbors ; ++i ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),offsetsIndex[i]);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }

         n[i]=neighbor.pt;
      }

   //rule 2: Count collisions between pixels belonging to different cells. If the collision count is greater than 2 reject the spin flip
   mediumFlag = false;
   int collisioncount = 0;
   for (unsigned int i = 0; i < numberOfNeighbors; i++)
   {
      if (
            ((potts->getCellFieldG()->get(n[i]) == oldCell) || (potts->getCellFieldG()->get(n[(i+1) % numberOfNeighbors]) == oldCell))
              &&
            (potts->getCellFieldG()->get(n[i]) !=potts->getCellFieldG()->get(n[(i+1) % numberOfNeighbors]))
         )
      {
        addUnique(potts->getCellFieldG()->get(n[i]));
        addUnique(potts->getCellFieldG()->get(n[(i+1)%numberOfNeighbors]));
	collisioncount++;
      }
   }

   if (collisioncount == 2) return 0;  // Accept
   else { // Conditional rejection

      return penalty;  // Reject
   }
 
}
*/
// Original Implementation - kept as a reference
// double ConnectivityEnergy::changeEnergy(const Point3D &pt,
//                                   const CellG *newCell,
//                                    const CellG *oldCell) {
//  
//    if (!oldCell) return 0;
//    uniqueCells.clear();
// 
//    // Immediate neighbors
//       Neighbor neighbor;
//       for(int i=0 ; i < numberOfNeighbors ; ++i ){
//          neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),offsetsIndex[i]);
//          if(!neighbor.distance){
//          //if distance is 0 then the neighbor returned is invalid
//          continue;
//          }
// 
//          n[i]=neighbor.pt;
//       }
// 
// 
// 
// 
//    mediumFlag = false;
//    int collisioncount = 0;
//    for (unsigned int i = 0; i < numberOfNeighbors; i++)
//    {
//       if (((potts->getCellFieldG()->get(n[i]) == oldCell) ||
//            (potts->getCellFieldG()->get(n[(i+1) % numberOfNeighbors]) == oldCell))
//               &&
//           (potts->getCellFieldG()->get(n[i]) !=
//            potts->getCellFieldG()->get(n[(i+1) % numberOfNeighbors])))
//       {
//         addUnique(potts->getCellFieldG()->get(n[i]));
//         addUnique(potts->getCellFieldG()->get(n[(i+1)%numberOfNeighbors]));
// 	collisioncount++;
//       }
//    }
//    //if (collisioncount == 0) {
//    //    cout << "COLLISION COUNT OF 0" << endl;
//        /*cout << potts->getCellFieldG()->get(n[0]) << endl;
//        cout << potts->getCellFieldG()->get(n[1]) << endl;
//        cout << potts->getCellFieldG()->get(n[2]) << endl;
//        cout << potts->getCellFieldG()->get(n[3]) << endl;
//        cout << potts->getCellFieldG()->get(n[4]) << endl;
//        cout << potts->getCellFieldG()->get(n[5]) << endl;
//        cout << potts->getCellFieldG()->get(n[6]) << endl;
//        cout << potts->getCellFieldG()->get(n[7]) << endl;
//        int aaa;
//        cin >> aaa;*/
//    //}
//    if (collisioncount == 2) return 0;  // Accept
//    else { // Conditional rejection
//       if (collisioncount > 2 && uniqueCells.size() == 2 && !mediumFlag) return 0; // Accept
//       else return penalty;  // Reject
//    }
// }




void ConnectivityEnergy::readXML(XMLPullParser &in) {
  in.skip(TEXT);

  while (in.check(START_ELEMENT)) {
    if (in.getName() == "Penalty") {
      cpd.penalty = BasicString::parseDouble(in.matchSimple());
      
    }
   else {
      throw BasicException(string("Unexpected element '") + in.getName() +
                           "'!", in.getLocation());
    }

    in.skip(TEXT);
  }
}


// This function assumes that the ordering may change.
// In two dimensions in a hex lattice the ordering is just one 
// of two ways, and thus we can safely not call this function.
void ConnectivityEnergy::orderNeighborsClockwise
(Point3D & _midPoint, const std::vector<Point3D> & _offsets, std::vector<int> & _offsetsIndex)
{
    cerr << "in clockwise ordering" << endl;
      //this function maps indexes of neighbors as given by boundary strategy to indexes of neighbors which are in clockwise order
      //that is when iterating over list of neighbors using boundaryStrategy API you can retrieve neighbors in clocwise order if you use
      //neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),offsetsIndex[i]) call
      Neighbor neighbor;
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(_midPoint),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         for(int i = 0 ; i < numberOfNeighbors ; ++i){
            if(_midPoint+_offsets[i] == neighbor.pt){
               _offsetsIndex[i]=nIdx;
            }
         }
      }
}

/*
 * This function will set the hex offsets, depending on whether curPoint has an even or odd
 * y coordinate.
 *
 */
void ConnectivityEnergy::setHexOffsets(const Point3D & curPoint) {

//    cerr << "in setHexOffsets" << endl;
    
//    cerr << "curPoint is " << curPoint << endl;
    
    /* This code relies on the offsets appearing in different ways
      depending on whether y is even or odd.
      
      Even:
      
         3   5
     1   x   0
         2   4   
    
      Odd:
      
      5   3
      1   x   0
      4   2   
      
      And the desired ordering will be:
      
        5   0
      4   x   1
        3   2
    
    */
    

    // Even:
    if (curPoint.y % 2 == 0) {
//        cerr << "creating offsetsIndex assignments" << endl;
        offsetsIndex[0] = 5;
        offsetsIndex[1] = 0;
        offsetsIndex[2] = 4;
        offsetsIndex[3] = 2;
        offsetsIndex[4] = 1;
        offsetsIndex[5] = 3;
    } // Odd:
    else {
        offsetsIndex[0] = 3;
        offsetsIndex[1] = 0;
        offsetsIndex[2] = 2;
        offsetsIndex[3] = 4;
        offsetsIndex[4] = 1;
        offsetsIndex[5] = 5;
    }

//    cerr << "done with setHexOffSets " << endl;
}


void ConnectivityEnergy::initializeNeighborsOffsets(){
   
   Dim3D fieldDim=potts->getCellFieldG()->getDim();
   vector<Point3D> offsets;

   offsets.assign(numberOfNeighbors,Point3D(0,0,0));//allocates memory for vector of offsets 

   boundaryStrategy=BoundaryStrategy::getInstance();
   maxNeighborIndex=0;

   maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromDepth(1.45);//second nearest neighbor

   ASSERT_OR_THROW("This plugin will only work for 2D simulations i.e. one lattice dimansion must be equal to 1 Your simulations appears to be 3D", !(fieldDim.x>1 && fieldDim.y>1 && fieldDim.z>1 ) );

   //here we define neighbors  offsets in the "clockwise order"
   if(fieldDim.x==1){
      //clockwise offsets
      offsets[0]=Point3D(0,0,-1);
      offsets[1]=Point3D(0,-1,-1);
      offsets[2]=Point3D(0,-1,0);
      offsets[3]=Point3D(0,-1,1);
      offsets[4]=Point3D(0,0,1);
      offsets[5]=Point3D(0,1,1);
      offsets[6]=Point3D(0,1,0);
      offsets[7]=Point3D(0,1,-1);

      Point3D midPoint(0, fieldDim.y/2, fieldDim.z/2);
      orderNeighborsClockwise(midPoint , offsets , offsetsIndex);

   }

   if(fieldDim.y==1){

      offsets[0]=Point3D(0,0,-1);
      offsets[1]=Point3D(-1,0,-1);
      offsets[2]=Point3D(-1,0,0);
      offsets[3]=Point3D(-1,0,1);
      offsets[4]=Point3D(0,0,1);
      offsets[5]=Point3D(1,0,1);
      offsets[6]=Point3D(1,0,0);
      offsets[7]=Point3D(1,0,-1);

      Point3D midPoint(fieldDim.x/2, 0, fieldDim.z/2);
      orderNeighborsClockwise(midPoint , offsets , offsetsIndex);



   }
   
   if(fieldDim.z==1){
      offsets[0]=Point3D(0,-1,0);
      offsets[1]=Point3D(-1,-1,0);
      offsets[2]=Point3D(-1,0,0);
      offsets[3]=Point3D(-1,1,0);
      offsets[4]=Point3D(0,1,0);
      offsets[5]=Point3D(1,1,0);
      offsets[6]=Point3D(1,0,0);
      offsets[7]=Point3D(1,-1,0);
      
      Point3D midPoint(fieldDim.x/2, fieldDim.y/2, 0);
      orderNeighborsClockwise(midPoint , offsets , offsetsIndex);
   }

}


void ConnectivityEnergy::writeXML(XMLSerializer &out) {
}

std::string ConnectivityEnergy::steerableName(){
   return cpd.ModuleName();
}
