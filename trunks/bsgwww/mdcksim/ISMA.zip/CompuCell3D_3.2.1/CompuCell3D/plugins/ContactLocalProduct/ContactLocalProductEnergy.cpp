/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/Potts3D/Cell.h>
#include <CompuCell3D/Automaton/Automaton.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <CompuCell3D/Potts3D/Cell.h>
#include <PublicUtilities/StringUtils.h>
#include <algorithm>


#include <string>
using namespace std;

#define EXP_STL
#include "ContactLocalProductEnergy.h"

ContactLocalProductEnergy::ContactLocalProductEnergy() :
   potts(potts), 
   depth(1),
   weightDistance(false),
   contactProductDataAccessorPtr(0),
   contactEnergyPtr(&ContactLocalProductEnergy::contactEnergyLinear),
   maxNeighborIndex(0),
   boundaryStrategy(0),
   energyOffset(0.0),
   clppdPtr(0)

{}

ContactLocalProductEnergy::~ContactLocalProductEnergy()
{}

double ContactLocalProductEnergy::localEnergy(const Point3D &pt) {
  return 0;
}



double ContactLocalProductEnergy::changeEnergy(const Point3D &pt,
                                  const CellG *newCell,
                                  const CellG *oldCell) {
   //cerr<<"ChangeEnergy"<<endl;
   
   
  double energy = 0;
  unsigned int token = 0;
  double distance = 0;
//   Point3D n;
  Neighbor neighbor;
  
  CellG *nCell=0;
  WatchableField3D<CellG *> *fieldG = (WatchableField3D<CellG *> *)potts->getCellFieldG();

   if(weightDistance){
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         nCell = fieldG->get(neighbor.pt);

         if(nCell!=oldCell){
            energy -= (this->*contactEnergyPtr)(oldCell, nCell) / distance;
         }
         if(nCell!=newCell){
            energy += (this->*contactEnergyPtr)(newCell, nCell) / distance;
         }
      }
  }else{
   //default behaviour  no energy weighting 
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         nCell = fieldG->get(neighbor.pt);

         if(nCell!=oldCell){
            energy -= (this->*contactEnergyPtr)(oldCell, nCell);
         }
         if(nCell!=newCell){
            energy += (this->*contactEnergyPtr)(newCell, nCell);
         }
      }

   }

//   cerr<<"energy="<<energy<<endl;
  return energy;
}


double ContactLocalProductEnergy::contactEnergyLinear(const CellG *cell1, const CellG *cell2) {
   
   CellG *cell;
   CellG *neighbor;

   if(cell1){
      cell=const_cast<CellG *>(cell1);
      neighbor=const_cast<CellG *>(cell2);
   }else{
      cell=const_cast<CellG *>(cell2);
      neighbor=const_cast<CellG *>(cell1);
   }

   
   
   
   if(neighbor){
      vector<float> & jVecCell  = contactProductDataAccessorPtr->get(cell->extraAttribPtr)->jVec;
      vector<float> & jVecNeighbor  = contactProductDataAccessorPtr->get(neighbor->extraAttribPtr)->jVec;


      return energyOffset-jVecCell[0]*jVecNeighbor[0]*contactSpecificity(cell,neighbor);
   }else{
         return energyOffset- contactSpecificity(cell,neighbor);

   }

}

double ContactLocalProductEnergy::contactEnergyQuadratic(const CellG *cell1, const CellG *cell2) {
   
   CellG *cell;
   CellG *neighbor;

   if(cell1){
      cell=const_cast<CellG *>(cell1);
      neighbor=const_cast<CellG *>(cell2);
   }else{
      cell=const_cast<CellG *>(cell2);
      neighbor=const_cast<CellG *>(cell1);
   }

   
   
   if(neighbor){
      vector<float> & jVecCell  = contactProductDataAccessorPtr->get(cell->extraAttribPtr)->jVec;
      vector<float> & jVecNeighbor  = contactProductDataAccessorPtr->get(neighbor->extraAttribPtr)->jVec;


      return energyOffset-jVecCell[0]*jVecCell[0]*jVecNeighbor[0]*jVecNeighbor[0]*contactSpecificity(cell,neighbor);
   }else{
         return energyOffset- contactSpecificity(cell,neighbor);

   }

}

double ContactLocalProductEnergy::contactEnergyMin(const CellG *cell1, const CellG *cell2) {
   
   CellG *cell;
   CellG *neighbor;

   if(cell1){
      cell=const_cast<CellG *>(cell1);
      neighbor=const_cast<CellG *>(cell2);
   }else{
      cell=const_cast<CellG *>(cell2);
      neighbor=const_cast<CellG *>(cell1);
   }

   
   
   
   if(neighbor){
      vector<float> & jVecCell  = contactProductDataAccessorPtr->get(cell->extraAttribPtr)->jVec;
      vector<float> & jVecNeighbor  = contactProductDataAccessorPtr->get(neighbor->extraAttribPtr)->jVec;


      return energyOffset-(jVecCell[0]<jVecNeighbor[0] ? jVecCell[0] : jVecNeighbor[0])*contactSpecificity(cell,neighbor);
   }else{
         return energyOffset- contactSpecificity(cell,neighbor);

   }

}



double ContactLocalProductEnergy::contactSpecificity(const CellG *cell1, const CellG *cell2){
   return contactSpecificityArray[cell1 ? cell1->type : 0][cell2? cell2->type : 0];
}

void ContactLocalProductEnergy::setContactEnergy(const string typeName1,
				     const string typeName2,
				     const double energy) {
                    
  char type1 = automaton->getTypeId(typeName1);
  char type2 = automaton->getTypeId(typeName2);
    
  int index = getIndex(type1, type2);

  contactEnergies_t::iterator it = contactEnergies.find(index);
  ASSERT_OR_THROW(string("Contact energy for ") + typeName1 + " " + typeName2 +
		  " already set!", it == contactEnergies.end());

  contactEnergies[index] = energy;
}

int ContactLocalProductEnergy::getIndex(const int type1, const int type2) const {
  if (type1 < type2) return ((type1 + 1) | ((type2 + 1) << 16));
  else return ((type2 + 1) | ((type1 + 1) << 16));
}


void ContactLocalProductEnergy::readXML(XMLPullParser &in) {
  
  in.skip(TEXT);

  while (in.check(START_ELEMENT)) {
    if (in.getName() == "ContactSpecificity") {

      string type1 = in.getAttribute("Type1").value;
      string type2 = in.getAttribute("Type2").value;

      double spec = BasicString::parseDouble(in.matchSimple());

      ContactLocalProductSpecificityTupple tupple(type1,type2,spec);
      clppd.contactLocalProductSpecificityTuppleVec.push_back(tupple);
    } 
    else if (in.getName() == "Depth") {
      
      clppd.depth = BasicString::parseDouble(in.matchSimple());
      
    }
   else if (in.getName() == "NeighborOrder") {
      clppd.NeighborOrder( BasicString::parseUInteger(in.matchSimple()));
    }


   else if (in.getName() == "Weight") {
      
      clppd.weightDistance=true;
      in.matchSimple();

      
    } 

    else if (in.getName() == "EnergyOffset") {
      clppd.energyOffset = BasicString::parseDouble(in.matchSimple());
      
    }
    else if (in.getName() == "ContactFunctionType") {
      clppd.contactFunctionType=in.matchSimple();
      changeToLower(clppd.contactFunctionType);

   }   else {
      throw BasicException(string("Unexpected element '") + in.getName() +
                           "'!", in.getLocation());
    }

    in.skip(TEXT);
  }


}

void ContactLocalProductEnergy::writeXML(XMLSerializer &out) {
}

void ContactLocalProductEnergy::initializeContactEnergy(ParseData *_pd){
   clppdPtr=(ContactLocalProductParseData*)_pd;

   automaton = potts->getAutomaton();
   set<unsigned char> cellTypesSet;
   contactEnergies.clear();
   contactSpecificityArray.clear();

   for ( int i=0 ; i < clppdPtr->contactLocalProductSpecificityTuppleVec.size() ; ++ i){
     
      setContactEnergy(clppdPtr->contactLocalProductSpecificityTuppleVec[i].type1Name, clppdPtr->contactLocalProductSpecificityTuppleVec[i].type2Name, clppdPtr->contactLocalProductSpecificityTuppleVec[i].specificity);

      //inserting all the types to the set (duplicate are automatically eleminated) to figure out max value of type Id
      cellTypesSet.insert(automaton->getTypeId(clppdPtr->contactLocalProductSpecificityTuppleVec[i].type1Name));
      cellTypesSet.insert(automaton->getTypeId(clppdPtr->contactLocalProductSpecificityTuppleVec[i].type2Name));
   }

   
  //Now that we know all the types used in the simulation we will find size of the contactSpecificityArray
  vector<unsigned char> cellTypesVector(cellTypesSet.begin(),cellTypesSet.end());//coping set to the vector

  int size= * max_element(cellTypesVector.begin(),cellTypesVector.end());
  size+=1;//if max element is e.g. 5 then size has to be 6 for an array to be properly allocated
  
  int index ;
  contactSpecificityArray.assign(size,vector<double>(size,0.0));

  for(int i = 0 ; i < size ; ++i)
   for(int j = 0 ; j < size ; ++j){
   
      index = getIndex(cellTypesVector[i],cellTypesVector[j]);
      
      contactSpecificityArray[i][j] = contactEnergies[index];
      
   }
   cerr<<"size="<<size<<endl;
   
  for(int i = 0 ; i < size ; ++i)
   for(int j = 0 ; j < size ; ++j){
   
      cerr<<"contact["<<i<<"]["<<j<<"]="<<contactSpecificityArray[i][j]<<endl;
      
   }

   if(clppdPtr->contactFunctionType=="linear"){
      contactEnergyPtr=&ContactLocalProductEnergy::contactEnergyLinear;
   }else if(clppdPtr->contactFunctionType=="quadratic"){
      contactEnergyPtr=&ContactLocalProductEnergy::contactEnergyQuadratic;
   }else if (clppdPtr->contactFunctionType=="min"){
      contactEnergyPtr=&ContactLocalProductEnergy::contactEnergyMin;
   }else{
      contactEnergyPtr=&ContactLocalProductEnergy::contactEnergyLinear;
   }

   boundaryStrategy=BoundaryStrategy::getInstance();
   maxNeighborIndex=0;

   if(clppdPtr->depthFlag){
      maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromDepth(clppdPtr->depth);
//       cerr<<"got here will do depth"<<endl;
   }else{
//       cerr<<"got here will do neighbor order"<<endl;
      maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(clppdPtr->neighborOrder);
   }




}

void ContactLocalProductEnergy::update(ParseData *_pd, bool _fullInitFlag){
   initializeContactEnergy(_pd);
}

std::string ContactLocalProductEnergy::steerableName(){
   return clppd.ModuleName();
}



std::string ContactLocalProductEnergy::toString(){
  return string("ContactLocalProduct");
}
