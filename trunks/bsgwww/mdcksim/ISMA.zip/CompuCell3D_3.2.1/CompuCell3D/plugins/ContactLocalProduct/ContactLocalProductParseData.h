/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef CONTACTLOCALPRODUCTPARSEDATA_H
#define CONTACTLOCALPRODUCTPARSEDATA_H

#include <CompuCell3D/ParseData.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

  class DECLSPECIFIER ContactLocalProductSpecificityTupple{
      public:
      ContactLocalProductSpecificityTupple():
         type1Name(""),
         type2Name(""),
         specificity(0)
         
      {}

      ContactLocalProductSpecificityTupple(std::string _type1Name, std::string _type2Name,double _specificity):
         type1Name(_type1Name),
         type2Name(_type2Name),
         specificity(_specificity)
      {}

      std::string type1Name;
      std::string type2Name;
      double specificity;
      
  };

  class DECLSPECIFIER ContactLocalProductParseData : public ParseData {
      public:
         ContactLocalProductParseData():
            ParseData("ContactLocalProduct"),
            depth(1.1),
            energyOffset(0.),
            depthFlag(false),
            weightDistance(false),
            neighborOrder(1)
            {}
         
         double depth;
         bool depthFlag;
         double energyOffset;

         unsigned int neighborOrder;

         std::string contactFunctionType;
         std::vector<ContactLocalProductSpecificityTupple> contactLocalProductSpecificityTuppleVec;
         bool weightDistance;
         void ContactSpecificity(std::string _type1Name, std::string _type2Name,double _specificity){
            contactLocalProductSpecificityTuppleVec.push_back(ContactLocalProductSpecificityTupple(_type1Name,_type2Name,_specificity));
         }


         ContactLocalProductSpecificityTupple * getContactLocalProductSpecificityTupple(std::string _type1Name, std::string _type2Name){
            for (int i = 0 ; i < contactLocalProductSpecificityTuppleVec.size() ; ++i){
               if(contactLocalProductSpecificityTuppleVec[i].type1Name==_type1Name && contactLocalProductSpecificityTuppleVec[i].type2Name==_type2Name)
                  return &contactLocalProductSpecificityTuppleVec[i];
               else if (contactLocalProductSpecificityTuppleVec[i].type2Name==_type1Name && contactLocalProductSpecificityTuppleVec[i].type1Name==_type2Name)
                  return &contactLocalProductSpecificityTuppleVec[i];
            }
            return 0;
         }



         void Depth(double _depth){
            depthFlag=true;
            depth=_depth;
         }

         void NeighborOrder(unsigned int _neighborOrder=1){
            depthFlag=false;
            if(_neighborOrder>neighborOrder){
               neighborOrder=_neighborOrder;
            }
         }
         void EnergyOffset(double _energyOffset){energyOffset=_energyOffset;}
         void Weight(bool _weightDistance){weightDistance=_weightDistance;}
  };
};
#endif
