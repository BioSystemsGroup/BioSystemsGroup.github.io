/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef CONTACTLOCALPRODUCTENERGY_H
#define CONTACTLOCALPRODUCTENERGY_H

#include <CompuCell3D/Potts3D/EnergyFunction.h>

#include <XMLCereal/XMLSerializable.h>

#include "ContactLocalProductPlugin.h"
#include <CompuCell3D/Potts3D/Cell.h>

#include <map>
#include <vector>
#include "ContactLocalProductParseData.h"
#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {
  class Potts3D;
  class Automaton;
  class ContactLocalProductData;
  class BoundaryStrategy;

  class DECLSPECIFIER ContactLocalProductEnergy : public EnergyFunction, public XMLSerializable {

   public:
      typedef double (ContactLocalProductEnergy::*contactEnergyPtr_t)(const CellG *cell1, const CellG *cell2);


   private:
    Potts3D *potts;

    typedef std::map<int, double> contactEnergies_t;
    typedef std::vector<std::vector<double> > contactSpecificityArray_t;
    
    contactEnergies_t contactEnergies;

    contactSpecificityArray_t contactSpecificityArray;
    
    std::string autoName;
    double depth;

    BasicClassAccessor<ContactLocalProductData> * contactProductDataAccessorPtr;

    Automaton *automaton;
    bool weightDistance;
    
    contactEnergyPtr_t contactEnergyPtr;

    unsigned int maxNeighborIndex;
    BoundaryStrategy *boundaryStrategy;
    float energyOffset;
   

    
  public:
    ContactLocalProductParseData clppd;
    ContactLocalProductParseData * clppdPtr;

    ContactLocalProductEnergy() ;
    
    virtual ~ContactLocalProductEnergy();
    void setContactProductDataAccessorPtr(BasicClassAccessor<ContactLocalProductData> *  _cpdAccessorPtr){
      contactProductDataAccessorPtr=_cpdAccessorPtr;
    }
    double contactSpecificity(const CellG *cell1, const CellG *cell2);
   void initializeContactEnergy(ParseData *_pd);
   void setPotts(Potts3D * _potts){potts=_potts;}
    virtual double localEnergy(const Point3D &pt);
//      virtual double changeEnergy(const Point3D &pt, const Cell *newCell,
//                                  const Cell *oldCell);

    virtual double changeEnergy(const Point3D &pt, const CellG *newCell,
                                const CellG *oldCell);
    
				
    /**
     * @return The contact energy between cell1 and cell2.
     */
    double contactEnergyLinear(const CellG *cell1, const CellG *cell2);
    double contactEnergyQuadratic(const CellG *cell1, const CellG *cell2);
    double contactEnergyMin(const CellG *cell1, const CellG *cell2);

    /**
     * Sets the contact energy for two cell types.  A -1 type is interpreted
     * as the medium.
     */
    void setContactEnergy(const std::string typeName1,
			  const std::string typeName2, const double energy);


    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    virtual std::string toString();
    // End XMLSerializable interface
    //Steerrable interface
    virtual void update(ParseData *_pd, bool _fullInitFlag=false);
    virtual std::string steerableName();


  protected:
    /**
     * @return The index used for ordering contact energies in the map.
     */
    int getIndex(const int type1, const int type2) const;
  };
};
#endif
