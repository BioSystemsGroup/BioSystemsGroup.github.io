/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/plugins/PolarizationVector/PolarizationVector.h>
#include <CompuCell3D/plugins/PolarizationVector/PolarizationVectorPlugin.h>

using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <iostream>
using namespace std;

#define EXP_STL
#include "CellOrientationPlugin.h"

#include "CellOrientationEnergy.h"


CellOrientationPlugin::CellOrientationPlugin() : cellOrientationEnergy(0), cellFieldG(0) {}

void CellOrientationPlugin::setLambdaCellOrientation(CellG * _cell, double _lambda){
   lambdaCellOrientationAccessor.get(_cell->extraAttribPtr)->lambdaVal=_lambda;
}
double CellOrientationPlugin::getLambdaCellOrientation(CellG * _cell){
   return lambdaCellOrientationAccessor.get(_cell->extraAttribPtr)->lambdaVal;
}


CellOrientationPlugin::~CellOrientationPlugin() {
  if (cellOrientationEnergy) delete cellOrientationEnergy;
}

void CellOrientationPlugin::init(Simulator *simulator, ParseData *_pd) {
   if(!cellOrientationEnergy){
      cellOrientationEnergy=new CellOrientationEnergy();
   }

  pd=_pd;
  cellOrientationEnergy->copdPtr=(CellOrientationParseData*)pd;
  cellOrientationEnergy->init(simulator);

   cerr<<"INITIALIZE CELL ORIENTATION PLUGIN"<<endl;   
   Potts3D *potts = simulator->getPotts();
//    potts->getCellFactoryGroupPtr()->registerClass(&CellOrientationVectorAccessor); //register new class with the factory

   bool pluginAlreadyRegisteredFlag;
   PolarizationVectorPlugin * polVectorPlugin = (PolarizationVectorPlugin*) Simulator::pluginManager.get("PolarizationVector",&pluginAlreadyRegisteredFlag);
   if(!pluginAlreadyRegisteredFlag)
   polVectorPlugin->init(simulator);

   polarizationVectorAccessorPtr=polVectorPlugin->getPolarizationVectorAccessorPtr();

   cellFieldG = potts->getCellFieldG();
   
   potts->registerEnergyFunctionWithName(cellOrientationEnergy,"CellOrientationEnergy");

   potts->getCellFactoryGroupPtr()->registerClass(&lambdaCellOrientationAccessor);

   simulator->registerSteerableObject(this);


}

void CellOrientationPlugin::extraInit(Simulator *simulator) {
  cerr<<"EXTRA INITIALIZE CELL ORIENTATION PLUGIN"<<endl;   
  Potts3D *potts = simulator->getPotts();
  cellFieldG = potts->getCellFieldG();
  cellOrientationEnergy->initialize( simulator);
  cellOrientationEnergy->setPolarizationVectorAccessorPtr(this->getPolarizationVectorAccessorPtr() );
  cellOrientationEnergy->setLambdaCellOrientationAccessorPtr(this->getLambdaCellOrientationAccessorPtr());
}


void CellOrientationPlugin::readXML(XMLPullParser &in) {
   if(!cellOrientationEnergy){
      cellOrientationEnergy=new CellOrientationEnergy();
   }

   pd=&cellOrientationEnergy->copd;


  cellOrientationEnergy->readXML(in);
}

void CellOrientationPlugin::writeXML(XMLSerializer &out) {
  cellOrientationEnergy->writeXML(out);
}


void CellOrientationPlugin::update(ParseData *_pd, bool _fullInitFlag){
   cellOrientationEnergy->update(_pd);
}
std::string CellOrientationPlugin::steerableName(){
   return cellOrientationEnergy->copd.ModuleName();
}

