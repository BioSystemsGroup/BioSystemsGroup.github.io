/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR1 PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef CELLORIENTATIONENERGY_H
#define CELLORIENTATIONENERGY_H

#include <CompuCell3D/Potts3D/EnergyFunction.h>

#include <XMLCereal/XMLSerializable.h>
#include <CompuCell3D/Field3D/Dim3D.h>
#include "CellOrientationParseData.h"

#include <CompuCell3D/dllDeclarationSpecifier.h>

template <class T>
class BasicClassAccessor;


namespace CompuCell3D {

  template <class T> class Field3D;
  class Point3D;
  class Potts3D;
  class Simulator;
  class PolarizationVector;
  class LambdaCellOrientation;


  class BoundaryStrategy;

  class DECLSPECIFIER CellOrientationEnergy: public EnergyFunction, public virtual XMLSerializable {
    
    Field3D<CellG *> *cellFieldG;
   Potts3D *potts;

    
    double lambdaCellOrientation;
    Simulator *simulator;
    Dim3D fieldDim;
    BasicClassAccessor<PolarizationVector> *polarizationVectorAccessorPtr;
    BasicClassAccessor<LambdaCellOrientation> * lambdaCellOrientationAccessorPtr;

   bool lambdaFlexFlag;

    
  public:
    CellOrientationParseData copd;
    CellOrientationParseData * copdPtr;

    CellOrientationEnergy():
          potts(0),lambdaCellOrientation(0.0),lambdaFlexFlag(false)

    {}
    

    void init(Simulator * simulator);
    
      
   

//     void setMaxNeighborIndex(unsigned int _maxNeighborIndex){maxNeighborIndex=_maxNeighborIndex;}
//     void setBoundaryStrategy(BoundaryStrategy *_boundaryStrategy){boundaryStrategy=_boundaryStrategy;}

    virtual double localEnergy(const Point3D &pt);
    virtual double changeEnergy(const Point3D &pt, const CellG *newCell,
				const CellG *oldCell);
    
    void initialize(Simulator * _simulator);
    void setPolarizationVectorAccessorPtr(BasicClassAccessor<PolarizationVector> *_polarizationVectorAccessorPtr){polarizationVectorAccessorPtr = _polarizationVectorAccessorPtr;}

    void setLambdaCellOrientationAccessorPtr(BasicClassAccessor<LambdaCellOrientation> *_lambdaCellOrientationAccessorPtr){lambdaCellOrientationAccessorPtr = _lambdaCellOrientationAccessorPtr;}
     
				
    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    // End XMLSerializable interface
    virtual std::string toString();
    //Steerable interface
    virtual void update(ParseData *_pd, bool _fullInitFlag=false);
    virtual std::string steerableName();



  };
};
#endif
