#ifndef PLASTICITYTRACKERPARSEDATA_H
#define PLASTICITYTRACKERPARSEDATA_H



#include <CompuCell3D/ParseData.h>
#include <set>
#include <string>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class DECLSPECIFIER PlasticityTrackerParseData:public ParseData{
      public:
      
      PlasticityTrackerParseData():ParseData("PlasticityTracker")
       {}
      std::set<std::string>   plasticityTypesNames;
      void IncludeType(std::string _typeName){plasticityTypesNames.insert(_typeName);}
   };
};
#endif
