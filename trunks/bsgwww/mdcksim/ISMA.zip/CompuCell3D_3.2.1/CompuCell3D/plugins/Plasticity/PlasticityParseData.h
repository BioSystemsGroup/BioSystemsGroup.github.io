#ifndef PLASTICITYPARSEDATA_H
#define PLASTICITYPARSEDATA_H



#include <CompuCell3D/ParseData.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class DECLSPECIFIER PlasticityParseData:public ParseData{
      public:
      PlasticityParseData():ParseData("Plasticity"),
      localCalcFlag (false),
      targetLengthPlasticity (0.),
      lambdaPlasticity(0.)
      {}

   void Local(bool _localCalcFlag){localCalcFlag=_localCalcFlag;}
   void TargetLengthPlasticity(double _targetLengthPlasticity){targetLengthPlasticity=_targetLengthPlasticity;}
   void LambdaPlasticity(double _lambdaPlasticity){lambdaPlasticity=_lambdaPlasticity;}

   bool localCalcFlag;
   double targetLengthPlasticity;
   double lambdaPlasticity;
   };
};
#endif
