/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/


#include <CompuCell3D/Automaton/Automaton.h>
#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>
#include <CompuCell3D/plugins/Volume/VolumePlugin.h>
#include <CompuCell3D/plugins/Volume/VolumeEnergy.h>
#include <CompuCell3D/Potts3D/CellInventory.h>

using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <iostream>
#include <cmath>
using namespace std;

#define EXP_STL
#include "PlasticityTrackerPlugin.h"


PlasticityTrackerPlugin::PlasticityTrackerPlugin() :
   cellFieldG(0),
   initialized(false),
   maxNeighborIndex(0),
   boundaryStrategy(0),
   ptpdPtr(0)
   {}

PlasticityTrackerPlugin::~PlasticityTrackerPlugin() {
}


void PlasticityTrackerPlugin::init(Simulator *_simulator,ParseData *_pd) {

  
  if(_pd){
      ptpdPtr=(PlasticityTrackerParseData *)_pd;
      pd=_pd;
   }

  simulator=_simulator;
  Potts3D *potts = simulator->getPotts();
  cellFieldG = (WatchableField3D<CellG *> *)potts->getCellFieldG();

  ///getting cell inventory
  cellInventoryPtr=& potts->getCellInventory(); 



  ///will register PlasticityTracker here
  BasicClassAccessorBase * plasticityTrackerAccessorPtr=&plasticityTrackerAccessor;
   ///************************************************************************************************  
  ///REMARK. HAVE TO USE THE SAME BASIC CLASS ACCESSOR INSTANCE THAT WAS USED TO REGISTER WITH FACTORY
   ///************************************************************************************************  
  potts->getCellFactoryGroupPtr()->registerClass(plasticityTrackerAccessorPtr);

  potts->registerCellGChangeWatcher(this);
  
  fieldDim=cellFieldG->getDim();

  boundaryStrategy=BoundaryStrategy::getInstance();
  maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(1);//1st nearest neighbor

   bool pluginAlreadyRegisteredFlag;
   Plugin *plugin=Simulator::pluginManager.get("CenterOfMass",&pluginAlreadyRegisteredFlag); //this will load COM plugin if it is not already loaded
  if(!pluginAlreadyRegisteredFlag)
      plugin->init(simulator);
   
  
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void PlasticityTrackerPlugin::extraInit(Simulator *_simulator) {

   plasticityTypesNames=ptpdPtr->plasticityTypesNames;
   Automaton * automaton=simulator->getPotts()->getAutomaton();
   // Initializing set of plasticitytypes
   for (set<string>::iterator sitr = plasticityTypesNames.begin() ; sitr != plasticityTypesNames.end() ; ++sitr){
      plasticityTypes.insert(automaton->getTypeId( *sitr));
   }
   

  
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void PlasticityTrackerPlugin::field3DChange(const Point3D &pt, CellG *newCell,
				  CellG *oldCell) {  

   //do not do any updates until the lattice is fully initialized
/*   if(simulator->getStep()<0){
      return;
   }*/
   

   if(simulator->getStep()>=0 && ! initialized){
      initializePlasticityNeighborList();
      initialized=true;
   }

   if (initialized){
      if(oldCell && oldCell->volume==1){
         //remove oldCell from neighbor list of old cell neighbors
         set<PlasticityTrackerData>::iterator sitr;
         set<PlasticityTrackerData> * plasticityNeighborsPtr=&plasticityTrackerAccessor.get(oldCell->extraAttribPtr)->plasticityNeighbors;
         set<PlasticityTrackerData> * plasticityNeighborsTmpPtr;
         for(sitr=plasticityNeighborsPtr->begin() ; sitr != plasticityNeighborsPtr->end() ; ++sitr){
            //getting set of plasticityNeighbors from the neighbor (pointed by sitr) of the oldCell
            plasticityNeighborsTmpPtr=&plasticityTrackerAccessor.get(sitr->neighborAddress->extraAttribPtr)->plasticityNeighbors ;
            //removing oldCell from the set
            plasticityNeighborsTmpPtr->erase(PlasticityTrackerData(oldCell));
         }
      }
   }


   
   

}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void PlasticityTrackerPlugin::readXML(XMLPullParser &in) {
   
   in.skip(TEXT);
   
   pd=&ptpd;
   while (in.check(START_ELEMENT)) {
      if (in.getName() == "IncludeType") {
//          plasticityTypesNames.insert(in.matchSimple());
         ptpd.IncludeType(in.matchSimple());
      }
      else {
         throw BasicException(string("Unexpected element '") + in.getName() +
                              "'!", in.getLocation());
      }
   
      in.skip(TEXT);
   }
}

void PlasticityTrackerPlugin::writeXML(XMLSerializer &out) {

}


void PlasticityTrackerPlugin::initializePlasticityNeighborList(){

   Point3D pt;
   CellG* cell;
   CellG* nCell;
   Neighbor neighbor;
   set<PlasticityTrackerData> * plasticityNeighborsTmpPtr;
   set<unsigned char>::iterator endSitr=plasticityTypes.end();

   for( unsigned int x =0 ; x< fieldDim.x ; ++x)
      for( unsigned int y =0 ; y< fieldDim.y ; ++y)
         for( unsigned int z =0 ; z< fieldDim.z ; ++z){
            pt=Point3D(x,y,z);
            cell=cellFieldG->get(pt);
            for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
               neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
               if(!neighbor.distance){
                  //if distance is 0 then the neighbor returned is invalid
                  continue;
               }
               nCell = cellFieldG->get(neighbor.pt);
               if(nCell!=cell){
                  if(nCell && cell){//only cells which are of certain types are considered as plasticityNeighbors
                     if(plasticityTypes.find(nCell->type)!=endSitr && plasticityTypes.find(cell->type)!=endSitr){
                        plasticityNeighborsTmpPtr=&plasticityTrackerAccessor.get(nCell->extraAttribPtr)->plasticityNeighbors;
                        plasticityNeighborsTmpPtr->insert(PlasticityTrackerData(cell));
                        plasticityNeighborsTmpPtr=&plasticityTrackerAccessor.get(cell->extraAttribPtr)->plasticityNeighbors;
                        plasticityNeighborsTmpPtr->insert(PlasticityTrackerData(nCell));
                     }
                  }
               }
            }
         }

// CellInventory::cellInventoryIterator cInvItr;
// for(cInvItr=cellInventoryPtr->cellInventoryBegin() ; cInvItr !=cellInventoryPtr->cellInventoryEnd() ;++cInvItr ){
//          
//       cell=*cInvItr;
//       plasticityNeighborsTmpPtr=&plasticityTrackerAccessor.get(cell->extraAttribPtr)->plasticityNeighbors;
//       cerr<<"cell.ID "<<cell->id<<" has "<<plasticityNeighborsTmpPtr->size()<<" Plasticity neighbors"<<endl;
// 
//    }
// 
// 
// exit(0);

}

