/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#include <CompuCell3D/plugins/Plasticity/PlasticityTrackerPlugin.h>

#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <iostream>
using namespace std;

#define EXP_STL
#include "PlasticityPlugin.h"

#include "PlasticityEnergy.h"


PlasticityPlugin::PlasticityPlugin() : plasticityEnergy(0), cellFieldG(0) {}

PlasticityPlugin::~PlasticityPlugin() {
  if (plasticityEnergy) delete plasticityEnergy;
}

void PlasticityPlugin::init(Simulator *simulator, ParseData * _pd) {
   if(!plasticityEnergy){
      plasticityEnergy = new PlasticityEnergy();
   }
  pd=_pd;
  plasticityEnergy->ppdPtr=(PlasticityParseData*)pd;
  plasticityEnergy->init(simulator);
   
   Potts3D *potts = simulator->getPotts();
   cellFieldG = potts->getCellFieldG();

   
   
   potts->registerEnergyFunctionWithName(plasticityEnergy,"PlasticityEnergy");
   simulator->registerSteerableObject(this);
   


}

void PlasticityPlugin::extraInit(Simulator *simulator) {
  Potts3D *potts = simulator->getPotts();
  cellFieldG = potts->getCellFieldG();
  plasticityEnergy->initialize( simulator);
  

   bool pluginAlreadyRegisteredFlag;
   PlasticityTrackerPlugin * trackerPlugin = (PlasticityTrackerPlugin *) Simulator::pluginManager.get("PlasticityTracker",&pluginAlreadyRegisteredFlag); //this will load PlasticityTracker plugin if it is not already loaded  
   if(!pluginAlreadyRegisteredFlag)
      trackerPlugin->init(simulator);
   plasticityEnergy->setPlasticityTrackerAccessorPtr(trackerPlugin->getPlasticityTrackerAccessorPtr() );

//   surfaceEnergy->setMaxNeighborIndex( trackerPlugin->getMaxNeighborIndex() );
   

}


void PlasticityPlugin::readXML(XMLPullParser &in) {
   
   if(!plasticityEnergy){
      plasticityEnergy = new PlasticityEnergy();
   }
   pd=&plasticityEnergy->ppd;
  plasticityEnergy->readXML(in);
}

void PlasticityPlugin::writeXML(XMLSerializer &out) {
  plasticityEnergy->writeXML(out);
}

void PlasticityPlugin::update(ParseData *pd, bool _fullInitFlag){
   plasticityEnergy->update(pd);
}

std::string PlasticityPlugin::steerableName(){
   return plasticityEnergy->ppd.moduleName;
}
