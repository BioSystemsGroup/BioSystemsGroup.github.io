/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR1 PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef PLASTICITYENERGY_H
#define PLASTICITYENERGY_H

#include <CompuCell3D/Potts3D/EnergyFunction.h>

#include <XMLCereal/XMLSerializable.h>
#include <CompuCell3D/Field3D/Dim3D.h>
#include "PlasticityParseData.h"

#include <CompuCell3D/dllDeclarationSpecifier.h>

template <class T>
class BasicClassAccessor;


namespace CompuCell3D {

  

  template <class T> class Field3D;
  class Point3D;
  class Simulator;
  class PlasticityTrackerData;
  class PlasticityTracker;
  class BoundaryStrategy;

  /** 
   * Calculates surface energy based on a target surface and
   * lambda surface.
   */
  class BoundaryStrategy;

  class DECLSPECIFIER PlasticityEnergy: public EnergyFunction, public virtual XMLSerializable {
    
    Field3D<CellG *> *cellFieldG;
    
       
    float targetLengthPlasticity;
    double lambdaPlasticity;
    Simulator *simulator;
    Dim3D fieldDim;
    BasicClassAccessor<PlasticityTracker> *plasticityTrackerAccessorPtr;
    typedef double (PlasticityEnergy::*diffEnergyFcnPtr_t)(float _deltaL,float _lBefore,const PlasticityTrackerData * _plasticityTrackerData,const CellG *_cell);

    diffEnergyFcnPtr_t diffEnergyFcnPtr;
    BoundaryStrategy  *boundaryStrategy;

    
  public:
    PlasticityParseData ppd;
    PlasticityParseData * ppdPtr;
    PlasticityEnergy() :
          cellFieldG(0), targetLengthPlasticity(0.0),lambdaPlasticity(0.0),diffEnergyFcnPtr(&PlasticityEnergy::diffEnergyGlobal),boundaryStrategy(0)

    {}
    

      
    void init(Simulator * simulator);
//     void update(ParseData * _pd);


//     void setMaxNeighborIndex(unsigned int _maxNeighborIndex){maxNeighborIndex=_maxNeighborIndex;}
//     void setBoundaryStrategy(BoundaryStrategy *_boundaryStrategy){boundaryStrategy=_boundaryStrategy;}

    virtual double localEnergy(const Point3D &pt);
    virtual double changeEnergy(const Point3D &pt, const CellG *newCell,
				const CellG *oldCell);
    double diffEnergyGlobal(float _deltaL,float _lBefore,const PlasticityTrackerData * _plasticityTrackerData,const CellG *_cell);
    double diffEnergyLocal(float _deltaL,float _lBefore,const PlasticityTrackerData * _plasticityTrackerData,const CellG *_cell);
    
    void initialize(Simulator * _simulator);
    void setPlasticityTrackerAccessorPtr(BasicClassAccessor<PlasticityTracker> *_plasticityTrackerAccessorPtr){plasticityTrackerAccessorPtr=_plasticityTrackerAccessorPtr;}
     
				
    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    // End XMLSerializable interface
    //SteerableObject interface
    virtual void update(ParseData *pd, bool _fullInitFlag=false);
    virtual std::string steerableName();


    virtual std::string toString();

  };
};
#endif
