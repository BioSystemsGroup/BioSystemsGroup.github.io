
#ifndef PLASTICITYTRACKER_H
#define PLASTICITYTRACKER_H


/**
@author m
*/
#include <set>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class CellG;
   

   class DECLSPECIFIER PlasticityTrackerData{
      public:

         PlasticityTrackerData(CellG * _neighborAddress=0,float lambda=0.0, float targetLength=0.0)
         :neighborAddress(_neighborAddress)
          {}

         ///have to define < operator if using a class in the set and no < operator is defined for this class
         bool operator<(const PlasticityTrackerData & _rhs) const{
            return neighborAddress < _rhs.neighborAddress;
         }
         ///members
         CellG * neighborAddress;
         float lambdaLength;
         float targetLength;

   };

   class DECLSPECIFIER PlasticityTracker{
      public:
         PlasticityTracker(){};
         ~PlasticityTracker(){};
         std::set<PlasticityTrackerData> plasticityNeighbors; //stores ptrs to cell neighbors i.e. each cell keeps track of its neighbors

   };
};
#endif


