/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Field3D/Point3D.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <string>
using namespace std;

#define EXP_STL
#include "SurfaceEnergy.h"

double SurfaceEnergy::diffEnergy(double surface, double diff) {
  return spdPtr->lambdaSurface *
    (diff*diff + 2 * diff * (surface - fabs(spdPtr->targetSurface)));
}


double SurfaceEnergy::localEnergy(const Point3D &pt) {
  return 0;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

double SurfaceEnergy::changeEnergy(const Point3D &pt,
				  const CellG *newCell,
				  const CellG *oldCell) {

  // E = lambda * (surface - targetSurface) ^ 2
  CellG *nCell;
  
  if (oldCell == newCell) return 0;

  unsigned int token = 0;
  double distance;
  double oldDiff = 0.;
  double newDiff = 0.;
  Point3D n;
  double energy = 0;


//    cerr<<"scaleSurface="<<scaleSurface<<" maxNeighborIndex="<<maxNeighborIndex<<endl;


  // Count surface difference

   Neighbor neighbor;
   for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
      neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
      if(!neighbor.distance){
      //if distance is 0 then the neighbor returned is invalid
      continue;
      }
      nCell = cellFieldG->get(neighbor.pt);
      if (newCell == nCell) newDiff-=lmf.surfaceMF;
      else newDiff+=lmf.surfaceMF;

      if (oldCell == nCell) oldDiff+=lmf.surfaceMF;
      else oldDiff-=lmf.surfaceMF;

   }



  if (newCell){
    energy += diffEnergy(newCell->surface*spdPtr->scaleSurface, newDiff*spdPtr->scaleSurface);
//     cerr<<"newCell->surface="<<newCell->surface<<endl;
   }
  if (oldCell){
    energy += diffEnergy(oldCell->surface*spdPtr->scaleSurface, oldDiff*spdPtr->scaleSurface);
//       cerr<<"oldCell->surface="<<oldCell->surface<<endl;
  }
   
  
//    cerr<<"lmf.surfaceMF="<<lmf.surfaceMF<<endl;
//    cerr<<"newDiff="<<newDiff<<" oldDiff="<<oldDiff<<endl;
//    if(energy<0) 
//       cerr<<"Energy="<<energy<<endl;
  return energy;
}


void SurfaceEnergy::readXML(XMLPullParser &in) {
  in.skip(TEXT);


  while (in.check(START_ELEMENT)) {
    if (in.getName() == "TargetSurface") {
      spd.targetSurface = BasicString::parseDouble(in.matchSimple());

    } else if (in.getName() == "LambdaSurface") {
      spd.lambdaSurface = BasicString::parseDouble(in.matchSimple());

    } else if (in.getName() == "ScaleSurface") { //should be less than 1.0 if surface tracker goes to second or higher neighbor
                                                 // to calculate effective surface
      spd.scaleSurface = BasicString::parseDouble(in.matchSimple());

    } else {
      throw BasicException(string("Unexpected element '") + in.getName() + 
			   "'!", in.getLocation());
    }

    in.skip(TEXT);
  }  


}

void SurfaceEnergy::init(Simulator *simulator, ParseData *_pd){
   boundaryStrategy=BoundaryStrategy::getInstance();
}

void SurfaceEnergy::writeXML(XMLSerializer &out) {
}

std::string SurfaceEnergy::toString(){
   return string("Surface");
}

void SurfaceEnergy::update(ParseData *_pd, bool _fullInitFlag){
   spdPtr=(SurfaceParseData*)_pd;
}


std::string SurfaceEnergy::steerableName(){
   return spd.moduleName;
}