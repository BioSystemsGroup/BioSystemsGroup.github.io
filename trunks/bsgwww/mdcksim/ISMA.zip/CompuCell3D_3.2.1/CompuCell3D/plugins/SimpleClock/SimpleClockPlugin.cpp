/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <iostream>
using namespace std;

#define EXP_STL
#include "SimpleClockPlugin.h"

SimpleClockPlugin::SimpleClockPlugin() : potts(0),scpdPtr(0) {}

SimpleClockPlugin::~SimpleClockPlugin() {}

void SimpleClockPlugin::init(Simulator *simulator,ParseData *_pd) {
   pd=&scpd;
   potts = simulator->getPotts();
   
   potts->getCellFactoryGroupPtr()->registerClass(&simpleClockAccessor);
  
   ///potts->registerCellGChangeWatcher(this);

   ///potts->registerStepper(this);
  
  
}

//void SimpleClockPlugin::field3DChange(const Point3D &pt, CellG *newCell, CellG *oldCell) {
   
   ///although currently main updating of cumulative SimpleClock and decision whether to kill cell is made in target volume steppable
   ///we still may need at some poit to start making the decision in this plugin  so I leave code that updates cumulative SimpleClock here
   ///It will be just comented out
//    if(oldCell){
//       SimpleClockAccessor.get(oldCell->extraAttribPtr)->SimpleClock -= SimpleClockFieldPtr->get(pt);
// 
// 
//    }
// 
//    if(newCell){
// 
//       SimpleClockAccessor.get(newCell->extraAttribPtr)->SimpleClock += SimpleClockFieldPtr->get(pt);
//    }


//}


//void SimpleClockPlugin::step() {
//}

void SimpleClockPlugin::readXML(XMLPullParser &in) {
   pd=&scpd;
}

void SimpleClockPlugin::writeXML(XMLSerializer &out) {

}
