#ifndef SIMPLECLOCKPARSEDATA_H
#define SIMPLECLOCKPARSEDATA_H

#include <CompuCell3D/ParseData.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {


class DECLSPECIFIER SimpleClockParseData:public ParseData{
public:
    SimpleClockParseData():ParseData("SimpleClock")
    {}
};

};

#endif
