#ifndef COMPUCELL3DSIMPLECLOCK_H
#define COMPUCELL3DSIMPLECLOCK_H

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

/**
@author m
*/
class DECLSPECIFIER SimpleClock{
public:
    SimpleClock():clock(0),flag(0)
    {
      
    };
   void decrementUntilZero(){
      if(clock>=1)
         --clock;
   } 
   int clock;
   char flag;
};

};

#endif
