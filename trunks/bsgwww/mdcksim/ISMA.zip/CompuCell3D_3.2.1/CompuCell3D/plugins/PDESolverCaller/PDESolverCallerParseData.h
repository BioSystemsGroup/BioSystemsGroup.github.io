/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR1 PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef PDESOLVERCALLERPARSEDATA_H
#define PDESOLVERCALLERPARSEDATA_H


#include <vector>
#include <string>
#include <CompuCell3D/ParseData.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class DECLSPECIFIER SolverData{
      public:
         SolverData():extraTimesPerMC(0){}
         SolverData(std::string _solverName,unsigned int _extraTimesPerMC):
         solverName(_solverName),
         extraTimesPerMC(_extraTimesPerMC)
         {}

         std::string solverName;
         unsigned int extraTimesPerMC;

   };


   class DECLSPECIFIER PDESolverCallerParseData: public ParseData{
      public:
         PDESolverCallerParseData():ParseData("PDESolverCaller")
         {}
         std::vector<SolverData> solverDataVec;
         SolverData * CallPDE(std::string _solverName,unsigned int _extraTimesPerMC){
             solverDataVec.push_back(SolverData(_solverName,_extraTimesPerMC));
            return &solverDataVec[solverDataVec.size()-1];
         }
         SolverData * getPDESolverCallerDataBySolverName(std::string _solverName){
            for (int i = 0 ; i < solverDataVec.size() ; ++i){
               if (solverDataVec[i].solverName==_solverName)
                  return &solverDataVec[i];
            }
            return 0;
         }


   };
   
};
#endif
