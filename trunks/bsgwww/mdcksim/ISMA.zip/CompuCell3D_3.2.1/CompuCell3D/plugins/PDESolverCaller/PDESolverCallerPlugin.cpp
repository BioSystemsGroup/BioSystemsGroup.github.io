/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/
 

#include <CompuCell3D/ClassRegistry.h>

using namespace CompuCell3D;

#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <iostream>
using namespace std;

#define EXP_STL
#include "PDESolverCallerPlugin.h"

PDESolverCallerPlugin::PDESolverCallerPlugin():pscpdPtr(0) {}

PDESolverCallerPlugin::~PDESolverCallerPlugin() {}

void PDESolverCallerPlugin::init(Simulator *simulator,ParseData * _pd) {

   pd=_pd;
   pscpdPtr=(PDESolverCallerParseData *)pd;

   sim=simulator;
   potts = sim->getPotts();

   potts->registerFixedStepper(this);

//    for (int i = 0 ; i <pscpdPtr->solverDataVec.size() ;++i){
//       cerr<<"PDESolverNames["<<i<<"]="<<pscpdPtr->solverDataVec[i].solverName<<" times="<<pscpdPtr->solverDataVec[i].extraTimesPerMC<<endl;
//    }
//    exit(0);
   sim->registerSteerableObject(this);

}

void PDESolverCallerPlugin::extraInit(Simulator *simulator) { 

   update(pscpdPtr);

}

void PDESolverCallerPlugin::step(){

//    cerr<<"inside STEP"<<endl;
   unsigned int currentStep;
   unsigned int currentAttempt;
   unsigned int numberOfAttempts;
   

   currentStep=sim->getStep();
   currentAttempt=potts->getCurrentAttempt();
   numberOfAttempts=potts->getNumberOfAttempts();
   
   


   for(int i=0 ; i <pscpdPtr->solverDataVec.size() ; ++i){
      int reminder= (numberOfAttempts % (pscpdPtr->solverDataVec[i].extraTimesPerMC+1));
      
      int ratio=(numberOfAttempts / (pscpdPtr->solverDataVec[i].extraTimesPerMC+1));
//       cerr<<"pscpdPtr->solverDataVec[i].extraTimesPerMC="<<pscpdPtr->solverDataVec[i].extraTimesPerMC<<endl;
//       cerr<<"ratio="<<ratio<<" reminder="<<reminder<<endl;
      if( ! ((currentAttempt-reminder) % ratio ) && currentAttempt>reminder ){
//          cerr<<"before calling step"<<endl;
          solverPtrVec[i]->step(currentStep);
//          float a=reminder+ratio;
//         cerr<<"calling Solver"<<pscpdPtr->solverDataVec[i].solverName<<" currentAttempt="<<currentAttempt<<" numberOfAttempts="<<numberOfAttempts<<endl;

      }

   }
   
   


}

void PDESolverCallerPlugin::readXML(XMLPullParser &in) {
   pd=&pscpd;
   in.skip(TEXT);
   
   cerr<<"inside readXML PDECaller"<<endl;
   
  while (in.check(START_ELEMENT)) {
    if (in.getName() == "CallPDE") {
      
      
      string solverName = in.getAttribute("PDESolverName").value;
      unsigned int timesPerMC = BasicString::parseUInteger(in.getAttribute("ExtraTimesPerMC").value);
//       PDESolverNames.push_back(solverName);
//       timesPerMCVec.push_back(timesPerMC);

      pscpd.solverDataVec.push_back(SolverData(solverName,timesPerMC));

      in.matchSimple();
    }
    else {
      throw BasicException(string("Unexpected element '") + in.getName() +
                           "'!", in.getLocation());
    }

    in.skip(TEXT);
  }


  
}

void PDESolverCallerPlugin::writeXML(XMLSerializer &out) {
}

void PDESolverCallerPlugin::update(ParseData *pd, bool _fullInitFlag){

   pscpdPtr=(PDESolverCallerParseData *)pd;
   ClassRegistry *classRegistry=sim->getClassRegistry();
   Steppable * steppable;

   solverPtrVec.clear();
   for(unsigned int i=0; i < pscpdPtr->solverDataVec.size() ; ++i ){
      steppable=classRegistry->getStepper(pscpdPtr->solverDataVec[i].solverName);
      solverPtrVec.push_back(steppable);
   }


}

std::string PDESolverCallerPlugin::steerableName(){

   return pscpd.ModuleName();

}
