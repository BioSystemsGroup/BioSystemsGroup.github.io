/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/


#ifndef CELLTYPEPLUGIN_H
#define CELLTYPEPLUGIN_H

#include <CompuCell3D/Plugin.h>

//#include <CompuCell3D/Potts3D/CellChangeWatcher.h>
#include <CompuCell3D/Automaton/Automaton.h>
#include <CompuCell3D/plugins/CellType/CellTypeG.h>
#include <string>
#include <map>
#include "CellTypeParseData.h"
#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {
  class Potts3D;
  class CellG;


  class DECLSPECIFIER CellTypePlugin : public Plugin, public Automaton {
    Potts3D* potts;
    
    std::map<unsigned char,std::string> typeNameMap;
    std::map<std::string,unsigned char> nameTypeMap;
    
    
    
//     std::map<unsigned char,std::string>::const_iterator typeNameMapItr;  
//     std::map<std::string,unsigned char>::const_iterator nameTypeMapItr;

    
  public:
    CellTypeParseData cpd;

    CellTypePlugin();
    virtual ~CellTypePlugin();

    ///SimObject interface
    virtual void init(Simulator *simulator, ParseData *_pd=0);
   
    std::map<unsigned char,std::string> & getTypeNameMap(){return typeNameMap;}
    
    ///Automaton Interface
    virtual unsigned char getCellType(const CellG*) const;
    virtual std::string getTypeName(const char type) const;
    virtual unsigned char getTypeId(const std::string typeName) const;

    


    ///Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    virtual std::string toString();
    ///End XMLSerializable interface

    //Steerable object interface
    virtual std::string steerableName();
    virtual void update(ParseData *_pd, bool _fullInitFlag=false);

    
  };
};
#endif

