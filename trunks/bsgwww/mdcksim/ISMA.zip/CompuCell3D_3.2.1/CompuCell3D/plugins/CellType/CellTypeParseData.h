/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef CELLTYPEPARSEDATA_H
#define CELLTYPEPARSEDATA_H

#include <CompuCell3D/ParseData.h>
#include <vector>
#include <string>
#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

  class DECLSPECIFIER CellTypeTupple{
      public:
      CellTypeTupple():
         typeName(""),
         typeId(0),
         freeze(false)
      {}

      CellTypeTupple(std::string _typeName, unsigned char _typeId, bool _freeze=false):
         typeName(_typeName),
         typeId(_typeId),
         freeze(_freeze)
      {}

      std::string typeName;
      unsigned char typeId;
      bool freeze;
  };

  class DECLSPECIFIER CellTypeParseData : public ParseData {
      public:
         CellTypeParseData():
            ParseData("CellType")
            {}
         std::vector<CellTypeTupple> cellTypeTuppleVec;
         CellTypeTupple * getCellTypeTuppleByTypeName(std::string _typeName){
            for (int i = 0 ; i < cellTypeTuppleVec.size() ; ++i){
               if(cellTypeTuppleVec[i].typeName==_typeName)
                  return &cellTypeTuppleVec[i];
            }
            return 0;
         }
         void CellType(std::string _typeName, unsigned char _typeId, bool _freeze=false){
            cellTypeTuppleVec.push_back(CellTypeTupple(_typeName,_typeId,_freeze));
         }
  };
};
#endif
