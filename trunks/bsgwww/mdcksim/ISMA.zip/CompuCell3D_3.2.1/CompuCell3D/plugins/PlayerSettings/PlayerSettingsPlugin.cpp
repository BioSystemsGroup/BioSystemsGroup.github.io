



#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/Field3D/Dim3D.h>
#include <CompuCell3D/Field3D/Field3D.h>

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>
#include <PublicUtilities/StringUtils.h>
#include <iostream>
#include <algorithm>

using namespace std;

#define EXP_STL
#include "PlayerSettingsPlugin.h"
using namespace CompuCell3D;

std::string PlayerSettingsPlugin::steerableName(){
  return playerSettings.ModuleName();
}



PlayerSettingsPlugin::PlayerSettingsPlugin():playerSettingsPtr(0) {playerSettingsPtr=&playerSettings;}

PlayerSettingsPlugin::~PlayerSettingsPlugin() {}


void PlayerSettingsPlugin::init(Simulator *simulator, ParseData *_pd){
   pd=_pd;
   playerSettingsPtr=(PlayerSettings *)pd;
}


void PlayerSettingsPlugin::extraInit(Simulator *simulator) {
   Potts3D *potts=simulator->getPotts();
   Dim3D fieldDim = potts->getCellFieldG()->getDim();

     cerr<<"\n\n\\t\t\tPlayer Settings \n\n";
      cerr<<"playerSettingsPtr->xyProjFlag="<<playerSettingsPtr->xyProjFlag<<endl;
      cerr<<"playerSettingsPtr->xyProj="<<playerSettingsPtr->xyProj<<endl;
      cerr<<"This is field dim="<<fieldDim<<endl;
   ///Making sure that player settings are reasonable
   if(playerSettingsPtr->xyProjFlag){
//       cerr<<"playerSettingsPtr->xyProjFlag="<<playerSettingsPtr->xyProjFlag<<endl;
      ASSERT_OR_THROW("Value of XYProj has to be within limits for z dimension of the field",
         playerSettingsPtr->xyProj>=0 && playerSettingsPtr->xyProj<fieldDim.z
      );
//       cerr<<"playerSettingsPtr->xyProj="<<playerSettingsPtr->xyProj<<endl;
   }

   if(playerSettingsPtr->xzProjFlag){
      ASSERT_OR_THROW("Value of XZProj has to be within limits for y dimension of the field",
         playerSettingsPtr->xzProj>=0 && playerSettingsPtr->xyProj<fieldDim.y
      );
   }

   if(playerSettingsPtr->yzProjFlag){
      ASSERT_OR_THROW("Value of YZProj has to be within limits for x dimension of the field",
         playerSettingsPtr->yzProj>=0 && playerSettingsPtr->yzProj<fieldDim.x
      );
   }

   if(playerSettingsPtr->rotationXFlag){
      ASSERT_OR_THROW("Value of XRot must be between -180 and 180",
         playerSettingsPtr->rotationX>=-180 && playerSettingsPtr->rotationX<=180
      );
   }

   if(playerSettingsPtr->rotationYFlag){
      ASSERT_OR_THROW("Value of YRot must be between -180 and 180",
         playerSettingsPtr->rotationY>=-180 && playerSettingsPtr->rotationY<=180
      );
   }

      if(playerSettingsPtr->rotationZFlag){
      ASSERT_OR_THROW("Value of ZRot must be between -180 and 180",
         playerSettingsPtr->rotationZ>=-180 && playerSettingsPtr->rotationZ<=180
      );
   }

//    cerr<<"\n\n\\t\t\tPlayer Settings \n\n"; 
   
      
}





void PlayerSettingsPlugin::readXML(XMLPullParser &in) {
  in.skip(TEXT);

  int attrNum;
  pd=&playerSettings;
  while (in.check(START_ELEMENT)) {
    if (in.getName() == "Project2D") {
    
//       string typeName = in.getAttribute("TypeName").value;
//       unsigned char typeId = BasicString::parseUByte(in.getAttribute("TypeId").value);
//       cerr<<"typeName="<<typeName<<endl;
//       cerr<<"typeId="<<(short)typeId<<endl;
//   
//       typeNameMap[typeId]=typeName;
//       nameTypeMap[typeName]=typeId;

      ///reading 2D settings - projections
      attrNum=in.findAttribute("XYProj");
      if(attrNum != -1){
         playerSettings.xyProj=BasicString::parseUInteger(in.getAttribute("XYProj").value);
         playerSettings.xyProjFlag=true;
      }

      attrNum=in.findAttribute("XZProj");
      if(attrNum != -1){
         playerSettings.xzProj=BasicString::parseUInteger(in.getAttribute("XZProj").value);
         playerSettings.xzProjFlag=true;
      }
      
      attrNum=in.findAttribute("YZProj");
      if(attrNum != -1){
         playerSettings.yzProj=BasicString::parseUInteger(in.getAttribute("YZProj").value);
         playerSettings.yzProjFlag=true;
      }
            
      
      in.matchSimple();
    }
    else if (in.getName() == "Rotate3D"){
      ///reading  3D rotations parameters - used by player
      attrNum=in.findAttribute("XRot");
      if(attrNum != -1){
         playerSettings.rotationX=BasicString::parseUInteger(in.getAttribute("XRot").value);
         playerSettings.rotationXFlag=true;
      }

      attrNum=in.findAttribute("YRot");
      if(attrNum != -1){
         playerSettings.rotationY=BasicString::parseUInteger(in.getAttribute("YRot").value);
         playerSettings.rotationYFlag=true;
      }

      attrNum=in.findAttribute("ZRot");
      if(attrNum != -1){
         playerSettings.rotationZ=BasicString::parseUInteger(in.getAttribute("ZRot").value);
         playerSettings.rotationZFlag=true;
      }
      in.matchSimple();
                  
    }
    else if(in.getName() == "Resize3D"){
      ///reading  3D widget size parameters used by player - the bigger the smaller object will be
      attrNum=in.findAttribute("X");
      if(attrNum != -1){
         playerSettings.sizeX3D=BasicString::parseUInteger(in.getAttribute("X").value);
         playerSettings.sizeX3DFlag=true;
      }

      attrNum=in.findAttribute("Y");
      if(attrNum != -1){
         playerSettings.sizeY3D=BasicString::parseUInteger(in.getAttribute("Y").value);
         playerSettings.sizeY3DFlag=true;
      }

      attrNum=in.findAttribute("Z");
      if(attrNum != -1){
         playerSettings.sizeZ3D=BasicString::parseUInteger(in.getAttribute("Z").value);
         playerSettings.sizeY3DFlag=true;
      }
      
      in.matchSimple();
    }
    else if(in.getName() == "InitialProjection"){
      attrNum=in.findAttribute("Projection");
      if(attrNum != -1){
         playerSettings.initialProjection=in.getAttribute("Projection").value;
         //changing to lowercase 
         changeToLower(playerSettings.initialProjection);
         ASSERT_OR_THROW("InitialProjection has have a value of xy or xz or yz",
         playerSettings.initialProjection=="xy" || playerSettings.initialProjection=="xz" || playerSettings.initialProjection=="yz"
         );
      }
      in.matchSimple();
    }
    //Now will process advanced settings
    else if(in.getName() == "Concentration"){
      playerSettings.advancedSettingsOn=true;
      attrNum=in.findAttribute("Min");
      if(attrNum != -1){
         playerSettings.minConcentration=BasicString::parseDouble(in.getAttribute("Min").value);
         playerSettings.minConcentrationFlag=true;

         playerSettings.minConcentrationFixed=true;
         playerSettings.minConcentrationFixedFlag=true;
      }
      attrNum=in.findAttribute("Max");
      if(attrNum != -1){
         playerSettings.maxConcentration=BasicString::parseDouble(in.getAttribute("Max").value);
         playerSettings.maxConcentrationFlag=true;
         playerSettings.maxConcentrationFixed=true;
         playerSettings.maxConcentrationFixedFlag=true;
      }
      attrNum=in.findAttribute("MinFixed");
      if(attrNum != -1){
         playerSettings.minConcentrationFixed=BasicString::parseBool(in.getAttribute("MinFixed").value);
         playerSettings.minConcentrationFixedFlag=true;
      }

      attrNum=in.findAttribute("MaxFixed");
      if(attrNum != -1){
         playerSettings.maxConcentrationFixed=BasicString::parseBool(in.getAttribute("MaxFixed").value);
         playerSettings.maxConcentrationFixedFlag=true;
      }

      attrNum=in.findAttribute("LegendEnable");
      if(attrNum != -1){
         playerSettings.legendEnable=BasicString::parseBool(in.getAttribute("LegendEnable").value);
         playerSettings.legendEnableFlag=true;
      }

      attrNum=in.findAttribute("NumberOfLegendBoxes");
      if(attrNum != -1){
         playerSettings.numberOfLegendBoxes=BasicString::parseUInteger(in.getAttribute("NumberOfLegendBoxes").value);
         playerSettings.numberOfLegendBoxesFlag=true;
      }

      attrNum=in.findAttribute("NumberAccuracy");
      if(attrNum != -1){
         playerSettings.numberAccuracy=BasicString::parseUInteger(in.getAttribute("NumberAccuracy").value);
         playerSettings.numberAccuracyFlag=true;
      }
      attrNum=in.findAttribute("ConcentrationLimitsOn");
      if(attrNum != -1){
         playerSettings.concentrationLimitsOn=BasicString::parseBool(in.getAttribute("ConcentrationLimitsOn").value);
         playerSettings.concentrationLimitsOnFlag=true;
      }


      in.matchSimple();
    }
    else if(in.getName() == "Magnitude"){
      playerSettings.advancedSettingsOn=true;
      attrNum=in.findAttribute("Min");
      if(attrNum != -1){
         playerSettings.minMagnitude=BasicString::parseDouble(in.getAttribute("Min").value);
         playerSettings.minMagnitudeFlag=true;

         playerSettings.minMagnitudeFixed=true;
         playerSettings.minMagnitudeFixedFlag=true;
      }
      attrNum=in.findAttribute("Max");
      if(attrNum != -1){
         playerSettings.maxMagnitude=BasicString::parseDouble(in.getAttribute("Max").value);
         playerSettings.maxMagnitudeFlag=true;
         playerSettings.maxMagnitudeFixed=true;
         playerSettings.maxMagnitudeFixedFlag=true;
      }
      attrNum=in.findAttribute("MinFixed");
      if(attrNum != -1){
         playerSettings.minMagnitudeFixed=BasicString::parseBool(in.getAttribute("MinFixed").value);
         playerSettings.minMagnitudeFixedFlag=true;
      }

      attrNum=in.findAttribute("MaxFixed");
      if(attrNum != -1){
         playerSettings.maxMagnitudeFixed=BasicString::parseBool(in.getAttribute("MaxFixed").value);
         playerSettings.maxMagnitudeFixedFlag=true;
      }
      attrNum=in.findAttribute("LegendEnable");
      if(attrNum != -1){
         playerSettings.legendEnableVector=BasicString::parseBool(in.getAttribute("LegendEnable").value);
         playerSettings.legendEnableVectorFlag=true;
      }

      attrNum=in.findAttribute("NumberOfLegendBoxes");
      if(attrNum != -1){
         playerSettings.numberOfLegendBoxesVector=BasicString::parseUInteger(in.getAttribute("NumberOfLegendBoxes").value);
         playerSettings.numberOfLegendBoxesVectorFlag=true;
      }

      attrNum=in.findAttribute("NumberAccuracy");
      if(attrNum != -1){
         playerSettings.numberAccuracyVector=BasicString::parseUInteger(in.getAttribute("NumberAccuracy").value);
         playerSettings.numberAccuracyVectorFlag=true;
      }

      attrNum=in.findAttribute("OverlayVectorAndCellFields");
      if(attrNum != -1){
         playerSettings.overlayVectorCellFields=BasicString::parseBool(in.getAttribute("OverlayVectorAndCellFields").value);
         playerSettings.overlayVectorCellFieldsFlag=true;
      }

      attrNum=in.findAttribute("ScaleArrows");
      if(attrNum != -1){
         playerSettings.scaleArrows=BasicString::parseBool(in.getAttribute("ScaleArrows").value);
         playerSettings.scaleArrowsFlag=true;
      }

      attrNum=in.findAttribute("FixedArrowColorFlag");
      if(attrNum != -1){
         playerSettings.fixedArrowColorFlag=BasicString::parseBool(in.getAttribute("FixedArrowColorFlag").value);
         playerSettings.fixedArrowColorFlagFlag=true;
      }

      attrNum=in.findAttribute("ArrowColor");
      if(attrNum != -1){
         playerSettings.arrowColorName=in.getAttribute("ArrowColor").value;
         changeToLower(playerSettings.arrowColorName);
         playerSettings.arrowColorNameFlag=true;
      }

      in.matchSimple();
    }

    else if(in.getName() == "Border"){
      playerSettings.advancedSettingsOn=true;
      attrNum=in.findAttribute("Color");
      if(attrNum != -1){
         playerSettings.borderColorName=in.getAttribute("Color").value;
         
         //changing to lowercase 
         changeToLower(playerSettings.borderColorName);
         playerSettings.borderColorNameFlag=true;
      }
      attrNum=in.findAttribute("BorderOn");
      if(attrNum != -1){
         playerSettings.borderOn=BasicString::parseBool(in.getAttribute("BorderOn").value);
         playerSettings.borderOnFlag=true;
      }
      in.matchSimple();
    }

    else if(in.getName() == "Contour"){
      playerSettings.advancedSettingsOn=true;
      attrNum=in.findAttribute("Color");
      if(attrNum != -1){
         playerSettings.contourColorName=in.getAttribute("Color").value;
         
         //changing to lowercase 
         changeToLower(playerSettings.contourColorName);
         playerSettings.contourColorNameFlag=true;
      }
      attrNum=in.findAttribute("ContourOn");
      if(attrNum != -1){
         playerSettings.contourOn=BasicString::parseBool(in.getAttribute("ContourOn").value);
         playerSettings.contourOnFlag=true;
      }
      in.matchSimple();
    }

    else if(in.getName() == "Cell"){
      playerSettings.advancedSettingsOn=true;
      std::string color;
      unsigned short type;

      type=(unsigned short)BasicString::parseUInteger(in.getAttribute("Type").value);
      color=in.getAttribute("Color").value;
      playerSettings.typeToColorNameMap[type]=color;

      playerSettings.typeToColorNameMapFlag=true;
      in.matchSimple();
    }
    else if(in.getName() == "VisualControl"){
      playerSettings.advancedSettingsOn=true;
      attrNum=in.findAttribute("ZoomFactor");
      if(attrNum != -1){
         unsigned int factor;
   
         factor=BasicString::parseUInteger(in.getAttribute("ZoomFactor").value);
         
         playerSettings.zoomFactor=factor;
         playerSettings.zoomFactorFlag=true;
      }

      attrNum=in.findAttribute("ScreenshotFrequency");
      if(attrNum != -1){
   
         playerSettings.screenshotFrequency=BasicString::parseUInteger(in.getAttribute("ScreenshotFrequency").value);
         playerSettings.screenshotFrequencyFlag=true;

      }

      attrNum=in.findAttribute("ScreenUpdateFrequency");
      if(attrNum != -1){
   
         playerSettings.screenUpdateFrequency=BasicString::parseUInteger(in.getAttribute("ScreenUpdateFrequency").value);
         playerSettings.screenUpdateFrequencyFlag=true;

      }

      attrNum=in.findAttribute("NoOutput");
      if(attrNum != -1){
         playerSettings.noOutputFlag=BasicString::parseBool(in.getAttribute("NoOutput").value);
         playerSettings.noOutputFlagFlag=true;
      }


      in.matchSimple();
    }
    else if(in.getName() == "TypesInvisibleIn3D"){
      playerSettings.advancedSettingsOn=true;
      std::string typesInvisibleIn3DString=in.getAttribute("Types").value;
      vector<string> typesInvisiblein3DVector; 
      parseStringIntoList(typesInvisibleIn3DString,typesInvisiblein3DVector,",");

      for(unsigned int i = 0 ; i < typesInvisiblein3DVector.size() ; ++i){
         playerSettings.types3DInvisible.push_back((unsigned short)BasicString::parseUInteger(typesInvisiblein3DVector[i]));
      }

      playerSettings.types3DInvisibleFlag=true;
      in.matchSimple();
    }
   else if(in.getName() == "Settings"){  
      attrNum=in.findAttribute("SaveSettings");
      if(attrNum != -1){
         playerSettings.saveSettings=BasicString::parseBool(in.getAttribute("SaveSettings").value);
         playerSettings.saveSettingsFlag=true;
      }

      in.matchSimple();
   }
    else {
      throw BasicException(string("Unexpected element '") + in.getName() +
                           "'!", in.getLocation());
    }

    in.skip(TEXT);
  }

  
  
}

void PlayerSettingsPlugin::writeXML(XMLSerializer &out) {
}
