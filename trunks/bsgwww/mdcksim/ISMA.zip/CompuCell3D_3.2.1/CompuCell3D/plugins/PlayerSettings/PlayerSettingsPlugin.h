


#ifndef PLAYERSETTINGSPLUGIN_H
#define PLAYERSETTINGSPLUGIN_H

#include <CompuCell3D/Plugin.h>

#include <CompuCell3D/plugins/PlayerSettings/PlayerSettings.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {


  class DECLSPECIFIER PlayerSettingsPlugin : public Plugin {

  public:

    PlayerSettings playerSettings;
    PlayerSettings *playerSettingsPtr;

    PlayerSettingsPlugin();
    virtual ~PlayerSettingsPlugin();

    
    ///SimObject interface
    virtual void init(Simulator *simulator, ParseData *_pd);
    virtual void extraInit(Simulator *simulator);
    
    PlayerSettings getPlayerSettings() const {return *(playerSettingsPtr);} 

    ///Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    ///End XMLSerializable interface
    virtual std::string steerableName();
    
  };


};
#endif


