/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR1 PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef STRETCHNESSENERGY_H
#define STRETCHNESSENERGY_H

#include <CompuCell3D/Potts3D/EnergyFunction.h>

#include <XMLCereal/XMLSerializable.h>

#include "StretchnessParseData.h"
#include <CompuCell3D/Boundary/BoundaryTypeDefinitions.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

  

  template <class T> class Field3D;
  template <class T> class WatchableField3D;
  class Point3D;

  /**
   * Calculates surface energy based on a target surface and
   * lambda surface.
   */
  class BoundaryStrategy;

  class DECLSPECIFIER StretchnessEnergy: public EnergyFunction, public virtual XMLSerializable {

    WatchableField3D<CellG *> *cellFieldG;


    double targetStretchness;
    double lambdaStretchness;
    double scaleSurface;
    BoundaryStrategy *boundaryStrategy;
    unsigned int maxNeighborIndex;
    LatticeMultiplicativeFactors lmf;
  public:
    StretchnessParseData spd;
    StretchnessParseData * spdPtr;

    StretchnessEnergy() :
           targetStretchness(0),lambdaStretchness(0),scaleSurface(1.0),boundaryStrategy(0),maxNeighborIndex(0)
    {}
    
    void init(Simulator * simulator);
    

      
    double diffEnergy(double surface, double diff);
    void setLatticeMultiplicativeFactors(const LatticeMultiplicativeFactors & _lmf){lmf=_lmf;}
    void setMaxNeighborIndex(unsigned int _maxNeighborIndex){maxNeighborIndex=_maxNeighborIndex;}
//     void setBoundaryStrategy(BoundaryStrategy *_boundaryStrategy){boundaryStrategy=_boundaryStrategy;}

    virtual double localEnergy(const Point3D &pt);
    virtual double changeEnergy(const Point3D &pt, const CellG *newCell,
				const CellG *oldCell);

				
    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    // End XMLSerializable interface
    //SteerableObject Interface
    virtual void update(ParseData *pd, bool _fullInitFlag=false);
    virtual std::string steerableName();

    virtual std::string toString();
  };
};
#endif
