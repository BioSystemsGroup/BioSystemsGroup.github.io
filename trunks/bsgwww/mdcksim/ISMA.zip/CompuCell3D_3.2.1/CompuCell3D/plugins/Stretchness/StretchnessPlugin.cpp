/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#include <CompuCell3D/plugins/SurfaceTracker/SurfaceTrackerPlugin.h>

#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <iostream>
using namespace std;

#define EXP_STL
#include "StretchnessPlugin.h"

#include "StretchnessEnergy.h"

StretchnessPlugin::StretchnessPlugin() : stretchnessEnergy(0), cellFieldG(0) {}

StretchnessPlugin::~StretchnessPlugin() {
  if (stretchnessEnergy) delete stretchnessEnergy;
}

void StretchnessPlugin::init(Simulator *simulator,ParseData * _pd) {

  if(!stretchnessEnergy){
      stretchnessEnergy = new StretchnessEnergy();
  }
  pd=_pd;
  stretchnessEnergy->spdPtr=(StretchnessParseData*)pd;
  stretchnessEnergy->init(simulator);


  Potts3D *potts = simulator->getPotts();
  cellFieldG = (WatchableField3D<CellG *> *)potts->getCellFieldG();


  potts->registerEnergyFunctionWithName(stretchnessEnergy,"StretchnessEnergy");
  simulator->registerSteerableObject(this);



}

void StretchnessPlugin::extraInit(Simulator *simulator) {
  Potts3D *potts = simulator->getPotts();
  cellFieldG = (WatchableField3D<CellG *> *)potts->getCellFieldG();
  

  

   bool pluginAlreadyRegisteredFlag;
   SurfaceTrackerPlugin *trackerPlugin=(SurfaceTrackerPlugin*)Simulator::pluginManager.get("SurfaceTracker",&pluginAlreadyRegisteredFlag); //this will load VolumeTracker plugin if it is not already loaded
  if(!pluginAlreadyRegisteredFlag)
      trackerPlugin->init(simulator);


  stretchnessEnergy->setMaxNeighborIndex( trackerPlugin->getMaxNeighborIndex() );
  stretchnessEnergy->setLatticeMultiplicativeFactors( trackerPlugin->getLatticeMultiplicativeFactors() );
}


void StretchnessPlugin::readXML(XMLPullParser &in) {
  if(!stretchnessEnergy){
      stretchnessEnergy=new StretchnessEnergy();
  }
  pd=&stretchnessEnergy->spd;
  stretchnessEnergy->readXML(in);
}

void StretchnessPlugin::writeXML(XMLSerializer &out) {
  stretchnessEnergy->writeXML(out);
}

void StretchnessPlugin::update(ParseData *pd, bool _fullInitFlag){
   stretchnessEnergy->update(pd);
   SurfaceTrackerPlugin *trackerPlugin=(SurfaceTrackerPlugin*)Simulator::pluginManager.get("SurfaceTracker"); 
   stretchnessEnergy->setMaxNeighborIndex( trackerPlugin->getMaxNeighborIndex() );
   stretchnessEnergy->setLatticeMultiplicativeFactors( trackerPlugin->getLatticeMultiplicativeFactors() );


}

std::string StretchnessPlugin::steerableName(){
   return stretchnessEnergy->spd.ModuleName();
}


