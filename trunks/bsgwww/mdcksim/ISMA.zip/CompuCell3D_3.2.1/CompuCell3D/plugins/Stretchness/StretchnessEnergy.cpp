/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Field3D/WatchableField3D.h>
#include <CompuCell3D/Field3D/Point3D.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>
#include <CompuCell3D/Simulator.h>

#include <string>
using namespace std;

#define EXP_STL
#include "StretchnessEnergy.h"

double StretchnessEnergy::diffEnergy(double surface, double diff) {
  return lambdaStretchness *
    (diff*diff + 2 * diff * (surface - targetStretchness));
}


double StretchnessEnergy::localEnergy(const Point3D &pt) {
  return 0;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

double StretchnessEnergy::changeEnergy(const Point3D &pt,
				  const CellG *newCell,
				  const CellG *oldCell) {

  // E = lambda * (surface - targetStretchness) ^ 2
  CellG *nCell;
  
  if (oldCell == newCell) return 0;

  unsigned int token = 0;
  double distance;
  int oldDiff = 0;
  int newDiff = 0;
  int newVolume=0;
  int oldVolume=0;
  float oldStretchness0=0.0;
  float newStretchness0=0.0;
  float oldStretchness1=0.0;
  float newStretchness1=0.0;
  float deltaStretchness=0.0;

  Point3D n;
  double energy = 0;


//    cerr<<"scaleStretchness="<<scaleStretchness<<" maxNeighborIndex="<<maxNeighborIndex<<endl;


  // Count surface difference

   Neighbor neighbor;
   for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
      neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
      if(!neighbor.distance){
      //if distance is 0 then the neighbor returned is invalid
      continue;
      }
      nCell = cellFieldG->get(neighbor.pt);
      if (newCell == nCell) newDiff-=lmf.surfaceMF;
      else newDiff+=lmf.surfaceMF;
   
      if (oldCell == nCell) oldDiff+=lmf.surfaceMF;
      else oldDiff-=lmf.surfaceMF;

   }

  if (newCell){
//       newVolume1=newCell->volume+1;
      newStretchness0=newCell->surface*scaleSurface/sqrt((float)newCell->volume);
      newStretchness1=(newCell->surface+newDiff)*scaleSurface/sqrt((float)newCell->volume+1);
      energy+=(newStretchness1-newStretchness0)*lambdaStretchness;

   }

  if (oldCell){
//       oldVolume1=oldCell->volume-1;
      oldStretchness0=oldCell->surface*scaleSurface/sqrt((float)oldCell->volume);
      
      oldStretchness1=(oldCell->volume > 1 ? 
                                          (oldCell->surface+oldDiff)*scaleSurface/sqrt((float)oldCell->volume-1) 
                                          :oldStretchness0
                     );
      energy+=(oldStretchness1-oldStretchness0)*lambdaStretchness;
   }

   
   


//   if (newCell){
//     energy += diffEnergy(newCell->surface*scaleSurface, newDiff*scaleSurface);
//    }
//   if (oldCell){
//     energy += diffEnergy(oldCell->surface*scaleSurface, oldDiff*scaleSurface);
//   }
   

//   cerr<<"energy="<<energy<<endl;
  return energy;
}


void StretchnessEnergy::readXML(XMLPullParser &in) {
  in.skip(TEXT);
  
  while (in.check(START_ELEMENT)) {
    if (in.getName() == "TargetStretchness") {
      spd.targetStretchness = BasicString::parseDouble(in.matchSimple());

    } else if (in.getName() == "LambdaStretchness") {
      spd.lambdaStretchness = BasicString::parseDouble(in.matchSimple());

    } else if (in.getName() == "ScaleSurface") { //should be less than 1.0 if surface tracker goes to second or higher neighbor
                                                 // to calculate effective surface
      spd.scaleSurface = BasicString::parseDouble(in.matchSimple());

    } else {
      throw BasicException(string("Unexpected element '") + in.getName() + 
			   "'!", in.getLocation());
    }

    in.skip(TEXT);
  }  



}

void StretchnessEnergy::init(Simulator * simulator){
   boundaryStrategy=BoundaryStrategy::getInstance();
   cellFieldG=(WatchableField3D<CellG *> *)simulator->getPotts()->getCellFieldG();
   update(spdPtr);
}

void StretchnessEnergy::update(ParseData * _pd, bool _fullInitFlag){

   spdPtr=(StretchnessParseData*)_pd;
   targetStretchness=spdPtr->targetStretchness;
   lambdaStretchness=spdPtr->lambdaStretchness;
   scaleSurface=spdPtr->scaleSurface;
   



}


std::string StretchnessEnergy::steerableName(){
   return spd.ModuleName();
}



void StretchnessEnergy::writeXML(XMLSerializer &out) {
}




std::string StretchnessEnergy::toString(){
   return string("Stretchness");
}