#ifndef SIMPLEARRAYPARSEDATA_H
#define SIMPLEARRAYPARSEDATA_H

#include <CompuCell3D/ParseData.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {


class DECLSPECIFIER SimpleArrayParseData:public ParseData{
public:
    SimpleArrayParseData():ParseData("SimpleArray")
    {}
    std::string test_string;
    void Values(std::string _test_string){test_string=_test_string;}
};

};

#endif
