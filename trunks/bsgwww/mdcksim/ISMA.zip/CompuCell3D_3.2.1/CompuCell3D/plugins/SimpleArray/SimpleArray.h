#ifndef COMPUCELL3DSIMPLEARRAY_H
#define COMPUCELL3DSIMPLEARRAY_H

#include <XMLCereal/XMLSerializable.h>
#include <BasicUtils/BasicClassAccessor.h>
#include <BasicUtils/BasicClassGroup.h> 
#include<vector>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

/**
@author m
*/
   class DECLSPECIFIER SimpleArray {
      public:
         SimpleArray(){};
         ~SimpleArray(){};
   };
};

#endif
