/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Automaton/Automaton.h>
#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>
#include <CompuCell3D/Field3D/Point3D.h>
#include <CompuCell3D/Potts3D/Potts3D.h>


using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <string>
using namespace std;

#define EXP_STL
#include "SurfaceFlexEnergy.h"

double SurfaceFlexEnergy::localEnergy(const Point3D &pt) {
  return 0;
}

double SurfaceFlexEnergy::diffEnergy(double surface, double diff, double targetSurface, double lambdaSurface){
  
  return lambdaSurface *
    (diff * diff + 2 * diff * (surface- fabs(targetSurface)));

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
double SurfaceFlexEnergy::changeEnergy(const Point3D &pt,
				  const CellG *newCell,
				  const CellG *oldCell) {

  // E = lambda * (surface - targetSurface) ^ 2
  CellG *nCell;
  
  if (oldCell == newCell) return 0;

  unsigned int token = 0;
  double distance;
  double oldDiff = 0.;
  double newDiff = 0.;
  Point3D n;
  double energy = 0;
  
 
   Neighbor neighbor;
   for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
      neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
      if(!neighbor.distance){
      //if distance is 0 then the neighbor returned is invalid
      continue;
      }
      nCell = cellFieldG->get(neighbor.pt);
      if (newCell == nCell) newDiff-=lmf.surfaceMF;
      else newDiff+=lmf.surfaceMF;
   
      if (oldCell == nCell) oldDiff+=lmf.surfaceMF;
      else oldDiff-=lmf.surfaceMF;

   }
    


  
  if (newCell)
    energy += diffEnergy(
                           newCell->surface*scaleSurface,
                           newDiff*scaleSurface,
                           surfaceEnergyParamVector[newCell->type].targetSurface,
                           surfaceEnergyParamVector[newCell->type].lambdaSurface
                        );

  if (oldCell)
    energy += diffEnergy(
                           oldCell->surface*scaleSurface,
                           oldDiff*scaleSurface,
                           surfaceEnergyParamVector[oldCell->type].targetSurface,
                           surfaceEnergyParamVector[oldCell->type].lambdaSurface
                           );

  return energy;
              
}


void SurfaceFlexEnergy::readXML(XMLPullParser &in) {
  in.skip(TEXT);

  
  string type;
  
  
  double lambda;
  double targetSur;
  
  while (in.check(START_ELEMENT)) {
    if (in.getName() == "SurfaceEnergyParameters") {
     sfpd.surfaceEnergyParamVec.push_back(SurfaceEnergyParam());
     SurfaceEnergyParam &sep=sfpd.surfaceEnergyParamVec[sfpd.surfaceEnergyParamVec.size()-1];
      
    sep.typeName = in.getAttribute("CellType").value;

//     typeNameVec.push_back(type);  

      
    sep.targetSurface=BasicString::parseDouble(in.getAttribute("TargetSurface").value);
    sep.lambdaSurface= BasicString::parseDouble(in.getAttribute("LambdaSurface").value);

//     surfaceEnergyParamVector.push_back(SurfaceEnergyParam(targetSur,lambda));
    
    in.matchSimple();

    
    }else if (in.getName() == "ScaleSurface") { //should be less than 1.0 if surface tracker goes to second or higher neighbor
                                                 // to calculate effective surface
      sfpd.scaleSurface = BasicString::parseDouble(in.matchSimple());

    } else {
      throw BasicException(string("Unexpected element '") + in.getName() + 
			   "'!", in.getLocation());
    }

    in.skip(TEXT);
  }

   

}

void SurfaceFlexEnergy::writeXML(XMLSerializer &out) {
}


void SurfaceFlexEnergy::initTypeId(Potts3D * potts){
   
   
   scaleSurface=sfpdPtr->scaleSurface;

   boundaryStrategy=BoundaryStrategy::getInstance();

   unsigned char maxType(0);
   
   Automaton * automaton=potts->getAutomaton();

   vector<unsigned char> typeIdVec(sfpdPtr->surfaceEnergyParamVec.size(),0);
   
   vector<SurfaceEnergyParam> sepVec=sfpdPtr->surfaceEnergyParamVec;//temporaty storage


      
   //translate type name to type id
   for(unsigned int i =0 ; i < sfpdPtr->surfaceEnergyParamVec.size() ;++i){
      typeIdVec[i]=automaton->getTypeId(sfpdPtr->surfaceEnergyParamVec[i].typeName);
      
      if(typeIdVec[i]>maxType)
         maxType=typeIdVec[i];
  }

   //assigning vector lambda targetSur pairs in such a wav that it will be possible to use e.g.vec[cellType].lambda statements
   surfaceEnergyParamVector.clear();
   // note that some of the vector elements migh be left default initialized
   surfaceEnergyParamVector.assign(maxType+1,SurfaceEnergyParam());
  

   for(unsigned int i =0 ; i < typeIdVec.size() ;++i){
      surfaceEnergyParamVector[typeIdVec[i]]=sepVec[i];
   }

}


void SurfaceFlexEnergy::update(ParseData *_pd, bool _fullInitFlag){
   sfpdPtr=(SurfaceFlexParseData * )_pd;
   initTypeId(potts);

}

std::string SurfaceFlexEnergy::steerableName(){
   return sfpd.moduleName;
}

