/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/


#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>

using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>
#include <CompuCell3D/plugins/SurfaceTracker/SurfaceTrackerPlugin.h>

#include <iostream>
using namespace std;

#define EXP_STL

#include "SurfaceFlexPlugin.h"
#include "SurfaceFlexEnergy.h"


SurfaceFlexPlugin::SurfaceFlexPlugin() : potts(0) {}

SurfaceFlexPlugin::~SurfaceFlexPlugin() {
}


void SurfaceFlexPlugin::init(Simulator *simulator, ParseData *_pd) {

  surfaceEnergy.sfpdPtr=(SurfaceFlexParseData * )_pd;
  potts = simulator->getPotts();
  cellFieldG = (WatchableField3D<CellG *> *)potts->getCellFieldG();


  surfaceEnergy.setCellField(potts->getCellFieldG());
  surfaceEnergy.setPotts(potts);

  potts->registerEnergyFunctionWithName(&surfaceEnergy,"SurfaceEnergy");
  Plugin *surTracker=Simulator::pluginManager.get("SurfaceTracker"); //this will load SurfaceTracker plugin if it is not already loaded  
   surTracker->init(simulator);
   simulator->registerSteerableObject(this);
}


void SurfaceFlexPlugin::extraInit(Simulator *simulator){

   cerr<<"potts addr="<<potts<<endl;
   surfaceEnergy.initTypeId(potts);

   cellFieldG = (WatchableField3D<CellG *> *)potts->getCellFieldG();
  
   bool pluginAlreadyRegisteredFlag;
   SurfaceTrackerPlugin *plugin=(SurfaceTrackerPlugin *)
Simulator::pluginManager.get("SurfaceTracker",&pluginAlreadyRegisteredFlag); //this will load SurfaceTracker plugin if it is not already loaded
  if(!pluginAlreadyRegisteredFlag)
      plugin->init(simulator);

    surfaceEnergy.setMaxNeighborIndex( plugin->getMaxNeighborIndex() );

    surfaceEnergy.setLatticeMultiplicativeFactors( plugin->getLatticeMultiplicativeFactors() );

}

void SurfaceFlexPlugin::readXML(XMLPullParser &in) {
  pd=&surfaceEnergy.sfpd;
  surfaceEnergy.readXML(in);
}

void SurfaceFlexPlugin::writeXML(XMLSerializer &out) {
  surfaceEnergy.writeXML(out);
}

void SurfaceFlexPlugin::update(ParseData *pd, bool _fullInitFlag){
   surfaceEnergy.update(pd);

   SurfaceTrackerPlugin *plugin=(SurfaceTrackerPlugin *)
Simulator::pluginManager.get("SurfaceTracker"); //this will load SurfaceTracker plugin if it is not already loaded

    surfaceEnergy.setMaxNeighborIndex( plugin->getMaxNeighborIndex() );

    surfaceEnergy.setLatticeMultiplicativeFactors( plugin->getLatticeMultiplicativeFactors() );


}

std::string SurfaceFlexPlugin::steerableName(){
   return surfaceEnergy.sfpd.moduleName;
}