/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR1 PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef SURFACEFLEXPARSEDATA_H
#define SURFACEFLEXPARSEDATA_H


#include <vector>
#include <string>
#include <CompuCell3D/ParseData.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class DECLSPECIFIER SurfaceEnergyParam{
      public:
         SurfaceEnergyParam():targetSurface(0),lambdaSurface(0.0){}
         SurfaceEnergyParam(double _targetSurface,double _lambdaSurface, std::string _typeName):
                  targetSurface(_targetSurface),lambdaSurface(_lambdaSurface),typeName(_typeName)
         {}
         double targetSurface;
         double lambdaSurface;
         std::string typeName;

   };


   class DECLSPECIFIER SurfaceFlexParseData: public ParseData{
      public:
         SurfaceFlexParseData():ParseData("SurfaceFlex"),scaleSurface(1.0)
         {}
         std::vector<SurfaceEnergyParam> surfaceEnergyParamVec;
         double scaleSurface;
         SurfaceEnergyParam * SurfaceEnergyParameters(std::string _type="", double _targetSur=0.0, double _lambdaSur=0.0){
            surfaceEnergyParamVec.push_back(SurfaceEnergyParam(_targetSur,_lambdaSur,_type));
            return &surfaceEnergyParamVec[surfaceEnergyParamVec.size()-1];
         }
         void ScaleSurface(double _scale){scaleSurface=_scale;}

         SurfaceEnergyParam * getSurfaceEnergyParametersByTypeName(std::string _type){
            for (int i = 0 ; i<surfaceEnergyParamVec.size() ; ++i){
               if (surfaceEnergyParamVec[i].typeName==_type){
                  return &surfaceEnergyParamVec[i];
               }
            }
            return 0;
         }


   };
   
};
#endif
