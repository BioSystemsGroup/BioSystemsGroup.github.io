/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR1 PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef SURFACEFLEXENERGY_H
#define SURFACEFLEXENERGY_H

#include <CompuCell3D/Potts3D/EnergyFunction.h>

#include <XMLCereal/XMLSerializable.h>
#include <CompuCell3D/Potts3D/Cell.h>
#include <vector>
#include "SurfaceFlexParseData.h"

#include <CompuCell3D/Boundary/BoundaryTypeDefinitions.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>


namespace CompuCell3D {
   class Simulator;
    template <class T> class Field3D;
	 template <class T> class WatchableField3D;
    class Point3D;
    class BoundaryStrategy;
    class Potts3D;


     	
  /** 
   * Calculates volume energy based on a target volume and
   * lambda volume.
   */
   
  class DECLSPECIFIER SurfaceFlexEnergy: public EnergyFunction, public virtual XMLSerializable {
       

    std::vector<SurfaceEnergyParam> surfaceEnergyParamVector;
    std::vector<std::string> typeNameVec;

    WatchableField3D<CellG *> *cellFieldG;
    double scaleSurface;
    BoundaryStrategy *boundaryStrategy;
    unsigned int maxNeighborIndex;

    LatticeMultiplicativeFactors lmf;
    Potts3D *potts;

  public:
    SurfaceFlexParseData sfpd;
    SurfaceFlexParseData * sfpdPtr;

    SurfaceFlexEnergy() :scaleSurface(1.0),boundaryStrategy(0),maxNeighborIndex(0) {}
    void setCellField(Field3D<CellG *> *_cellFieldG){cellFieldG=(WatchableField3D<CellG *> *)_cellFieldG;}
    void setLatticeMultiplicativeFactors(const LatticeMultiplicativeFactors & _lmf){lmf=_lmf;}
    void setPotts(Potts3D *_potts){potts=_potts;}

   double diffEnergy(double surface, double diff, double targetSurface, double lambdaSurface);
   void setMaxNeighborIndex(unsigned int _maxNeighborIndex){maxNeighborIndex=_maxNeighborIndex;}

    virtual double localEnergy(const Point3D &pt);
/*    virtual double changeEnergy(const Point3D &pt, const Cell *newCell,
				const Cell *oldCell);*/
            
    virtual double changeEnergy(const Point3D &pt, const CellG *newCell,
				const CellG *oldCell);

				
    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    // End XMLSerializable interface
    void initTypeId(Potts3D * potts);

    //SteerableObject interface
    virtual void update(ParseData *pd, bool _fullInitFlag=false);
    virtual std::string steerableName();


  };
};
#endif
