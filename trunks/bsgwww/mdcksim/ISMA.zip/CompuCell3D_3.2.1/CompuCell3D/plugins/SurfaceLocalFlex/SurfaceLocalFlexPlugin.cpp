/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/


#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>

using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>
#include <CompuCell3D/plugins/SurfaceTracker/SurfaceTrackerPlugin.h>

#include <iostream>
using namespace std;

#define EXP_STL

#include "SurfaceLocalFlexPlugin.h"
#include "SurfaceLocalFlexEnergy.h"

SurfaceLocalFlexPlugin::SurfaceLocalFlexPlugin() : potts(0),surfaceLocalFlexEnergyPtr(0) 
{

   

}

SurfaceLocalFlexPlugin::~SurfaceLocalFlexPlugin() 
{
   if (surfaceLocalFlexEnergyPtr) delete surfaceLocalFlexEnergyPtr; 
   surfaceLocalFlexEnergyPtr=0;
}

void SurfaceLocalFlexPlugin::init(Simulator *simulator,ParseData *_pd) {
   
  potts = simulator->getPotts();  
  
  if(!surfaceLocalFlexEnergyPtr){
      surfaceLocalFlexEnergyPtr=new SurfaceLocalFlexEnergy();
   }
  pd=_pd;
  surfaceLocalFlexEnergyPtr->slfpdPtr=(SurfaceLocalFlexParseData*)pd;
  surfaceLocalFlexEnergyPtr->init(simulator);
  
  potts->registerEnergyFunctionWithName(surfaceLocalFlexEnergyPtr,"SurfaceLocalFlex");


}

void SurfaceLocalFlexPlugin::extraInit(Simulator *simulator) {
  Potts3D *potts = simulator->getPotts();
  
  

  


   bool pluginAlreadyRegisteredFlag;
   SurfaceTrackerPlugin *plugin=(SurfaceTrackerPlugin *)Simulator::pluginManager.get("SurfaceTracker",&pluginAlreadyRegisteredFlag); //this will load SurfaceTracker plugin if it is not already loaded
  if(!pluginAlreadyRegisteredFlag)
      plugin->init(simulator);
  surfaceLocalFlexEnergyPtr->setMaxNeighborIndex( plugin->getMaxNeighborIndex() );
  surfaceLocalFlexEnergyPtr->setLatticeMultiplicativeFactors( plugin->getLatticeMultiplicativeFactors() );

}


void SurfaceLocalFlexPlugin::readXML(XMLPullParser &in) {

  if(!surfaceLocalFlexEnergyPtr){
      surfaceLocalFlexEnergyPtr=new SurfaceLocalFlexEnergy();
   }
  pd=&surfaceLocalFlexEnergyPtr->slfpd;
  surfaceLocalFlexEnergyPtr->readXML(in);
}

void SurfaceLocalFlexPlugin::writeXML(XMLSerializer &out) {
  surfaceLocalFlexEnergyPtr->writeXML(out);
}

