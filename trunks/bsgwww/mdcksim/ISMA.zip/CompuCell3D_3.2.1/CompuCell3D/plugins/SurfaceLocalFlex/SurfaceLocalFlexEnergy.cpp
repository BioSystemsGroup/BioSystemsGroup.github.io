/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Potts3D/Potts3D.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <string>
#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Boundary/BoundaryStrategy.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>
using namespace std;

#define EXP_STL
#include "SurfaceLocalFlexEnergy.h"

double SurfaceLocalFlexEnergy::diffLocalFlexEnergy(const CellG *cell, double diff) {
  return cell->lambdaSurface *
    (diff* diff+ 2 * diff * (cell->surface*scaleSurface - fabs(cell->targetSurface)));
}


double SurfaceLocalFlexEnergy::localEnergy(const Point3D &pt) {
  return 0;
}

double SurfaceLocalFlexEnergy::changeEnergy(const Point3D &pt,
				  const CellG *newCell,
				  const CellG *oldCell) {

  /// E = lambdaSurface * (surface - targetSurface) ^ 2 
  
  
  

  double energy = 0;
  



  if (oldCell == newCell) return 0;
    
  CellG *nCell;
  


  unsigned int token = 0;
  double distance;
  double oldDiff = 0.;
  double newDiff = 0.;
  Point3D n;

  
 
    
  // Count surface difference

    Neighbor neighbor;
   for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
      neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
      if(!neighbor.distance){
      //if distance is 0 then the neighbor returned is invalid
      continue;
      }
      nCell = cellFieldG->get(neighbor.pt);
      if (newCell == nCell) newDiff-=lmf.surfaceMF;
      else newDiff+=lmf.surfaceMF;
   
      if (oldCell == nCell) oldDiff+=lmf.surfaceMF;
      else oldDiff-=lmf.surfaceMF;

   }


  if (newCell)
    energy += diffLocalFlexEnergy(newCell, newDiff*scaleSurface);

  if (oldCell)
    energy += diffLocalFlexEnergy(oldCell, oldDiff*scaleSurface);

 
  return energy;


}

void SurfaceLocalFlexEnergy::init(Simulator * simulator){
   cellFieldG=(WatchableField3D<CellG*>*)simulator->getPotts()->getCellFieldG();
   boundaryStrategy=BoundaryStrategy::getInstance();
   update(slfpdPtr);
}
void SurfaceLocalFlexEnergy::update(ParseData * _pd){
   slfpdPtr=(SurfaceLocalFlexParseData*)_pd;
   scaleSurface=slfpdPtr->scaleSurface;
}




void SurfaceLocalFlexEnergy::readXML(XMLPullParser &in) {
  in.skip(TEXT);
  while (in.check(START_ELEMENT)) {
   if (in.getName() == "ScaleSurface") { //should be less than 1.0 if surface tracker goes to second or higher neighbor
                                                 // to calculate effective surface
      scaleSurface = BasicString::parseDouble(in.matchSimple());

    } else {
      throw BasicException(string("Unexpected element '") + in.getName() + 
			   "'!", in.getLocation());
    }

    in.skip(TEXT);
  } 
  
}

void SurfaceLocalFlexEnergy::writeXML(XMLSerializer &out) {
}


