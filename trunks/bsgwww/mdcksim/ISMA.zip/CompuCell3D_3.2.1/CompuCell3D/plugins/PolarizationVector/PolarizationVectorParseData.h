#ifndef POLARIZATIONVECTORPARSEDATA_H
#define POLARIZATIONVECTORPARSEDATA_H



#include <CompuCell3D/ParseData.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class DECLSPECIFIER PolarizationVectorParseData:public ParseData{
      public:
      PolarizationVectorParseData():ParseData("PolarizationVector")
      {}
   };
};
#endif
