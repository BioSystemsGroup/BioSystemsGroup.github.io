/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/Potts3D/Cell.h>
#include <CompuCell3D/Automaton/Automaton.h>
#include <CompuCell3D/plugins/NeighborTracker/NeighborTrackerPlugin.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <CompuCell3D/Potts3D/Cell.h>
#include <CompuCell3D/Simulator.h>

#include <algorithm>
#include <PublicUtilities/StringUtils.h>


#include <string>
#include <limits>
using namespace std;

#define EXP_STL
#include "NeighborStickEnergy.h"

double NeighborStickEnergy::localEnergy(const Point3D &pt) {
  return 0;
}
    
        

double NeighborStickEnergy::changeEnergy(const Point3D &pt,
                                  const CellG *newCell,
                                  const CellG *oldCell) {
//    cerr<<"ChangeEnergy"<<endl;
   
   
  double energy = 0;
  unsigned int token = 0;
  double distance = 0;
  Point3D n;
  int totalArea = 0;
  CellG *nCell=0;
  WatchableField3D<CellG *> *fieldG = (WatchableField3D<CellG *> *)potts->getCellFieldG();
  Neighbor neighbor;
  
  std::set<NeighborSurfaceData> * neighborData;
  std::set<NeighborSurfaceData >::iterator sitr;
  
//   cout << "Threshold: " << thresh << endl;
//   cerr << "  SIZE: " << typeNames.size() << endl;
//   for(int i = 0; i < typeNames.size(); i++) {
//      cerr << "Name: " << typeNames[i] << " ID: " << (int)automaton->getTypeId(typeNames[i]) << " and again: " << idNames[i] << endl;
//   }
  
  
  
     

   if(oldCell) {
      neighborData = &(neighborTrackerAccessorPtr->get(oldCell->extraAttribPtr)->cellNeighbors);
      
      for(sitr=neighborData->begin() ; sitr != neighborData->end() ; ++sitr){
         
//          cout << "Type: " << (int)oldCell->type << " ID: " << oldCell->id << endl;
         nCell= sitr->neighborAddress;
         if(nCell){
            int nType = (int)nCell->type;
//             cout << "Neighbor Type: " << nType << endl;
            for(int i = 0; i < idNames.size() ; i++) {
               if(nType==idNames[i]) {
                  /*cout << "SAME TYPE step: " << i << endl;
                  cout << "Common Surface Area: " << (int)sitr->commonSurfaceArea << endl;
                  */
                  totalArea +=(int)sitr->commonSurfaceArea;
                  break;
               }
               else {
                  continue;
//                   cout << "Wrong Type" << endl;
               }
            }
         }
      
      }
   }
   if((totalArea < thresh) & (totalArea != 0)){
      return numeric_limits<float>::max()/2.0;
   }
   else {
      return 0;
   }
}

double NeighborStickEnergy::orientedContactEnergy(const CellG *cell1, const CellG *cell2) {
   
   return 0;


}


int NeighborStickEnergy::getIndex(const int type1, const int type2) const {
  if (type1 < type2) return ((type1 + 1) | ((type2 + 1) << 16));
  else return ((type2 + 1) | ((type1 + 1) << 16));
}


void NeighborStickEnergy::init(Simulator * simulator){

   sim=simulator;
   potts=sim->getPotts();
   update(ocpdPtr);
   
   bool pluginAlreadyRegisteredFlag;
   NeighborTrackerPlugin * neighborTrackerPluginPtr=(NeighborTrackerPlugin*)(Simulator::pluginManager.get("NeighborTracker",&pluginAlreadyRegisteredFlag));
   if (!pluginAlreadyRegisteredFlag){
      neighborTrackerPluginPtr->init(simulator,&neighborTrackerPluginPtr->ntpd);
      ASSERT_OR_THROW("NeighborTracker plugin not initialized!", neighborTrackerPluginPtr);
      neighborTrackerAccessorPtr=neighborTrackerPluginPtr->getNeighborTrackerAccessorPtr();
      ASSERT_OR_THROW("neighborAccessorPtr  not initialized!", neighborTrackerAccessorPtr);
   }
}

void NeighborStickEnergy::update(ParseData * _pd, bool _fullInitFlag){
   ocpdPtr=(NeighborStickParseData *)_pd;
   automaton = potts->getAutomaton();
   set<unsigned char> cellTypesSet;

   thresh=ocpdPtr->thresh;
   std::vector<std::string> temp;
   typeNames=ocpdPtr->typeNames;
   //done because of weird doulbing in vector ???
   for(int i = 0; i < typeNames.size()/2; i++) {
      temp.push_back(typeNames[i]); 
   }
   typeNames.clear();
   typeNames=temp;
   typeNames.pop_back(); //delete empyt element
   for(int i = 0; i < typeNames.size(); i++) {
      idNames.push_back(automaton->getTypeId(typeNames[i])); 
   }
   
   
   boundaryStrategy=BoundaryStrategy::getInstance();
   maxNeighborIndex=0;

   
//    exit(0);

}

void NeighborStickEnergy::readXML(XMLPullParser &in) {
   in.skip(TEXT);

   while (in.check(START_ELEMENT)) {
      if (in.getName() == "Threshold") {
         ocpd.thresh = BasicString::parseDouble(in.matchSimple());

      } else if (in.getName() == "Types"){
         ocpd.typeNamesString=in.matchSimple();
      } else {
         throw BasicException(string("Unexpected element '") + in.getName() +
               "'!", in.getLocation());
      }

      in.skip(TEXT);
   }
   
   in.skip(TEXT);
   ocpd.typeNames.push_back(typeNamesString);
   parseStringIntoList(ocpd.typeNamesString , ocpd.typeNames , ",");
   
}

void NeighborStickEnergy::writeXML(XMLSerializer &out) {
}

std::string NeighborStickEnergy::toString(){
  return string("NeighborStick");
}


std::string NeighborStickEnergy::steerableName(){

   return ocpd.ModuleName();

}
