/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef CHEMOTAXISENERGY_H
#define CHEMOTAXISENERGY_H

#include <CompuCell3D/Potts3D/EnergyFunction.h>

#include <XMLCereal/XMLSerializable.h>
#include <CompuCell3D/Potts3D/Cell.h>
//#include <BasicUtils/BasicClassGroup.h>

#include <string>
#include <vector>

#include "ChemotaxisParseData.h"

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {
  template <class T>
  class Field3D;
  template <class T>
  class Field3DImpl;

  class Potts3D;
  class Simulator; 

  class ChemotaxisData;

  class DECLSPECIFIER ChemotaxisEnergy : public EnergyFunction, public XMLSerializable {

    Potts3D *potts;
    Simulator *sim;
    std::vector<Field3DImpl<float> *> fieldVec;

   std::vector<std::vector<ChemotaxisData> > vecVecChemotaxisData;
   float simpleChemotaxisFormula(float _flipNeighborConc,float _conc,ChemotaxisData & _chemotaxisData);
   float saturationChemotaxisFormula(float _flipNeighborConc,float _conc,ChemotaxisData & _chemotaxisData);
   float saturationLinearChemotaxisFormula(float _flipNeighborConc,float _conc,ChemotaxisData & _chemotaxisData);
   //bool okToChemotact(unsigned int fieldIdx,unsigned char cellType);
   std::string chemotaxisAlgorithm;

  public:

    typedef float (ChemotaxisEnergy::*chemotaxisEnergyFormulaFcnPtr_t)(float,float,ChemotaxisData &);

    typedef double (ChemotaxisEnergy::*changeEnergyEnergyFormulaFcnPtr_t)(const Point3D &, const CellG *,
                                const CellG *);
   private:
      changeEnergyEnergyFormulaFcnPtr_t algorithmPtr;
   
   public:
    ChemotaxisParseData cpd;
    ChemotaxisParseData * cpdPtr;

    ChemotaxisEnergy() ;


    virtual ~ChemotaxisEnergy() {}

    void setSimulatorPtr(Simulator * _sim);
    

    float getLambda(int i);
    
    void initializeField();      
    void initializeChemotaxisEnergy(ParseData *_pd);
    
    Field3D<float>* getField(int i);
    //void setField(int i,Field3DImpl<float>* _field ) { fieldVec[i]=_field;}
    

    
    double regularChemotaxis(const Point3D &pt, const CellG *newCell,
                                const CellG *oldCell);
   
    double merksChemotaxis(const Point3D &pt, const CellG *newCell,
                                const CellG *oldCell);


    virtual double localEnergy(const Point3D &pt);
    virtual double changeEnergy(const Point3D &pt, const CellG *newCell,
                                const CellG *oldCell);

    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    // End XMLSerializable interface

    //Steerable interface
    virtual void update(ParseData *_pd, bool _fullInitFlag=false);
    virtual std::string steerableName();

//     void initNonChemotactingTypeId();
    void initChemotaxisData();

   private:
      


  };

//   inline float ChemotaxisEnergy::getLambda(int i){return lambdaVec[i];}
  inline Field3D<float>* ChemotaxisEnergy::getField(int i){
   if(i<fieldVec.size())
      return (Field3D<float> *)fieldVec[i];
   else
      return 0;
  }

//    class ChemotaxisData{
//       public:
//          ChemotaxisData(float _lambda=0.0 , float _saturationCoef=0.0 , std::string _typeName=""):
//          lambda(_lambda),saturationCoef(_saturationCoef),typeName(_typeName),formulaPtr(0)
//          {}
// 
//          float lambda;
//          float saturationCoef;
//          ChemotaxisEnergy::chemotaxisEnergyFormulaFcnPtr_t  formulaPtr;
// 
//          std::string typeName;
//          std::vector<unsigned char> chemotactTowardsTypesVec;
//          std::string chemotactTowardsTypesStrig;
//          void outScr();
//          bool okToChemotact( const CellG * _oldCell);
//          
// 
//    };
  
};

#endif
