/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Automaton/Automaton.h>
#include <CompuCell3D/Field3D/Dim3D.h>
#include <CompuCell3D/ClassRegistry.h>
#include <CompuCell3D/Simulator.h>
//#include <CompuCell3D/Diffusable.h>
#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Field3D/Field3DIO.h>
#include <CompuCell3D/Potts3D/Cell.h>
//#include <CompuCell3D/DiffusionSolverBiofilmFE.h>
#include <CompuCell3D/steppables/PDESolvers/DiffusableVector.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>
#include <PublicUtilities/StringUtils.h>


#include <fstream>
#include <string>
using namespace std;

#define EXP_STL
#include "ChemotaxisEnergy.h"


void ChemotaxisEnergy::initializeChemotaxisEnergy(ParseData *_pd){
   cpdPtr=(ChemotaxisParseData *)_pd;
//    initChemotaxisData();
}


ChemotaxisEnergy::ChemotaxisEnergy() {
   algorithmPtr=0;
   algorithmPtr=&ChemotaxisEnergy::merksChemotaxis;
   cpdPtr=0;

};

void ChemotaxisEnergy::setSimulatorPtr(Simulator * _sim)
{
   sim=_sim;
   potts=sim->getPotts();
}


double ChemotaxisEnergy::localEnergy(const Point3D &pt) {
  ASSERT_OR_THROW("No chemical field has been initialized!", fieldVec.size()>0);
  return 0;
}


void ChemotaxisEnergy::initializeField(){

   ClassRegistry *classRegistry=sim->getClassRegistry();
   Steppable * steppable;
   cerr<<"chemicalFieldSourceVec.size()="<<cpdPtr->chemotaxisFieldDataVec.size()<<endl;
   fieldVec.assign(cpdPtr->chemotaxisFieldDataVec.size(),0);//allocate fieldVec
   

   for(unsigned int i=0; i < cpdPtr->chemotaxisFieldDataVec.size() ; ++i ){
      if(cpdPtr->chemotaxisFieldDataVec[i].chemicalFieldSource=="DiffusionSolverFE"){
         map<string,Field3DImpl<float>*> & nameFieldMap = sim->getConcentrationFieldNameMap();
         map<string,Field3DImpl<float>*>::iterator mitr=nameFieldMap.find(cpdPtr->chemotaxisFieldDataVec[i].chemicalFieldName);
         
         if(mitr!=nameFieldMap.end()){
            fieldVec[i]=mitr->second;
         }else{
            ASSERT_OR_THROW("No chemical field has been loaded!", fieldVec[i]);
            
         }
      }else{
         cerr<<"WILL REQUEST "<<cpdPtr->chemotaxisFieldDataVec[i].chemicalFieldSource<<endl;
         steppable=classRegistry->getStepper(cpdPtr->chemotaxisFieldDataVec[i].chemicalFieldSource);
         fieldVec[i]=((DiffusableVector<float> *) steppable)->getConcentrationField(cpdPtr->chemotaxisFieldDataVec[i].chemicalFieldName);
         ASSERT_OR_THROW("No chemical field has been loaded!", fieldVec[i]);
      }
   }

}

float ChemotaxisEnergy::simpleChemotaxisFormula(float _flipNeighborConc,float _conc,ChemotaxisData & _chemotaxisData){
   return (_flipNeighborConc-_conc)*_chemotaxisData.lambda;
}

float ChemotaxisEnergy::saturationChemotaxisFormula(float _flipNeighborConc,float _conc,ChemotaxisData & _chemotaxisData){
   cout << "Chemotaxis value: " << _chemotaxisData.lambda*(
         _flipNeighborConc/(_chemotaxisData.saturationCoef+_flipNeighborConc)
         -_conc/(_chemotaxisData.saturationCoef+_conc)) << endl;
         cout << " Lambda: " << _chemotaxisData.lambda << " Conc: " << _conc << " NeighborConc: " << _flipNeighborConc << " Coef: " << _chemotaxisData.saturationCoef << endl;
                                                          
   
   return   _chemotaxisData.lambda*(
               _flipNeighborConc/(_chemotaxisData.saturationCoef+_flipNeighborConc)
               -_conc/(_chemotaxisData.saturationCoef+_conc)
            );

}

float ChemotaxisEnergy::saturationLinearChemotaxisFormula(float _flipNeighborConc,float _conc,ChemotaxisData & _chemotaxisData){
   cout << "Chemotaxis value: " << _chemotaxisData.lambda*(
         _flipNeighborConc/(_chemotaxisData.saturationCoef*_flipNeighborConc+1)
         -_conc/(_chemotaxisData.saturationCoef*_conc+1)) << endl;
   cout << " Lambda: " << _chemotaxisData.lambda << " Conc: " << _conc << " NeighborConc: " << _flipNeighborConc << " Coef: " << _chemotaxisData.saturationCoef << endl;
   
   return   _chemotaxisData.lambda*(
               _flipNeighborConc/(_chemotaxisData.saturationCoef*_flipNeighborConc+1)
               -_conc/(_chemotaxisData.saturationCoef*_conc+1)
            );

}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
double ChemotaxisEnergy::regularChemotaxis(const Point3D &pt, const CellG *newCell,const CellG *oldCell){

//    cerr<<"This is regular chemotaxis"<<endl;

   ///cells move up the concentration gradient
   

   /// new cell has to be different than medium i.e. only non-medium cells can chemotact
   ///e.g. in chemotaxis only non-medium cell can move a pixel that either belonged to other cell or to medium
   ///but situation where medium moves to a new pixel is not considered a chemotaxis

   float energy=0.0;
   if(newCell){
//       cerr<<"INSIDE NEW CELL CONDITION fieldVec.size()="<<fieldVec.size()<<endl;
      for(unsigned int i = 0 ; i < fieldVec.size() ; ++i){
            
            if( (int)newCell->type < vecVecChemotaxisData[i].size() ){

               ChemotaxisData & chemotaxisDataRef = vecVecChemotaxisData[i][(int)newCell->type];
               ChemotaxisData * chemotaxisDataPtr = & vecVecChemotaxisData[i][(int)newCell->type];

               ChemotaxisEnergy::chemotaxisEnergyFormulaFcnPtr_t formulaCurrentPtr=0;

               formulaCurrentPtr=chemotaxisDataRef.formulaPtr;


               if( !chemotaxisDataRef.okToChemotact(oldCell) ){ // chemotaxis id not allowed towards this type of oldCell
                  continue;
               }
               
               if(chemotaxisDataRef.lambda!=0.0){ //THIS IS THE CONDITION THAT TRIGGERS CHEMOTAXIS
//                   if((int)newCell->type==2){
//                   cerr<<"pointer to formula="<<formulaCurrentPtr<<endl;
//                   chemotaxisDataRef.outScr();
// 
//                   
//                   cerr<<"concentration N="<<fieldVec[i]->get(potts->getFlipNeighbor())<<" conc="<<fieldVec[i]->get(pt)<<endl;
//                   cerr<<"energy="<<(this->*formulaCurrentPtr)(fieldVec[i]->get(potts->getFlipNeighbor()) , fieldVec[i]->get(pt) , chemotaxisDataRef)<<endl;
// //                   cerr<<"energy="<<simpleChemotaxisFormula(fieldVec[i]->get(potts->getFlipNeighbor()) , fieldVec[i]->get(pt) , chemotaxisDataRef)<<endl;
//                   }
//                  energy+=(this->*formulaPtr)(fieldVec[i]->get(potts->getFlipNeighbor()) , fieldVec[i]->get(pt) , chemotaxisDataRef);
                  if(formulaCurrentPtr)
                     energy+=(this->*formulaCurrentPtr)(fieldVec[i]->get(potts->getFlipNeighbor()) , fieldVec[i]->get(pt) , chemotaxisDataRef);
                  


               }
               

            }

      }
//       cerr<<"CHEMOTAXIS EN="<<energy<<endl;   
      return energy;
   }
//   cerr<<"CHEMOTAXIS EN="<<energy<<endl;
  return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
double ChemotaxisEnergy::merksChemotaxis(const Point3D &pt, const CellG *newCell,const CellG *oldCell){

//    cerr<<"this is merks chemotaxis"<<endl;   
   float energy=0.0;
   
   

//    cerr<<"fieldVec.size()="<<fieldVec.size()<<endl;
   for(unsigned int i = 0 ; i < fieldVec.size() ; ++i){
      bool chemotaxisDone=false;
      //first will see if newCell is chemotacting and if it chemotacts towards oldCell. If yes, then nex if statement
      // will be skipped and 
      if(newCell && (int)newCell->type < vecVecChemotaxisData[i].size()){// check if newCell is potentially chemotacting

         ChemotaxisData & chemotaxisDataRef = vecVecChemotaxisData[i][(int)newCell->type];



         if( chemotaxisDataRef.okToChemotact(oldCell) && chemotaxisDataRef.lambda!=0.0){ 
         // chemotaxis is allowed towards this type of oldCell and lambda is non-zero
//          cerr<<"BASED ON NEW pt "<<pt<<" oldCell="<<oldCell<<" newCell="<<newCell<<endl;
            ChemotaxisEnergy::chemotaxisEnergyFormulaFcnPtr_t formulaCurrentPtr=0;
            formulaCurrentPtr=chemotaxisDataRef.formulaPtr;
            if(formulaCurrentPtr){
               energy+=(this->*formulaCurrentPtr)(fieldVec[i]->get(potts->getFlipNeighbor()) , fieldVec[i]->get(pt) 
                              , chemotaxisDataRef);
               chemotaxisDone=true;
           }
         }
      }
      
      if(!chemotaxisDone && oldCell && (int)oldCell->type < vecVecChemotaxisData[i].size()){
      //since chemotaxis "based on" newCell did not work we try to see it "based on" oldCell will work
         ChemotaxisData & chemotaxisDataRef = vecVecChemotaxisData[i][(int)oldCell->type];

         if( chemotaxisDataRef.okToChemotact(newCell) && chemotaxisDataRef.lambda!=0.0){ 
         // chemotaxis is allowed towards this type of oldCell and lambda is non-zero
//             cerr<<"BASED ON OLD pt="<<pt<<" oldCell="<<oldCell<<" newCell="<<newCell<<endl;
            ChemotaxisEnergy::chemotaxisEnergyFormulaFcnPtr_t formulaCurrentPtr=0;
            formulaCurrentPtr=chemotaxisDataRef.formulaPtr;
            if(formulaCurrentPtr){
//                energy+=(this->*formulaCurrentPtr)(fieldVec[i]->get(potts->getFlipNeighbor()) , fieldVec[i]->get(pt) 
//                         , chemotaxisDataRef);
               energy+=(this->*formulaCurrentPtr)(fieldVec[i]->get(potts->getFlipNeighbor()), fieldVec[i]->get(pt)
                        , chemotaxisDataRef);

               chemotaxisDone=true;
           }
         }
      }
      
   }
//    cerr<<"Chemotaxis energy  - Merks alg = "<<energy<<endl;
   return energy;


}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

double ChemotaxisEnergy::changeEnergy(const Point3D &pt,
                                  const CellG *newCell,
                                  const CellG *oldCell) {
  
//    cerr<<"algorithmPtr="<<algorithmPtr<<endl;
   

   
//    double energy=(this->*algorithmPtr)(pt,newCell,oldCell);
//    exit(0);
//    return 0.0;
   
    
//     cerr<<"Chemotaxis Energy="<<energy<<endl;
//     return energy;
    return (this->*algorithmPtr)(pt,newCell,oldCell);


}


void ChemotaxisEnergy::readXML(XMLPullParser &in) {
  in.skip(TEXT);

//   string fieldSource;
//   string fieldName;
//   string nonChemotactingTypes;
//   float lambdaTmp;
//   float saturationCoefTmp=0.0;
//   bool saturationFormFlag=false;

//   float saturationLinearCoefTmp=0.0;
//   bool saturationLinearFormFlag=false;


  string chemotactTowardsTypesStrigTmp;
  string chemotaxisAlgorithmTmp;

//   vector<ChemotaxisData> vecChemotaxisData;
/*  vector<pair<string ,float> > lambdaTypeVecTmp;
  vector<pair<string ,float> > saturationCoefTypeVecTmp;*/
  string typeTmp;


  
  while (in.check(START_ELEMENT)) {

    if(in.getName()=="Algorithm"){
      cpd.chemotaxisAlgorithm=in.matchSimple();
      //setting function Ptr for chemotaxis algorithm
      changeToLower(cpd.chemotaxisAlgorithm);
      cerr<<"Name of the Chemotaxis="<<cpd.chemotaxisAlgorithm<<endl;

      //to initialize
//       if(chemotaxisAlgorithm=="merks"){
//          algorithmPtr=&ChemotaxisEnergy::merksChemotaxis;
//       } else if(chemotaxisAlgorithm=="regular") {
//          algorithmPtr=&ChemotaxisEnergy::regularChemotaxis;
//       }
      //to initialize


    } else if (in.getName() == "ChemicalField") {

      cpd.chemotaxisFieldDataVec.push_back(ChemotaxisFieldData());
      ChemotaxisFieldData & cfd=cpd.chemotaxisFieldDataVec[cpd.chemotaxisFieldDataVec.size()-1];
      
      cfd.chemicalFieldSource = in.getAttribute("Source").value;
      cfd.chemicalFieldName =in.getAttribute("Name").value;
      
//       chemicalFieldSourceVec.push_back(fieldSource);
//       chemicalFieldNameVec.push_back(fieldName);
      cerr<<"fieldSource="<<cfd.chemicalFieldSource<<" fieldName="<<cfd.chemicalFieldName<<endl;


         in.match(START_ELEMENT);
         in.skip(TEXT);

         cfd.vecChemotaxisData.clear();
         while(in.check(START_ELEMENT)){

            
            
            if(in.getName() == "ChemotaxisByType"){
               cfd.vecChemotaxisData.push_back(ChemotaxisData());
               ChemotaxisData & cd=cfd.vecChemotaxisData[cfd.vecChemotaxisData.size()-1];



               cd.typeName=in.getAttribute("Type").value;
               
               if(in.findAttribute("Lambda")>=0){
                  cd.lambda=BasicString::parseDouble(in.getAttribute("Lambda").value);
                  cerr<<"in.getAttribute(Lambda).value="<<in.getAttribute("Lambda").value<<endl;
               }

//                saturationFormFlag=false;
               if(in.findAttribute("SaturationCoef")>=0){
                  cd.saturationCoef=BasicString::parseDouble(in.getAttribute("SaturationCoef").value);
                  cd.formulaName="SaturationChemotaxisFormula";
//                   cd.saturationCoef=BasicString::parseDouble(in.getAttribute("SaturationCoef").value);
//                   saturationFormFlag=true;
               }

//                saturationLinearFormFlag=false;
               if(in.findAttribute("SaturationLinearCoef")>=0){
                  cd.saturationCoef=BasicString::parseDouble(in.getAttribute("SaturationLinearCoef").value);
                  cd.formulaName="SaturationLinearChemotaxisFormula";
//                   cd.saturationCoef=BasicString::parseDouble(in.getAttribute("SaturationLinearCoef").value);
//                   saturationLinearFormFlag=true;
               }



               if(in.findAttribute("ChemotactTowards")>=0){
                  cd.chemotactTowardsTypesString=in.getAttribute("ChemotactTowards").value;
                  
               }


               

//                cerr<<"lambda="<<lambdaTmp<<" SaturationCoef="<<saturationCoefTmp<<" typeTmp="<<typeTmp<<endl;
//                ChemotaxisData chemotaxisData(lambdaTmp,saturationCoefTmp,typeTmp);//new copy of chemotaxis data for a given cell type
               //ChemotaxisData chemotaxisData(12,20,"Sickle");//new copy of chemotaxis data for a given cell type
//                cerr<<"SCANNED CHEMOTAXIS DATA"<<endl;
//                chemotaxisData.outScr();

//                if(saturationFormFlag && ! saturationLinearFormFlag){
//                   cd.formulaName="SaturationChemotaxisFormula";
// 
//                }
//                else if( ! saturationFormFlag &&  saturationLinearFormFlag){
//                   cd.formulaName="SaturationLinearChemotaxisFormula";
// 
//                }
//                else{
//                   cd.formulaName="SimpleChemotaxisFormula";
//                }

               

//                chemotaxisData.chemotactTowardsTypesStrig=chemotactTowardsTypesStrigTmp;
// 
//                vecChemotaxisData.push_back(chemotaxisData);
            

               in.matchSimple();
            }/*else if(in.getName() == "ChemotaxisSaturationForm"){
               typeTmp=in.getAttribute("Type").value;
            }*/
            else {
               throw BasicException(string("Unexpected element '") + in.getName() + 
               "'!", in.getLocation());
            }
            
            in.skip(TEXT);
         }
//          vecVecChemotaxisData.push_back(vecChemotaxisData);
         in.skip(TEXT);
         in.match(END_ELEMENT);

      
      
    }
        
   else {
      throw BasicException(string("Unexpected element '") + in.getName() +
                           "'!", in.getLocation());
    }

    in.skip(TEXT);
  }

   
//  initChemotaxisData();
   
  
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ChemotaxisEnergy::writeXML(XMLSerializer &out) {
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ChemotaxisEnergy::initChemotaxisData(){

   Automaton *automaton=potts->getAutomaton();
   
   unsigned char maxType=0;
   //first will find max type value
   cerr<<"cpdPtr->chemotaxisFieldDataVec[0].vecChemotaxisData.size()="<<cpdPtr->chemotaxisFieldDataVec[0].vecChemotaxisData.size()<<endl;

   for(int i = 0 ; i < cpdPtr->chemotaxisFieldDataVec.size() ; ++ i)
      for(int j = 0 ; j < cpdPtr->chemotaxisFieldDataVec[i].vecChemotaxisData.size() ; ++j){
         if( automaton->getTypeId(cpdPtr->chemotaxisFieldDataVec[i].vecChemotaxisData[j].typeName) > maxType )
            maxType = automaton->getTypeId(cpdPtr->chemotaxisFieldDataVec[i].vecChemotaxisData[j].typeName);
      }

   //make copy vector vecVecChemotaxisData 
//    std::vector<std::vector<ChemotaxisData> > vecVecChemotaxisDataTmp=vecVecChemotaxisData;
   vecVecChemotaxisData.clear();

   cerr<<"maxType="<<(int)maxType<<endl;
   //now will allocate vectors based on maxType - this will result in t=0 lookup time later...
//    cerr<<"vecVecChemotaxisDataTmp.size()="<<vecVecChemotaxisDataTmp.size()<<endl;
//    cerr<<"(int)maxType+1="<<(int)maxType+1<<endl;
   vecVecChemotaxisData.assign(cpdPtr->chemotaxisFieldDataVec.size() , vector<ChemotaxisData>((int)maxType+1,ChemotaxisData() ) );


/*   //now will allocate vectors based on maxType - this will result in t=0 lookup time later...
   flexChemotaxisDataVec.assign(flexChemotaxisDataVecTmp.size(),vector<float>((int)maxType+1,0.0));*/

   vector<string> vecTypeNamesTmp;

   
   if(cpdPtr->chemotaxisAlgorithm=="merks"){
      algorithmPtr=&ChemotaxisEnergy::merksChemotaxis;
   } else if(cpdPtr->chemotaxisAlgorithm=="regular") {
      algorithmPtr=&ChemotaxisEnergy::regularChemotaxis;
   }


   for(int i = 0 ; i < cpdPtr->chemotaxisFieldDataVec.size() ; ++ i)
      for(int j = 0 ; j < cpdPtr->chemotaxisFieldDataVec[i].vecChemotaxisData.size() ; ++j){

      vecTypeNamesTmp.clear();

      int cellTypeId = automaton->getTypeId(cpdPtr->chemotaxisFieldDataVec[i].vecChemotaxisData[j].typeName);

      vecVecChemotaxisData[i][cellTypeId]=cpdPtr->chemotaxisFieldDataVec[i].vecChemotaxisData[j];

      ChemotaxisData &chemotaxisDataTmp=vecVecChemotaxisData[i][cellTypeId];
      //Mapping type names to type ids
      if(chemotaxisDataTmp.chemotactTowardsTypesString!=""){ //non-empty string we need to parse and process it 

         parseStringIntoList(chemotaxisDataTmp.chemotactTowardsTypesString,vecTypeNamesTmp,",");
         chemotaxisDataTmp.chemotactTowardsTypesString=""; //empty original string it is no longer needed

         for(int idx=0 ; idx < vecTypeNamesTmp.size() ; ++idx){

            unsigned char typeTmp=automaton->getTypeId(vecTypeNamesTmp[idx]);
            chemotaxisDataTmp.chemotactTowardsTypesVec.push_back(typeTmp);

         }
      }


      if(vecVecChemotaxisData[i][cellTypeId].formulaName=="SaturationChemotaxisFormula"){
         vecVecChemotaxisData[i][cellTypeId].formulaPtr=&ChemotaxisEnergy::saturationChemotaxisFormula;
      }
      else if( vecVecChemotaxisData[i][cellTypeId].formulaName=="SaturationLinearChemotaxisFormula"){
         vecVecChemotaxisData[i][cellTypeId].formulaPtr=&ChemotaxisEnergy::saturationLinearChemotaxisFormula;
         
      }
      else{
         vecVecChemotaxisData[i][cellTypeId].formulaPtr=&ChemotaxisEnergy::simpleChemotaxisFormula;
      }

      cerr<<"i="<<i<<" cellTypeId="<<cellTypeId<<endl;
      vecVecChemotaxisData[i][cellTypeId].outScr();

   }

}


void ChemotaxisEnergy::update(ParseData *_pd, bool _fullInitFlag){
   initializeChemotaxisEnergy(_pd);
   initChemotaxisData();
   
}

std::string ChemotaxisEnergy::steerableName(){
   return cpd.ModuleName();
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// bool ChemotaxisEnergy::okToChemotact(unsigned int fieldIdx,unsigned char cellType){
// 
//    for(unsigned int i = 0 ; i < nonChemotactingTypeIdVecVec[fieldIdx].size() ; ++i){
//       if(cellType==nonChemotactingTypeIdVecVec[fieldIdx][i])
//          return false;
//    }
//    return true;
// }

