/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/ClassRegistry.h>
#include <CompuCell3D/Potts3D/Potts3D.h>


using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>
#include <BasicUtils/BasicClassFactoryBase.h>


#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
using namespace std;

#define EXP_STL

#include "ChemotaxisPlugin.h"

#include "ChemotaxisEnergy.h"


void ChemotaxisPlugin::init(Simulator *simulator,ParseData *_pd) {
  sim = simulator;
  CompuCell3D::Potts3D *potts = simulator->getPotts();
  chemicalEnergy.setSimulatorPtr(simulator);
  chemicalEnergy.initializeChemotaxisEnergy(_pd);
  
  potts->registerEnergyFunctionWithName(&chemicalEnergy,"Chemotaxis");
  simulator->registerSteerableObject(this);          

}

void ChemotaxisPlugin::extraInit(Simulator *simulator) {
   chemicalEnergy.initChemotaxisData();
   chemicalEnergy.initializeField();


}


ChemotaxisPlugin::ChemotaxisPlugin() {
}

ChemotaxisPlugin::~ChemotaxisPlugin() {

}

void ChemotaxisPlugin::readXML(XMLPullParser &in) {
  pd=&chemicalEnergy.cpd;
  chemicalEnergy.readXML(in);
}

void ChemotaxisPlugin::writeXML(XMLSerializer &out) {
  
  chemicalEnergy.writeXML(out);
}


void ChemotaxisPlugin::update(ParseData *_pd, bool _fullInitFlag){
   chemicalEnergy.update(_pd);
}

std::string ChemotaxisPlugin::steerableName(){
   return chemicalEnergy.cpd.ModuleName();
}

