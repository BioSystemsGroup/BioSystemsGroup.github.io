/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Potts3D/Potts3D.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>
#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Boundary/BoundaryStrategy.h>
#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>
#include <NeighborTracker/NeighborTrackerPlugin.h>

#include <string>
#include <set>

using namespace std;

#define EXP_STL
#include "RearrangementEnergy.h"

double RearrangementEnergy::localEnergy(const Point3D &pt) {
  return 0;
}
RearrangementEnergy::RearrangementEnergy() : 
   fRearrangement(0.0),
   lambdaRearrangement(0.0),
   percentageLossThreshold(1.0),
   defaultPenalty(0.0),
   potts(0),
   cellFieldG(0) {

}

RearrangementEnergy::RearrangementEnergy(double fRearrangement, double lambdaRearrangement) :
      fRearrangement(fRearrangement), 
      lambdaRearrangement(lambdaRearrangement),
      percentageLossThreshold(1.0),
      defaultPenalty(0.0),
      potts(0),
      cellFieldG(0) {
  
}



void RearrangementEnergy::init(Simulator * simulator){

  boundaryStrategy=BoundaryStrategy::getInstance();
  maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(1);// 1st nearest neighbor
  potts=simulator->getPotts();
  cellFieldG=(WatchableField3D<CellG *> *)potts->getCellFieldG();

 
  update(rpdPtr);

  bool pluginAlreadyRegisteredFlag;
  NeighborTrackerPlugin * nTracker =(NeighborTrackerPlugin *) Simulator::pluginManager.get("NeighborTracker",&pluginAlreadyRegisteredFlag); //this will load NeighborTracker plugin if it si not already loaded 
   if(!pluginAlreadyRegisteredFlag)
      nTracker->init(simulator,0);
  neighborTrackerAccessorPtr = nTracker->getNeighborTrackerAccessorPtr();

}

void RearrangementEnergy::update(ParseData *_pd, bool _fullInitFlag){
   rpdPtr=(RearrangementParseData*)_pd;
   fRearrangement=rpdPtr->fRearrangement;
   lambdaRearrangement=rpdPtr->lambdaRearrangement;
   percentageLossThreshold=rpdPtr->percentageLossThreshold;
   defaultPenalty=rpdPtr->defaultPenalty;
   
}

pair<CellG*,CellG*> RearrangementEnergy::preparePair(CellG* cell1, CellG* cell2){

   if(cell1<cell2)
      return make_pair(cell1,cell2);
   else
      return make_pair(cell2,cell1);


}


double RearrangementEnergy::changeEnergy(const Point3D &pt,
				  const CellG *newCell,
				  const CellG *oldCell) {

  float energy=0.0;
  CellG *nCell=0;
  Neighbor neighbor;
  multiset<std::pair<CellG*,CellG*> > oldSet;
  multiset<std::pair<CellG*,CellG*> > newSet;
  set<NeighborSurfaceData> * nsdSetPtr;
  set<NeighborSurfaceData>::iterator nsdSitr;

   for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
      neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
      if(!neighbor.distance){
      //if distance is 0 then the neighbor returned is invalid
      continue;
      }
      nCell = cellFieldG->get(neighbor.pt);
         if(newCell!=nCell && (newCell!=0 && nCell!=0)){
            newSet.insert(preparePair(nCell,const_cast<CellG*>(newCell)));
         }

         if(oldCell!=nCell && (oldCell!=0 && nCell!=0) ){
            oldSet.insert(preparePair(nCell,const_cast<CellG*>(oldCell)));
         }

//       if (newCell == nCell) newDiff--;
//       else newDiff++;
//    
//       if (oldCell == nCell) oldDiff++;
//       else oldDiff--;
   }

   pair<CellG*,CellG*> lastPair;
   lastPair=preparePair(0,0);
   int diff=0;
   short commonSufraceContactArea;
   float percentageSurfaceLoss;
    
   for (multiset<std::pair<CellG*,CellG*> >::iterator sitr=oldSet.begin() ; sitr!= oldSet.end() ; ++sitr){
      if(lastPair!=*sitr){
         lastPair=*sitr;
         //here I am penalizing for lost cell-cell contact
         diff=newSet.count(*sitr)-oldSet.count(*sitr);

         

//          cerr<<"diff="<<diff<<endl;
//          if(diff==-4 || diff==4){
//             cerr<<"sitr="<<sitr->first<<" , "<<sitr->second<<endl;
//             cerr<<" newSet.count(*sitr)="<<newSet.count(*sitr)<<" oldSet.count(*sitr)="<<oldSet.count(*sitr)<<endl;
//             cerr<<"oldCell="<<oldCell<<" newCell="<<newCell<<endl;
//             for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
//                neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
//                if(!neighbor.distance){
//                //if distance is 0 then the neighbor returned is invalid
//                continue;
//                }
//                nCell = cellFieldG->get(neighbor.pt);
//                cerr<<"nCell="<<nCell<<endl;         
//             }
// 
// 
// 
//          }
         if(diff<0){

            nsdSetPtr=&(neighborTrackerAccessorPtr->get(sitr->first->extraAttribPtr)->cellNeighbors);
            nsdSitr=nsdSetPtr->find(NeighborSurfaceData(sitr->second));
            if(nsdSitr != nsdSetPtr->end()){
               commonSufraceContactArea=nsdSitr->commonSurfaceArea;
               percentageSurfaceLoss=-diff/float(commonSufraceContactArea);
//                cerr<<"commonSufraceContactArea="<<commonSufraceContactArea<<" percentageSurfaceLoss="<<percentageSurfaceLoss<<endl;
//                if(percentageSurfaceLoss>0.95){
//                   cerr<<"LOSING CONTACT"<<endl;
//                   cerr<<"commonSufraceContactArea="<<commonSufraceContactArea<<" percentageSurfaceLoss="<<percentageSurfaceLoss<<endl;

//                }
            }else{
               cerr<<" THIS IS THE ERROR: COULD NOT FIND REQUESTED NEIGHBOR"<<endl;
               exit(0);
            }            
            if (percentageSurfaceLoss>=percentageLossThreshold){
               energy+=defaultPenalty;
//                cerr<<"Energy="<<energy<<endl;
            }else{
               energy+=exp(-percentageSurfaceLoss)*lambdaRearrangement;
            }
//             energy+=-diff*lambdaRearrangement;
         }
      }
   }
  
//   cerr<<"energy="<<energy<<endl;
  if(newCell){
//       energy+=newCell->surface/(float)newCell->volume*fRearrangement;
//       cerr<<"newCell->surface/newCell->volume*fRearrangement="<<newCell->surface/(float)newCell->volume*fRearrangement<<endl;
  }
  if(oldCell){
//       energy+=oldCell->surface/(float)oldCell->volume*fRearrangement;
//       cerr<<"oldCell->surface/oldCell->volume*fRearrangement="<<oldCell->surface/(float)oldCell->volume*fRearrangement<<endl;
  }

  return energy;

}


void RearrangementEnergy::readXML(XMLPullParser &in) {
  in.skip(TEXT);

  while (in.check(START_ELEMENT)) {
    if (in.getName() == "FRearrangement") {
      rpd.fRearrangement = BasicString::parseDouble(in.matchSimple());

    } else if (in.getName() == "LambdaRearrangement") {
      rpd.lambdaRearrangement = BasicString::parseDouble(in.matchSimple());

    }else if (in.getName() == "PercentageLossThreshold") {
      rpd.percentageLossThreshold = BasicString::parseDouble(in.matchSimple());

    }else if (in.getName() == "DefaultPenalty") {
      rpd.defaultPenalty = BasicString::parseDouble(in.matchSimple());
    }
    else {
      throw BasicException(string("Unexpected element '") + in.getName() + 
			   "'!", in.getLocation());
    }

    in.skip(TEXT);
  }  
}

void RearrangementEnergy::writeXML(XMLSerializer &out) {
}

std::string RearrangementEnergy::toString(){
   return string("RearrangementEnergy");
}

std::string RearrangementEnergy::steerableName(){
   return rpd.moduleName;
}
