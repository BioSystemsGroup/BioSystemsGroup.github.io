/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
// #include <CompuCell3D/Potts3D/TypeTransition.h>
#include <CompuCell3D/Potts3D/CellInventory.h>
#include <CompuCell3D/Automaton/Automaton.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>
#include <CompuCell3D/plugins/NeighborTracker/NeighborTrackerPlugin.h>
#include <algorithm>
#include <set>

using namespace std;

#define EXP_STL
#include "ContactLocalFlexPlugin.h"

#include "ContactLocalFlexEnergy.h"



ContactLocalFlexPlugin::ContactLocalFlexPlugin()  {
   initializadContactData=false;
}

ContactLocalFlexPlugin::~ContactLocalFlexPlugin() {
  
}

void ContactLocalFlexPlugin::init(Simulator *simulator, ParseData *_pd) {
  pd=_pd;
  sim=simulator;
  potts=simulator->getPotts();
  contactEnergy.setPotts(potts);
  contactEnergy.setContactDataContainerAccessorPtr(&contactDataContainerAccessor);
  contactEnergy.initializeContactEnergy(pd);
  
  
  potts->getCellFactoryGroupPtr()->registerClass(&contactDataContainerAccessor);
  potts->registerEnergyFunction(&contactEnergy);
  
   bool pluginAlreadyRegisteredFlag;
   Plugin *plugin=Simulator::pluginManager.get("NeighborTracker",&pluginAlreadyRegisteredFlag); //this will load SurfaceTracker plugin if it is not already loaded
  if(!pluginAlreadyRegisteredFlag)
      plugin->init(sim);

  potts->registerCellGChangeWatcher(this);
//   potts->getTypeTransition()->registerTypeChangeWatcher(this);

  simulator->registerSteerableObject(this);
}

// void ContactLocalFlexPlugin::typeChange(CellG* _cell,CellG::CellType_t _newType){
//    cerr<<"typeChange"<<endl;
//    if(_cell){
//       set<ContactLocalFlexData> & clfdSet=contactDataContainerAccessor.get(_cell->extraAttribPtr)->contactDataContainer;
//       clfdSet.clear();
//       updateContactEnergyData(_cell);      
//    }
// 
// }
//this function is called once per simulation after cells have been assigned types (some initializers postpone type initialization)
void ContactLocalFlexPlugin::initializeContactLocalFlexData(){

   CellInventory * cellInventoryPtr=&potts->getCellInventory();
   CellInventory::cellInventoryIterator cInvItr;
   CellG * cell;
   for(cInvItr=cellInventoryPtr->cellInventoryBegin() ; cInvItr !=cellInventoryPtr->cellInventoryEnd() ;++cInvItr ){
      cell=*cInvItr;
      ContactLocalFlexDataContainer *dataContainer = contactDataContainerAccessor.get(cell->extraAttribPtr);
      dataContainer->localDefaultContactEnergies = contactEnergy.getContactEnergyArray();
   }
   


   for(cInvItr=cellInventoryPtr->cellInventoryBegin() ; cInvItr !=cellInventoryPtr->cellInventoryEnd() ;++cInvItr ){
        cell=*cInvItr;
        set<ContactLocalFlexData> & clfdSet=contactDataContainerAccessor.get(cell->extraAttribPtr)->contactDataContainer;
        clfdSet.clear();
        updateContactEnergyData(cell);
   }


}

void ContactLocalFlexPlugin::updateContactEnergyData(CellG *_cell){
   //this function syncs neighbor list for _cell and contac data for _cell so that they contain same number of corresponding 
   //entries

   NeighborTrackerPlugin *neighborTrackerPlugin=(NeighborTrackerPlugin *)Simulator::pluginManager.get("NeighborTracker");
   BasicClassAccessor<NeighborTracker> *neighborTrackerAccessorPtr = neighborTrackerPlugin->getNeighborTrackerAccessorPtr();
   unsigned int size1=0, size2=0;   
//neighborTrackerAccessor.get(newCell->extraAttribPtr)->cellNeighbors


      set<ContactLocalFlexData> & clfdSet=contactDataContainerAccessor.get(_cell->extraAttribPtr)->contactDataContainer;
      set<NeighborSurfaceData> & nsdSet = neighborTrackerAccessorPtr->get(_cell->extraAttribPtr)->cellNeighbors;

      size1=clfdSet.size();
      size2=nsdSet.size();
      

     //if sizes of sets are different then we add any new neighbors from nsdSet and remove those neighbors from clfdSet
     //that do not show up in nsdSet anymore
     //This way we avoid all sorts of problems associated with various configuration of neighbors after spin flip.
     // Although it is not the fastest algorithm , it is very simple and self explanatory and given the fact that in most
     // cases number of neighbors is fairly small all those inefficiencies do not matter too much.

//     if(size1!=size2){
//          clfdSet.clear();
         ContactLocalFlexData clfdObj;
         NeighborSurfaceData nfdObj;
         set<NeighborSurfaceData>::iterator sitrND;
         set<ContactLocalFlexData>::iterator sitrCD;

         //here we insert neighbors from nsdSet into clfdSet that do not show up in clfdSet
         for(sitrND=nsdSet.begin() ; sitrND!=nsdSet.end() ; ++sitrND){
            clfdObj.neighborAddress=sitrND->neighborAddress;
            clfdObj.J=contactEnergy.defaultContactEnergy(clfdObj.neighborAddress,_cell);
//             cerr<<"INSERTING _cell->type="<<(_cell? (int)_cell->type:0)<<" neighbor->type="<<(clfdObj.neighborAddress? (int)clfdObj.neighborAddress->type:0)<<" energy="<<clfdObj.J<<endl;

            clfdSet.insert(clfdObj); //the element will be inserted only if it is not there
         }

          //here we remove neighbors from clfd if they do not show up in nsdSet
         for(sitrCD=clfdSet.begin() ; sitrCD!=clfdSet.end() ; ){ //notice that incrementing takes place in the loop because we are erasing elements
            nfdObj.neighborAddress=sitrCD->neighborAddress;
            sitrND=nsdSet.find(nfdObj);
            if(sitrND==nsdSet.end()){ //did not find nfdObj.neighborAddress in nsdSet  - need to remove it from clfdSet 
               clfdSet.erase(sitrCD++);
            }else{
               ++sitrCD;
            }
         }
     //}

   

//    if(clfdSet.size()!=nsdSet.size()){
//       cerr<<"problem with syncing neighbors and contact energies"<<endl;
//       exit(0);
//    }
}

void ContactLocalFlexPlugin::field3DChange(const Point3D &pt, CellG *newCell,CellG *oldCell){
   if(!initializadContactData && sim->getStep()==0){
      initializeContactLocalFlexData();
      initializadContactData=true;
   }

//    cerr<<"INSIDE field3DChange"<<endl
   if(newCell){
      updateContactEnergyData(newCell);
   }
   if(oldCell){
      updateContactEnergyData(oldCell);
   }
}


void ContactLocalFlexPlugin::readXML(XMLPullParser &in) {
  pd=&contactEnergy.clfpd;
  contactEnergy.readXML(in);
}

void ContactLocalFlexPlugin::writeXML(XMLSerializer &out) {
  
  contactEnergy.writeXML(out);
}



//      if(size1!=size2){
//          if(size1>size2){
//             //this means we will be removing entries from set in ContactLocalFlexDataContainer
//             set<NeighborSurfaceData>::iterator sitrND=nsdSet.begin();
// 
//             for(set<ContactLocalFlexData>::iterator sitrCD=clfdSet.begin() ; sitrCD!= clfdSet.end() ; ++sitrCD ){
//                if(size2==0 || sitrCD->neighborAddress!=sitrND->neighborAddress){
// //                   bool doDecr=false;
//                   set<ContactLocalFlexData>::iterator tmpItr = sitrCD;
//                   sitrCD++;
// //                   if(tmpItr!=clfdSet.begin()){  
// //                      doDecr=true;
// //                   }
//                   if(tmpItr->neighborAddress==0){
//                         cerr<<"\n\nREMOVING NULL POINTER FROM CFD \n\n"<<endl;
//                         exit(0);
//                   }
//                   clfdSet.erase(tmpItr);
// //                   if(doDecr)
//                      --sitrCD;
//                   
// 
//                }else{
//                   ++sitrND;
//                }
//             }
//             if(clfdSet.size()!=nsdSet.size()){
//                   cerr<<"problem with syncing neighbors and contact energies: REMOVING SECTION"<<endl;
//                   exit(0);
//                }
//          }else{
//             //this means that we will be inserting into ContactLocalFlexDataContainer
//             cerr<<"print NSD set before update"<<endl;
//             for(set<NeighborSurfaceData>::iterator sitrND=nsdSet.begin() ; sitrND!= nsdSet.end() ; ++sitrND ){
//                cerr<<"ND_addr="<<sitrND->neighborAddress<<endl;
//             }
//             cerr<<"print CD set before update"<<endl;
//             for(set<ContactLocalFlexData>::iterator sitrCD=clfdSet.begin() ; sitrCD!= clfdSet.end() ; ++sitrCD ){
//                cerr<<"CD_addr="<<sitrCD->neighborAddress<<endl;
//             }
// 
//             set<ContactLocalFlexData>::iterator sitrCD=clfdSet.begin();
//             cerr<<"iteration over nsd"<<endl;
//             for(set<NeighborSurfaceData>::iterator sitrND=nsdSet.begin() ; sitrND!= nsdSet.end() ; ++sitrND ){
//                cerr<<"ND="<<sitrND->neighborAddress<<endl;
//                if(sitrCD!=clfdSet.end()){ 
//                   cerr<<"CD="<<sitrCD->neighborAddress<<endl;
//                }
//                if(size1==0 || sitrND->neighborAddress != sitrCD->neighborAddress){
// 
//                   
//                   cerr<<"sitrCD->neighborAddress="<<sitrCD->neighborAddress<<" size1="<<size1<<" size2="<<size2<<endl;
//                   ContactLocalFlexData clfdObj;
//                   clfdObj.neighborAddress=sitrND->neighborAddress;
//                   clfdObj.J=contactEnergy->contactEnergy(clfdObj.neighborAddress,_cell);
//                   cerr<<"before insert size="<<clfdSet.size()<< "inserting sitrND->neighborAddress="<<sitrND->neighborAddress<<endl;
//                   clfdSet.insert(clfdObj);
//                   ++sitrCD;
//                   cerr<<"after insert size="<<clfdSet.size()<<endl;
//                }else{
//                   ++sitrCD;
//                }
// 
//             }
//          }
//       }
//    
//    cerr<<"finished updateContactEnergyData"<<endl;


void ContactLocalFlexPlugin::update(ParseData *_pd, bool _fullInitFlag){
   contactEnergy.update(pd);
}

std::string ContactLocalFlexPlugin::steerableName(){
   return contactEnergy.clfpd.ModuleName();
}
