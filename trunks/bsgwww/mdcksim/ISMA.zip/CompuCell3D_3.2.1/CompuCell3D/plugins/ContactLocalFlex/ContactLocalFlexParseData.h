/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef CONTACTLOCALFLEXPARSEDATA_H
#define CONTACTLOCALFLEXPARSEDATA_H

#include <CompuCell3D/ParseData.h>
#include <CompuCell3D/dllDeclarationSpecifier.h>



namespace CompuCell3D {

  class DECLSPECIFIER ContactLocalFlexEnergyTupple{
      public:
      ContactLocalFlexEnergyTupple():
         type1Name(""),
         type2Name(""),
         energy(0)
         
      {}

      ContactLocalFlexEnergyTupple(std::string _type1Name, std::string _type2Name,double _energy):
         type1Name(_type1Name),
         type2Name(_type2Name),
         energy(_energy)
      {}

      std::string type1Name;
      std::string type2Name;
      double energy;
      
  };

  class DECLSPECIFIER ContactLocalFlexParseData : public ParseData {
      public:
         ContactLocalFlexParseData():
            ParseData("ContactLocalFlex"),
            depth(1.1),
            weightDistance(false),
            depthFlag(false),
            neighborOrder(1)
            {}
         
         double depth;
         bool depthFlag;
         unsigned int neighborOrder;

         std::vector<ContactLocalFlexEnergyTupple> contactLocalFlexEnergyTuppleVec;
         bool weightDistance;
         void Energy(std::string _type1Name, std::string _type2Name,double _energy){
            contactLocalFlexEnergyTuppleVec.push_back(ContactLocalFlexEnergyTupple(_type1Name,_type2Name,_energy));
         }

         ContactLocalFlexEnergyTupple * getContactLocalFlexEnergyTupple(std::string _type1Name, std::string _type2Name){
            for (int i = 0 ; i < contactLocalFlexEnergyTuppleVec.size() ; ++i){
               if(contactLocalFlexEnergyTuppleVec[i].type1Name==_type1Name && contactLocalFlexEnergyTuppleVec[i].type2Name==_type2Name)
                  return &contactLocalFlexEnergyTuppleVec[i];
               else if (contactLocalFlexEnergyTuppleVec[i].type2Name==_type1Name && contactLocalFlexEnergyTuppleVec[i].type1Name==_type2Name)
                  return &contactLocalFlexEnergyTuppleVec[i];
            }
            return 0;
         }


         void Depth(double _depth){
            depthFlag=true;
            depth=_depth;
         }
         void NeighborOrder(unsigned int _neighborOrder=1){
            depthFlag=false;
            if(_neighborOrder>neighborOrder){
               neighborOrder=_neighborOrder;
            }
         }
         void Weight(bool _weightDistance){weightDistance=_weightDistance;}
  };
};
#endif
