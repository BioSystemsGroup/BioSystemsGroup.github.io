/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef CONTACTLOCALFLEXPLUGIN_H
#define CONTACTLOCALFLEXPLUGIN_H






#include <BasicUtils/BasicClassAccessor.h>
#include <BasicUtils/BasicClassGroup.h> //had to include it to avoid problems with template instantiation

#include <CompuCell3D/Potts3D/CellGChangeWatcher.h>
// #include <CompuCell3D/Potts3D/TypeChangeWatcher.h>
#include <CompuCell3D/Plugin.h>
#include "ContactLocalFlexEnergy.h"
#include "ContactLocalFlexData.h"

#include <CompuCell3D/dllDeclarationSpecifier.h>
namespace CompuCell3D {
  
  class Simulator;


  class DECLSPECIFIER ContactLocalFlexPlugin : public Plugin ,public CellGChangeWatcher/* public TypeChangeWatcher*/{
   ContactLocalFlexEnergy contactEnergy;
    BasicClassAccessor<ContactLocalFlexDataContainer> contactDataContainerAccessor;
    Potts3D *potts;
    Simulator *sim;
    void updateContactEnergyData(CellG *_cell);  
    bool initializadContactData;

  public:
    ContactLocalFlexPlugin();
    virtual ~ContactLocalFlexPlugin();
    ContactLocalFlexEnergy * getContactLocalFlexEnergy() { return &contactEnergy; }
    BasicClassAccessor<ContactLocalFlexDataContainer> * getContactDataContainerAccessorPtr(){return & contactDataContainerAccessor;}
   void initializeContactLocalFlexData();
   virtual void field3DChange(const Point3D &pt, CellG *newCell,
                                 CellG *oldCell);
    //TypeChangeWatcher interface
//     virtual void typeChange(CellG* _cell,CellG::CellType_t _newType);
    virtual void init(Simulator *simulator,ParseData *_pd);

    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    // End XMLSerializable interface

    //Steerrable interface
    virtual void update(ParseData *_pd, bool _fullInitFlag=false);
    virtual std::string steerableName();



  };
};
#endif
