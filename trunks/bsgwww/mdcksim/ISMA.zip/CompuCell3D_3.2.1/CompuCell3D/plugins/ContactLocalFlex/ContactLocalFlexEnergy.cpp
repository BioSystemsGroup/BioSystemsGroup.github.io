/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/


#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/Potts3D/Cell.h>
#include <CompuCell3D/Automaton/Automaton.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <CompuCell3D/Potts3D/Cell.h>
#include <CompuCell3D/Boundary/BoundaryStrategy.h>

#include <algorithm>


#include <string>
using namespace std;

#define EXP_STL
#include "ContactLocalFlexEnergy.h"
#include "ContactLocalFlexPlugin.h"


double ContactLocalFlexEnergy::localEnergy(const Point3D &pt) {
  return 0;
}



double ContactLocalFlexEnergy::changeEnergy(const Point3D &pt,
                                  const CellG *newCell,
                                  const CellG *oldCell) {
   //cerr<<"ChangeEnergy"<<endl;
   
   
  double energy = 0;
  Point3D n;
  
  CellG *nCell=0;
  WatchableField3D<CellG *> *fieldG = (WatchableField3D<CellG *> *)potts->getCellFieldG();
  Neighbor neighbor;


   if(weightDistance){
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         nCell = fieldG->get(neighbor.pt);
         if(nCell!=oldCell){
            energy -= contactEnergy(oldCell, nCell) / neighbor.distance;
         }
         if(nCell!=newCell){
            energy += contactEnergy(newCell, nCell) / neighbor.distance;
         }
   
   
      }
//       while (true) {
//          n = fieldG->getNeighbor(pt, token, distance, false);
//          if (distance > depth) break;
// 
//          nCell = fieldG->get(n);
//          if(nCell!=oldCell){
//             energy -= contactEnergy(oldCell, nCell) / distance;
//          }
//          if(nCell!=newCell){
//             energy += contactEnergy(newCell, nCell) / distance;
//          }
//       }
  }else{
         //default behaviour  no energy weighting 
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         
         nCell = fieldG->get(neighbor.pt);
         if(nCell!=oldCell){
            energy -= contactEnergy(oldCell, nCell);
/*            if(pt.x==25 && pt.y==74 && pt.z==0)
            cerr<<"!=oldCell neighbor.pt="<<neighbor.pt<<" contactEnergy(oldCell, nCell)="<<contactEnergy(oldCell, nCell)<<endl;*/
         }
         if(nCell!=newCell){
            energy += contactEnergy(newCell, nCell);
//             if(pt.x==25 && pt.y==74 && pt.z==0)
//             cerr<<"!=newCell neighbor.pt="<<neighbor.pt<<" contactEnergy(oldCell, nCell)="<<contactEnergy(newCell, nCell)<<endl;

//             cerr<<"!=newCell neighbor.pt="<<neighbor.pt<<" energyTmp="<<energy<<endl;
         }
   
   
      }

//       while (true) {
//          n = fieldG->getNeighbor(pt, token, distance, false);
//          if (distance > depth) break;
// 
//          nCell = fieldG->get(n);
//          if(nCell!=oldCell){
//             energy -= contactEnergy(oldCell, nCell);
//          }
//          if(nCell!=newCell){
//             energy += contactEnergy(newCell, nCell);
//          }
//       }

   }

//   cerr<<"energy="<<energy<<endl;
  return energy;
}


double ContactLocalFlexEnergy::contactEnergy(const CellG *cell1, const CellG *cell2) {
   ContactLocalFlexData clfdObj;
   CellG *cell;
   CellG *neighbor;

   if(cell1){
      cell=const_cast<CellG *>(cell1);
      neighbor=const_cast<CellG *>(cell2);
   }else{
      cell=const_cast<CellG *>(cell2);
      neighbor=const_cast<CellG *>(cell1);
   }

   set<ContactLocalFlexData> & clfdSet = contactDataContainerAccessorPtr->get(cell->extraAttribPtr)->contactDataContainer;
   
   
   clfdObj.neighborAddress=neighbor;
 
   set<ContactLocalFlexData>::iterator sitrCD=clfdSet.find(clfdObj);

   if( sitrCD != clfdSet.end() ){
//       cerr<<"\t retrieving cell->type="<<(int)cell->type<<" neighbor->type="<<(neighbor? (int)neighbor->type:0)<<" energy="<<sitrCD->J<<endl;
      return sitrCD->J;
   }else{
//       cerr<<"\t\t default energy="<<defaultContactEnergy(cell1,cell2)<<endl;
      return defaultContactEnergy(cell1,cell2);
   }

}

double ContactLocalFlexEnergy::defaultContactEnergy(const CellG *cell1, const CellG *cell2){
   //implementing only referring to the local defaultContactEnergy
//   CellG *cell;
//   CellG *neighbor;
//   
//   if(cell1){
//      cell=const_cast<CellG *>(cell1);
//      neighbor=const_cast<CellG *>(cell2);
//   }else{
//      cell=const_cast<CellG *>(cell2);
//      neighbor=const_cast<CellG *>(cell1);
//   }
//   ContactLocalFlexDataContainer *cellContainer = contactDataContainerAccessorPtr->get(cell->extraAttribPtr);
//   std::vector< std::vector<double> > *localDefaultContactEnergies = &cellContainer->localDefaultContactEnergies;
//
//   return (*localDefaultContactEnergies)[cell1 ? cell1->type : 0][cell2 ? cell2->type : 0];
   return contactEnergyArray[cell1 ? cell1->type : 0][cell2? cell2->type : 0];
}

void ContactLocalFlexEnergy::setContactEnergy(const string typeName1,
				     const string typeName2,
				     const double energy) {
                    
  char type1 = automaton->getTypeId(typeName1);
  char type2 = automaton->getTypeId(typeName2);
    
  int index = getIndex(type1, type2);

  contactEnergies_t::iterator it = contactEnergies.find(index);
  ASSERT_OR_THROW(string("Contact energy for ") + typeName1 + " " + typeName2 +
		  " already set!", it == contactEnergies.end());

  contactEnergies[index] = energy;
}

int ContactLocalFlexEnergy::getIndex(const int type1, const int type2) const {
  if (type1 < type2) return ((type1 + 1) | ((type2 + 1) << 16));
  else return ((type2 + 1) | ((type1 + 1) << 16));
}


void ContactLocalFlexEnergy::readXML(XMLPullParser &in) {


  in.skip(TEXT);

  while (in.check(START_ELEMENT)) {
    if (in.getName() == "Energy") {

      string type1 = in.getAttribute("Type1").value;
      string type2 = in.getAttribute("Type2").value;

      double energy = BasicString::parseDouble(in.matchSimple());

      ContactLocalFlexEnergyTupple tupple(type1,type2,energy);
      clfpd.contactLocalFlexEnergyTuppleVec.push_back(tupple);
    } 
    else if (in.getName() == "Depth") {
      
      clfpd.depth = BasicString::parseDouble(in.matchSimple());
      
    }else if (in.getName() == "NeighborOrder") {
      clfpd.NeighborOrder( BasicString::parseUInteger(in.matchSimple()));
    }else if (in.getName() == "Weight") {
      
      clfpd.weightDistance=true;
      in.matchSimple();

      
    }
   else {
      throw BasicException(string("Unexpected element '") + in.getName() +
                           "'!", in.getLocation());
    }

    in.skip(TEXT);
  }






}


void ContactLocalFlexEnergy::writeXML(XMLSerializer &out) {
}

void ContactLocalFlexEnergy::initializeContactEnergy(ParseData *_pd){
   automaton = potts->getAutomaton();
   set<unsigned char> cellTypesSet;

   clfpdPtr=(ContactLocalFlexParseData*)_pd;

   contactEnergies.clear();


   for ( int i=0 ; i < clfpdPtr->contactLocalFlexEnergyTuppleVec.size() ; ++ i){
     
      setContactEnergy(clfpdPtr->contactLocalFlexEnergyTuppleVec[i].type1Name, clfpdPtr->contactLocalFlexEnergyTuppleVec[i].type2Name, clfpdPtr->contactLocalFlexEnergyTuppleVec[i].energy);

      //inserting all the types to the set (duplicate are automatically eleminated) to figure out max value of type Id
      cellTypesSet.insert(automaton->getTypeId(clfpdPtr->contactLocalFlexEnergyTuppleVec[i].type1Name));
      cellTypesSet.insert(automaton->getTypeId(clfpdPtr->contactLocalFlexEnergyTuppleVec[i].type2Name));
   }



  //Now that we know all the types used in the simulation we will find size of the contactEnergyArray
  vector<unsigned char> cellTypesVector(cellTypesSet.begin(),cellTypesSet.end());//coping set to the vector

  int size= * max_element(cellTypesVector.begin(),cellTypesVector.end());
  size+=1;//if max element is e.g. 5 then size has to be 6 for an array to be properly allocated
  
  int index ;

  contactEnergyArray.clear();
  contactEnergyArray.assign(size,vector<double>(size,0.0));

  for(int i = 0 ; i < size ; ++i)
   for(int j = 0 ; j < size ; ++j){
   
      index = getIndex(cellTypesVector[i],cellTypesVector[j]);
      
      contactEnergyArray[i][j] = contactEnergies[index];
      
   }
   cerr<<"size="<<size<<endl;
   
  for(int i = 0 ; i < size ; ++i)
   for(int j = 0 ; j < size ; ++j){
   
      cerr<<"contact["<<i<<"]["<<j<<"]="<<contactEnergyArray[i][j]<<endl;
   }

   boundaryStrategy=BoundaryStrategy::getInstance();
   maxNeighborIndex=0;

   if(clfpdPtr->depthFlag){
      maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromDepth(clfpdPtr->depth);
//       cerr<<"got here will do depth"<<endl;
   }else{
//       cerr<<"got here will do neighbor order"<<endl;
      maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(clfpdPtr->neighborOrder);
   }


}


std::string ContactLocalFlexEnergy::toString(){
  return string("ContactLocalFlex");
}

void ContactLocalFlexEnergy::update(ParseData *_pd, bool _fullInitFlag){
   initializeContactEnergy(_pd);
}

std::string ContactLocalFlexEnergy::steerableName(){
   return clfpd.ModuleName();
}


