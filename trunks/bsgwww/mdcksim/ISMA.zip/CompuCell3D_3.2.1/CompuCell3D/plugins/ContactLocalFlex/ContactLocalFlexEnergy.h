/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef CONTACTLOCALFLEXENERGY_H
#define CONTACTLOCALFLEXENERGY_H

#include <CompuCell3D/Potts3D/EnergyFunction.h>

#include <XMLCereal/XMLSerializable.h>

// #include "ContactLocalFlexPlugin.h"
#include <CompuCell3D/Potts3D/Cell.h>

#include <map>
#include <vector>

#include "ContactLocalFlexParseData.h"
#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {
  class Potts3D;
  class Automaton;
  class ContactLocalFlexDataContainer;
  class BoundaryStrategy;

  class DECLSPECIFIER ContactLocalFlexEnergy : public EnergyFunction, public XMLSerializable {
    Potts3D *potts;

    typedef std::map<int, double> contactEnergies_t;
    typedef std::vector<std::vector<double> > contactEnergyArray_t;
    
    contactEnergies_t contactEnergies;

    contactEnergyArray_t contactEnergyArray;
    
    std::string autoName;
    double depth;

    BasicClassAccessor<ContactLocalFlexDataContainer> * contactDataContainerAccessorPtr;

    Automaton *automaton;
    bool weightDistance;

    unsigned int maxNeighborIndex;
    BoundaryStrategy * boundaryStrategy;

    
    
  public:
    ContactLocalFlexParseData clfpd;
    ContactLocalFlexParseData * clfpdPtr;

    ContactLocalFlexEnergy() :depth(1),weightDistance(false),contactDataContainerAccessorPtr(0),boundaryStrategy(0)
   {}
    
    virtual ~ContactLocalFlexEnergy() {}
    void setContactDataContainerAccessorPtr(BasicClassAccessor<ContactLocalFlexDataContainer> *  _cfdAccessorPtr){
      contactDataContainerAccessorPtr=_cfdAccessorPtr;
    }
   std::vector<std::vector<double> > getContactEnergyArray() { return contactEnergyArray;}
    double defaultContactEnergy(const CellG *cell1, const CellG *cell2);
    virtual double localEnergy(const Point3D &pt);
//      virtual double changeEnergy(const Point3D &pt, const Cell *newCell,
//                                  const Cell *oldCell);

    virtual double changeEnergy(const Point3D &pt, const CellG *newCell,
                                const CellG *oldCell);
    void initializeContactEnergy(ParseData *_pd);
    void setPotts(Potts3D *_potts){potts=_potts;}
    /**
     * @return The contact energy between cell1 and cell2.
     */
    double contactEnergy(const CellG *cell1, const CellG *cell2);

    /**
     * Sets the contact energy for two cell types.  A -1 type is interpreted
     * as the medium.
     */
    void setContactEnergy(const std::string typeName1,
			  const std::string typeName2, const double energy);


    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    virtual std::string toString();
    // End XMLSerializable interface
    //Steerrable interface
    virtual void update(ParseData *_pd, bool _fullInitFlag=false);
    virtual std::string steerableName();



  protected:
    /**
     * @return The index used for ordering contact energies in the map.
     */
    int getIndex(const int type1, const int type2) const;
  };



};
#endif
