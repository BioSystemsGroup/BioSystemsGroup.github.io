#ifndef COMPUCELL3DEXTERNALPOTENTIALENERGY_H
#define COMPUCELL3DEXTERNALPOTENTIALENERGY_H

#include <CompuCell3D/Potts3D/EnergyFunction.h>

#include <CompuCell3D/Potts3D/Cell.h>
#include <Utils/Coordinates3D.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>

#include <XMLCereal/XMLSerializable.h>
#include "ExternalPotentialParseData.h"
#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

/**
@author m
*/

class AdjacentNeighbor;
template <class T> class Field3D;
class Potts3D;

class DECLSPECIFIER ExternalPotentialEnergy:public EnergyFunction , public virtual XMLSerializable {
   Potts3D *potts;
public:
    ExternalPotentialParseData eppd;
    ExternalPotentialParseData * eppdPtr;

    ExternalPotentialEnergy();
   
    virtual ~ExternalPotentialEnergy();

    //setting base ptr to the cellAccessor
    //void setCellAccessorPtr(BasicClassAccessor<CellPtr> * _cellAccessorPtr)
    //{cellAccessorPtr=_cellAccessorPtr;}
    void setAdjacentNeighborPtr(AdjacentNeighbor  * _adjNeighbor_ptr){
      adjNeighbor_ptr=_adjNeighbor_ptr;
    }
    void setCellFieldG(Field3D<CellG *> *_cellFieldG){cellFieldG=(WatchableField3D<CellG *> *)_cellFieldG;}
    void setPotts(Potts3D *_potts){potts=_potts;}
    void initData();
   // Begin EnergyFunction interface
    virtual double localEnergy(const Point3D &pt);    
    virtual double changeEnergy(const Point3D &pt, const CellG *newCell,
            const CellG *oldCell);
   // End EnergyFunction interface
        
    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    // End XMLSerializable interface
    //SteerableObject interface
    virtual void update(ParseData *pd, bool _fullInitFlag=false);
    virtual std::string steerableName();


        
private:
    //BasicClassAccessor<CellPtr>  * cellAccessorPtr;
    Coordinates3D<float> lambdaVec;
    //double lambdaCoefficient;
    AdjacentNeighbor  * adjNeighbor_ptr;
    WatchableField3D<CellG *> *cellFieldG;
    Dim3D fieldDim;
};

};

#endif
