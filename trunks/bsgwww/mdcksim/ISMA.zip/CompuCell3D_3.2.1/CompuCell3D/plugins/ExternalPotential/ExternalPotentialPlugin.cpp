
#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/Field3D/Field3D.h>
using namespace CompuCell3D;
using namespace std;

#define EXP_STL
#include "ExternalPotentialPlugin.h"

namespace CompuCell3D {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ExternalPotentialPlugin::ExternalPotentialPlugin()
 : Plugin()/*, CellGChangeWatcher()*/
{
//   adjNeighbor_ptr=0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ExternalPotentialPlugin::~ExternalPotentialPlugin()
{
//   if(adjNeighbor_ptr) delete adjNeighbor_ptr;
   //adjNeighbor_ptr=0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ExternalPotentialPlugin::init(Simulator *_simulator, ParseData *_pd){
  pd=_pd;
  externalPotentialEnergy.eppdPtr=(ExternalPotentialParseData *)pd;
  externalPotentialEnergy.initData();//will initialzie lambda vector

  potts = _simulator->getPotts();
  
  //cellAccessorPtr=potts->getCellAccessorPtr();
//  potts->registerCellDynamicClassNode(&classNode);

  //volumeEnergy.setClassNode(classNode);
  
//  externalPotentialEnergy.setCellAccessorPtr(potts->getCellAccessorPtr());

  
  potts->registerEnergyFunctionWithName(&externalPotentialEnergy,"ExternalPotential");
  
//   potts->registerCellGChangeWatcher(this);
  //potts->registerStepper(this);

   Dim3D fieldDim=potts->getCellFieldG()->getDim();
   
   
   
  //adjNeighbor_ptr = new AdjacentNeighbor(fieldDim);
  
  //adjNeighbor=AdjacentNeighbor(fieldDim);///THIS causes problems!!!!
  adjNeighbor.initialize(fieldDim);
  if(potts->getBoundaryXName()=="Periodic"){
      adjNeighbor.setPeriodicX();
  }
  if(potts->getBoundaryYName()=="Periodic"){
      adjNeighbor.setPeriodicY();
  }
  if(potts->getBoundaryZName()=="Periodic"){
      adjNeighbor.setPeriodicZ();
  }

  externalPotentialEnergy.setAdjacentNeighborPtr(&adjNeighbor);
  externalPotentialEnergy.setCellFieldG(potts->getCellFieldG());
  externalPotentialEnergy.setPotts(potts);

  _simulator->registerSteerableObject(this);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ExternalPotentialPlugin::extraInit(Simulator *_simulator){
   // check why registering in init gives segfault
//    _simulator->registerSteerableObject(this);
}

void ExternalPotentialPlugin::readXML(XMLPullParser &in){
   pd=&externalPotentialEnergy.eppd;
   externalPotentialEnergy.readXML(in);

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void ExternalPotentialPlugin::update(ParseData *pd, bool _fullInitFlag){
   externalPotentialEnergy.update(pd);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
std::string ExternalPotentialPlugin::steerableName(){
   cerr<<"externalPotentialEnergy.eppd.moduleName="<<externalPotentialEnergy.eppd.moduleName<<endl;
   return externalPotentialEnergy.eppd.moduleName;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



};
