#ifndef COMPUCELL3DLINEARPOTENTIALENERGY_H
#define COMPUCELL3DLINEARPOTENTIALENERGY_H

#include <CompuCell3D/plugins/ExternalPotential/ExternalPotentialEnergy.h>

namespace CompuCell3D {

/**
@author m
*/
class LinearPotentialEnergy : public ExternalPotentialEnergy
{
public:
    LinearPotentialEnergy();
    
    virtual double localEnergy(const Point3D &pt){return 0.0;};
    virtual double changeEnergy(const Point3D &pt, const CellG *newCell,
            const CellG *oldCell){return 0.0;};

            
    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in){};
    virtual void writeXML(XMLSerializer &out){};
    // End XMLSerializable interface


    ~LinearPotentialEnergy();

};

};

#endif
