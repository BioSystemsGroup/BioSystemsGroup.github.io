#ifndef COMPUCELL3DEXTERNALPOTENTIALPLUGIN_H
#define COMPUCELL3DEXTERNALPOTENTIALPLUGIN_H

#include <CompuCell3D/Plugin.h>
#include <CompuCell3D/Potts3D/CellGChangeWatcher.h>
#include <BasicUtils/BasicClassAccessor.h>
#include <CompuCell3D/Potts3D/Cell.h>
#include "ExternalPotentialEnergy.h"
#include <CompuCell3D/Field3D/AdjacentNeighbor.h>
#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

/**
@author m
*/

class Simlator;
class Potts3D;



class DECLSPECIFIER ExternalPotentialPlugin : public Plugin/*, public CellGChangeWatcher*/
{
   public:
      ExternalPotentialPlugin();

      ~ExternalPotentialPlugin();
       virtual void init(Simulator *_simulator, ParseData *_pd);
       virtual void extraInit(Simulator *_simulator);
       // BCGChangeWatcher interface
//       virtual void field3DChange(const Point3D &pt, CellG *newCell,
//                                CellG *oldCell){};

      // Begin XMLSerializable interface
      virtual void readXML(XMLPullParser &in);
      virtual void writeXML(XMLSerializer &out){};
    //SteerableObject interface
    virtual void update(ParseData *pd, bool _fullInitFlag=false);
    virtual std::string steerableName();

   
   private:
      //Simulator *simulator;
      Potts3D *potts;
      ExternalPotentialEnergy  externalPotentialEnergy;
      //AdjacentNeighbor  *adjNeighbor_ptr;
      AdjacentNeighbor  adjNeighbor;
};

};

#endif
