#ifndef EXTERNALPOTENTIALPARSEDATA_H
#define EXTERNALPOTENTIALPARSEDATA_H

#include <CompuCell3D/ParseData.h>
#include <CompuCell3D/dllDeclarationSpecifier.h>
namespace CompuCell3D {



class DECLSPECIFIER ExternalPotentialParseData:public ParseData  {
public:
    ExternalPotentialParseData():ParseData("ExternalPotential"),lX(0.),lY(0.),lZ(0.)
    {}
    double lX,lY,lZ;
    void Lambda(double _lX, double _lY,double _lZ )
    {
      lX=_lX;
      lY=_lY;
      lZ=_lZ;
    }

};

};

#endif
