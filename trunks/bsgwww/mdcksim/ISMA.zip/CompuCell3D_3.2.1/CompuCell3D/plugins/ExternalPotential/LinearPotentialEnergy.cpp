#include "LinearPotentialEnergy.h"

namespace CompuCell3D {

LinearPotentialEnergy::LinearPotentialEnergy()
 : ExternalPotentialEnergy()
{
}


LinearPotentialEnergy::~LinearPotentialEnergy()
{
}


};
