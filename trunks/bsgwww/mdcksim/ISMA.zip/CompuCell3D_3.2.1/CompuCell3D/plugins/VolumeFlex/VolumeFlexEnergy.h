/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR1 PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef VOLUMEFLEXENERGY_H
#define VOLUMEFLEXENERGY_H

#include <CompuCell3D/Potts3D/EnergyFunction.h>

#include <XMLCereal/XMLSerializable.h>
#include <CompuCell3D/Potts3D/Cell.h>
#include <vector>
#include "VolumeFlexParseData.h"
//#include <string>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {
   class Simulator;
   class Potts3D;	
  /** 
   * Calculates volume energy based on a target volume and
   * lambda volume.
   */

   
  class DECLSPECIFIER VolumeFlexEnergy: public EnergyFunction, public virtual XMLSerializable {
       

    std::vector<VolumeEnergyParam> volumeEnergyParamVector;
    std::vector<std::string> typeNameVec;//temporary vector for storage type names
//     Simulator *simulator;
    Potts3D *potts;
  public:
    VolumeFlexParseData vfpd;
    VolumeFlexParseData * vfpdPtr;

    VolumeFlexEnergy():vfpdPtr(0){}

   
   //void setSimulator(Simulator * _simulator){simulator=_simulator;}
   
    virtual double localEnergy(const Point3D &pt);
/*    virtual double changeEnergy(const Point3D &pt, const Cell *newCell,
				const Cell *oldCell);*/
    
    virtual double changeEnergy(const Point3D &pt, const CellG *newCell,
				const CellG *oldCell);

   const std::vector<VolumeEnergyParam> & getVolumeEnergyParamVector()const{return volumeEnergyParamVector;}
    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    virtual std::string toString();
    void setPotts(Potts3D *_potts){potts=_potts;}
    
    // End XMLSerializable interface
    void initTypeId(Potts3D * potts);
    //steerableObject interface
    virtual void update(ParseData *pd, bool _fullInitFlag=false);
    virtual std::string steerableName();
  };
};
#endif
