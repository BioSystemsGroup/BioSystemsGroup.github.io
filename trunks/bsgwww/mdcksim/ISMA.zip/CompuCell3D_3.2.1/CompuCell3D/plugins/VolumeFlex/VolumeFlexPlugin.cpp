/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>


#include <iostream>
using namespace std;

#define EXP_STL
#include "VolumeFlexPlugin.h"

VolumeFlexPlugin::VolumeFlexPlugin() : potts(0){}

VolumeFlexPlugin::~VolumeFlexPlugin() {}

void VolumeFlexPlugin::init(Simulator *simulator, ParseData *_pd) {

  volumeEnergy.vfpdPtr=(VolumeFlexParseData * )_pd;
  potts = simulator->getPotts();
  volumeEnergy.setPotts(potts);
  string energyFunctionName("VolumeFlexEnergy");

   bool pluginAlreadyRegisteredFlag;
   Plugin *plugin=Simulator::pluginManager.get("VolumeTracker",&pluginAlreadyRegisteredFlag); //this will load VolumeTracker plugin if it is not already loaded
  if(!pluginAlreadyRegisteredFlag)
      plugin->init(simulator);
//   potts->registerEnergyFunction(&volumeEnergy);
  
  potts->registerEnergyFunctionWithName(&volumeEnergy,energyFunctionName);

  
  simulator->registerSteerableObject(this);
}

void VolumeFlexPlugin::update(ParseData *_pd, bool _fullInitFlag){
   volumeEnergy.update((VolumeFlexParseData *)_pd);
}


void VolumeFlexPlugin::extraInit(Simulator *simulator){
//    volumeEnergy.initTypeId(potts);
   volumeEnergy.update(volumeEnergy.vfpdPtr);
}

void VolumeFlexPlugin::readXML(XMLPullParser &in) {
  pd=&volumeEnergy.vfpd;
  volumeEnergy.readXML(in);
}

void VolumeFlexPlugin::writeXML(XMLSerializer &out) {
  volumeEnergy.writeXML(out);
}

std::string VolumeFlexPlugin::steerableName(){
   return volumeEnergy.vfpd.ModuleName();
}

