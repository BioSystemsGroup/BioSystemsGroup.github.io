/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/


#include <CompuCell3D/Automaton/Automaton.h>

#include <CompuCell3D/Potts3D/Potts3D.h>

using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <string>
using namespace std;

#define EXP_STL
#include "VolumeFlexEnergy.h"

std::string VolumeFlexEnergy::steerableName(){
   return vfpd.ModuleName();
}

double VolumeFlexEnergy::localEnergy(const Point3D &pt) {
  return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
double VolumeFlexEnergy::changeEnergy(const Point3D &pt,
				  const CellG *newCell,
				  const CellG *oldCell) {

  /// E = lambda * (volume - targetVolume) ^ 2 
  
  
//  cellAccessor->getClass(newCell);
  double energy = 0;

  if (oldCell == newCell) return 0;
    
//   if (newCell)
//     energy += lambdaVolume *
//       (1 + 2 * ((int)newCell->volume - newCell->targetVolume));
// 
//   if (oldCell)
//     energy += lambdaVolume *
//       (1 - 2 * ((int)oldCell->volume - oldCell->targetVolume));

   //as in the original version 
  if (newCell)
    energy += volumeEnergyParamVector[newCell->type].lambdaVolume *
      (1 + 2 * (newCell->volume - fabs(volumeEnergyParamVector[newCell->type].targetVolume)));

  if (oldCell)
    energy += volumeEnergyParamVector[oldCell->type].lambdaVolume  *
      (1 - 2 * (oldCell->volume - fabs(volumeEnergyParamVector[oldCell->type].targetVolume)));

      
  //cout<<"VOLUME CHANGE ENERGY NEW: "<<energy<<endl;
  return energy;
}


void VolumeFlexEnergy::readXML(XMLPullParser &in) {
  in.skip(TEXT);


  string type;
  
  
  double lambda;
  double targetVol;
  //cerr<<"GOT HERE VOL FLEX"<<endl;
  while (in.check(START_ELEMENT)) {
    if (in.getName() == "VolumeEnergyParameters") {
      
     vfpd.volumeEnergyParamVec.push_back(VolumeEnergyParam());
     VolumeEnergyParam &vep=vfpd.volumeEnergyParamVec[vfpd.volumeEnergyParamVec.size()-1];

    vep.typeName = in.getAttribute("CellType").value;
//     typeNameVec.push_back(type);
            
    vep.targetVolume=BasicString::parseDouble(in.getAttribute("TargetVolume").value);
    vep.lambdaVolume= BasicString::parseDouble(in.getAttribute("LambdaVolume").value);

//     volumeEnergyParamVector.push_back(VolumeEnergyParam(targetVol,lambda));
    
    in.matchSimple();

    
    }else {
      throw BasicException(string("Unexpected element '") + in.getName() + 
			   "'!", in.getLocation());
    }

    in.skip(TEXT);
  }

  
}

void VolumeFlexEnergy::writeXML(XMLSerializer &out) {
}


std::string VolumeFlexEnergy::toString(){
   return string("VolumeFlex");
}

void VolumeFlexEnergy::initTypeId(Potts3D * _potts){

/*   cerr<<"GOT HERE INIT TYPE ID"<<endl;
   exit(0);*/
   
   unsigned char maxType(0);
   Automaton * automaton=_potts->getAutomaton();
   vector<unsigned char> typeIdVec(vfpdPtr->volumeEnergyParamVec.size(),0);


   vector<VolumeEnergyParam> vepVec=vfpdPtr->volumeEnergyParamVec;//temporaty storage
/*   cerr<<"GOT HERE INIT TYPE ID"<<endl;
   exit(0)   ;*/
   //translate type name to type id
   for(unsigned int i =0 ; i < vfpdPtr->volumeEnergyParamVec.size() ;++i){
      typeIdVec[i]=automaton->getTypeId(vfpdPtr->volumeEnergyParamVec[i].typeName);
      
      if(typeIdVec[i]>maxType)
         maxType=typeIdVec[i];
  }

   //assigning vector lambda targetVol pairs in such a wav that it will be possible to use e.g.vec[cellType].lambda statements
   // note that some of the vector elements migh be left default initialized
   volumeEnergyParamVector.clear();
   volumeEnergyParamVector.assign(maxType+1,VolumeEnergyParam());
//       cerr<<"volumeEnergyParamVector.size()="<<volumeEnergyParamVector.size()<<endl;
   for(unsigned int i =0 ; i < typeIdVec.size() ;++i){
//       cerr<<"i="<<i<<" "<<" typeIdVec[i]="<<(int)typeIdVec[i]<<endl;
      
      
      volumeEnergyParamVector[typeIdVec[i]]=vepVec[i];
   }

//    exit(0);
}


void VolumeFlexEnergy::update(ParseData *_pd, bool _fullInitFlag){
   vfpdPtr=(VolumeFlexParseData * )_pd;
   initTypeId(potts);
}