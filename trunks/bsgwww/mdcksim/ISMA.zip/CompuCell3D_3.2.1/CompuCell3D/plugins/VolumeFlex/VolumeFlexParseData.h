/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR1 PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef VOLUMEFLEXPARSEDATA_H
#define VOLUMEFLEXPARSEDATA_H


#include <vector>
#include <string>
#include <CompuCell3D/ParseData.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class DECLSPECIFIER VolumeEnergyParam{
      public:
         VolumeEnergyParam():targetVolume(0.),lambdaVolume(0.0){}
         VolumeEnergyParam(double _targetVolume,double _lambdaVolume, std::string _typeName):
                  targetVolume(_targetVolume),lambdaVolume(_lambdaVolume),typeName(_typeName)
         {}
         double targetVolume;
         double lambdaVolume;
         std::string typeName;

   };


   class DECLSPECIFIER VolumeFlexParseData: public ParseData{
      public:
         VolumeFlexParseData():ParseData("VolumeFlex")
         {}
         std::vector<VolumeEnergyParam> volumeEnergyParamVec;
         
         VolumeEnergyParam * VolumeEnergyParameters(std::string _type="", double _targetVol=0.0,double _lambdaVol=0.0){
            volumeEnergyParamVec.push_back(VolumeEnergyParam(_targetVol,_lambdaVol,_type));
            return &volumeEnergyParamVec[volumeEnergyParamVec.size()-1];
         }
         VolumeEnergyParam * getVolumeEnergyParametersByTypeName(std::string _type){
            for (int i = 0 ; i<volumeEnergyParamVec.size() ; ++i){
               if (volumeEnergyParamVec[i].typeName==_type){
                  return &volumeEnergyParamVec[i];
               }
            }
            return 0;
         }

   };
   
};
#endif
