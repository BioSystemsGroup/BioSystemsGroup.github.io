#ifndef NEIGHBORTRACKERPARSEDATA_H
#define NEIGHBORTRACKERPARSEDATA_H



#include <CompuCell3D/ParseData.h>
#include <CompuCell3D/dllDeclarationSpecifier.h>
namespace CompuCell3D {

   class DECLSPECIFIER NeighborTrackerParseData:public ParseData{
      public:
      NeighborTrackerParseData():ParseData("NeighborTracker"),checkFreq(0),checkSanity(false)
      {}
      unsigned int checkFreq;
      bool checkSanity;
      void CheckLatticeSanityFrequency(unsigned int _checkFreq){
         checkFreq=_checkFreq;
         checkSanity=true;
      }

   };
};
#endif
