/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef CONTACTCOMPARTMENTPARSEDATA_H
#define CONTACTCOMPARTMENTPARSEDATA_H

#include <CompuCell3D/ParseData.h>
#include <CompuCell3D/dllDeclarationSpecifier.h>


namespace CompuCell3D {

  class DECLSPECIFIER ContactCompartmentEnergyTupple{
      public:
      ContactCompartmentEnergyTupple():
         type1Name(""),
         type2Name(""),
         energy(0)
         
      {}

      ContactCompartmentEnergyTupple(std::string _type1Name, std::string _type2Name,double _energy):
         type1Name(_type1Name),
         type2Name(_type2Name),
         energy(_energy)
      {}

      std::string type1Name;
      std::string type2Name;
      double energy;
      
  };

  class DECLSPECIFIER ContactCompartmentParseData : public ParseData {
      public:
         ContactCompartmentParseData():
            ParseData("ContactCompartment"),
            depth(1.1),
            depthFlag(false),
            weightDistance(false),
            neighborOrder(1)
            {}
         
         double depth;
         bool depthFlag;

         unsigned int neighborOrder;

         std::vector<ContactCompartmentEnergyTupple> contactEnergyTuppleVec;
         std::vector<ContactCompartmentEnergyTupple> internalContactEnergyTuppleVec;

         bool weightDistance;
         void Energy(std::string _type1Name, std::string _type2Name,double _energy){
            contactEnergyTuppleVec.push_back(ContactCompartmentEnergyTupple(_type1Name,_type2Name,_energy));
         }
         ContactCompartmentEnergyTupple * getContactCompartmentEnergyTupple(std::string _type1Name, std::string _type2Name){
            for (int i = 0 ; i < contactEnergyTuppleVec.size() ; ++i){
               if(contactEnergyTuppleVec[i].type1Name==_type1Name && contactEnergyTuppleVec[i].type2Name==_type2Name)
                  return &contactEnergyTuppleVec[i];
               else if (contactEnergyTuppleVec[i].type2Name==_type1Name && contactEnergyTuppleVec[i].type1Name==_type2Name)
                  return &contactEnergyTuppleVec[i];
            }
            return 0;
         }


         ContactCompartmentEnergyTupple * getInternalContactCompartmentEnergyTupple(std::string _type1Name, std::string _type2Name){
            for (int i = 0 ; i < internalContactEnergyTuppleVec.size() ; ++i){
               if(internalContactEnergyTuppleVec[i].type1Name==_type1Name && internalContactEnergyTuppleVec[i].type2Name==_type2Name)
                  return &internalContactEnergyTuppleVec[i];
               else if (internalContactEnergyTuppleVec[i].type2Name==_type1Name && internalContactEnergyTuppleVec[i].type1Name==_type2Name)
                  return &internalContactEnergyTuppleVec[i];
            }
            return 0;
         }


         void InternalEnergy(std::string _type1Name, std::string _type2Name,double _energy){
            internalContactEnergyTuppleVec.push_back(ContactCompartmentEnergyTupple(_type1Name,_type2Name,_energy));
         }

         void Depth(double _depth){
            depthFlag=true;
            depth=_depth;
         }
         void NeighborOrder(unsigned int _neighborOrder=1){
            depthFlag=false;
            if(_neighborOrder>neighborOrder){
               neighborOrder=_neighborOrder;
            }
         }
         void Weight(bool _weightDistance){weightDistance=_weightDistance;}
  };
};
#endif
