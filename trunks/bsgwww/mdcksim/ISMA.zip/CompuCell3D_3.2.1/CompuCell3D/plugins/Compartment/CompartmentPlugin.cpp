/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/


#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Automaton/Automaton.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#define EXP_STL

#include "CompartmentPlugin.h"

#include "CompartmentEnergy.h"



CompartmentPlugin::CompartmentPlugin() : contactEnergy(0) {
}

CompartmentPlugin::~CompartmentPlugin() {
  if (contactEnergy) delete contactEnergy;
}

void CompartmentPlugin::init(Simulator *simulator,ParseData *_pd) {
  if(!contactEnergy){
      contactEnergy = new ContactCompartmentEnergy();
  }
  
  pd=_pd;
  contactEnergy->ccpdPtr=(ContactCompartmentParseData*)pd;
  contactEnergy->init(simulator);


  simulator->getPotts()->registerEnergyFunctionWithName(contactEnergy,"ContactCompartment");
  simulator->registerSteerableObject(this);

}

void CompartmentPlugin::readXML(XMLPullParser &in) {
  if(!contactEnergy){
      contactEnergy = new ContactCompartmentEnergy();
  }
  pd=&contactEnergy->ccpd;

  ASSERT_OR_THROW("Contact plugin not initialized!", contactEnergy);
  contactEnergy->readXML(in);
}

void CompartmentPlugin::writeXML(XMLSerializer &out) {
  ASSERT_OR_THROW("Contact plugin not initialized!", contactEnergy);
  contactEnergy->writeXML(out);
}

void CompartmentPlugin::update(ParseData *_pd, bool _fullInitFlag){
   contactEnergy->update(_pd);
}

std::string CompartmentPlugin::steerableName(){
   return contactEnergy->ccpd.ModuleName();
}


