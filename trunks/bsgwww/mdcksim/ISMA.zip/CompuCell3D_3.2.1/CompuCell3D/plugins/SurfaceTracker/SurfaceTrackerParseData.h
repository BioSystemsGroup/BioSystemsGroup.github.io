#ifndef SURFACETRACKERPARSEDATA_H
#define SURFACETRACKERPARSEDATA_H



#include <CompuCell3D/ParseData.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class DECLSPECIFIER SurfaceTrackerParseData:public ParseData{
      public:
      SurfaceTrackerParseData():ParseData("SurfaceTracker"),deeperNeighborsRequested(false),higherOrderNeighborsRequested(false),maxNeighborDepth(1.05),maxNeighborOrder(1)

      {}
      bool deeperNeighborsRequested;
      bool higherOrderNeighborsRequested;
      double maxNeighborDepth;
      unsigned int maxNeighborOrder;
      
      void MaxNeighborDepth(double _maxNeighborDepth){
         if(_maxNeighborDepth>maxNeighborDepth){
            maxNeighborDepth=_maxNeighborDepth;
            deeperNeighborsRequested=true;
         }
      }
      void MaxNeighborOrder(unsigned int _maxNeighborOrder){
         if(maxNeighborOrder>1){
            maxNeighborOrder=_maxNeighborOrder;
            higherOrderNeighborsRequested=true;
         }
      }

   };
};
#endif
