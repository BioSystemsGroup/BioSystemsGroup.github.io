/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR1 PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef LENGTHCONSTRAINTPARSEDATA_H
#define LENGTHCONSTRAINTPARSEDATA_H


#include <vector>
#include <string>
#include <CompuCell3D/ParseData.h>
#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class DECLSPECIFIER LengthEnergyParam{
      public:
         LengthEnergyParam():targetLength(0),lambdaLength(0.0){}
         LengthEnergyParam(std::string _cellTypeName,unsigned int _targetLength,float _lambdaLength):
                  cellTypeName(_cellTypeName),targetLength(_targetLength),lambdaLength(_lambdaLength)
         {}
         unsigned int targetLength;
         float lambdaLength;
         std::string cellTypeName;

   };


   class DECLSPECIFIER LengthConstraintParseData: public ParseData{
      public:
         LengthConstraintParseData():ParseData("LengthConstraint")
         {}
         std::vector<LengthEnergyParam> lengthEnergyParamVec;
         LengthEnergyParam * LengthEnergyParameters(std::string _type, unsigned int _targetLength,float _lambdaLength){
            lengthEnergyParamVec.push_back(LengthEnergyParam(_type,_targetLength,_lambdaLength));
            return &lengthEnergyParamVec[lengthEnergyParamVec.size()-1];
         }
         LengthEnergyParam * getLengthEnergyParametersByTypeName(std::string _type){
            for (int i =0 ; i < lengthEnergyParamVec.size() ; ++i){
               if(lengthEnergyParamVec[i].cellTypeName==_type)
                  return &lengthEnergyParamVec[i];
            }
            return 0;
         }
         
   };
   
};
#endif
