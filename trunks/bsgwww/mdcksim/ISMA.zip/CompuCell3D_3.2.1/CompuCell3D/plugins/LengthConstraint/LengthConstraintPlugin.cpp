/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>


#include <iostream>
using namespace std;

#define EXP_STL
#include "LengthConstraintPlugin.h"

LengthConstraintPlugin::LengthConstraintPlugin() : potts(0) {
field3DChangeFcnPtr=0;
}

LengthConstraintPlugin::~LengthConstraintPlugin() {}

void LengthConstraintPlugin::init(Simulator *simulator,ParseData *_pd) {
  pd=_pd;
  lengthConstraintEnergy.lcpdPtr=(LengthConstraintParseData*)pd;
  lengthConstraintEnergy.setLengthConstraintPluginPtr(this);
  
  this->simulator=simulator; 
  potts = simulator->getPotts();  
  lengthConstraintEnergy.init(simulator);

  potts->registerEnergyFunction(&lengthConstraintEnergy);
  potts->registerCellGChangeWatcher(this);
  simulator->registerSteerableObject(this);
  //potts->registerStepper(this);

}

void LengthConstraintPlugin::extraInit(Simulator *simulator){
//    lengthConstraintEnergy.initTypeId(potts);
}


void LengthConstraintPlugin::field3DChange(const Point3D &pt, CellG *newCell,
				 CellG *oldCell) {

    (this->*field3DChangeFcnPtr)(pt,newCell,oldCell);

}


void LengthConstraintPlugin::field3DChange_xz(const Point3D &pt, CellG *newCell,
				 CellG *oldCell) {
    double xcm, ycm, zcm;
    if (newCell)
    {
       // Assumption: COM and Volume has been updated.
        double xcmOld, zcmOld, xcm, zcm;
        if (newCell->volume > 1) {
          xcmOld = (newCell->xCM - pt.x)/ ((float)newCell->volume - 1);
          zcmOld = (newCell->zCM - pt.z)/ ((float)newCell->volume - 1);
        }
        else
        {
            xcmOld = 0;
            zcmOld = 0;
        }
        xcm = (float) newCell->xCM / (float) newCell->volume;
        zcm = (float) newCell->zCM / (float) newCell->volume;
        double xPtSum = newCell->xCM - pt.x;
        double zPtSum = newCell->zCM - pt.z;
        double zPtSumSQ = newCell->iXX - (newCell->volume - 1)*zcmOld*zcmOld + 2*zcmOld*zPtSum + pt.z*pt.z;
        double xPtSumSQ = newCell->iZZ - (newCell->volume - 1)*xcmOld*xcmOld + 2*xcmOld*xPtSum + pt.x*pt.x;
        double xzSum = ((newCell->iXZ - xcmOld*zPtSum - zcmOld*xPtSum + (newCell->volume - 1)*xcmOld*zcmOld) / -1.0) + pt.x*pt.z;
        xPtSum += pt.x;
        zPtSum += pt.z;
        newCell->iXX = zPtSumSQ - 2*zcm*zPtSum + (newCell->volume)*zcm*zcm;
        newCell->iZZ = xPtSumSQ - 2*xcm*xPtSum + (newCell->volume)*xcm*xcm;
        newCell->iXZ = -xzSum + xcm*zPtSum + zcm*xPtSum - (newCell->volume)*xcm*zcm;
    }  
    if (oldCell)
    {
       // Assumption: COM and Volume has been updated.
       double xcmOld = (oldCell->xCM + pt.x) / ((float)oldCell->volume + 1);
       double zcmOld = (oldCell->zCM + pt.z) / ((float)oldCell->volume + 1);
       xcm = (float) oldCell->xCM / (float) oldCell->volume;
       zcm = (float) oldCell->zCM / (float) oldCell->volume;
       double xPtSum = oldCell->xCM + pt.x;
       double zPtSum = oldCell->zCM + pt.z;
       double xPtSumSQ = oldCell->iZZ - (oldCell->volume + 1)*xcmOld*xcmOld + 2*xcmOld*xPtSum - pt.x*pt.x;
       double zPtSumSQ = oldCell->iXX - (oldCell->volume + 1)*zcmOld*zcmOld + 2*zcmOld*zPtSum - pt.z*pt.z;
       double xzSum = ((oldCell->iXZ - xcmOld*zPtSum - zcmOld*xPtSum + (oldCell->volume + 1)*xcmOld*zcmOld) / -1.0) - pt.x*pt.z;
       xPtSum -= pt.x;
       zPtSum -= pt.z;
       oldCell->iXX = zPtSumSQ - 2*zcm*zPtSum + (oldCell->volume)*zcm*zcm;
       oldCell->iZZ = xPtSumSQ - 2*xcm*xPtSum + (oldCell->volume)*xcm*xcm;
       oldCell->iXZ = -xzSum + xcm*zPtSum + zcm*xPtSum - (oldCell->volume)*xcm*zcm;
    }  
}


void LengthConstraintPlugin::field3DChange_xy(const Point3D &pt, CellG *newCell,
				 CellG *oldCell) {
    double xcm, ycm, zcm;
    if (newCell)
    {
       // Assumption: COM and Volume has been updated.
        double xcmOld, ycmOld, xcm, ycm;
        if (newCell->volume > 1) {
          xcmOld = (newCell->xCM - pt.x)/ ((float)newCell->volume - 1);
          ycmOld = (newCell->yCM - pt.y)/ ((float)newCell->volume - 1);
        }
        else
        {
            xcmOld = 0;
            ycmOld = 0;
        }
        xcm = (float) newCell->xCM / (float) newCell->volume;
        ycm = (float) newCell->yCM / (float) newCell->volume;
        double xPtSum = newCell->xCM - pt.x;
        double yPtSum = newCell->yCM - pt.y;
        double yPtSumSQ = newCell->iXX - (newCell->volume - 1)*ycmOld*ycmOld + 2*ycmOld*yPtSum + pt.y*pt.y;
        double xPtSumSQ = newCell->iYY - (newCell->volume - 1)*xcmOld*xcmOld + 2*xcmOld*xPtSum + pt.x*pt.x;
        double xySum = ((newCell->iXY - xcmOld*yPtSum - ycmOld*xPtSum + (newCell->volume - 1)*xcmOld*ycmOld) / -1.0) + pt.x*pt.y;
        xPtSum += pt.x;
        yPtSum += pt.y;
        newCell->iXX = yPtSumSQ - 2*ycm*yPtSum + (newCell->volume)*ycm*ycm;
        newCell->iYY = xPtSumSQ - 2*xcm*xPtSum + (newCell->volume)*xcm*xcm;
        newCell->iXY = -xySum + xcm*yPtSum + ycm*xPtSum - (newCell->volume)*xcm*ycm;
    }  
    if (oldCell)
    {
       // Assumption: COM and Volume has been updated.
       double xcmOld = (oldCell->xCM + pt.x) / ((float)oldCell->volume + 1);
       double ycmOld = (oldCell->yCM + pt.y) / ((float)oldCell->volume + 1);
       xcm = (float) oldCell->xCM / (float) oldCell->volume;
       ycm = (float) oldCell->yCM / (float) oldCell->volume;
       double xPtSum = oldCell->xCM + pt.x;
       double yPtSum = oldCell->yCM + pt.y;
       double xPtSumSQ = oldCell->iYY - (oldCell->volume + 1)*xcmOld*xcmOld + 2*xcmOld*xPtSum - pt.x*pt.x;
       double yPtSumSQ = oldCell->iXX - (oldCell->volume + 1)*ycmOld*ycmOld + 2*ycmOld*yPtSum - pt.y*pt.y;
       double xySum = ((oldCell->iXY - xcmOld*yPtSum - ycmOld*xPtSum + (oldCell->volume + 1)*xcmOld*ycmOld) / -1.0) - pt.x*pt.y;
       xPtSum -= pt.x;
       yPtSum -= pt.y;
       oldCell->iXX = yPtSumSQ - 2*ycm*yPtSum + (oldCell->volume)*ycm*ycm;
       oldCell->iYY = xPtSumSQ - 2*xcm*xPtSum + (oldCell->volume)*xcm*xcm;
       oldCell->iXY = -xySum + xcm*yPtSum + ycm*xPtSum - (oldCell->volume)*xcm*ycm;
    }  
}


void LengthConstraintPlugin::field3DChange_yz(const Point3D &pt, CellG *newCell,
				 CellG *oldCell) {
    double xcm, ycm, zcm;
    if (newCell)
    {
       // Assumption: COM and Volume has been updated.
        double ycmOld, zcmOld, ycm, zcm;
        if (newCell->volume > 1) {
          ycmOld = (newCell->yCM - pt.y)/ ((float)newCell->volume - 1);
          zcmOld = (newCell->zCM - pt.z)/ ((float)newCell->volume - 1);
        }
        else
        {
            ycmOld = 0;
            zcmOld = 0;
        }
        ycm = (float) newCell->yCM / (float) newCell->volume;
        zcm = (float) newCell->zCM / (float) newCell->volume;
        double yPtSum = newCell->yCM - pt.y;
        double zPtSum = newCell->zCM - pt.z;
        double zPtSumSQ = newCell->iYY - (newCell->volume - 1)*zcmOld*zcmOld + 2*zcmOld*zPtSum + pt.z*pt.z;
        double yPtSumSQ = newCell->iZZ - (newCell->volume - 1)*ycmOld*ycmOld + 2*ycmOld*yPtSum + pt.y*pt.y;
        double yzSum = ((newCell->iYZ - ycmOld*zPtSum - zcmOld*yPtSum + (newCell->volume - 1)*ycmOld*zcmOld) / -1.0) + pt.y*pt.z;
        yPtSum += pt.y;
        zPtSum += pt.z;
        newCell->iYY = zPtSumSQ - 2*zcm*zPtSum + (newCell->volume)*zcm*zcm;
        newCell->iZZ = yPtSumSQ - 2*ycm*yPtSum + (newCell->volume)*ycm*ycm;
        newCell->iYZ = -yzSum + ycm*zPtSum + zcm*yPtSum - (newCell->volume)*ycm*zcm;
    }  
    if (oldCell)
    {
       // Assumption: COM and Volume has been updated.
       double ycmOld = (oldCell->yCM + pt.y) / ((float)oldCell->volume + 1);
       double zcmOld = (oldCell->zCM + pt.z) / ((float)oldCell->volume + 1);
       ycm = (float) oldCell->yCM / (float) oldCell->volume;
       zcm = (float) oldCell->zCM / (float) oldCell->volume;
       double yPtSum = oldCell->yCM + pt.y;
       double zPtSum = oldCell->zCM + pt.z;
       double yPtSumSQ = oldCell->iZZ - (oldCell->volume + 1)*ycmOld*ycmOld + 2*ycmOld*yPtSum - pt.y*pt.y;
       double zPtSumSQ = oldCell->iYY - (oldCell->volume + 1)*zcmOld*zcmOld + 2*zcmOld*zPtSum - pt.z*pt.z;
       double yzSum = ((oldCell->iYZ - ycmOld*zPtSum - zcmOld*yPtSum + (oldCell->volume + 1)*ycmOld*zcmOld) / -1.0) - pt.y*pt.z;
       yPtSum -= pt.y;
       zPtSum -= pt.z;
       oldCell->iYY = zPtSumSQ - 2*zcm*zPtSum + (oldCell->volume)*zcm*zcm;
       oldCell->iZZ = yPtSumSQ - 2*ycm*yPtSum + (oldCell->volume)*ycm*ycm;
       oldCell->iYZ = -yzSum + ycm*zPtSum + zcm*yPtSum - (oldCell->volume)*ycm*zcm;
    }  
}


/*
void LengthConstraintPlugin::step() {
   
}*/

void LengthConstraintPlugin::readXML(XMLPullParser &in) {
  pd=&lengthConstraintEnergy.lcpd;
  lengthConstraintEnergy.readXML(in);
}

void LengthConstraintPlugin::writeXML(XMLSerializer &out) {
  lengthConstraintEnergy.writeXML(out);
}

void LengthConstraintPlugin::update(ParseData *pd, bool _fullInitFlag){
   lengthConstraintEnergy.update(pd);
}

std::string LengthConstraintPlugin::steerableName(){

   return lengthConstraintEnergy.lcpd.ModuleName();

}

