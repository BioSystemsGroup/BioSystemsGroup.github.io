#ifndef CENTEROFMASSTRACKERPARSEDATA_H
#define CENTEROFMASSTRACKERPARSEDATA_H

#include <CompuCell3D/dllDeclarationSpecifier.h>

#include <CompuCell3D/ParseData.h>

namespace CompuCell3D {

   class DECLSPECIFIER CenterOfMassTrackerParseData:public ParseData{
      public:
      CenterOfMassTrackerParseData():ParseData("CenterOfMass")
      {}
   };
};
#endif
