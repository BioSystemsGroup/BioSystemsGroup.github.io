/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#include "CenterOfMassTypeRenderer.h"

#include "CenterOfMassPlugin.h"

#include <CompuCell3D/Automaton/Automaton.h>// I am importing Automaton.h with defined(not only declared) virtual function . It causes problems

#include <CompuCell3D/Simulator.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <math.h>

#include <string>
using namespace std;


void CenterOfMassTypeRenderer::init(Simulator *simulator) {
  centerOfMassPlugin =
    (CenterOfMassPlugin *)simulator->pluginManager.get("CenterOfMass");

    automaton = simulator->getPotts()->getAutomaton();
  FieldRenderer::init(simulator);
  
}


VizProperties CenterOfMassTypeRenderer::get(const Point3D &pt) const {
/// WILL HAVE TO WORK ON THIS ONE
//   Cell *cell = cellField->get(pt);
// 
//   if (cell) {
//     // Check for center
//     if (pt == centerOfMassPlugin->getCenterOfMass(cell))
//       return center;
//     
//     // Check for surface
//     unsigned int token = 0;
//     double distance;
//     Point3D n;
//     while (true) {
//       n = cellField->getNeighbor(pt, token, distance, false);
//       if (distance > 1) break;
//       if (cellField->get(n) != cell) {
//         char iType = automaton->getCellType(cell);
//         return surfaces.find(iType)->second; // f&*#ing STL
//       }
//     }
//   }
  //cerr<<"CenterOfMassTypeRenderer"<<endl;

   CellG *cell = cellFieldG->get(pt);
   if(!cell)
      return medium;
      
   char iType = automaton->getCellType(cell);
   return surfaces.find(iType)->second; // f&*#ing STL
   
   
}

 void CenterOfMassTypeRenderer::readXML(XMLPullParser &in) {
 in.skip(TEXT);

  while (in.check(START_ELEMENT)) {
    if (in.getName() == "Medium") {
      in.next();
      medium.readXML(in);
      in.match(END_ELEMENT);

    } else if (in.getName() == "Center") {
      in.next();
      center.readXML(in);
      in.match(END_ELEMENT);

    } else if (in.getName() == "Surface") {
      char iType = 0;

      try {
        string type = in.getAttribute("Type").value;
        if(automaton != NULL) {
          iType = automaton->getTypeId(type);
        } else {
          cout << "CenterOfMassTypeRenderer: Ignoring surface Type " << type <<  endl;
        }
      } catch(BasicException e) {
        // It's OK to not have a type
      }
      
      VizProperties surface;

      in.next();
      surface.readXML(in);
      in.match(END_ELEMENT);
      
      surfaces[iType] = surface;
    } else {
      throw BasicException(string("Unexpected element '") + in.getName() +
                           "'!", in.getLocation());
    }

    in.skip(TEXT);
  }
 }

void CenterOfMassTypeRenderer::writeXML(XMLSerializer &out) {
}
