/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/






#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Automaton/Automaton.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include "ConnectivityLocalFlexPlugin.h"

#define EXP_STL
#include "ConnectivityLocalFlexEnergy.h"

ConnectivityLocalFlexPlugin::ConnectivityLocalFlexPlugin() : connectivityLocalFlexEnergy(0) {
}

ConnectivityLocalFlexPlugin::~ConnectivityLocalFlexPlugin() {
  if (connectivityLocalFlexEnergy) delete connectivityLocalFlexEnergy;
}

void ConnectivityLocalFlexPlugin::setConnectivityStrength(CellG * _cell, double _connectivityStrength){
	if(_cell){
		connectivityLocalFlexDataAccessor.get(_cell->extraAttribPtr)->connectivityStrength=_connectivityStrength;
	}
}

void ConnectivityLocalFlexPlugin::init(Simulator *simulator,ParseData * _pd) {
  if(!connectivityLocalFlexEnergy){
      connectivityLocalFlexEnergy = new ConnectivityLocalFlexEnergy();
   }

  pd=_pd;
  connectivityLocalFlexEnergy->clfpdPtr=(ConnectivityLocalFlexParseData *)pd;
  connectivityLocalFlexEnergy->init(simulator);

  connectivityLocalFlexEnergy->setConnectivityLocalFlexDataAccessorPtr(&connectivityLocalFlexDataAccessor);
  simulator->getPotts()->getCellFactoryGroupPtr()->registerClass(&connectivityLocalFlexDataAccessor);
  simulator->getPotts()->registerEnergyFunctionWithName(connectivityLocalFlexEnergy,"ConnectivityLocalFlex");

}

void ConnectivityLocalFlexPlugin::readXML(XMLPullParser &in) {
  if(!connectivityLocalFlexEnergy){
      connectivityLocalFlexEnergy = new ConnectivityLocalFlexEnergy();
   }
  pd=&connectivityLocalFlexEnergy->clfpd;
  ASSERT_OR_THROW("ConnectivityLocalFlex plugin not initialized!", connectivityLocalFlexEnergy);
  connectivityLocalFlexEnergy->readXML(in);
}

void ConnectivityLocalFlexPlugin::writeXML(XMLSerializer &out) {
  ASSERT_OR_THROW("ConnectivityLocalFlex plugin not initialized!", connectivityLocalFlexEnergy);
  connectivityLocalFlexEnergy->writeXML(out);
}
