/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef CONNECTIVITYLOCALFLEXPLUGIN_H
#define CONNECTIVITYLOCALFLEXPLUGIN_H

#include "ConnectivityLocalFlexData.h"



#include <CompuCell3D/Plugin.h>

#include <BasicUtils/BasicClassAccessor.h>
#include <BasicUtils/BasicClassGroup.h> //had to include it to avoid problems with template instantiation
#include <CompuCell3D/dllDeclarationSpecifier.h>


namespace CompuCell3D {
  class ConnectivityLocalFlexEnergy;
  class CellG;

  class DECLSPECIFIER ConnectivityLocalFlexPlugin : public Plugin {
    ConnectivityLocalFlexEnergy *connectivityLocalFlexEnergy;
	BasicClassAccessor<ConnectivityLocalFlexData> connectivityLocalFlexDataAccessor;

  public:
    ConnectivityLocalFlexPlugin();
    virtual ~ConnectivityLocalFlexPlugin();

    virtual void init(Simulator *simulator,ParseData * _pd);

	BasicClassAccessor<ConnectivityLocalFlexData> * getConnectivityLocalFlexDataPtr(){return & connectivityLocalFlexDataAccessor;}
	void setConnectivityStrength(CellG * _cell, double _connectivityStrength);


    // Begin XMLSerializable interface
    virtual void readXML(XMLPullParser &in);
    virtual void writeXML(XMLSerializer &out);
    // End XMLSerializable interface
  };
};
#endif
