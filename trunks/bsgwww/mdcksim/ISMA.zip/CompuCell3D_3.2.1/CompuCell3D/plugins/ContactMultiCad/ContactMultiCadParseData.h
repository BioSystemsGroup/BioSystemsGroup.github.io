/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef CONTACTMULTICADPARSEDATA_H
#define CONTACTMULTICADPARSEDATA_H

#include <CompuCell3D/ParseData.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

  class DECLSPECIFIER ContactMultiCadEnergyTupple{
      public:
      ContactMultiCadEnergyTupple():
         type1Name(""),
         type2Name(""),
         energy(0)
         
      {}

      ContactMultiCadEnergyTupple(std::string _type1Name, std::string _type2Name,double _energy):
         type1Name(_type1Name),
         type2Name(_type2Name),
         energy(_energy)
      {}

      std::string type1Name;
      std::string type2Name;
      double energy;
      
  };


   class DECLSPECIFIER CadherinData{
   public:
      CadherinData(std::string _cad1Name,std::string _cad2Name,float _specificity):
      cad1Name(_cad1Name),cad2Name(_cad2Name),specificity(_specificity)
      {}
      std::string cad1Name,cad2Name;
      float specificity;
   };
   

  class DECLSPECIFIER ContactMultiCadSpecificityCadherin{
      public:
         ContactMultiCadSpecificityCadherin(){}
         
         std::set<std::string> cadherinNameLocalSet;

         std::vector<CadherinData> specificityCadherinTuppleVec;


         CadherinData * Specificity(std::string _cad1,std::string _cad2, double _spec){
            specificityCadherinTuppleVec.push_back(CadherinData(_cad1,_cad2,_spec));
            cadherinNameLocalSet.insert(_cad1);
            cadherinNameLocalSet.insert(_cad2);
            return &specificityCadherinTuppleVec[specificityCadherinTuppleVec.size()-1];
         }

         CadherinData * getSpecificity(std::string _cad1,std::string _cad2){
            for (int i=0 ; i < specificityCadherinTuppleVec.size() ; ++i){
               if(specificityCadherinTuppleVec[i].cad1Name==_cad1 && specificityCadherinTuppleVec[i].cad2Name==_cad2){
                  return & specificityCadherinTuppleVec[i];
               }
               else if (specificityCadherinTuppleVec[i].cad1Name==_cad2 && specificityCadherinTuppleVec[i].cad2Name==_cad1){
                  return & specificityCadherinTuppleVec[i];
               }
            }
            return 0;
         }



   };

  class DECLSPECIFIER ContactMultiCadParseData : public ParseData {
      public:
         ContactMultiCadParseData():
            ParseData("ContactMultiCad"),
            depth(1.1),
            depthFlag(false),
            energyOffset(0.),
            weightDistance(false),
            neighborOrder(1)
            {}
         
         double depth;
         bool depthFlag;
         unsigned int neighborOrder;
         
         std::vector<ContactMultiCadEnergyTupple> contactMultiCadEnergyTuppleVec;
         std::vector<ContactMultiCadSpecificityCadherin> contactMultiCadSpecificityTuppleVecVec;

         double energyOffset;
         bool weightDistance;



         std::string contactFunctionType;
         
         void Energy(std::string _type1Name, std::string _type2Name,double _energy){
            contactMultiCadEnergyTuppleVec.push_back(ContactMultiCadEnergyTupple(_type1Name,_type2Name,_energy));
         }
         

         ContactMultiCadEnergyTupple * getCContactMultiCadEnergyTupple(std::string _type1Name, std::string _type2Name){
            for (int i = 0 ; i < contactMultiCadEnergyTuppleVec.size() ; ++i){
               if(contactMultiCadEnergyTuppleVec[i].type1Name==_type1Name && contactMultiCadEnergyTuppleVec[i].type2Name==_type2Name)
                  return &contactMultiCadEnergyTuppleVec[i];
               else if (contactMultiCadEnergyTuppleVec[i].type2Name==_type1Name && contactMultiCadEnergyTuppleVec[i].type1Name==_type2Name)
                  return &contactMultiCadEnergyTuppleVec[i];
            }
            return 0;
         }



         void Depth(double _depth){
            depthFlag=true;
            depth=_depth;
         }
         void NeighborOrder(unsigned int _neighborOrder=1){
            depthFlag=false;
            if(_neighborOrder>neighborOrder){
               neighborOrder=_neighborOrder;
            }
         }
         void EnergyOffset(double _energyOffset){energyOffset=_energyOffset;}
         void Weight(bool _weightDistance){weightDistance=_weightDistance;}





         ContactMultiCadSpecificityCadherin * SpecificityCadherin(){
            contactMultiCadSpecificityTuppleVecVec.push_back(ContactMultiCadSpecificityCadherin());
            return &contactMultiCadSpecificityTuppleVecVec[contactMultiCadSpecificityTuppleVecVec.size()-1];
         }


         ContactMultiCadSpecificityCadherin * getContactMultiCadSpecificityCadherin(int _index){
            if(_index<0 || _index>contactMultiCadSpecificityTuppleVecVec.size()-1)
               return 0;
            return &contactMultiCadSpecificityTuppleVecVec[_index];
         }


  };
};
#endif
