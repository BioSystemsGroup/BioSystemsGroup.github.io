/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
// #include <CompuCell3D/Potts3D/TypeTransition.h>
#include <CompuCell3D/Potts3D/CellInventory.h>
#include <CompuCell3D/Automaton/Automaton.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>
#include <CompuCell3D/plugins/NeighborTracker/NeighborTrackerPlugin.h>
#include <algorithm>

#define EXP_STL
#include "ContactMultiCadPlugin.h"

#include "ContactMultiCadEnergy.h"


ContactMultiCadPlugin::ContactMultiCadPlugin() : contactEnergy(0) {

}

ContactMultiCadPlugin::~ContactMultiCadPlugin() {
  if (contactEnergy) delete contactEnergy;
}

void ContactMultiCadPlugin::init(Simulator *simulator,ParseData *_pd) {
   sim=simulator;
   potts=simulator->getPotts();

  if(!contactEnergy){
      contactEnergy = new ContactMultiCadEnergy();
  }

  contactEnergy->setPotts(potts);
  contactEnergy->setContactMultiCadDataAccessorPtr(&contactMultiCadDataAccessor);
  contactEnergy->initializeContactEnergy(_pd);
  
  potts->getCellFactoryGroupPtr()->registerClass(&contactMultiCadDataAccessor);
  
  potts->registerEnergyFunctionWithName(contactEnergy,"ContactMultiCad");
  simulator->registerSteerableObject(this);

}




void ContactMultiCadPlugin::readXML(XMLPullParser &in) {


  if(!contactEnergy){
      contactEnergy = new ContactMultiCadEnergy();
  }
  pd=&contactEnergy->cmcpd;
  ASSERT_OR_THROW("ContactMultiCad plugin not initialized!", contactEnergy);
  contactEnergy->readXML(in);
}

void ContactMultiCadPlugin::writeXML(XMLSerializer &out) {
  ASSERT_OR_THROW("ContactMultiCad plugin not initialized!", contactEnergy);
  contactEnergy->writeXML(out);
}

void ContactMultiCadPlugin::update(ParseData *_pd, bool _fullInitFlag){
   contactEnergy->update(_pd);
}
std::string ContactMultiCadPlugin::steerableName(){
   return contactEnergy->cmcpd.ModuleName();
}


