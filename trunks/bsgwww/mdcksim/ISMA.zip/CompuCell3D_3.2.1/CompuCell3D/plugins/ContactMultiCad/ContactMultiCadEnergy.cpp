/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Field3D/Field3D.h>
#include <CompuCell3D/Field3D/WatchableField3D.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
#include <CompuCell3D/Potts3D/Cell.h>
#include <CompuCell3D/Automaton/Automaton.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>

#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>

#include <CompuCell3D/Potts3D/Cell.h>
#include <PublicUtilities/StringUtils.h>
#include <algorithm>


#include <string>
using namespace std;

#define EXP_STL
#include "ContactMultiCadEnergy.h"

ContactMultiCadEnergy::ContactMultiCadEnergy() :
   depth(1),
   weightDistance(false),
   contactMultiCadDataAccessorPtr(0),
   contactEnergyPtr(&ContactMultiCadEnergy::contactEnergyLinear),
   maxNeighborIndex(0),
   boundaryStrategy(0),
   energyOffset(0.0)

{}

ContactMultiCadEnergy::~ContactMultiCadEnergy()
{}

double ContactMultiCadEnergy::localEnergy(const Point3D &pt) {
  return 0;
}



double ContactMultiCadEnergy::changeEnergy(const Point3D &pt,
                                  const CellG *newCell,
                                  const CellG *oldCell) {
   //cerr<<"ChangeEnergy"<<endl;
   
   
  double energy = 0;
  unsigned int token = 0;
  double distance = 0;
//   Point3D n;
  Neighbor neighbor;
  
  CellG *nCell=0;
  WatchableField3D<CellG *> *fieldG = (WatchableField3D<CellG *> *)potts->getCellFieldG();

   if(weightDistance){
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         nCell = fieldG->get(neighbor.pt);

         if(nCell!=oldCell){
            energy -= (this->*contactEnergyPtr)(oldCell, nCell) / distance;
         }
         if(nCell!=newCell){
            energy += (this->*contactEnergyPtr)(newCell, nCell) / distance;
         }
      }
  }else{
   //default behaviour  no energy weighting 
      for(unsigned int nIdx=0 ; nIdx <= maxNeighborIndex ; ++nIdx ){
         neighbor=boundaryStrategy->getNeighborDirect(const_cast<Point3D&>(pt),nIdx);
         if(!neighbor.distance){
         //if distance is 0 then the neighbor returned is invalid
         continue;
         }
         nCell = fieldG->get(neighbor.pt);

         if(nCell!=oldCell){
            energy -= (this->*contactEnergyPtr)(oldCell, nCell);
         }
         if(nCell!=newCell){
            energy += (this->*contactEnergyPtr)(newCell, nCell);
         }
      }

   }

//   cerr<<"energy="<<energy<<endl;
  return energy;
}


double ContactMultiCadEnergy::contactEnergyLinear(const CellG *cell1, const CellG *cell2) {

   CellG *cell;
   CellG *neighbor;

   double energy=0.0;

   if(cell1){
      cell=const_cast<CellG *>(cell1);
      neighbor=const_cast<CellG *>(cell2);
   }else{
      cell=const_cast<CellG *>(cell2);
      neighbor=const_cast<CellG *>(cell1);
   }

   
   //adding "regular" contact energy
   energy=energyOffset+contactEnergy(cell,neighbor); //The minus sign is because we are adding "regular" energy to the energy expresion
                                         //thus when using energyOffset-energy expresion we need to compensate for extra minus sign
//    cerr<<"energy before="<<-energy<<endl;
   if(neighbor){
      
      vector<float> & jVecCell  = contactMultiCadDataAccessorPtr->get(cell->extraAttribPtr)->jVec;
      vector<float> & jVecNeighbor  = contactMultiCadDataAccessorPtr->get(neighbor->extraAttribPtr)->jVec;
//       cerr<<"numberOfCadherins="<<numberOfCadherins<<endl;
      for (int i=0; i<numberOfCadherins ; ++i)
         for (int j=0; j<numberOfCadherins ; ++j){
            
//                cerr<<" jVecCell[i]="<<jVecCell[i]<<" jVecNeighbor[j]"<<jVecNeighbor[j]<<" cadherinSpecificityArray[i][j]="<<cadherinSpecificityArray[i][j]<<endl;
               energy-=jVecCell[i]*jVecNeighbor[j]*cadherinSpecificityArray[i][j];
            
         }
//       cerr<<"energy after="<<energyOffset-energy<<endl;
      return energy;

   }else{
//          cerr<<"energy after contact with medium="<<-energy<<endl;
         return energy;

   }

}


double ContactMultiCadEnergy::contactEnergy(const CellG *cell1, const CellG *cell2){
   return contactEnergyArray[cell1 ? cell1->type : 0][cell2? cell2->type : 0];
}

void ContactMultiCadEnergy::setContactEnergy(const string typeName1,
				     const string typeName2,
				     const double energy) {
                    
  char type1 = automaton->getTypeId(typeName1);
  char type2 = automaton->getTypeId(typeName2);
    
  int index = getIndex(type1, type2);

  contactEnergies_t::iterator it = contactEnergies.find(index);
  ASSERT_OR_THROW(string("Contact energy for ") + typeName1 + " " + typeName2 +
		  " already set!", it == contactEnergies.end());

  contactEnergies[index] = energy;
}

int ContactMultiCadEnergy::getIndex(const int type1, const int type2) const {
  if (type1 < type2) return ((type1 + 1) | ((type2 + 1) << 16));
  else return ((type2 + 1) | ((type1 + 1) << 16));
}


void ContactMultiCadEnergy::readXML(XMLPullParser &in) {
  
   in.skip(TEXT);

   
  while (in.check(START_ELEMENT)) {

    if (in.getName() == "Energy") {

      string type1 = in.getAttribute("Type1").value;
      string type2 = in.getAttribute("Type2").value;

      double energy = BasicString::parseDouble(in.matchSimple());

      ContactMultiCadEnergyTupple tupple(type1,type2,energy);
      cmcpd.contactMultiCadEnergyTuppleVec.push_back(tupple);
    } 

    else if (in.getName() == "SpecificityCadherin"){
         ContactMultiCadSpecificityCadherin & cmcsc=*(cmcpd.SpecificityCadherin());

      cerr<<"Inside SpecificityCadherin"<<endl;
      in.match(START_ELEMENT);
      in.skip(TEXT);
      
      
      while (in.check(START_ELEMENT)){
         if(in.getName() == "Specificity"){
            string cad1 = in.getAttribute("Cadherin1").value;
            string cad2 = in.getAttribute("Cadherin2").value;
            double specificity = BasicString::parseDouble(in.matchSimple());
            cerr<<"Specificity cad1="<<cad1<<" cad2="<<cad2<<" specificity="<<specificity<<endl;

            cmcsc.Specificity(cad1,cad2,specificity);
         }

         in.skip(TEXT);
      }
      in.match(END_ELEMENT);

    }

    else if (in.getName() == "Depth") {
      cmcpd.depth = BasicString::parseDouble(in.matchSimple());
      
    }
   else if (in.getName() == "NeighborOrder") {
      cmcpd.NeighborOrder( BasicString::parseUInteger(in.matchSimple()));
    }
   else if (in.getName() == "Weight") {
      cmcpd.weightDistance=true;
      in.matchSimple();
    }
     else if (in.getName() == "EnergyOffset") {
      cmcpd.energyOffset = BasicString::parseDouble(in.matchSimple());
      
    }

    else if (in.getName() == "ContactFunctionType") {
      cmcpd.contactFunctionType=in.matchSimple();
      changeToLower(cmcpd.contactFunctionType);

    }


   else {
      throw BasicException(string("Unexpected element '") + in.getName() +
                           "'!", in.getLocation());
    }

    in.skip(TEXT);
  }



}

void ContactMultiCadEnergy::writeXML(XMLSerializer &out) {
}


void ContactMultiCadEnergy::initializeContactEnergy(ParseData *_pd){

   contactEnergies.clear();
   contactEnergyArray.clear();
   cadherinSpecificityArray.clear();
   mapCadNameToIndex.clear();
   numberOfCadherins=0;

   cmcpdPtr=(ContactMultiCadParseData *)_pd;
   automaton = potts->getAutomaton();
   set<unsigned char> cellTypesSet;


   if(cmcpdPtr->contactFunctionType=="linear"){
       contactEnergyPtr=&ContactMultiCadEnergy::contactEnergyLinear;
   }


   cellTypesSet.clear();
   contactEnergies.clear();

   for ( int i=0 ; i < cmcpdPtr->contactMultiCadEnergyTuppleVec.size() ; ++ i){
     
      setContactEnergy(cmcpdPtr->contactMultiCadEnergyTuppleVec[i].type1Name, cmcpdPtr->contactMultiCadEnergyTuppleVec[i].type2Name, cmcpdPtr->contactMultiCadEnergyTuppleVec[i].energy);

      //inserting all the types to the set (duplicate are automatically eleminated) to figure out max value of type Id
      cellTypesSet.insert(automaton->getTypeId(cmcpdPtr->contactMultiCadEnergyTuppleVec[i].type1Name));
      cellTypesSet.insert(automaton->getTypeId(cmcpdPtr->contactMultiCadEnergyTuppleVec[i].type2Name));
   }


  vector<unsigned char> cellTypesVector(cellTypesSet.begin(),cellTypesSet.end());//coping set to the vector

  int size= * max_element(cellTypesVector.begin(),cellTypesVector.end());
  size+=1;//if max element is e.g. 5 then size has to be 6 for an array to be properly allocated
  
  int index ;
  contactEnergyArray.assign(size,vector<double>(size,0.0));

  for(int i = 0 ; i < size ; ++i)
   for(int j = 0 ; j < size ; ++j){
   
      index = getIndex(cellTypesVector[i],cellTypesVector[j]);
      
      contactEnergyArray[i][j] = contactEnergies[index];
      
   }
   cerr<<"size="<<size<<endl;
   
//   for(int i = 0 ; i < size ; ++i)
//    for(int j = 0 ; j < size ; ++j){
//    
//       cerr<<"contact["<<i<<"]["<<j<<"]="<<contactEnergyArray[i][j]<<endl;
//       
//    }

   //Here I initialize max neighbor index for direct acces to the list of neighbors 
   boundaryStrategy=BoundaryStrategy::getInstance();
   maxNeighborIndex=0;

   if(cmcpdPtr->depthFlag){
      maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromDepth(cmcpdPtr->depth);
//       cerr<<"got here will do depth"<<endl;
   }else{
//       cerr<<"got here will do neighbor order"<<endl;
      maxNeighborIndex=boundaryStrategy->getMaxNeighborIndexFromNeighborOrder(cmcpdPtr->neighborOrder);
   }


   
   unsigned int cadIndex=0;
   cadherinNameSet.clear();
   mapCadNameToIndex.clear();
   cadherinNameOrderedVector.clear();
   
   //copy all set elements to a master set - cadherinNameSet, defined in ContactMultiCadEnergy class
   for(int i =0 ; i < cmcpdPtr->contactMultiCadSpecificityTuppleVecVec.size() ; ++i){
      std::set<std::string> & cadherinNameLocalSetRef=cmcpdPtr->contactMultiCadSpecificityTuppleVecVec[i].cadherinNameLocalSet;
      cadherinNameSet.insert(cadherinNameLocalSetRef.begin(),cadherinNameLocalSetRef.end());
   }
   
   for(set<string>::iterator sitr=cadherinNameSet.begin() ;sitr != cadherinNameSet.end() ; ++sitr){

      mapCadNameToIndex.insert(make_pair(*sitr,cadIndex));
      cadherinNameOrderedVector.push_back(*sitr);
      ++cadIndex;
   }
   
   numberOfCadherins=cadherinNameOrderedVector.size();
   cerr<<"numberOfCadherins="<<numberOfCadherins<<endl;
   //allocate and initialize cadherinSpecificityArray 

   cadherinSpecificityArray.assign(numberOfCadherins,vector<double>(numberOfCadherins,0.));

   map<string,unsigned int>::iterator mitr_i;
   map<string,unsigned int>::iterator mitr_j;

   cadherinDataList.clear();

   for(int i =0 ; i < cmcpdPtr->contactMultiCadSpecificityTuppleVecVec.size() ; ++i){
      std::vector<CadherinData> & cadherinDataVecRef = cmcpdPtr->contactMultiCadSpecificityTuppleVecVec[i].specificityCadherinTuppleVec;

      cadherinDataList.insert(cadherinDataList.end(),cadherinDataVecRef.begin(),cadherinDataVecRef.end());
      
   }





   for (list<CadherinData>::iterator litr=cadherinDataList.begin() ; litr != cadherinDataList.end() ; ++litr){
      mitr_i=mapCadNameToIndex.find(litr->cad1Name);
      mitr_j=mapCadNameToIndex.find(litr->cad2Name);
      
      int i=mitr_i->second;
      int j=mitr_j->second;
      cadherinSpecificityArray[i][j]=litr->specificity;
      cadherinSpecificityArray[j][i]=cadherinSpecificityArray[i][j];
      
   }

  for(int i = 0 ; i < numberOfCadherins ; ++i)
   for(int j = 0 ; j < numberOfCadherins  ; ++j){
      cerr<<"specificity["<<i<<"]["<<j<<"]="<<cadherinSpecificityArray[i][j]<<endl;
   }

}


void ContactMultiCadEnergy::update(ParseData *_pd, bool _fullInitFlag){
   initializeContactEnergy(_pd);
}
std::string ContactMultiCadEnergy::steerableName(){
   return cmcpd.ModuleName();
}


std::string ContactMultiCadEnergy::toString(){
  return string("ContactMultiCad");
}
