/*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/



#include <CompuCell3D/Simulator.h>
#include <CompuCell3D/Potts3D/Potts3D.h>
using namespace CompuCell3D;

#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>


#include <iostream>
#include <string>
using namespace std;

#define EXP_STL
#include "VolumeTrackerPlugin.h"

VolumeTrackerPlugin::VolumeTrackerPlugin() : vtpdPtr(0),potts(0), deadCellG(0) {}

VolumeTrackerPlugin::~VolumeTrackerPlugin() {}

void VolumeTrackerPlugin::init(Simulator *simulator,ParseData *_pd) {

  potts = simulator->getPotts();
  potts->registerCellGChangeWatcher(this);
  potts->registerStepper(this);
  
  
}

std::string VolumeTrackerPlugin::toString(){return vtpd.ModuleName();}

void VolumeTrackerPlugin::field3DChange(const Point3D &pt, CellG *newCell,
				 CellG *oldCell) {

   
   if (newCell){
      newCell->volume++;
//        cerr<<"newCell vol="<<newCell->volume<<endl;
   }
   
   if (oldCell){
      
      if((--oldCell->volume) == 0)
         deadCellG = oldCell;
//        cerr<<"oldCell vol="<<oldCell->volume<<endl;
   }
   
}


void VolumeTrackerPlugin::step() {
   
  if (deadCellG) {
    potts->destroyCellG(deadCellG);
    deadCellG = 0;
  }
}

void VolumeTrackerPlugin::readXML(XMLPullParser &in) {
  pd= &vtpd;
  in.skip(TEXT);
}

void VolumeTrackerPlugin::writeXML(XMLSerializer &out) {
}
