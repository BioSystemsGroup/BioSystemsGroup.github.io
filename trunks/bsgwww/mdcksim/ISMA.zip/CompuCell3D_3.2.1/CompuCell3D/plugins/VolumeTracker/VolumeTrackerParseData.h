#ifndef VOLUMETRACKERPARSEDATA_H
#define VOLUMETRACKERPARSEDATA_H



#include <CompuCell3D/ParseData.h>
#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class DECLSPECIFIER VolumeTrackerParseData:public ParseData{
      public:
      VolumeTrackerParseData():ParseData("VolumeTracker")
      {}
   };
};
#endif
