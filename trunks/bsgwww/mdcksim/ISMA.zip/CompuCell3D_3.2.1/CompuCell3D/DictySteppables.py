import CompuCell
from random import random
from random import randint
from PySteppables import *
import CompuCell
import sys


class DictyTypeInitSteppable(SteppablePy):
   def __init__(self,_simulator,_frequency=100000):
      SteppablePy.__init__(self,_frequency)
      self.simulator=_simulator
      self.inventory=self.simulator.getPotts().getCellInventory()
      self.cellList=CellList(self.inventory)
   def setAutocyclingRegion(self,_xMin,_xMax, _yMin, _yMax):
      self.xMin=_xMin
      self.xMax=_xMax
      self.yMin=_yMin
      self.yMax=_yMax
      
   def start(self):
      for cell in self.cellList:
         xCM=cell.xCM/float(cell.volume)
         yCM=cell.yCM/float(cell.volume)
         if xCM<=self.xMax and self.xMin<=xCM and yCM<=self.yMax and self.yMin<=yCM:
            cell.type=3