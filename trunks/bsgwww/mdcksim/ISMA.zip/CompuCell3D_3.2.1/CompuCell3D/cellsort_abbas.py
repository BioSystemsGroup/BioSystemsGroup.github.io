import sys
from os import environ
import string
sys.path.append(environ["PYTHON_MODULE_PATH"])
   
import CompuCellSetup

sim,simthread = CompuCellSetup.getCoreSimulationObjects()
#Create extra player fields here or add attributes or plugin:



CompuCellSetup.initializeSimulationObjects(sim,simthread)

dim=sim.getPotts().getCellFieldG().getDim()
cSpecificityField=simthread.createFloatFieldPy(dim,"ContSpec") # initializing contactCpecifisity Field - 
                                                                           #this location in the code is important this must be called before
                                                                           #preStartInit or otherwise field list will not be initialized properly


#Add Python steppables here
steppableRegistry=CompuCellSetup.getSteppableRegistry()

from PySteppablesExamples import PressureDumperSteppable
pressDumper=PressureDumperSteppable()
pressDumper.setFileName("PressureStat.txt")
pressDumper.setTargetVolume(50)
steppableRegistry.registerSteppable(pressDumper)


CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)


