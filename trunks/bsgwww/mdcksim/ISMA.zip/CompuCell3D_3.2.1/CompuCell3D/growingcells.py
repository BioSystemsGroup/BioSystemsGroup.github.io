import sys
from os import environ
import string
sys.path.append(environ["PYTHON_MODULE_PATH"])
   
import CompuCellSetup

sim,simthread = CompuCellSetup.getCoreSimulationObjects()
CompuCellSetup.initializeSimulationObjects(sim,simthread)
#Create extra player fields here or add attributes or plugins
from PyPluginsExamples import VolumeEnergyFunction
from PyPluginsExamples import MitosisPy
import CompuCell #notice importing CompuCell to main script has to be done after call to getCoreSimulationObjects()

energyFunctionRegistry=CompuCellSetup.getEnergyFunctionRegistry(sim)

volumeEnergy=VolumeEnergyFunction(energyFunctionRegistry)
volumeEnergy.setParams(2.0,25.0)

energyFunctionRegistry.registerPyEnergyFunction(volumeEnergy)



changeWatcherRegistry=CompuCellSetup.getChangeWatcherRegistry(sim)


stepperRegistry=CompuCellSetup.getStepperRegistry(sim)

mitPy=MitosisPy(changeWatcherRegistry)
changeWatcherRegistry.registerPyChangeWatcher(mitPy)
stepperRegistry.registerPyStepper(mitPy)





#Add Python steppables here
steppableRegistry=CompuCellSetup.getSteppableRegistry()

from PySteppablesExamples import IncrementPluginTargetVolume
incrementPluginTargetVolume=IncrementPluginTargetVolume(sim)
incrementPluginTargetVolume.setVolumePlugin(volumeEnergy)

steppableRegistry.registerSteppable(incrementPluginTargetVolume)

CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)


