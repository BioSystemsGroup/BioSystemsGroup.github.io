from PyPlugins import *

class VolumeEnergyFunctionPlugin(EnergyFunctionPy):
   
   def __init__(self,_energyWrapper):
      EnergyFunctionPy.__init__(self)
      self.energyWrapper=_energyWrapper
      self.vt=0.0
      self.lambda_v=0.0
   def setParams(self,_lambda,_targetVolume):
      self.lambda_v=_lambda;
      self.vt=_targetVolume
   def changeEnergy(self):
      energy=0.0
      if(self.energyWrapper.newCell):
         energy+=self.lambda_v*(1+2*(self.energyWrapper.newCell.volume-self.vt))
      if(self.energyWrapper.oldCell):
         energy+=self.lambda_v*(1-2*(self.energyWrapper.oldCell.volume-self.vt))
      return energy


from PyPluginsExamples import MitosisPyPluginBase
class MitosisPyPlugin(MitosisPyPluginBase):
   def __init__(self , _simulator , _changeWatcherRegistry , _stepperRegistry):
      MitosisPyPluginBase.__init__(self,_simulator,_changeWatcherRegistry, _stepperRegistry)
   def updateAttributes(self):
      self.childCell.targetVolume=self.parentCell.targetVolume
      self.childCell.lambdaVolume=self.parentCell.lambdaVolume

      if self.parentCell.type==1:
         self.childCell.type=2
      else:
         self.childCell.type=1


# from CompuCell import MitosisSimplePlugin
# class MitosisPyPlugin (StepperPy,Field3DChangeWatcherPy):
#    def __init__(self,_changeWatcher):
#       Field3DChangeWatcherPy.__init__(self,_changeWatcher)
#       self.mitosisPlugin=MitosisSimplePlugin()
#       self.doublingVolume=50
#       self.mitosisPlugin.setDoublingVolume(self.doublingVolume)
#       self.mitosisPlugin.turnOn()
#       self.mitosisPlugin.init(self.changeWatcher.sim,self.mitosisPlugin.mpd)
#       self.counter=0
#       self.mitosisFlag=0
# 
#    def setPotts(self,potts):
#       self.mitosisPlugin.setPotts(potts)
# 
#    def field3DChange(self):
#       if self.changeWatcher.newCell and \
#       self.changeWatcher.newCell.volume>self.doublingVolume:
#          print "BIG CELL I WILL DO MITOSIS"
#          self.mitosisPlugin.field3DChange(self.changeWatcher.changePoint, \
#          self.changeWatcher.newCell, \
#          self.changeWatcher.newCell)
#          self.mitosisFlag=1
# 
#    def step(self):
#       if self.mitosisFlag:
#          self.mitosisFlag=self.mitosisPlugin.doMitosis()
#          self.childCell=self.mitosisPlugin.getChildCell()
#          self.parentCell=self.mitosisPlugin.getParentCell()
#          self.updateAttributes()
#          self.mitosisFlag=0
# 
#    def updateAttributes(self):
#       self.childCell.targetVolume=self.parentCell.targetVolume
#       self.childCell.lambdaVolume=self.parentCell.lambdaVolume
#       if self.parentCell.type==1:
#          self.childCell.type=2
#       else:
#          self.childCell.type=1

