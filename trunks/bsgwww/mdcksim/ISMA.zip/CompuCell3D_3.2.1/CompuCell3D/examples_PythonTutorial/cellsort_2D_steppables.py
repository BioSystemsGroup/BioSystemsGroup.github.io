from PySteppables import *
import CompuCell
import sys



class InfoPrinterSteppable(SteppablePy):
   def __init__(self,_simulator,_frequency=10):
      SteppablePy.__init__(self,_frequency)
      self.simulator=_simulator
      self.inventory=self.simulator.getPotts().getCellInventory()
      self.cellList=CellList(self.inventory)
      
   def start(self):
      print "This function is called once before simulation"

   def step(self,mcs):
      print "This function is called every 10 MCS"
      for cell in self.cellList:
         print "CELL ID=",cell.id, " CELL TYPE=",cell.type," volume=",cell.volume



class ExtraAttributeCellsort(SteppablePy):
   def __init__(self,_simulator,_frequency=10):
      SteppablePy.__init__(self,_frequency)
      self.simulator=_simulator
      self.inventory=self.simulator.getPotts().getCellInventory()
      self.cellList=CellList(self.inventory)
      
   def step(self,mcs):
      for cell in self.cellList:
         list_attrib=CompuCell.getPyAttrib(cell)
         print "length=",len(list_attrib)
         list_attrib[0:2]=[cell.id*mcs,cell.id*(mcs-1)]
         print "CELL ID modified=",list_attrib[0],"   ", list_attrib[1]



class TypeSwitcherSteppable(SteppablePy):
   def __init__(self,_simulator,_frequency=100):
      SteppablePy.__init__(self,_frequency)
      self.simulator=_simulator
      self.inventory=self.simulator.getPotts().getCellInventory()
      self.cellList=CellList(self.inventory)
      
   def step(self,mcs):
      for cell in self.cellList:
         if cell.type==1:
            cell.type=2
         elif (cell.type==2):
            cell.type=1
         else:
            print "Unknown type. In cellsort simulation there should only be two types 1 and 2"


class NeighborTrackerPrinterSteppable(SteppablePy):
   def __init__(self,_simulator,_frequency=100):
      SteppablePy.__init__(self,_frequency)
      self.simulator=_simulator
      self.nTrackerPlugin=CompuCell.getNeighborTrackerPlugin()
      
      self.inventory=self.simulator.getPotts().getCellInventory()
      self.cellList=CellList(self.inventory)
   def start(self):pass
         
   def step(self,mcs):
      self.cellList=CellList(self.inventory)
      for cell in self.cellList:
         cellNeighborList=CellNeighborListAuto(self.nTrackerPlugin,cell)
         print "*********NEIGHBORS OF CELL WITH ID ",cell.id," *****************"
         for neighborSurfaceData in cellNeighborList:
            if neighborSurfaceData.neighborAddress:
               print "neighbor.id",neighborSurfaceData.neighborAddress.id," commonSurfaceArea=",neighborSurfaceData.commonSurfaceArea
            else:
               print "Medium commonSurfaceArea=",neighborSurfaceData.commonSurfaceArea



class ConcentrationFieldDumperSteppable(SteppablePy):
   def __init__(self,_simulator,_frequency=1):
      SteppablePy.__init__(self,_frequency)
      self.simulator=_simulator
      self.dim=self.simulator.getPotts().getCellFieldG().getDim()
   
   def setFieldName(self,_fieldName):
      self.fieldName=_fieldName
   
   def step(self,mcs):
      fileName=self.fieldName+"_"+str(mcs)+".dat"
      self.outputField(self.fieldName,fileName)
      
   def outputField(self,_fieldName,_fileName):
      field=CompuCell.getConcentrationField(self.simulator,_fieldName)
      pt=CompuCell.Point3D()
      if field:
         try:
            fileHandle=open(_fileName,"w")
         except IOError:
            print "Could not open file ", _fileName," for writing. Check if you have necessary permissions"

         print "dim.x=",self.dim.x
         for i in xrange(self.dim.x):
            for j in xrange(self.dim.y):
               for k in xrange(self.dim.z):
                  pt.x=i
                  pt.y=j
                  pt.z=k
                  fileHandle.write("%d\t%d\t%d\t%f\n"%(pt.x,pt.y,pt.z,field.get(pt)))

from PlayerPython import *
from math import *

class ExtraFieldVisualizationSteppable(SteppablePy):
   def __init__(self,_simulator,_frequency=10):
      SteppablePy.__init__(self,_frequency)
      self.simulator=_simulator
      self.cellFieldG=self.simulator.getPotts().getCellFieldG()
      self.dim=self.cellFieldG.getDim()
      
   def setScalarField(self,_field):
      self.scalarField=_field
   
   def start(self):pass

   def step(self,mcs):
      for x in xrange(self.dim.x):
         for y in xrange(self.dim.y):
            for z in xrange(self.dim.z):
               pt=CompuCell.Point3D(x,y,z)
               if (not mcs%20):
                  value=x*y
                  fillScalarValue(self.scalarField,x,y,z,value)
               else:
                  value=sin(x*y)
                  fillScalarValue(self.scalarField,x,y,z,value)

class PressureFieldVisualizationSteppable(SteppablePy):
   def __init__(self,_simulator,_frequency=10):
      SteppablePy.__init__(self,_frequency)
      self.simulator=_simulator
      self.cellFieldG=self.simulator.getPotts().getCellFieldG()
      self.dim=self.cellFieldG.getDim()
      
   def setScalarField(self,_field):
      self.scalarField=_field
   
   def start(self):pass

   def step(self,mcs):
      for x in xrange(self.dim.x):
         for y in xrange(self.dim.y):
            for z in xrange(self.dim.z):
               pt=CompuCell.Point3D(x,y,z)
               cell=self.cellFieldG.get(pt)
               if cell:
                  fillScalarValue(self.scalarField,x,y,z, cell.targetVolume-cell.volume)
               else:
                  fillScalarValue(self.scalarField,x,y,z,0)


class VolumeParamSteppable(SteppablePy):
   def __init__(self,_simulator,_frequency=1):
      SteppablePy.__init__(self,_frequency)
      self.simulator=_simulator
      self.inventory=self.simulator.getPotts().getCellInventory()
      self.cellList=CellList(self.inventory)
   def start(self):
      for cell in self.cellList:
         cell.targetVolume=25
         cell.lambdaVolume=2.0
   def step(self,mcs):
      for cell in self.cellList:
         cell.targetVolume+=1

