def configureSimulation(sim):
   import CompuCell
   import CompuCellSetup
   ppd=CompuCell.PottsParseData()
   
   
   ppd.Steps(10000)
   ppd.Anneal(10)
   ppd.Temperature(5)
   ppd.NeighborOrder(2)
   ppd.Dimensions(CompuCell.Dim3D(50,50,1))
   ppd.Boundary_x("Periodic")   
   

   
   
   CompuCell.assignParseDataPtr(ppd,sim.ps.pottsParseData)
   
   ctpd=CompuCell.CellTypeParseData()
   
   ctpd.CellType("Medium",0)
   ctpd.CellType("Body1",1)
   ctpd.CellType("Body2",2)
   ctpd.CellType("Body3",3)
   
   cpd=CompuCell.ContactParseData()
   cpd.Energy("Medium" ,"Medium",0)
   cpd.Energy("Body1" ,"Body1",16)
   cpd.Energy("Body1" ,"Medium",4)
   cpd.Energy("Body2" ,"Body2",16)
   cpd.Energy("Body2" ,"Medium",4)
   cpd.Energy("Body3" ,"Body3",16)
   cpd.Energy("Body3" ,"Medium",4)

   cpd.Energy("Body1" ,"Body2",16)   
   cpd.Energy("Body1" ,"Body3",16)
   cpd.Energy("Body2" ,"Body3",16)   
   cpd.NeighborOrder(2)

   vpd=CompuCell.VolumeParseData()
   vpd.LambdaVolume(2.0)
   vpd.TargetVolume(30.0)


   comtpd=CompuCell.CenterOfMassTrackerParseData()
   lcpd=CompuCell.LengthConstraintParseData()
   lcpd.LengthEnergyParameters("Body1",10,1.0)
   lcpd.LengthEnergyParameters("Body2",10,1.0)
   lcpd.LengthEnergyParameters("Body3",10,1.0)
   
   connectpd=CompuCell.ConnectivityParseData()
   connectpd.Penalty(10000000000)
   
   
   pifpd=CompuCell.PIFInitializerParseData()
   pifpd.PIFName("elongationFlexTest.pif")


   CompuCellSetup.registerPotts(sim,ppd)
   CompuCellSetup.registerPlugin(sim,ctpd)
   CompuCellSetup.registerPlugin(sim,cpd)
   CompuCellSetup.registerPlugin(sim,vpd)
   CompuCellSetup.registerPlugin(sim,comtpd)
   CompuCellSetup.registerPlugin(sim,lcpd)
   CompuCellSetup.registerPlugin(sim,connectpd)
      
   CompuCellSetup.registerSteppable(sim,pifpd)
   
   
import sys
from os import environ
import string
sys.path.append(environ["PYTHON_MODULE_PATH"])
   
import CompuCellSetup

sim,simthread = CompuCellSetup.getCoreSimulationObjects()

configureSimulation(sim)

CompuCellSetup.initializeSimulationObjects(sim,simthread)


from PySteppables import SteppableRegistry
steppableRegistry=SteppableRegistry()

from steering_steppables_examples import LengthConstraintSteering
lcs=LengthConstraintSteering(sim,100)
steppableRegistry.registerSteppable(lcs)

CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)

