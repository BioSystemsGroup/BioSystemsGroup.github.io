 /*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/

#ifndef DICTYPARSEDATA_H
#define DICTYPARSEDATA_H
#include <CompuCell3D/ParseData.h>

#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   class DECLSPECIFIER DictyFieldInitializerParseData:public ParseData{
      public:
         DictyFieldInitializerParseData():ParseData("DictyInitializer"),
         gotAmoebaeFieldBorder(false),presporeRatio(0.5), gap(1),width(2),amoebaeFieldBorder(10)
         {}
      unsigned int gap;
      unsigned int width;
      unsigned int amoebaeFieldBorder;
      bool gotAmoebaeFieldBorder;
      Point3D zonePoint;
      unsigned int zoneWidth;
      double presporeRatio;
      void AmoebaeFieldBorder(unsigned int _amoebaeFieldBorder){
         amoebaeFieldBorder=_amoebaeFieldBorder;
         gotAmoebaeFieldBorder=true;
      }
      void ZonePoint(Point3D _zonePoint,unsigned int _zoneWidth){
         zonePoint=_zonePoint;
         zoneWidth=_zoneWidth;
      }
      void PresporeRatio(double _presporeRatio){presporeRatio=_presporeRatio;}
      void Gap(double _gap){gap=_gap;}
      void Width(double _width){width=_width;}

   };

   class DECLSPECIFIER DictyChemotaxisSteppableParseData:public ParseData{
      public:
         DictyChemotaxisSteppableParseData():ParseData("DictyChemotaxisSteppable"),clockReloadValue(0),chemotactUntil(0),chetmotaxisActivationThreshold(0.0),ignoreFirstSteps(0)
         {}
         unsigned int clockReloadValue;
         unsigned int chemotactUntil;
         float chetmotaxisActivationThreshold;
         unsigned int ignoreFirstSteps;

         std::string chemicalFieldSource;
         std::string chemicalFieldName;

         void ChemicalField(std::string _source, std::string _name){
            chemicalFieldSource=_source;
            chemicalFieldName=_name;
         }
         void ClockReloadValue(unsigned int _clockReloadValue){clockReloadValue=_clockReloadValue;}
         void ChemotactUntil(unsigned int _chemotactUntil){chemotactUntil=_chemotactUntil;}
         void ChetmotaxisActivationThreshold(float _chetmotaxisActivationThreshold)
         {chetmotaxisActivationThreshold=_chetmotaxisActivationThreshold;}
         void IgnoreFirstSteps(unsigned int _ignoreFirstSteps){ignoreFirstSteps=_ignoreFirstSteps;}

   };


};
#endif
