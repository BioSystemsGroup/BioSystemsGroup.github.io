import sys
from os import environ
import string
sys.path.append(environ["PYTHON_MODULE_PATH"])
   
import CompuCellSetup

sim,simthread = CompuCellSetup.getCoreSimulationObjects()
import CompuCell #notice importing CompuCell to main script has to be done after call to getCoreSimulationObjects()

#Create extra player fields here or add attributes or plugin:
#PUT YOUR CODE HERE
#PUT YOUR CODE HERE
#PUT YOUR CODE HERE


CompuCellSetup.initializeSimulationObjects(sim,simthread)


steppableRegistry=CompuCellSetup.getSteppableRegistry()
#Add Python steppables here
#PUT YOUR CODE HERE
#PUT YOUR CODE HERE
#PUT YOUR CODE HERE



CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)#main loop - simulation is invoked inside this function

