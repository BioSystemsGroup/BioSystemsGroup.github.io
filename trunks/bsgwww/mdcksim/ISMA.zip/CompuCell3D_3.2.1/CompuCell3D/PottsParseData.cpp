 /*************************************************************************
 *    CompuCell - A software framework for multimodel simulations of     *
 * biocomplexity problems Copyright (C) 2003 University of Notre Dame,   *
 *                             Indiana                                   *
 *                                                                       *
 * This program is free software; IF YOU AGREE TO CITE USE OF CompuCell  *
 *  IN ALL RELATED RESEARCH PUBLICATIONS according to the terms of the   *
 *  CompuCell GNU General Public License RIDER you can redistribute it   *
 * and/or modify it under the terms of the GNU General Public License as *
 *  published by the Free Software Foundation; either version 2 of the   *
 *         License, or (at your option) any later version.               *
 *                                                                       *
 * This program is distributed in the hope that it will be useful, but   *
 *      WITHOUT ANY WARRANTY; without even the implied warranty of       *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    *
 *             General Public License for more details.                  *
 *                                                                       *
 *  You should have received a copy of the GNU General Public License    *
 *     along with this program; if not, write to the Free Software       *
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.        *
 *************************************************************************/


#include <XMLCereal/XMLPullParser.h>
#include <XMLCereal/XMLSerializer.h>
#include <BasicUtils/BasicString.h>
#include <BasicUtils/BasicException.h>



#define EXP_STL
#include "PottsParseData.h"

using namespace std;
using namespace CompuCell3D;


void EnergyFunctionCalculatorStatisticsParseData::readXML(XMLPullParser &in){

  in.match(START_ELEMENT); 
  in.skip(TEXT);
  
  while (in.check(START_ELEMENT)) {
    if (in.getName() == "OutputFileName") {
      if(in.findAttribute("Frequency")>=0){
         analysisFrequency=BasicString::parseUInteger(in.getAttribute("Frequency").value);
      }
      
      outFileName = in.matchSimple();
  
    } else if (in.getName() == "OutputCoreFileNameSpinFlips") {
      
      if(in.findAttribute("Frequency")>=0){
         singleSpinFrequency=BasicString::parseUInteger(in.getAttribute("Frequency").value);
      }

      if(in.findAttribute("GatherResults")>=0){
         gatherResultsSpinFlip=true;
         
      }

      if(in.findAttribute("OutputAccepted")>=0){
         outputAcceptedSpinFlip=true;
         
      }

      if(in.findAttribute("OutputRejected")>=0){
          outputRejectedSpinFlip=true;
      }

      if(in.findAttribute("OutputTotal")>=0){
         outputTotalSpinFlip=true;
      }

      outFileCoreNameSpinFlips = in.matchSimple();
      outputEverySpinFlip=true;
  
    } else {
      throw BasicException(string("Unexpected element '") + in.getName() + "'!", in.getLocation());
    }

    in.skip(TEXT);
  }  
   in.match(END_ELEMENT,-TEXT);

}


  

