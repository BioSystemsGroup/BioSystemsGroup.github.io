package alc_sim;

import sim.engine.*;
import sim.display.*;
import ec.util.*;
import java.io.*;
import java.util.*;

public class AlsMain {
  
  public static void main (String[] args) {
    
    ExpManager exp_manager = new ExpManager();
    exp_manager.run();
  } // end main()

} // end class Main
