package alc_sim;

import sim.engine.SimState;
import sim.field.grid.ObjectGrid2D;

public class Matrix extends Agent {
  public Matrix(int x, int y,ObjectGrid2D grid) {
    super(x,y,grid);
  } // end Matrix ()
  public void step(SimState state) {
  } // end step()
} // end class Matrix
