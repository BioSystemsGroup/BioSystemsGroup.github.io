package epith_morph_sim;

import java.io.*;
import sim.engine.*;
import sim.field.grid.ObjectGrid2D;
import sim.util.*;
import ec.util.*;

public class Culture extends SimState {
  
  private int step = 0;
  static int[] emb_axiom_usage;
  static int[] sus_axiom_usage;
  static int[] sur_axiom_usage;
  static int[] ove_axiom_usage;
  
  int grid_width = 100;
  int grid_height = 100;
  
  boolean emb_on = true;
  boolean sus_on = false;
  boolean sur_on = false;
  boolean ove_on = false;
  
  double malig_to_norm_ratio = 0.0; // if non-zero then at least one malignant cell is added
  int emb_malignancy_setoff_time = 30; // time step at which malignancy is introduced into embedded culture
  int sus_malignancy_setoff_time = 30; // no malignancy introduced if negative time
  int sur_malignancy_setoff_time = 30;
  int ove_malignancy_setoff_time = 30;
  
  EmbeddedGrid embeddedGrid = new EmbeddedGrid(grid_width, grid_height);
  SuspensionGrid suspensionGrid = new SuspensionGrid(grid_width, grid_height);
  SurfaceGrid surfaceGrid = new SurfaceGrid(grid_width, grid_height);
  OverlayGrid overlayGrid = new OverlayGrid(grid_width, grid_height);

  String outputFileName = "scratch_data"; // Must be initialized to something other than null
  BufferedWriter embFileWriter = null;
  BufferedWriter susFileWriter = null;
  BufferedWriter surFileWriter = null;
  BufferedWriter oveFileWriter = null;
  ParameterDatabase paramDB = null;
  
  /* ================== PARAMETERIZATION FUNCTIONS ======================== */
  public int getGridWidth() { return grid_width; }
  public void setGridWidth(int width) { if(width > 0 && width%2 == 0) grid_width = width; }
  public int getGridHeight() { return grid_height; }
  public void setGridHeight(int height) { if(height > 0 && height%2 == 0) grid_height = height; }
  public double getMalignancyRatio() { return malig_to_norm_ratio; }
  public void setMalignancyRatio(double ratio) { malig_to_norm_ratio = ratio; }

  public boolean getEmbeddedOn() { return emb_on; }
  public void setEmbeddedOn(boolean val) { emb_on = val; }
  public boolean getSuspensionOn() { return sus_on; }
  public void setSuspensionOn(boolean val) { sus_on = val; }
  public boolean getSurfaceOn() { return sur_on; }
  public void setSurfaceOn(boolean val) { sur_on = val; }
  public boolean getOverlayOn() { return ove_on; }
  public void setOverlayOn(boolean val) { ove_on = val; }
  
  public int getEmbMaligSetOffTime() { return emb_malignancy_setoff_time; }
  public void setEmbMaligSetOffTime(int time) { emb_malignancy_setoff_time = time; }
  public int getSusMaligSetOffTime() { return sus_malignancy_setoff_time; }
  public void setSusMaligSetOffTime(int time) { sus_malignancy_setoff_time = time; }
  public int getSurMaligSetOffTime() { return sur_malignancy_setoff_time; }
  public void setSurMaligSetOffTime(int time) { sur_malignancy_setoff_time = time; }
  public int getOveMaligSetOffTime() { return ove_malignancy_setoff_time; }
  public void setOveMaligSetOffTime(int time) { ove_malignancy_setoff_time = time; }
  
  void loadParams() {
    if(paramDB==null)
      return;
    Properties p = Properties.getProperties(this,false,true,false);
    for(int i=0; i< p.numProperties(); i++) {
      if (p.isReadWrite(i) && !p.isComposite(i) && paramDB.exists(new Parameter(p.getName(i)))) {
        Parameter param = new Parameter(p.getName(i));
        String value = paramDB.getString(param,null);
        p.setValue(i,value);
      }
    }
  }
  
  public Culture () {
    super(new MersenneTwisterFast(System.currentTimeMillis()), new Schedule());
  }
  
  public Culture(long seed) {
    super(new MersenneTwisterFast(seed), new Schedule());
  }
  
  public Culture(MersenneTwisterFast random, Schedule schedule) {
    super(random, schedule);
  }
  
  public Culture(MersenneTwisterFast random, Schedule schedule, ParameterDatabase params) {
    super(random, schedule);
    paramDB = params;
  }
  
  public Culture(MersenneTwisterFast random, Schedule schedule, ParameterDatabase params, String path) {
    super(random, schedule);
    paramDB = params;
    outputFileName = path;
  }
  
  public EmbeddedGrid getEmbeddedGrid() {
    return embeddedGrid;
  }
  public SuspensionGrid getSuspensionGrid() {
    return suspensionGrid;
  }
  public SurfaceGrid getSurfaceGrid() {
    return surfaceGrid;
  }
  public OverlayGrid getOverlayGrid() {
    return overlayGrid;
  }
  
  public static void updateAxiomUsage(int culture, int index) {
    if (index < 0 || index >= ExpManager.AXIOM_ARRAY_SIZE) {
      System.out.println("ERROR in Morphogenesis::updateAxiomUsage() index out of bounds: " + index);
      return;
    }
    if (culture == ExpManager.EMBEDDED) {
      emb_axiom_usage[index]++;
    }
    else if (culture == ExpManager.SUSPENSION) {
      sus_axiom_usage[index]++;
    }
    else if (culture == ExpManager.SURFACE) {
      sur_axiom_usage[index]++;
    }
    else if (culture == ExpManager.OVERLAY) {
      ove_axiom_usage[index]++;
    }
    else {
      System.out.println("ERROR in Morphogenesis::updateAxiomUsage() culture out of bounds:" + culture);
    }
  }
  
  public void start() {
    super.start(); // clear out the schedule
    loadParams();
    this.step = 0;
    emb_axiom_usage = new int[ExpManager.AXIOM_ARRAY_SIZE];
    sus_axiom_usage = new int[ExpManager.AXIOM_ARRAY_SIZE];
    sur_axiom_usage = new int[ExpManager.AXIOM_ARRAY_SIZE];
    ove_axiom_usage = new int[ExpManager.AXIOM_ARRAY_SIZE];
    for (int i = 0; i < ExpManager.AXIOM_ARRAY_SIZE; i++) {
      emb_axiom_usage[i] = 0;
      sus_axiom_usage[i] = 0;
      sur_axiom_usage[i] = 0;
      ove_axiom_usage[i] = 0;
    }
    
    if (emb_on) { embeddedGrid = new EmbeddedGrid(grid_width, grid_height); }
    if (sus_on) { suspensionGrid = new SuspensionGrid(grid_width, grid_height); }
    if (sur_on) { surfaceGrid = new SurfaceGrid(grid_width, grid_height); }
    if (ove_on) { overlayGrid = new OverlayGrid(grid_width, grid_height); }

    String embOutput = outputFileName + "_EMB.txt";
    String susOutput = outputFileName + "_SUS.txt";
    String surOutput = outputFileName + "_SUR.txt";
    String oveOutput = outputFileName + "_OVE.txt";
    try {
      if (emb_on) { embFileWriter = new BufferedWriter(new FileWriter(embOutput, false)); }
      if (sus_on) { susFileWriter = new BufferedWriter(new FileWriter(susOutput, false)); }
      if (sur_on) { surFileWriter = new BufferedWriter(new FileWriter(surOutput, false)); }
      if (ove_on) { oveFileWriter = new BufferedWriter(new FileWriter(oveOutput, false)); }
    }
    catch (IOException e) { e.printStackTrace(); }
    
    // To add Morphogenesis steps to the event schedule
    class MorphogenesisStep implements Steppable {
      public void step(SimState state) {
        epith_morph_sim.Culture model = (epith_morph_sim.Culture) state;
        model.step++;
      }
    }
    // schedule.scheduleRepeating(new MorphogenesisStep());
    
    // *** UpdateSeries class ***
    class UpdateSeries implements Steppable {
      int step_count = 0;
      public void step(SimState state) {
        epith_morph_sim.Culture model = (epith_morph_sim.Culture) state;
        int embCellNorm = 0;
        int susCellNorm = 0;
        int surCellNorm = 0;
        int oveCellNorm = 0;
        
        Agent agent = null;
        for (int i = 0; i < model.grid_height; i++) {
          for (int j = 0; j < model.grid_width; j++) {
            // embedded culture
            if (emb_on) {
              agent = (Agent) model.embeddedGrid.get(i, j);
              if (agent instanceof Cell) {
                embCellNorm++;
              }
            }
            // supension culture
            if (sus_on) {
              agent = (Agent) model.suspensionGrid.get(i, j);
              if (agent instanceof Cell) {
                susCellNorm++;
              }
            }
            // surface culture
            if (sur_on) {
              agent = (Agent) model.surfaceGrid.get(i, j);
              if (agent instanceof Cell) {
                surCellNorm++;
              }
            }
            // overlay culture
            if (ove_on) {
              agent = (Agent) model.overlayGrid.get(i, j);
              if (agent instanceof Cell) {
                oveCellNorm++;
              }
            }
          }
        }
        try {
          if (emb_on) {
            embFileWriter.write(embCellNorm + " ");
            embFileWriter.write(" " + determineMorphDisruptionLevel(ExpManager.EMBEDDED));
            for (int idx = 0; idx < ExpManager.AXIOM_ARRAY_SIZE; idx++) {
              embFileWriter.write(" " + emb_axiom_usage[idx]);
              emb_axiom_usage[idx] = 0; // reset for next simulation time step
            }
            embFileWriter.newLine();
          }
          if (sus_on) {
            susFileWriter.write(susCellNorm + " ");
            susFileWriter.write(" " + determineMorphDisruptionLevel(ExpManager.SUSPENSION));
            for (int idx = 0; idx < ExpManager.AXIOM_ARRAY_SIZE; idx++) {
              susFileWriter.write(" " + sus_axiom_usage[idx]);
              sus_axiom_usage[idx] = 0; // reset for next simulation time step
            }

            susFileWriter.newLine();
          }
          if (sur_on) {
            surFileWriter.write(surCellNorm + " ");
            surFileWriter.write(" " + determineMorphDisruptionLevel(ExpManager.SURFACE));
            for (int idx = 0; idx < ExpManager.AXIOM_ARRAY_SIZE; idx++) {
              surFileWriter.write(" " + sur_axiom_usage[idx]);
              sur_axiom_usage[idx] = 0;
            }
            surFileWriter.newLine();
          }
          if (ove_on) {
            oveFileWriter.write(oveCellNorm + " ");
            oveFileWriter.write(" " + determineMorphDisruptionLevel(ExpManager.OVERLAY));
            for (int idx = 0; idx < ExpManager.AXIOM_ARRAY_SIZE; idx++) {
              oveFileWriter.write(" " + ove_axiom_usage[idx]);
              ove_axiom_usage[idx] = 0;
            }
            oveFileWriter.newLine();
          }
        }
        catch (IOException e) { e.printStackTrace(); }
        step_count++;
      }
    }
    // schedule.scheduleRepeating(new UpdateSeries());
    // *** end class UpdateSeries ***

    //populate embedded grid
    if (emb_on) {
      Cell e = null;
      if (ExpManager.cell_type == 1) {
        e = new ISEA2_Cell(grid_width/2, grid_height/2, this.embeddedGrid, paramDB);
        ((ISEA2_Cell)e).setCultureType(ExpManager.EMBEDDED);
      }
      else {
        e = new ISEA1_Cell(grid_width/2, grid_height/2, this.embeddedGrid, paramDB);
        ((ISEA1_Cell)e).setCultureType(ExpManager.EMBEDDED);
      }
      embeddedGrid.set(grid_width/2, grid_height/2, e);
      schedule.scheduleOnce(e);
      /*
      Cell e2 = new Cell(grid_width/2 + 1, grid_height/2, this.embeddedGrid, paramDB);
      e2.setCultureType(ExpManager.EMBEDDED);
      embeddedGrid.set(grid_width/2 + 1, grid_height/2, e2);
      schedule.scheduleOnce(e2);
      */
    }
    //populate suspension grid
    if (sus_on) {
      Cell f = null;
      if (ExpManager.cell_type == 1) {
        f = new ISEA2_Cell(grid_width/2, grid_height/2, suspensionGrid, paramDB);
        ((ISEA2_Cell)f).setCultureType(ExpManager.SUSPENSION);
      }
      else {
        f = new ISEA1_Cell(grid_width/2, grid_height/2, suspensionGrid, paramDB);
        ((ISEA1_Cell)f).setCultureType(ExpManager.SUSPENSION);
      }
      suspensionGrid.set(f.x, f.y, f);
      schedule.scheduleOnce(f);
      Cell g = null;
      if (ExpManager.cell_type == 1) {
        g = new ISEA2_Cell(grid_width/2 + 1, grid_height/2, suspensionGrid, paramDB);
        ((ISEA2_Cell)g).setCultureType(ExpManager.SUSPENSION);
      }
      else {
        g = new ISEA1_Cell(grid_width/2 + 1, grid_height/2, suspensionGrid, paramDB);
        ((ISEA1_Cell)g).setCultureType(ExpManager.SUSPENSION);
      }
      suspensionGrid.set(g.x, g.y, g);
      schedule.scheduleOnce(g);
    }
    //populate surface grid
    if (sur_on) {
      Cell d = null;
      if (ExpManager.cell_type == 1) {
        d = new ISEA2_Cell(grid_width/2, grid_height/2, surfaceGrid, paramDB);
        ((ISEA2_Cell)d).setCultureType(ExpManager.SURFACE);
      }
      else {
        d = new ISEA1_Cell(grid_width/2, grid_height/2, surfaceGrid, paramDB);
        ((ISEA1_Cell)d).setCultureType(ExpManager.SURFACE);
      }
      surfaceGrid.set(grid_width/2, grid_height/2, d);
      schedule.scheduleOnce(d);
    }
    //populate overlay grid
    if (ove_on) {
      for (int i = 0; i < grid_width; i++) {
        int xCoord = i;
        int yCoord = grid_height/4 + i/2;
        Cell c = null;
        if (ExpManager.cell_type == 1) {
          c = new ISEA2_Cell(xCoord, yCoord, overlayGrid, paramDB);
          ((ISEA2_Cell)c).setCultureType(ExpManager.OVERLAY);
        }
        else {
          c = new ISEA1_Cell(xCoord, yCoord, overlayGrid, paramDB);
          ((ISEA1_Cell)c).setCultureType(ExpManager.OVERLAY);
        }
        overlayGrid.set(xCoord, yCoord, c);
        schedule.scheduleOnce(c);
      }
    }
    
  } // end start()
  
  public void finish() {
    try {
      if (emb_on && embFileWriter != null) {
        embFileWriter.flush();
        embFileWriter.close();
      }
      if (sus_on && susFileWriter != null) {
        susFileWriter.flush();
        susFileWriter.close();
      }
      if (sur_on && surFileWriter != null) {
        surFileWriter.flush();
        surFileWriter.close();
      }
      if (ove_on && oveFileWriter != null) {
        oveFileWriter.flush();
        oveFileWriter.close();
      }
    }
    catch (IOException e) { e.printStackTrace(); }
    super.finish();
  } // end finish()
    
  public double determineMorphDisruptionLevel(int cultureType) {

    double maxCellPercent = 0.15;
    double maxLumenPercent = 0.15;
    double cellLevelMax = 1.5;
    double lumenLevelMax = 1.5;
    double shapeLevelMax = 1.0;
    
    ObjectGrid2D targetGrid = null;
    if (cultureType == ExpManager.EMBEDDED) { targetGrid = embeddedGrid; }
    else if (cultureType == ExpManager.SUSPENSION) { targetGrid = suspensionGrid; }
    else if (cultureType == ExpManager.SURFACE) { targetGrid = surfaceGrid; }
    else if (cultureType == ExpManager.OVERLAY) { targetGrid = overlayGrid; }
    
    /* ======= Local Analysis ======= */
    
    Bag cellBag = new Bag();
    Bag lumenBag = new Bag();
    Bag matrixBag = new Bag();
    Agent curAgent = null;
    double localLevel = 0.0;
    for (int i = 0; i < grid_width; i++) {
      for (int j = 0; j < grid_height; j++) {
        curAgent = (Agent) targetGrid.get(i, j);
        if (curAgent instanceof ISEA2_Cell) {
          cellBag.add(curAgent);
          localLevel += ((ISEA2_Cell)curAgent).determineSurroundingMorphology();
        }
        else if (curAgent instanceof ISEA1_Cell) {
          cellBag.add(curAgent);
          localLevel += ((ISEA1_Cell)curAgent).determineSurroundingMorphology();
        }
        else if (curAgent instanceof FreeSpace) {
          lumenBag.add(curAgent);
        }
        else if (curAgent instanceof Matrix) {
          matrixBag.add(curAgent);
        }
      }
    }
    if (cellBag.numObjs != 0) {
      localLevel = localLevel / (double)cellBag.numObjs;  // average the total (should be <= 3.0)
    }
    
    /* ======= Global Analysis ======= */
    
    Bag neighbors = new Bag();
    IntBag xPositions = new IntBag();
    IntBag yPositions = new IntBag();
    
    // ANALYSIS OF CELLULAR CONTINUITY
    int numCellGroups = 0;
    Object[] cellBagArray = cellBag.toArray();
    java.util.LinkedList adjacentCellList[] = new java.util.LinkedList[cellBagArray.length];
    boolean[] visitedCells = new boolean[cellBagArray.length];
    
    // Create an adjacency list for cells
    for (int curCellId = 0; curCellId < cellBagArray.length; curCellId++) {
      adjacentCellList[curCellId] = new java.util.LinkedList();
      Cell curCell = (Cell) cellBagArray[curCellId];
      targetGrid.getNeighborsHexagonalDistance
              (curCell.x, curCell.y, 1, ExpManager.TOROIDAL, neighbors, xPositions, yPositions);
      neighbors.remove(curCell);
      for (int ndx = 0; ndx < neighbors.numObjs; ndx++) {
        Agent adjacentAgent = (Agent) neighbors.get(ndx);
        if (adjacentAgent instanceof Cell) {
          for (int adjCellId = 0; adjCellId < cellBagArray.length; adjCellId++) {
            if (adjacentAgent == cellBagArray[adjCellId]) {
              adjacentCellList[curCellId].add(new Integer(adjCellId));
              break;
            }
          }
        }
      }
    }
    // Run depth-first search to identify the number of strongly connected groups of cells
    for (int i = 0; i < cellBagArray.length; i++) {
      visitedCells[i] = false;
    }
    for (int i = 0; i < cellBagArray.length; i++) {
      if (visitedCells[i] == false) {
        numCellGroups++; // beginning iteration of a strongly connected group
        dfsRun(i, visitedCells, adjacentCellList);
      }
    }
    // Evaluate morphological disruption of cells at global level
    double maxCellGrpNum = cellBagArray.length * maxCellPercent;
    double minCellGrpNum = 1.0; // number of strongly connected groups when normal (2 for normal overlay)
    if (cultureType == ExpManager.OVERLAY) {
      minCellGrpNum = 2.0;
    }
    if (minCellGrpNum + 2.0 > maxCellGrpNum) {
      maxCellGrpNum = minCellGrpNum + 2.0;
    }
    double cellLevel = 0.0;
    if (numCellGroups > maxCellGrpNum) {
      cellLevel = cellLevelMax;
    }
    else if (numCellGroups > minCellGrpNum) {
      cellLevel = (cellLevelMax / (maxCellGrpNum - minCellGrpNum)) * (numCellGroups - minCellGrpNum);
    }
    
    // ANALYSIS OF LUMINAL CONTINUITY
    int numLumenGroups = 0;
    Object[] lumenBagArray = lumenBag.toArray();
    java.util.LinkedList adjacentLumenList[] = new java.util.LinkedList[lumenBagArray.length];
    boolean[] visitedLumens = new boolean[lumenBagArray.length];
    
    // Create adjacent lumen list
    for (int curLumenId = 0; curLumenId < lumenBagArray.length; curLumenId++) {
      adjacentLumenList[curLumenId] = new java.util.LinkedList();
      FreeSpace curLumen = (FreeSpace) lumenBagArray[curLumenId];
      targetGrid.getNeighborsHexagonalDistance
              (curLumen.x, curLumen.y, 1, ExpManager.TOROIDAL, neighbors, xPositions, yPositions);
      neighbors.remove(curLumen);
      for (int ndx = 0; ndx < neighbors.numObjs; ndx++) {
        Agent adjacentAgent = (Agent) neighbors.get(ndx);
        if (adjacentAgent instanceof FreeSpace) {
          for (int adjLumenId = 0; adjLumenId < lumenBagArray.length; adjLumenId++) {
            if (adjacentAgent == lumenBagArray[adjLumenId]) {
              adjacentLumenList[curLumenId].add(new Integer(adjLumenId));
              break;
            }
          }
        }
      }
    }
    // Run depth-first search to identify the number of strongly connected groups of lumen
    for (int i = 0; i < lumenBagArray.length; i++) {
      visitedLumens[i] = false;
    }
    for (int i = 0; i < lumenBagArray.length; i++) {
      if (visitedLumens[i] == false) {
        numLumenGroups++; // beginning iteration of a strongly connected group
        dfsRun(i, visitedLumens, adjacentLumenList);
      }
    }
    // Evaluate global morphological disruption of lumens
    double maxLumenGrpNum = lumenBagArray.length * maxLumenPercent;
    double minLumenGrpNum = 1.0; // number of strongly connected groups when normal
    if (minLumenGrpNum + 2.0 > maxLumenGrpNum) {
      maxLumenGrpNum = minLumenGrpNum + 2.0;
    }
    double lumenLevel = 0.0;
    if (numLumenGroups > maxLumenGrpNum) {
      lumenLevel = lumenLevelMax;
    }
    else if (numLumenGroups > minLumenGrpNum) {
      lumenLevel = (lumenLevelMax / (maxLumenGrpNum - minLumenGrpNum)) * (numLumenGroups - minLumenGrpNum);
    }
    
    // SHAPE ANALYSIS
    double shapeLevel = 0.0;
    double structureArea = 0.0;
    double enclosingArea = 0.0;
    int minCoordX = grid_width;
    int maxCoordX = 0;
    int minCoordY = grid_height;
    int maxCoordY = 0;
    for (int i = 0; i < cellBag.numObjs; i++) {
      curAgent = (Agent) cellBag.get(i);
      if (curAgent.x < minCoordX) { minCoordX = curAgent.x; }
      if (curAgent.x > maxCoordX) { maxCoordX = curAgent.x; }
      if (curAgent.y < minCoordY) { minCoordY = curAgent.y; }
      if (curAgent.y > maxCoordY) { maxCoordY = curAgent.y; }
    }
    double lengthX = maxCoordX - minCoordX + 1.0;
    double lengthY = maxCoordX - minCoordY + 1.0;
    double hexTocir = 2.0 * java.lang.Math.sqrt(3.0) / java.lang.Math.PI;
    if (lengthX > 0 && lengthY > 0) {
      if (cultureType == ExpManager.EMBEDDED) {
        structureArea = cellBag.numObjs + lumenBag.numObjs;
        enclosingArea = java.lang.Math.PI * (lengthX / 2.0) * (lengthY / 2.0) * hexTocir;
      }
      else if (cultureType == ExpManager.SUSPENSION) {
        structureArea = cellBag.numObjs + matrixBag.numObjs;
        enclosingArea = java.lang.Math.PI * (lengthX / 2.0) * (lengthY / 2.0) * hexTocir;
      }
      else if (cultureType == ExpManager.SURFACE) {
        structureArea = cellBag.numObjs;
        FreeSpace curLumen = null;
        int surfaceY = grid_height / 2;
        for (int k = 0; k < lumenBag.numObjs; k++) {
          curLumen = (FreeSpace) lumenBag.get(k);
          if (curLumen.y < surfaceY) {
            structureArea++;
          }
        }
        enclosingArea = lengthX * lengthY;
      }
      else {
        structureArea = cellBag.numObjs + lumenBag.numObjs;
        enclosingArea = lengthX * lengthY;
      }
      shapeLevel = 1.0 - (structureArea / enclosingArea);
      if (shapeLevel < 0.0) { shapeLevel = 0.0; }
      if (shapeLevel > shapeLevelMax) { shapeLevel = shapeLevelMax; }
    }
    
    /*
    System.out.println
            ("*** Morphology Level: " + ExpManager.form_0d00.format(localLevel + cellLevel + lumenLevel + shapeLevel)
                        + " [local=" + ExpManager.form_0d00.format(localLevel) 
                        + ", cell=" + ExpManager.form_0d00.format(cellLevel) + "(" + numCellGroups
                        + "), lumen=" + ExpManager.form_0d00.format(lumenLevel) + "(" + numLumenGroups
                        + "), shape=" + ExpManager.form_0d00.format(shapeLevel)
                        + "(" + ExpManager.form_0d00.format(structureArea) + "," + ExpManager.form_0d00.format(enclosingArea)+ ")]");
     
     */
    
    // Return the overall level of morphological disruption
    return localLevel + cellLevel + lumenLevel + shapeLevel;
    
  } // end determineMorphDisruptionLevel()
  
  // recursive depth-first search
  public static void dfsRun(int nodeId, boolean[] visited, java.util.LinkedList[] adjacencyList) {
    visited[nodeId] = true;
    java.util.ListIterator adjacencyIterator = adjacencyList[nodeId].listIterator(0);
    while (adjacencyIterator.hasNext()) {
      int adjacentNodeId = ((Integer)adjacencyIterator.next()).intValue();
      if (! visited[adjacentNodeId]) {
        dfsRun(adjacentNodeId, visited, adjacencyList);
      }
    }
  } // end dfsRun()
  
  public void printGraphicsInfo(String outputFileName, int cultureType) {
    ObjectGrid2D targetGrid = null;
    if (cultureType == ExpManager.EMBEDDED) {targetGrid = embeddedGrid; }
    else if (cultureType == ExpManager.SUSPENSION) { targetGrid = suspensionGrid; }
    else if (cultureType == ExpManager.SURFACE) { targetGrid = surfaceGrid; }
    else if (cultureType == ExpManager.OVERLAY) { targetGrid = overlayGrid; }
    
    try {
      BufferedWriter out = new BufferedWriter(new FileWriter(outputFileName, false));
      Agent agent = null;
      for (int i = 0; i < grid_width; i++) {
        for (int j = 0; j < grid_height; j++) {
          agent = (Agent) targetGrid.get(i, j);
          if (agent instanceof ISEA2_PCell || agent instanceof ISEA1_PCell) {
            out.write(i + "," + j + "," + 0);
            out.newLine();
          }
          else if (agent instanceof ISEA2_Cell || agent instanceof ISEA1_Cell) {
            out.write(i + "," + j + "," + 1);
            out.newLine();
          }
          else if (agent instanceof Matrix) {
            out.write(i + "," + j + "," + 2);
            out.newLine();
          }
          else if (agent instanceof FreeSpace) {
            out.write(i + "," + j + "," + 3);
            out.newLine();
          }
        }
      }
      out.flush();
      out.close();
    }
    catch (IOException e) { e.printStackTrace(); }
  } // end printGraphicsInfo()

}