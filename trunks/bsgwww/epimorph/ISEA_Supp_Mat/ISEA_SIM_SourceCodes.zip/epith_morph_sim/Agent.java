
package epith_morph_sim;

import sim.engine.SimState;
import sim.engine.Steppable;
import sim.field.grid.ObjectGrid2D;

public abstract class Agent implements Steppable {
	int x,y;
	ObjectGrid2D grid;

	public Agent(int x, int y, ObjectGrid2D grid) {
		this.x = x;
		this.y = y;
		this.grid = grid;
	}
	public void step(SimState state) {

	}

}
