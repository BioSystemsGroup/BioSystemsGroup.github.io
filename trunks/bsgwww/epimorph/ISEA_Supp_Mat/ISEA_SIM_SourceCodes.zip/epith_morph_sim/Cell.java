package epith_morph_sim;

import sim.field.grid.ObjectGrid2D;
import sim.util.*;

public class Cell extends Agent {
  
  public static final int UP = 0;
  public static final int UR = 1;
  public static final int DR = 2;
  public static final int DN = 3;
  public static final int DL = 4;
  public static final int UL = 5;
  
  boolean alive = true;
  boolean moved = false;
  
  /** Creates a new instance of Cell */
  public Cell(int x, int y, ObjectGrid2D grid) {
    super(x, y, grid);
  }
  
  public boolean alive() {
    return alive;
  }
  
  public boolean polarizingEnvironment() {
    boolean isPolarizing = false;
    //one free space
    String pattern1 = "cfcmmm";

    //two free spaces
    String pattern2 = "cffcmm";

    //three free spaces
    String pattern3 = "cfffcm";

    //create the neighbor array;
    Agent[] agents = new Agent[6];
    agents[5] = (Agent)grid.get(grid.stx(grid.dlx(this.x,this.y)), grid.sty(grid.dly(this.x,this.y)));
    agents[4] = (Agent)grid.get(grid.stx(grid.downx(this.x,this.y)), grid.sty(grid.downy(this.x,this.y)));
    agents[3] = (Agent)grid.get(grid.stx(grid.drx(this.x,this.y)), grid.sty(grid.dry(this.x,this.y)));
    agents[0] = (Agent)grid.get(grid.stx(grid.ulx(this.x,this.y)), grid.sty(grid.uly(this.x,this.y)));
    agents[2] = (Agent)grid.get(grid.stx(grid.urx(this.x,this.y)), grid.sty(grid.ury(this.x,this.y)));
    agents[1] = (Agent)grid.get(grid.stx(grid.upx(this.x,this.y)), grid.sty(grid.upy(this.x,this.y)));
    
    for(int j = 0; j < 6; j++) {
      String neighborsAsString = "";
      for(int i = j; i < 6+j; i++) {
        Agent a = agents[i%6];
        if (a instanceof Cell) {
          neighborsAsString = neighborsAsString + "c";
        }
        else if (a instanceof Matrix) {
          neighborsAsString += "m";
        } else if (a instanceof FreeSpace) {
          neighborsAsString += "f";
        } else {
          System.out.println("wrong object type");
        }
      }
      if (pattern1.equals(neighborsAsString) || 
              pattern2.equals(neighborsAsString) || pattern3.equals(neighborsAsString)) {
        isPolarizing = true;
      }
    }
    return isPolarizing;
  } // end polarizingEnvironment()
  
  
  public boolean depolarizingEnvironment() {
    boolean depolarizing = true;

    //polarization-preserving environments
    String pattern1 = "cfcmmm";  //one free space
    String pattern2 = "cffcmm";  //two free spaces
    String pattern3 = "cfffcm";  //three free spaces

    //contiguous cell and matrix spaces
    String pattern4 = "ccmmmm";
    String pattern5 = "cccmmm";
    String pattern6 = "ccccmm";
    String pattern7 = "cccccm";

    //contiguous cell and matrix spaced in which there is some free space
    //three cells, one free space
    String pattern8 = "cfccmm";
    String pattern9 = "ccfcmm";
    //three cells, two free space
    String pattern10 = "ccffcm";
    String pattern11 = "cffccm";
    String pattern12 = "cfcfcm";

    //create the neighbor array;
    Agent[] agents = new Agent[6];
    agents[5] = (Agent)grid.get(grid.stx(grid.dlx(this.x,this.y)), grid.sty(grid.dly(this.x,this.y)));
    agents[4] = (Agent)grid.get(grid.stx(grid.downx(this.x,this.y)), grid.sty(grid.downy(this.x,this.y)));
    agents[3] = (Agent)grid.get(grid.stx(grid.drx(this.x,this.y)), grid.sty(grid.dry(this.x,this.y)));
    agents[0] = (Agent)grid.get(grid.stx(grid.ulx(this.x,this.y)), grid.sty(grid.uly(this.x,this.y)));
    agents[2] = (Agent)grid.get(grid.stx(grid.urx(this.x,this.y)), grid.sty(grid.ury(this.x,this.y)));
    agents[1] = (Agent)grid.get(grid.stx(grid.upx(this.x,this.y)), grid.sty(grid.upy(this.x,this.y)));
    
    for(int j = 0; j < 6; j++) {
      String neighborsAsString = "";
      for(int i = j; i < 6+j; i++) {
        Agent a = agents[i%6];
        if (a instanceof Cell) { neighborsAsString += "c"; }
        else if (a instanceof Matrix) { neighborsAsString += "m"; }
        else if (a instanceof FreeSpace) { neighborsAsString += "f"; }
      }
      if (pattern1.equals(neighborsAsString) ||
          pattern2.equals(neighborsAsString) ||
          pattern3.equals(neighborsAsString) ||
          pattern4.equals(neighborsAsString) ||
          pattern5.equals(neighborsAsString) ||
          pattern6.equals(neighborsAsString) ||
          pattern7.equals(neighborsAsString) ||
          pattern8.equals(neighborsAsString) ||
          pattern9.equals(neighborsAsString) ||
          pattern10.equals(neighborsAsString) ||
          pattern11.equals(neighborsAsString) ||
          pattern12.equals(neighborsAsString)) {
        depolarizing = false;
      }
    }
    return depolarizing; 
  } // end depolarizingEnvironment();
  
  // determines whether the two agents are neighbors
  public boolean areNeighbors(Agent a, Agent b) {
    IntBag xPositions = new IntBag();
    IntBag yPositions = new IntBag();
    Bag neighbors = new Bag();
    Bag matrixNeighbors = new Bag();
    Bag lumenNeighbors = new Bag();
    Bag cellNeighbors = new Bag();
    Bag mediaNeighbors = new Bag();
    boolean toroidal = true;
    int radius = 1;
    
    this.grid.getNeighborsHexagonalDistance(a.x, a.y, 1, toroidal, neighbors, xPositions, yPositions);
    neighbors.remove(this);
    for (int i = 0; i < neighbors.numObjs; i++) {
      Agent agent = (Agent) neighbors.get(i);
      if (b == agent) {
        return true;
      }
    }
    return false;
  } // end areNeighbors()
  
  // returns numerical representation of the direction 'from'=>'to'
  public int determineDirection(Agent from, Agent to) {
    int toX = to.x;
    int toY = to.y;
    int upX = grid.stx(grid.upx(from.x, from.y));
    int upY = grid.sty(grid.upy(from.x, from.y));
    int urX = grid.stx(grid.urx(from.x, from.y));
    int urY = grid.sty(grid.ury(from.x, from.y));
    int drX = grid.stx(grid.drx(from.x, from.y));
    int drY = grid.sty(grid.dry(from.x, from.y));
    int dnX = grid.stx(grid.downx(from.x, from.y));
    int dnY = grid.sty(grid.downy(from.x, from.y));
    int dlX = grid.stx(grid.dlx(from.x, from.y));
    int dlY = grid.sty(grid.dly(from.x, from.y));
    int ulX = grid.stx(grid.ulx(from.x, from.y));
    int ulY = grid.sty(grid.uly(from.x, from.y));
    if (toX == upX && toY == upY) {
      return ExpManager.UP;
    }
    if (toX == ulX && toY == ulY) {
      return ExpManager.UL;
    }
    if (toX == urX && toY == urY) {
      return ExpManager.UR;
    }
    if (toX == drX && toY == drY) {
      return ExpManager.DR;
    }
    if (toX == dnX && toY == dnY) {
      return ExpManager.DN;
    }
    if (toX == dlX && toY == dlY) {
      return ExpManager.DL;
    }
    return 0;
  }
  
  // returns numerical representation of the opposite direction
  static public int getOppositeDirection(int direction) {
    int opposite = 0;
    switch (direction) {
      case ExpManager.UP: opposite = ExpManager.DN;
      break;
      case ExpManager.UR: opposite = ExpManager.DL;
      break;
      case ExpManager.UL: opposite = ExpManager.DR;
      break;
      case ExpManager.DR: opposite = ExpManager.UL;
      break;
      case ExpManager.DN: opposite = ExpManager.UP;
      break;
      case ExpManager.DL: opposite = ExpManager.UR;
      break;
      default: System.out.println("Cell:getOppositeDirection() - illegal arg" + direction);
      break;
    }
    return opposite;
  } // end getOppositeDirection()
  
  // retrieves neighboring agent at the indicated direction from the source
  public Agent getAgentAt(Agent sourceAgent, int direction) {
    int newX = sourceAgent.x;
    int newY = sourceAgent.y;
    switch (direction) {
        case ExpManager.UP: 
          newX = grid.stx(grid.upx(sourceAgent.x, sourceAgent.y));
          newY = grid.sty(grid.upy(sourceAgent.x, sourceAgent.y));
          break;
        case ExpManager.UR:
          newX = grid.stx(grid.urx(sourceAgent.x, sourceAgent.y));
          newY = grid.sty(grid.ury(sourceAgent.x, sourceAgent.y));
          break;
        case ExpManager.DR:
          newX = grid.stx(grid.drx(sourceAgent.x, sourceAgent.y));
          newY = grid.sty(grid.dry(sourceAgent.x, sourceAgent.y));
          break;
        case ExpManager.DN:
          newX = grid.stx(grid.downx(sourceAgent.x, sourceAgent.y));
          newY = grid.sty(grid.downy(sourceAgent.x, sourceAgent.y));
          break;
        case ExpManager.DL:
          newX = grid.stx(grid.dlx(sourceAgent.x, sourceAgent.y));
          newY = grid.sty(grid.dly(sourceAgent.x, sourceAgent.y));
          break;
        case ExpManager.UL:
          newX = grid.stx(grid.ulx(sourceAgent.x, sourceAgent.y));
          newY = grid.sty(grid.uly(sourceAgent.x, sourceAgent.y));
          break;
        default:
          break;
      }
    Agent targetAgent = (Agent) grid.get(newX, newY);
    return targetAgent;
  } // end getAgentAt()
  
}
