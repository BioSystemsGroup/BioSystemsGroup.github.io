/*
 * Created on Apr 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package epith_morph_sim;

import sim.field.grid.ObjectGrid2D;

public class EmbeddedGrid extends ObjectGrid2D {

	/**
	 * @param width
	 * @param height
	 */
	public EmbeddedGrid(int width, int height) {
		super(width, height);
		//populate the embedded grid with matrix
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				this.set(i, j, new Matrix(i, j, this));
			}
		}
		// TODO Auto-generated constructor stub
	}

}
