package epith_morph_sim;

import sim.engine.*;
import sim.display.*;
import sim.util.media.PngEncoder;
import ec.util.*;
import java.io.*;
import java.util.*;
import jxl.*;

public class ExpManager {
  
  File outputFile = null;
  String outputFilePath = null;
  
  // 1 = GUI; 2 = BATCH (SINGLE AXIOM); 3 = BATCH (DOUBLE AXIOM);
  // 4 = BATCH (MALIGNANT) else = default (NO GUI)
  public static int experiment_mode = 1;
  public static boolean image_capture = false; // store simulation image in png format
  public static boolean movie_capture = false; // store png sequence of simulation images
  public static boolean pairwise_spec = true;
  public static int spec_axiom01 = 5;
  public static int spec_axiom02 = 6;
  public static epith_morph_sim.CultureGUI modelUI = null;
  public static sim.display.Console modelConsole = null;
  
  public static int cell_type = 1; // 1 = ISEA2; else = ISEA1
  
  public static boolean emb_on = true;
  public static boolean sus_on = false;
  public static boolean sur_on = false;
  public static boolean ove_on = false;
  
  public static final int REPETITION = 10;
  public static final int NUM_STEPS = 100;
  public static final boolean TOROIDAL = true;
  public static final int NUM_AXIOMS = 12;
  public static final int AXIOM_ARRAY_SIZE = 23;
  public static final int DATA_COL_SIZE = AXIOM_ARRAY_SIZE + 4; // 3 for cell counts + 1 for disruption level
  
  public static final double PROB_INCREMENT = 0.1;
  public static final double MIN_PROB = 0.0;
  public static final double MAX_PROB = 1.0;
  
  public static final double MIN_MALIG_RATIO = 0.2;
  public static final double MAX_MALIG_RATIO = 0.7;
  public static final double MALIG_RATIO_INCREM = 0.2;
  public static final int EMB_MALIG_SETOFF_TIME = 30;
  public static final int SUS_MALIG_SETOFF_TIME = 30;
  public static final int SUR_MALIG_SETOFF_TIME = 30;
  public static final int OVE_MALIG_SETOFF_TIME = 30;
  
  public static final int EMBEDDED = 1;
  public static final int SUSPENSION = 2;
  public static final int SURFACE = 3;
  public static final int OVERLAY = 4;
  public static final String P_SEED = "seed";
  public static final String V_TIME = "time";
  public static final int UP = 0;
  public static final int UR = 1;
  public static final int DR = 2;
  public static final int DN = 3;
  public static final int DL = 4;
  public static final int UL = 5;
  
  static final String outputFolderName = "sim_output"; // folder containing all simulation output
  static final String paramFolderName = "params";  // under outputFolder(sim_output/)
  static final String rawDataFolderName = "rawdata";  // under outputFolder(sim_output/)
  static final String summaryFolderName = "summary";  // under outputFolder(sim_output/)
  static final String imageFolderName = "images";  // under outputFolder(sim_output/)
  static final String excelFolderName = "excel"; // under outputFolder(sim_output/)
  static final String srcFolderName = "src"; // under outputFolder(sim_output
  
  static final java.text.DecimalFormat form_0d00 = new java.text.DecimalFormat("0.00");
  static final java.text.DecimalFormat form_00 = new java.text.DecimalFormat("00");
  static final java.text.DecimalFormat form_000 = new java.text.DecimalFormat("000");
  static final java.text.DecimalFormat form_0000 = new java.text.DecimalFormat("0000");
  static final java.text.DecimalFormat form_00000 = new java.text.DecimalFormat("00000");
  
  
  /* ********* MAIN FUNCTION ******************** */
  public static void main(String[] args) {
    ExpManager manager = new ExpManager();
    manager.run();
  }
  /* ******************************************** */
  
  public ExpManager() {
  }
  
  public void run() {
    System.out.println("Running epith_morph_sim.ExpManager");
    // create output folders
    File outputFolderFile = new File(outputFolderName);
    outputFolderFile.mkdir();
    File paramFolderFile = new File(outputFolderName + File.separator + paramFolderName);
    paramFolderFile.mkdir();
    File rawDataFolderFile = new File(outputFolderName + File.separator + rawDataFolderName);
    rawDataFolderFile.mkdirs();
    File summaryFolderFile = new File(outputFolderName + File.separator + summaryFolderName);
    summaryFolderFile.mkdirs();
    File imageFolderFile = new File(outputFolderName + File.separator + imageFolderName);
    imageFolderFile.mkdirs();
    File srcFolderFile = new File(outputFolderName + File.separator + srcFolderName);
    srcFolderFile.mkdirs();
    
    ParameterDatabase parameters = null;
    File paramFile = new File("morph.params");
    if (!paramFile.exists()) {
      System.out.println("Parameter file not found: morph.params");
    }
    else {
      try {
        parameters=new ParameterDatabase(new File("morph.params").getAbsoluteFile());
      } 
      catch(IOException ex) { ex.printStackTrace(); }
    }
    if (experiment_mode != 1 && (image_capture || movie_capture)) {
      modelUI = new epith_morph_sim.CultureGUI();
      modelUI.setEmbeddedOn(emb_on);
      modelUI.setSuspensionOn(sus_on);
      modelUI.setSurfaceOn(sur_on);
      modelUI.setOverlayOn(ove_on);
      modelConsole = new sim.display.Console(modelUI);
      modelUI.init(modelConsole);
    }
    if (experiment_mode == 1) {
      // GUI MODE
      epith_morph_sim.CultureGUI model = new epith_morph_sim.CultureGUI(parameters);
      model.setEmbeddedOn(emb_on);
      model.setSuspensionOn(sus_on);
      model.setSurfaceOn(sur_on);
      model.setOverlayOn(ove_on);
      sim.display.Console c = new sim.display.Console(model);
      c.setVisible(true);   
    }
    else if (experiment_mode == 2) {
      // BATCH MODE (SINGLE AXIOM)
      createParameterFilesSingle();
      runParameterizedBatchSingle();
      if (emb_on) { processRawDataSingle(ExpManager.EMBEDDED); }
      if (sus_on) { processRawDataSingle(ExpManager.SUSPENSION); }
      if (sur_on) { processRawDataSingle(ExpManager.SURFACE); }
      if (ove_on) { processRawDataSingle(ExpManager.OVERLAY); }
      // post-simulation clean up
      if (modelUI != null) { modelUI.quit(); }
      if (modelConsole != null) { modelConsole.dispose(); }
      modelUI = null;
      modelConsole = null;
      System.exit(0);
    }
    else if (experiment_mode == 3) {
      // BATCH MODE (DOUBLE AXIOMS)
      createParameterFilesPairwise(pairwise_spec, spec_axiom01, spec_axiom02);
      runParameterizedBatchPairwise(pairwise_spec, spec_axiom01, spec_axiom02);
      if (emb_on) { processRawDataPairwise(ExpManager.EMBEDDED, pairwise_spec, spec_axiom01, spec_axiom02); }
      if (sus_on) { processRawDataPairwise(ExpManager.SUSPENSION, pairwise_spec, spec_axiom01, spec_axiom02); }
      if (sur_on) { processRawDataPairwise(ExpManager.SURFACE, pairwise_spec, spec_axiom01, spec_axiom02); }
      if (ove_on) { processRawDataPairwise(ExpManager.OVERLAY, pairwise_spec, spec_axiom01, spec_axiom02); }
      // post-simulation clean up
      if (modelUI != null) { modelUI.quit(); }
      if (modelConsole != null) { modelConsole.dispose(); }
      modelUI = null;
      modelConsole = null;
      System.exit(0);
    }
    else if (experiment_mode == 4) {
      // BATCH MODE (MALIGNANT CELL VERSION)
      createParameterFilesMalig();
      runParameterizedMalig();
      if (emb_on) { processRawDataMalig(ExpManager.EMBEDDED); }
      if (sus_on) { processRawDataMalig(ExpManager.SUSPENSION); }
      if (sur_on) { processRawDataMalig(ExpManager.SURFACE); }
      if (ove_on) { processRawDataMalig(ExpManager.OVERLAY); }
      // post-simulation clean up
      if (modelUI != null) { modelUI.quit(); }
      if (modelConsole != null) { modelConsole.dispose(); }
      modelUI = null;
      modelConsole = null;
      System.exit(0);
    }
    else {
      // NON-BATCH, NO-GUI MODE
      String outFileName = outputFolderName + File.separator + rawDataFolderName + File.separator + "Sim";
      String imgFileName = outputFolderName + File.separator + imageFolderName + File.separator + "Sim";
      runSimulation(parameters, outFileName, imgFileName);
      /*
      if (emb_on) { processRawData(ExpManager.EMBEDDED); }
      if (sus_on) { processRawData(ExpManager.SUSPENSION); }
      if (sur_on) { processRawData(ExpManager.SURFACE); }
      if (ove_on) { processRawData(ExpManager.OVERLAY); }
       */
      // post-simulation clean up
      if (modelUI != null) { modelUI.quit(); }
      if (modelConsole != null) { modelConsole.dispose(); }
      modelUI = null;
      modelConsole = null;
      System.exit(0);
    }
  } // end run()
  
  public void runSimulation(ParameterDatabase paramDB, String outFileName, String imgFileName) {
    epith_morph_sim.Culture model = null;
    String outputName = null;
    String imageOutName = null;
    try {
      for (int rep = 1; rep <= REPETITION; rep++) {
        if (rep%25 == 0) {
          System.out.println("\tREPETITION " + rep);
        }
        outputName = outFileName + "_Rep" + form_000.format(rep);
        model = new epith_morph_sim.Culture 
                      (new MersenneTwisterFast(), new Schedule(2), paramDB, outputName);
        model.setEmbeddedOn(emb_on);
        model.setSuspensionOn(sus_on);
        model.setSurfaceOn(sur_on);
        model.setOverlayOn(ove_on);
        model.start();
        for (int i = 0; i < NUM_STEPS; i++) {
          if (movie_capture || (image_capture && (i == 25 || i == 50 || i == 75))) {
            modelUI.load(model);
            if (emb_on) {
              // print Illustrator graphics info
              imageOutName = imgFileName + "_EMB_Rep" + form_000.format(rep) + "_Step" + form_000.format(i);
              model.printGraphicsInfo(imageOutName + ".txt", ExpManager.EMBEDDED);
              // generate PNG image
              java.awt.Graphics g = modelUI.embeddedDisplay.insideDisplay.getGraphics();
              modelUI.embeddedDisplay.setScale(1.0);
              java.awt.image.BufferedImage img = modelUI.embeddedDisplay.insideDisplay.paint(g, true);
              OutputStream stream = 
                       new BufferedOutputStream(new FileOutputStream(new File(imageOutName + ".png")));
              PngEncoder tmpEncoder = new PngEncoder(img, false,PngEncoder.FILTER_NONE, 9);
              stream.write(tmpEncoder.pngEncode());
              stream.close();
            }
            if (sus_on) {
              // print Illustrator graphics info
              imageOutName = imgFileName + "_SUS_Rep" + form_000.format(rep) + "_Step" + form_000.format(i);
              model.printGraphicsInfo(imageOutName + ".txt", ExpManager.SUSPENSION);
              // generate PNG image
              java.awt.Graphics g = modelUI.suspensionDisplay.insideDisplay.getGraphics();
              modelUI.suspensionDisplay.setScale(1.0);
              java.awt.image.BufferedImage img = modelUI.suspensionDisplay.insideDisplay.paint(g, true);
              OutputStream stream = 
                       new BufferedOutputStream(new FileOutputStream(new File(imageOutName + ".png")));
              PngEncoder tmpEncoder = new PngEncoder(img, false,PngEncoder.FILTER_NONE, 9);
              stream.write(tmpEncoder.pngEncode());
              stream.close();
            }
            if (sur_on) {
              // print Illustrator graphics info
              imageOutName = imgFileName + "_SUR_Rep" + form_000.format(rep) + "_Step" + form_000.format(i);
              model.printGraphicsInfo(imageOutName + ".txt", ExpManager.SURFACE);
              // generate PNG image
              java.awt.Graphics g = modelUI.surfaceDisplay.insideDisplay.getGraphics();
              modelUI.surfaceDisplay.setScale(1.0);
              java.awt.image.BufferedImage img = modelUI.surfaceDisplay.insideDisplay.paint(g, true);
              OutputStream stream = 
                       new BufferedOutputStream(new FileOutputStream(new File(imageOutName + ".png")));
              PngEncoder tmpEncoder = new PngEncoder(img, false,PngEncoder.FILTER_NONE, 9);
              stream.write(tmpEncoder.pngEncode());
              stream.close();
            }
            if (ove_on) {
              // print Illustrator graphics info
              imageOutName = imgFileName + "_OVE_Rep" + form_000.format(rep) + "_Step" + form_000.format(i);
              model.printGraphicsInfo(imageOutName + ".txt", ExpManager.OVERLAY);
              // generate PNG image
              java.awt.Graphics g = modelUI.overlayDisplay.insideDisplay.getGraphics();
              modelUI.overlayDisplay.setScale(1.0);
              java.awt.image.BufferedImage img = modelUI.overlayDisplay.insideDisplay.paint(g, true);
              OutputStream stream = 
                       new BufferedOutputStream(new FileOutputStream(new File(imageOutName + ".png")));
              PngEncoder tmpEncoder = new PngEncoder(img, false,PngEncoder.FILTER_NONE, 9);
              stream.write(tmpEncoder.pngEncode());
              stream.close();
            }
          }
          model.schedule.step(model);
        } // end for (NUM_STEPS)
        // model.finish();

        // Generate image files at the end of simulation
        if (image_capture || movie_capture) {
          modelUI.load(model);
          if (emb_on) {
            // print Illustrator graphics info
            imageOutName = imgFileName + "_EMB_Rep" + form_000.format(rep) + "_Step" + form_000.format(NUM_STEPS);
            model.printGraphicsInfo(imageOutName + ".txt", ExpManager.EMBEDDED);
            // generate PNG file
            java.awt.Graphics g = modelUI.embeddedDisplay.insideDisplay.getGraphics();
            modelUI.embeddedDisplay.setScale(1.0);
            java.awt.image.BufferedImage img = modelUI.embeddedDisplay.insideDisplay.paint(g, true);
            OutputStream stream = 
                     new BufferedOutputStream(new FileOutputStream(new File(imageOutName + ".png")));
            PngEncoder tmpEncoder = new PngEncoder(img, false,PngEncoder.FILTER_NONE, 9);
            stream.write(tmpEncoder.pngEncode());
            stream.close();   
          }
          if (sus_on) {
            imageOutName = imgFileName + "_SUS_Rep" + form_000.format(rep) + "_Step" + form_000.format(NUM_STEPS);
            model.printGraphicsInfo(imageOutName + ".txt", ExpManager.SUSPENSION);
            // generate PNG file
            java.awt.Graphics g = modelUI.embeddedDisplay.insideDisplay.getGraphics();
            modelUI.embeddedDisplay.setScale(1.0);
            java.awt.image.BufferedImage img = modelUI.embeddedDisplay.insideDisplay.paint(g, true);
            OutputStream stream = 
                     new BufferedOutputStream(new FileOutputStream(new File(imageOutName + ".png")));
            PngEncoder tmpEncoder = new PngEncoder(img, false,PngEncoder.FILTER_NONE, 9);
            stream.write(tmpEncoder.pngEncode());
            stream.close();
          }
          if (sur_on) {
            imageOutName = imgFileName + "_SUR_Rep" + form_000.format(rep) + "_Step" + form_000.format(NUM_STEPS);
            model.printGraphicsInfo(imageOutName + ".txt", ExpManager.SURFACE);
            // generate PNG file
            java.awt.Graphics g = modelUI.embeddedDisplay.insideDisplay.getGraphics();
            modelUI.embeddedDisplay.setScale(1.0);
            java.awt.image.BufferedImage img = modelUI.embeddedDisplay.insideDisplay.paint(g, true);
            OutputStream stream = 
                     new BufferedOutputStream(new FileOutputStream(new File(imageOutName + ".png")));
            PngEncoder tmpEncoder = new PngEncoder(img, false,PngEncoder.FILTER_NONE, 9);
            stream.write(tmpEncoder.pngEncode());
            stream.close();   
          }
          if (ove_on) {
            imageOutName = imgFileName + "_OVE_Rep" + form_000.format(rep) + "_Step" + form_000.format(NUM_STEPS);
            model.printGraphicsInfo(imageOutName + ".txt", ExpManager.OVERLAY);
            // generate PNG file
            java.awt.Graphics g = modelUI.embeddedDisplay.insideDisplay.getGraphics();
            modelUI.embeddedDisplay.setScale(1.0);
            java.awt.image.BufferedImage img = modelUI.embeddedDisplay.insideDisplay.paint(g, true);
            OutputStream stream = 
                     new BufferedOutputStream(new FileOutputStream(new File(imageOutName + ".png")));
            PngEncoder tmpEncoder = new PngEncoder(img, false,PngEncoder.FILTER_NONE, 9);
            stream.write(tmpEncoder.pngEncode());
            stream.close();   
          }
        }
        model.finish();
      }
    }
    catch (IOException e) { e.printStackTrace(); }
    catch (IllegalArgumentException e) { e.printStackTrace(); }
    
  } // end runSimulation()
  
/* ========================= START DEFAULT VERSION ======================== */
  
  public void processRawData(int culture) {
    String cultureType = "";
    if (culture == ExpManager.EMBEDDED) { cultureType = "_EMB"; }
    else if (culture == ExpManager.SUSPENSION) { cultureType = "_SUS"; }
    else if (culture == ExpManager.SURFACE) { cultureType = "_SUR"; }
    else if (culture == ExpManager.OVERLAY) { cultureType = "_OVE"; }
    else {
      System.out.println("ERROR in ExpManager.processRawData() invalid culture_type: " + culture);
      return;
    }
    
    // temporary data placeholder
    double[][] dataArray = new double[DATA_COL_SIZE][NUM_STEPS];
    for (int i=0; i < DATA_COL_SIZE; i++) {
      for (int j=0; j < NUM_STEPS; j++) {
        dataArray[i][j] = 0.0;
      }
    }
    // for each repetition, extract data and add to placeholder
    for (int rep=1;rep <=REPETITION;rep++) { // FOR#3: repetitions
      String dataFileName = outputFolderName + File.separator + rawDataFolderName + File.separator
                    + "Sim_Rep" + form_000.format(rep) + cultureType + ".txt";
      Scanner dataScan = null;
      try {
        dataScan = new Scanner(new BufferedReader(new FileReader(dataFileName)));
        int i = 0;
        int j = 0;
        while (dataScan.hasNext()) {
          if (j == NUM_STEPS) { break; }
          dataArray[i][j] += dataScan.nextDouble();
          i++;
          if (i == DATA_COL_SIZE) { i = 0; j++; }
        }
      }
      catch (IOException ex){ ex.printStackTrace(); }
      if (dataScan!= null) { dataScan.close(); }
    }
    String outFileName = outputFolderName + File.separator + summaryFolderName + File.separator
                 + "Sim_Avg" + cultureType + ".txt";
    BufferedWriter outFile  = null;
    try {
      outFile = new BufferedWriter(new FileWriter(outFileName));
      for (int j = 0; j < NUM_STEPS; j++) {
        for (int i = 0; i < DATA_COL_SIZE; i++) {
          dataArray[i][j] = dataArray[i][j] / ((double)REPETITION); // average
          outFile.write(dataArray[i][j] + "\t");
        }
        outFile.newLine();
      }
      if (outFile != null) { outFile.close(); }
    } catch (IOException ex) { ex.printStackTrace(); }
  } // end processRawData()
    
  /* ================== END DEFAULT VERSION =============================== */
  
  /* ================== MALIGNANT CELL VERSION ============================ */
  
  public void createParameterFilesMalig() {
    String fileName = null;
    for (double ratio = MIN_MALIG_RATIO; ratio <= MAX_MALIG_RATIO; ratio += MALIG_RATIO_INCREM) {
      // set file name
      fileName = outputFolderName + File.separator + paramFolderName + File.separator
                   + "Malig_Ratio" + form_0d00.format(ratio) + ".txt";
      // write actual content
      try {
        BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
        out.write("seed = time");
        out.newLine();
        out.newLine();
        out.write("GridWidth = 100");
        out.newLine();
        out.write("GridHeight = 100");
        out.newLine();
        out.write("EmbeddedOn = " + emb_on);
        out.newLine();
        out.write("SuspensionOn = " + sus_on);
        out.newLine();
        out.write("SurfaceOn = " + sur_on);
        out.newLine();
        out.write("OverlayOn = " + ove_on);
        out.newLine();
        out.newLine();
        for (int j=1; j <= NUM_AXIOMS; j++) {
          out.write("Axiom"+form_000.format(j)+"Prob = " + 1.0);
          out.newLine();
        }
        out.newLine();
        out.write("MalignancyRatio = " + ratio);
        out.newLine();
        out.write("EmbMaligSetOffTime = " + EMB_MALIG_SETOFF_TIME);
        out.newLine();
        out.write("SusMaligSetOffTime = " + SUS_MALIG_SETOFF_TIME);
        out.newLine();
        out.write("SurMaligSetOffTime = " + SUR_MALIG_SETOFF_TIME);
        out.newLine();
        out.write("OveMaligSetOffTime = " + OVE_MALIG_SETOFF_TIME);
        out.newLine();
        out.flush();
        out.close();
      }
      catch (IOException e) { e.printStackTrace(); }
    }
  }
  
  public void runParameterizedMalig() {
    ParameterDatabase parameters = null;
    String paramFileName = null;
    String outFileName = null;
    String imgFileName = null;
    for (double ratio = MIN_MALIG_RATIO; ratio <= MAX_MALIG_RATIO; ratio += MALIG_RATIO_INCREM) {
      System.out.println("MALIG RATIO " + form_0d00.format(ratio));
      paramFileName = outputFolderName+ File.separator
                        + paramFolderName + File.separator
                        + "Malig_Ratio" + form_0d00.format(ratio) + ".txt";
      try {
        parameters = new ParameterDatabase(new File(paramFileName).getAbsoluteFile());
      } 
      catch(IOException ex) { ex.printStackTrace(); }
      outFileName = outputFolderName + File.separator + rawDataFolderName + File.separator
                        + "Malig_Ratio" + form_0d00.format(ratio);
      imgFileName = outputFolderName + File.separator + imageFolderName + File.separator
                        + "Malig_Ratio" + form_0d00.format(ratio);
      runSimulation(parameters, outFileName, imgFileName);
    }
  }
  
  public void processRawDataMalig(int culture) { 
    String cultureType = "";
    if (culture == ExpManager.EMBEDDED) { cultureType = "_EMB"; }
    else if (culture == ExpManager.SUSPENSION) { cultureType = "_SUS"; }
    else if (culture == ExpManager.SURFACE) { cultureType = "_SUR"; }
    else if (culture == ExpManager.OVERLAY) { cultureType = "_OVE"; }
    else { 
      System.out.println("ERROR in ExpManager.processRawDataSingle() invalid culture: " + culture);
      return;
    }
    for (double ratio = MIN_MALIG_RATIO; ratio <= MAX_MALIG_RATIO; ratio += MALIG_RATIO_INCREM) {
      // temporary data placeholder
      double[][] dataArray = new double[DATA_COL_SIZE][NUM_STEPS];
      for (int i=0; i < DATA_COL_SIZE; i++) {
        for (int j=0; j < NUM_STEPS; j++) {
          dataArray[i][j] = 0.0;
        }
      }
      // for each repetition, extract data and add to placeholder
      for (int rep=1;rep <=REPETITION;rep++) {
        String dataFileName = outputFolderName + File.separator + rawDataFolderName + File.separator
                                + "Malig_Ratio" + form_0d00.format(ratio)
                                + "_Rep" + form_000.format(rep) + cultureType + ".txt";
        Scanner dataScan = null;
        try {
          dataScan = new Scanner(new BufferedReader(new FileReader(dataFileName)));
          int i = 0;
          int j = 0;
          while (dataScan.hasNext()) {
            if (j == NUM_STEPS) { break; }
            dataArray[i][j] += dataScan.nextDouble();
            i++;
            if (i == DATA_COL_SIZE) { i = 0; j++; }
          }
        }
        catch (IOException ex){ ex.printStackTrace(); }
        if (dataScan!= null) { dataScan.close(); }
      }
      String outFileName = outputFolderName + File.separator + summaryFolderName + File.separator
                             + "Malig_Ratio" + form_0d00.format(ratio)
                             + "_Avg" + cultureType + ".txt";
      BufferedWriter outFile  = null;
      try {
        outFile = new BufferedWriter(new FileWriter(outFileName));
        for (int j = 0; j < NUM_STEPS; j++) {
          for (int i = 0; i < DATA_COL_SIZE; i++) {
            dataArray[i][j] = dataArray[i][j] / ((double)REPETITION); // average
            outFile.write(dataArray[i][j] + "\t");
          }
          outFile.newLine();
        }
        if (outFile != null) { outFile.close(); }
      }
      catch (IOException ex) { ex.printStackTrace(); }
    }
  } // end processRawDataMalig()
  
  /* ================== END MALIGNANT CELL VERSION ======================== */
  
  /* ================== SINGLE AXIOM VERSION ============================== */
  
  public void createParameterFilesSingle() {
    String fileName = null;
    for (int idx=1; idx <= NUM_AXIOMS; idx++) {
      for (double prob = MIN_PROB; prob <= MAX_PROB; prob+=PROB_INCREMENT) {
        // set file name
        fileName = outputFolderName + File.separator + paramFolderName + File.separator
                   + "Axiom" + form_000.format(idx)
                   + "_Prob" + form_0d00.format(prob) + ".txt";
        // write actual content
        try {
          BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
          out.write("seed = time");
          out.newLine();
          out.newLine();
          out.write("GridWidth = 100");
          out.newLine();
          out.write("GridHeight = 100");
          out.newLine();
          out.write("EmbeddedOn = " + emb_on);
          out.newLine();
          out.write("SuspensionOn = " + sus_on);
          out.newLine();
          out.write("SurfaceOn = " + sur_on);
          out.newLine();
          out.write("OverlayOn = " + ove_on);
          out.newLine();
          out.newLine();
          for (int j=1; j <= NUM_AXIOMS; j++) {
            if (idx==j) {
              out.write("Axiom"+form_000.format(j)+"Prob = " + form_0d00.format(prob));
            }
            else {
              out.write("Axiom"+form_000.format(j)+"Prob = " + 1.0);
            }
            out.newLine();
          }
          out.close();
        }
        catch (IOException e) { e.printStackTrace(); }
      }
    }
  } // end createParameterFiles()
  
  public void runParameterizedBatchSingle() {
    ParameterDatabase parameters = null;
    String paramFileName = null;
    String outFileName = null;
    String imgFileName = null;
    for (int idx = 12 /* 1 */; idx <= 12/* NUM_AXIOMS */; idx++) {
      for (double prob = MIN_PROB; prob <= MAX_PROB; prob += PROB_INCREMENT) {
        System.out.println("AXIOM " + idx + " PROB " + form_0d00.format(prob));
        paramFileName = outputFolderName+ File.separator
                        + paramFolderName + File.separator
                        + "Axiom" + form_000.format(idx)
                        + "_Prob" + form_0d00.format(prob) + ".txt";
        try {
          parameters = new ParameterDatabase(new File(paramFileName).getAbsoluteFile());
        } 
        catch(IOException ex) { ex.printStackTrace(); }
        outFileName = outputFolderName + File.separator + rawDataFolderName + File.separator
                        + "A" + form_000.format(idx) + "_P" + form_0d00.format(prob);
        imgFileName = outputFolderName + File.separator + imageFolderName + File.separator
                        + "A" + form_000.format(idx) + "_P" + form_0d00.format(prob);
        runSimulation(parameters, outFileName, imgFileName);
      }
    }
  } // end runParameterizedBatchSingle()
  
  public void processRawDataSingle(int culture) { 
    String cultureType = "";
    if (culture == ExpManager.EMBEDDED) { cultureType = "_EMB"; }
    else if (culture == ExpManager.SUSPENSION) { cultureType = "_SUS"; }
    else if (culture == ExpManager.SURFACE) { cultureType = "_SUR"; }
    else if (culture == ExpManager.OVERLAY) { cultureType = "_OVE"; }
    else { 
      System.out.println("ERROR in ExpManager.processRawDataSingle() invalid culture: " + culture);
      return;
    }
    
    for (int idx= 12 /* 1 */; idx <= 12 /* NUM_AXIOMS */; idx++) {
      for (double prob=MIN_PROB; prob <= MAX_PROB; prob+=PROB_INCREMENT) {
        // temporary data placeholder
        double[][] dataArray = new double[DATA_COL_SIZE][NUM_STEPS];
        for (int i=0; i < DATA_COL_SIZE; i++) {
          for (int j=0; j < NUM_STEPS; j++) {
            dataArray[i][j] = 0.0;
          }
        }
        // for each repetition, extract data and add to placeholder
        for (int rep=1;rep <=REPETITION;rep++) {
          String dataFileName = outputFolderName + File.separator + rawDataFolderName + File.separator
                                + "A" + form_000.format(idx)
                                + "_P" + form_0d00.format(prob)
                                + "_Rep" + form_000.format(rep) + cultureType + ".txt";
          Scanner dataScan = null;
          try {
            dataScan = new Scanner(new BufferedReader(new FileReader(dataFileName)));
            int i = 0;
            int j = 0;
            while (dataScan.hasNext()) {
              if (j == NUM_STEPS) { break; }
              dataArray[i][j] += dataScan.nextDouble();
              i++;
              if (i == DATA_COL_SIZE) { i = 0; j++; }
            }
          }
          catch (IOException ex){ ex.printStackTrace(); }
          if (dataScan!= null) { dataScan.close(); }
        }
        String outFileName = outputFolderName + File.separator + summaryFolderName + File.separator
                             + "A" + form_000.format(idx)
                             + "_P" + form_0d00.format(prob)
                             + "_Avg" + cultureType + ".txt";
        BufferedWriter outFile  = null;
        try {
          outFile = new BufferedWriter(new FileWriter(outFileName));
          for (int j = 0; j < NUM_STEPS; j++) {
            for (int i = 0; i < DATA_COL_SIZE; i++) {
              dataArray[i][j] = dataArray[i][j] / ((double)REPETITION); // average
              outFile.write(dataArray[i][j] + "\t");
            }
            outFile.newLine();
          }
          if (outFile != null) { outFile.close(); }
        }
        catch (IOException ex) { ex.printStackTrace(); }
      }
    }
  } // end processRawDataSingle()
  
  /* ==================== END SINGLE AXIOM VERSION ======================== */
  
    
  /* ==================== START DOUBLE AXIOM VERSION ====================== */
  
  public void createParameterFilesPairwise(boolean specified, int spec01, int spec02) {
    String fileName = null;
    int rule01 = spec01;
    int rule02 = spec02;
    if (spec01 > spec02) {
      rule01 = spec02;
      rule02 = spec01;
    }
    try {
      for (int idx01=1; idx01 <= NUM_AXIOMS; idx01++) {
        if (specified && idx01 != rule01) { continue; }
        for (double prob01 = MIN_PROB; prob01 <= MAX_PROB; prob01+=PROB_INCREMENT) {
          for (int idx02=idx01 + 1; idx02 <= NUM_AXIOMS; idx02++) {
            if (specified && idx02 != rule02) { continue; }
            for (double prob02 = MIN_PROB; prob02 <= MAX_PROB; prob02+=PROB_INCREMENT) {
              // set file name
              fileName = outputFolderName + File.separator + paramFolderName + File.separator
                        + "A" + form_000.format(idx01)
                        + "_P" + form_0d00.format(prob01)
                        + "_A" + form_000.format(idx02)
                        + "_P" + form_0d00.format(prob02) + "_param.txt";
              // write actual content
              BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
              out.write("seed = time");
              out.newLine();
              out.newLine();
              out.write("GridWidth = 100");
              out.newLine();
              out.write("GridHeight = 100");
              out.newLine();
              out.write("EmbeddedOn = " + emb_on);
              out.newLine();
              out.write("SuspensionOn = " + sus_on);
              out.newLine();
              out.write("SurfaceOn = " + sur_on);
              out.newLine();
              out.write("OverlayOn = " + ove_on);
              out.newLine();
              out.newLine();
              for (int i=1; i <= NUM_AXIOMS; i++) {
                if (i==idx01) {
                  out.write("Axiom"+form_000.format(i)+"Prob = " + form_0d00.format(prob01));
                }
                else if (i==idx02) {
                  out.write("Axiom"+form_000.format(i)+"Prob = " + form_0d00.format(prob02));
                }
                else {
                  out.write("Axiom"+form_000.format(i)+"Prob = " + 1.0);
                }
                out.newLine();
              }
              out.close();
            }
          }
        }
      }
    }
    catch (IOException e) { e.printStackTrace(); }
  }  // end createParameterFilesPairwise()
  
  public void runParameterizedBatchPairwise(boolean specified, int spec01, int spec02) {
    ParameterDatabase parameters = null;
    String paramFileName = null;
    String outFileName = null;
    String imgFileName = null;
    int rule01 = spec01;
    int rule02 = spec02;
    if (spec01 > spec02) {
      rule01 = spec02;
      rule02 = spec01;
    }
    for (int idx01 = 1; idx01 <= NUM_AXIOMS; idx01++) {
      if (specified && idx01 != rule01) { continue; }
      for (double prob01 = MIN_PROB; prob01 <= MAX_PROB; prob01 += PROB_INCREMENT) {
        for (int idx02 = idx01 + 1; idx02 <= NUM_AXIOMS; idx02++) {
          if (specified && idx02 != rule02) { continue; }
          for (double prob02 = MIN_PROB; prob02 <= MAX_PROB; prob02 += PROB_INCREMENT) {
            System.out.println("AXIOM " + idx01 + "(" + form_0d00.format(prob01) + ") AXIOM "
                                 + idx02 + "(" + form_0d00.format(prob02) + ")");
            paramFileName = outputFolderName + File.separator + paramFolderName + File.separator
                                       + "A" + form_000.format(idx01)
                                       + "_P" + form_0d00.format(prob01)
                                       + "_A" + form_000.format(idx02)
                                       + "_P" + form_0d00.format(prob02) + "_param.txt";
            try {
              parameters=new ParameterDatabase(new File(paramFileName).getAbsoluteFile());
            }
            catch(IOException ex) { ex.printStackTrace(); }  
            // set output file name
            outFileName = outputFolderName + File.separator + rawDataFolderName + File.separator
                                     + "A" + form_000.format(idx01)
                                     + "_P" + form_0d00.format(prob01)
                                     + "_A" + form_000.format(idx02)
                                     + "_P" + form_0d00.format(prob02);
            imgFileName = outputFolderName + File.separator + imageFolderName + File.separator
                                     + "A" + form_000.format(idx01)
                                     + "_P" + form_0d00.format(prob01)
                                     + "_A" + form_000.format(idx02)
                                     + "_P" + form_0d00.format(prob02);
            runSimulation(parameters, outFileName, imgFileName);
          }
        }
      }
    }

  } // end runParameterizedBatchPairwise()
  
  public void processRawDataPairwise(int culture, boolean specified, int spec01, int spec02) {
    
    String cultureType = "";
    if (culture == ExpManager.EMBEDDED) { cultureType = "_EMB"; }
    else if (culture == ExpManager.SUSPENSION) { cultureType = "_SUS"; }
    else if (culture == ExpManager.SURFACE) { cultureType = "_SUR"; }
    else if (culture == ExpManager.OVERLAY) { cultureType = "_OVE"; }
    else { 
      System.out.println("ERROR in ExpManager.processRawDataSingle() invalid culture: " + culture);
      return;
    }
    
    int rule01 = spec01;
    int rule02 = spec02;
    if (spec01 > spec02) {
      rule01 = spec02;
      rule02 = spec01;
    }
    for (int idx01 = 1; idx01 <= NUM_AXIOMS; idx01++) { // FOR#1: rules
      if (specified && idx01 != rule01) { continue; }
      for (double prob01 = MIN_PROB; prob01 <= MAX_PROB; prob01 += PROB_INCREMENT) { // FOR#2: probabilities
        for (int idx02 = idx01+1; idx02 <= NUM_AXIOMS; idx02++) {
          if (specified && idx02 != rule02) { continue; }
          for (double prob02 = MIN_PROB; prob02 <= MAX_PROB; prob02 += PROB_INCREMENT) {
            // temporary data placeholder
            double[][] dataArray = new double[DATA_COL_SIZE][NUM_STEPS];
            for (int i=0; i < DATA_COL_SIZE; i++) {
              for (int j=0; j < NUM_STEPS; j++) {
                dataArray[i][j] = 0.0;
              }
            }
            for (int rep = 1; rep <= REPETITION; rep++) {
              String dataFileName = outputFolderName + File.separator
                                 + rawDataFolderName + File.separator
                                 + "A" + form_000.format(idx01)
                                 + "_P" + form_0d00.format(prob01)
                                 + "_A" + form_000.format(idx02)
                                 + "_P" + form_0d00.format(prob02)
                                 + "_Rep" + form_000.format(rep) + cultureType + ".txt";
              Scanner dataScan = null;
              try {
                dataScan = new Scanner(new BufferedReader(new FileReader(dataFileName)));
                int i = 0;
                int j = 0;
                while (dataScan.hasNext()) {
                  if (j == NUM_STEPS) { break; }
                  dataArray[i][j] += dataScan.nextDouble();
                  i++;
                  if (i == DATA_COL_SIZE) { i = 0; j++; }
                }
              }
              catch (IOException ex){ ex.printStackTrace(); }
              if (dataScan!= null) { dataScan.close(); }
            }
            
            String outFileName = outputFolderName + File.separator
                              + summaryFolderName + File.separator
                              + "A" + form_000.format(idx01)
                              + "_P" + form_0d00.format(prob01)
                              + "_A" + form_000.format(idx02)
                              + "_P" + form_0d00.format(prob02) + cultureType + "_Avg.txt";
            BufferedWriter outFile  = null;
            try {
              outFile = new BufferedWriter(new FileWriter(outFileName));
              for (int j = 0; j < NUM_STEPS; j++) {
                for (int i = 0; i < DATA_COL_SIZE; i++) {
                  dataArray[i][j] = dataArray[i][j] / ((double)REPETITION); // average
                  outFile.write(dataArray[i][j] + "\t");
                }
                outFile.newLine();
              }
              if (outFile != null) { outFile.close(); }
            } catch (IOException ex) { ex.printStackTrace(); }
            
          }
        }
      }
    }
    
  } // end processRawDataPairwise()
  /*
  public void transferSummaryToExcelPairwise(boolean specified, int spec01, int spec02) {
    int rule01 = spec01;
    int rule02 = spec02;
    if (spec01 > spec02) {
      rule01 = spec02;
      rule02 = spec01;
    }
    try {
      for (int idx01 = 1; idx01 <= NUM_AXIOMS; idx01++) {
        if (specified && idx01 != rule01) { continue; }
        for (int idx02 = idx01 + 1; idx02 <= NUM_AXIOMS; idx02++) {
          if (specified && idx02 != rule02) { continue; }
          // transfer simulation output to Excel spreadsheet
          String outFileName = outputFolderName + File.separator + excelFolderName + File.separator
                                 + "SimResults_AXIOMS_" + form_000.format(idx01)
                                 + "_" + form_000.format(idx02) + ".xls";
          WritableWorkbook resultWorkbook = Workbook.createWorkbook(new File(outFileName));
          String workSheetName = "Summary";
          String wsDesc = "Axioms " + idx01 + " & " + idx02;
          WritableSheet resultSheet = resultWorkbook.createSheet(workSheetName, 0);
          resultSheet.addCell(new Label(0,0,workSheetName));
          resultSheet.addCell(new Label(0,1,wsDesc));
          resultSheet.addCell(new Label(0,3,"Step"));
          for (int step = 0; step < NUM_STEPS; step++) {
            jxl.write.Number snum = new jxl.write.Number(0, (step + 4), step);
            resultSheet.addCell(snum);
          }
          int iter_col = 2;
          for (double prob01 = MIN_PROB; prob01 <= MAX_PROB; prob01 += PROB_INCREMENT) {
            for (double prob02 = MIN_PROB; prob02 <= MAX_PROB; prob02 += PROB_INCREMENT) {
              String pstr = "Axiom " + idx01 + " (p=" + form_0d00.format(prob01) + "); "
                          + "Axiom " + idx02 + " (p=" + form_0d00.format(prob02) + ")";
              resultSheet.addCell(new Label(iter_col, 2, pstr));
              resultSheet.addCell(new Label(iter_col, 3, "Emb"));
              resultSheet.addCell(new Label(iter_col+1, 3, "Sus"));
              resultSheet.addCell(new Label(iter_col+2, 3, "Sur"));
              resultSheet.addCell(new Label(iter_col+3, 3, "Ove"));
              String avgFileName = outputFolderName + File.separator
                                + summaryFolderName + File.separator
                                + "A" + form_000.format(idx01)
                                + "_P" + form_0d00.format(prob01)
                                + "_A" + form_000.format(idx02)
                                + "_P" + form_0d00.format(prob02)
                                + "_Avg.txt";
              Scanner avgScan = null;
              avgScan = new Scanner(new BufferedReader(new FileReader(avgFileName)));
              int row = 4;
              int col = iter_col;
              while (avgScan.hasNext()) {
                if (row == NUM_STEPS + 4) { break; }
                resultSheet.addCell(new jxl.write.Number(col, row, avgScan.nextDouble()));
                col++;
                if (col == iter_col + 4) { col = iter_col; row++; }
              }
              iter_col += 5;
              if (avgScan!= null) { avgScan.close(); }
            }
          }
          resultWorkbook.write();
          resultWorkbook.close();
        }
      }
    }
    catch (IOException ex) { ex.printStackTrace(); }
    catch (jxl.write.WriteException wx) { wx.printStackTrace(); }
    
  }
  // end transferSummaryToExcelPairwise()
  */
  
  /*
  public void dataAnalysisPairwise() {
    
    DecimalFormat dform = new DecimalFormat("0.00");
    DecimalFormat iform = new DecimalFormat("000");
    DecimalFormat mform = new DecimalFormat("00");
    
    for (int ang=1; ang <= 2; ang++) { // FOR#4: analogues
      for (int idx=1; idx <= NUM_AXIOMS; idx++) { // FOR#1: rules
        for (int pdx=idx+1; pdx <= NUM_AXIOMS; pdx++) {
          if (idx==5 && pdx==6) {
            // extract average values of normal output
            double[][] avgArray = new double[4][NUM_STEPS];
            for (int i=0; i < 4; i++) {
              for (int j=0; j < NUM_STEPS; j++) {
                avgArray[i][j] = 0.0;
              }
            }
            String avgFileName = "output" + File.separator
                               + "model" + mform.format(ang)
                               + "_rule" + iform.format(idx)
                               + "_prob" + dform.format(1.00)
                               + "_rule" + iform.format(pdx)
                               + "_prob" + dform.format(1.00)
                               + "_avg.txt";
            Scanner avgScan = null;
            try {
              avgScan = new Scanner(new BufferedReader(new FileReader(avgFileName)));
              int i = 0;
              int j = 0;
              while (avgScan.hasNext()) {
                if (j == NUM_STEPS) { break; }
                avgArray[i][j] += avgScan.nextDouble();
                i++;
                if (i == 4) { i = 0; j++; }
              }
            }
            catch (FileNotFoundException ex) {
              ex.printStackTrace();
            }
            catch (IOException ex){
              ex.printStackTrace();
            }
            if (avgScan!= null) { avgScan.close(); }
          
            // calculate standard deviation values of normal output
            double[][] sdArray = new double[4][NUM_STEPS];
            for (int i=0; i < 4; i++) {
              for (int j=0; j < NUM_STEPS; j++) {
                sdArray[i][j] = 0.0;
              }
            }
            for (int rep=1; rep <= REPETITION; rep++) {
              String sdFileName = "rawdata" + File.separator
                                + "model" + mform.format(ang)
                                + "_rule" + iform.format(idx)
                                + "_prob" + dform.format(1.00)
                                + "_rule" + iform.format(pdx)
                                + "_prob" + dform.format(1.00)
                                + "_rep" + iform.format(rep) + "_out.txt";
              Scanner sdScan = null;
              try {
                sdScan = new Scanner(new BufferedReader(new FileReader(sdFileName)));
                int i = 0;
                int j = 0;
                while (sdScan.hasNext()) {
                  if (j == NUM_STEPS) { break; }
                  sdArray[i][j] += Math.pow((avgArray[i][j] - sdScan.nextDouble()), 2.0);
                  i++;
                  if (i == 4) { i = 0; j++; }
                }
              }
              catch (FileNotFoundException ex) {
                ex.printStackTrace();
              }
              catch (IOException ex){
                ex.printStackTrace();
              }
              if (sdScan!= null) { sdScan.close(); }
            }
            for (int i=0; i<4; i++) {
              for (int j=0; j<NUM_STEPS; j++) {
                sdArray[i][j] = Math.sqrt(sdArray[i][j] / (((double)REPETITION) - 1.0));
              }
            }
          
            // compare time series points with the 'normal' curve
            for (double prob=MIN_PROB; prob <= MAX_PROB; prob+=PROB_INCREMENT) { // FOR#2: probabilities
              for (double ppb=MIN_PROB; ppb <= MAX_PROB; ppb+=PROB_INCREMENT) {
                // temporary data placeholder
                int[][] compArray = new int[4][NUM_STEPS];
                for (int i=0; i < 4; i++) {
                  for (int j=0; j < NUM_STEPS; j++) {
                    compArray[i][j] = 0;
                  }
                }
                // for each repetition, test if the points lie within 1 sd of the mean
                for (int rep=1;rep <=REPETITION;rep++) { // FOR#3: repetitions
                  String compFileName = "rawdata" + File.separator
                                      + "model" + mform.format(ang)
                                      + "_rule" + iform.format(idx)
                                      + "_prob" + dform.format(prob)
                                      + "_rule" + iform.format(pdx)
                                      + "_prob" + dform.format(ppb)
                                      + "_rep" + iform.format(rep) + "_out.txt";
                  Scanner compScan = null;
                  try {
                    compScan = new Scanner(new BufferedReader(new FileReader(compFileName)));
                    int i = 0;
                    int j = 0;
                    while (compScan.hasNext()) {
                      if (j == NUM_STEPS) { break; }
                      double mean = avgArray[i][j];
                      double sd = sdArray[i][j];
                      double curVal = compScan.nextDouble();
                      if ( (mean - sd) <= curVal && curVal <= (mean + sd) ) {
                        compArray[i][j]++;
                      }
                      i++;
                      if (i == 4) { i = 0; j++; }
                    }
                  }
                  catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                  }
                  catch (IOException ex){
                    ex.printStackTrace();
                  }
                  if (compScan!= null) { compScan.close(); }

                } // end FOR#3: repetitions
          
                // total the number of points inside & outside the sd range
                int col_01_tot = 0;
                int col_02_tot = 0;
                int col_03_tot = 0;
                int col_04_tot = 0;
                for (int j = 0; j < NUM_STEPS; j++) {
                  col_01_tot += compArray[0][j];
                  col_02_tot += compArray[1][j];
                  col_03_tot += compArray[2][j];
                  col_04_tot += compArray[3][j];
                }
                String outFileName = "analysis" + File.separator
                                   + "model" + mform.format(ang)
                                   + "_rule" + iform.format(idx)
                                   + "_prob" + dform.format(prob)
                                   + "_rule" + iform.format(pdx)
                                   + "_prob" + dform.format(ppb)
                                   + ".txt";
                BufferedWriter outFile  = null;
                try {
                  outFile = new BufferedWriter(new FileWriter(outFileName));

                  outFile.write((col_01_tot * 100.0 / ((double)(REPETITION * NUM_STEPS))) + "\t");
                  outFile.write((col_02_tot * 100.0 / ((double)(REPETITION * NUM_STEPS))) + "\t");
                  outFile.write((col_03_tot * 100.0 / ((double)(REPETITION * NUM_STEPS))) + "\t");
                  outFile.write((col_04_tot * 100.0 / ((double)(REPETITION * NUM_STEPS))) + "\n");
                  
                  if (outFile != null) { outFile.close(); }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
              }
            }
          }
        } // end FOR#2: probabilities
      } // end FOR#1: rules
    } // end FOR#4: analogues
    
  } // end dataAnalysisPairwise()
  */

  /*
  public void transferAnalysisToExcelPairwise() {
    DecimalFormat dform = new DecimalFormat("0.00");
    DecimalFormat iform = new DecimalFormat("000");
    DecimalFormat mform = new DecimalFormat("00");
    
    try {
      for (int idx=1; idx <= NUM_AXIOMS; idx++) {
        for (int pdx=idx+1; pdx <= NUM_AXIOMS; pdx++) {
            if (idx==6 && pdx==8) {
              // transfer simulation output to Excel spreadsheet
              String outFileName = "excel_out" + File.separator
                                 + "SimAnalysis_AXIOMS_" + iform.format(idx)
                                 + "_" + iform.format(pdx) + ".xls";
              WritableWorkbook resultWorkbook = Workbook.createWorkbook
                                                    (new File(outFileName));
              for (int ang=1; ang <= 2; ang++) {
                String mstr = "Analog_" + ang;
                String desc = "Axioms " + idx + " & " + pdx;
                WritableSheet resultSheet = resultWorkbook.createSheet(mstr, ang);
                resultSheet.addCell(new Label(0,0,mstr));
                resultSheet.addCell(new Label(0,1,desc));
                resultSheet.addCell(new Label(3,3,"Embedded"));
                resultSheet.addCell(new Label(3,13,"Suspension"));
                resultSheet.addCell(new Label(3,23,"Surface"));
                resultSheet.addCell(new Label(3,33,"Overlay"));
                for (int num=4; num<=34; num+=10) {
                  resultSheet.addCell(new Label(0,num+1,("Axiom " + idx)));
                  resultSheet.addCell(new Label(1,num,("Axiom " + pdx)));
                }
                double dnum = 0.0;
                for (int num=1; num<=6; num++) {
                  resultSheet.addCell(new jxl.write.Number(num, 5, dnum));
                  resultSheet.addCell(new jxl.write.Number(num, 15, dnum));
                  resultSheet.addCell(new jxl.write.Number(num, 25, dnum));
                  resultSheet.addCell(new jxl.write.Number(num, 35, dnum));
                  dnum += 0.2;
                }
                dnum = 0.0;
                for (int num=6; num<=11; num++) {
                  resultSheet.addCell(new jxl.write.Number(0, num, dnum));
                  resultSheet.addCell(new jxl.write.Number(0, num+10, dnum));
                  resultSheet.addCell(new jxl.write.Number(0, num+20, dnum));
                  resultSheet.addCell(new jxl.write.Number(0, num+30, dnum));
                  dnum += 0.2;
                }               
                int col = 1;
                int row = 6;
                for (double prob=MIN_PROB; prob <= MAX_PROB; prob+=PROB_INCREMENT) {
                  for (double ppb=MIN_PROB; ppb <= MAX_PROB; ppb+=PROB_INCREMENT) {
                    String analysisFileName = "analysis" + File.separator
                                       + "model" + mform.format(ang)
                                       + "_rule" + iform.format(idx)
                                       + "_prob" + dform.format(prob)
                                       + "_rule" + iform.format(pdx)
                                       + "_prob" + dform.format(ppb)
                                       + ".txt";
                    Scanner analysisScan = null;
                    analysisScan = new Scanner(new BufferedReader(new FileReader(analysisFileName)));
                    resultSheet.addCell(new jxl.write.Number(col,row,analysisScan.nextDouble()));
                    resultSheet.addCell(new jxl.write.Number(col,row+10,analysisScan.nextDouble()));
                    resultSheet.addCell(new jxl.write.Number(col,row+20,analysisScan.nextDouble()));
                    resultSheet.addCell(new jxl.write.Number(col,row+30,analysisScan.nextDouble()));
                    if (analysisScan != null) { analysisScan.close(); }
                    col++;
                  }
                  col = 1;
                  row++;
                }
              }
              resultWorkbook.write();
              resultWorkbook.close();
            }
          }
        }
      }      
      catch (IOException ex) {
        ex.printStackTrace();
      }
      catch (jxl.write.WriteException wx) {
        wx.printStackTrace();
      }
    
  }
  // end transferAnalysisToExcelPairwise()
   */
  
/* ====================== END DOUBLE AXIOM VERSION ======================== */
  
}
