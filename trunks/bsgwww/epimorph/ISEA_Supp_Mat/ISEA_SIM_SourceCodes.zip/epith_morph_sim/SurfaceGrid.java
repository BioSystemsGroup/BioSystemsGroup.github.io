
package epith_morph_sim;

import sim.field.grid.ObjectGrid2D;

public class SurfaceGrid extends ObjectGrid2D {

	/**
	 * @param width
	 * @param height
	 */
	public SurfaceGrid(int width, int height) {
		super(width, height);
		//populate the embedded grid with matrix
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
			    if(j <= height/2) {
			        this.set(i,j,new FreeSpace(i,j,this));
			    } else {
				this.set(i, j, new Matrix(i, j, this));
			    }
			}
		}
		// TODO Auto-generated constructor stub
	}

}
