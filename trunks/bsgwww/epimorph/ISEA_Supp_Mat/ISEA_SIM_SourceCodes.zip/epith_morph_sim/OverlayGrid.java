
package epith_morph_sim;

import sim.field.grid.ObjectGrid2D;

public class OverlayGrid extends ObjectGrid2D {
	/**
	 * 
	 */
	public OverlayGrid(int x, int y) {
		super(x,y);
		// TODO Auto-generated constructor stub
		//populate the overlay grid with matrix
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				this.set(i, j, new Matrix(i, j, this));
			}
		}
	}

}
