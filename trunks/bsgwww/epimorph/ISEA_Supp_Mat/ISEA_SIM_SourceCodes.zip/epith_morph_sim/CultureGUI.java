package epith_morph_sim;

import java.io.*;
import sim.display.*;
import sim.engine.*;
import sim.portrayal.grid.*;
import sim.portrayal.simple.*;
import ec.util.*;

public class CultureGUI extends GUIState {
  
  public boolean show_embedded = true;
  public boolean show_surface = true;
  public boolean show_suspension = true;
  public boolean show_overlay = true;
  
  public Display2D overlayDisplay, embeddedDisplay, suspensionDisplay,surfaceDisplay;
  public javax.swing.JFrame overlayFrame, embeddedFrame, suspensionFrame,surfaceFrame;
  public HexaObjectGridPortrayal2D overlayPortrayal = new HexaObjectGridPortrayal2D();
  public HexaObjectGridPortrayal2D embeddedPortrayal = new HexaObjectGridPortrayal2D();
  public HexaObjectGridPortrayal2D suspensionPortrayal = new HexaObjectGridPortrayal2D();
  public HexaObjectGridPortrayal2D surfacePortrayal = new HexaObjectGridPortrayal2D();

  public void setEmbeddedOn(boolean status) {
    show_embedded = status;
  }
  public void setSuspensionOn(boolean status) {
    show_suspension = status;
  }
  public void setSurfaceOn(boolean status) {
    show_surface = status;
  }
  public void setOverlayOn(boolean status) {
    show_overlay = status;
  }
  
  public CultureGUI(ParameterDatabase params) {
    super(new Culture(new MersenneTwisterFast(), new Schedule(), params));
  }
  public CultureGUI(SimState state) {
    super(state);
  }
  public CultureGUI() {
    super(new Culture(new MersenneTwisterFast(),new Schedule()));
  }

  public Object getSimulationInspectedObject() {
    return state;
  } // non-volatile

  public void start() {
    super.start();
    setupPortrayals();
  } // end start()

  public void load(SimState state) {
    super.load(state);
    // we now have new grids. Set up the portrayals to reflect that
    setupPortrayals();
  } // end load()

  // This is called by start() and by load() because they both had this code
  // so I didn't have to type it twice :-)
  public void setupPortrayals() {
    // tell the portrayals what to portray and how to portray them
    HexagonalPortrayal2D cellPortrayal = new HexagonalPortrayal2D(java.awt.Color.gray);       
    HexagonalPortrayal2D polarizedCellPortrayal = new HexagonalPortrayal2D(java.awt.Color.red);
    HexagonalPortrayal2D malignantCellPortrayal = new HexagonalPortrayal2D(java.awt.Color.orange);
    HexagonalPortrayal2D lumenPortrayal = new HexagonalPortrayal2D(java.awt.Color.black);
    HexagonalPortrayal2D matrixPortrayal = new HexagonalPortrayal2D(java.awt.Color.white);

    embeddedPortrayal.setField(((Culture)state).embeddedGrid);
    embeddedPortrayal.setPortrayalForClass(ISEA1_Cell.class,cellPortrayal);
    embeddedPortrayal.setPortrayalForClass(ISEA1_PCell.class,polarizedCellPortrayal);
    embeddedPortrayal.setPortrayalForClass(ISEA2_Cell.class,cellPortrayal);
    embeddedPortrayal.setPortrayalForClass(ISEA2_PCell.class,polarizedCellPortrayal);
    embeddedPortrayal.setPortrayalForClass(FreeSpace.class,lumenPortrayal);
    embeddedPortrayal.setPortrayalForClass(Matrix.class,matrixPortrayal);

    suspensionPortrayal.setField(((Culture)state).suspensionGrid);
    suspensionPortrayal.setPortrayalForClass(ISEA1_Cell.class,cellPortrayal);
    suspensionPortrayal.setPortrayalForClass(ISEA1_PCell.class,polarizedCellPortrayal);
    suspensionPortrayal.setPortrayalForClass(ISEA2_Cell.class,cellPortrayal);
    suspensionPortrayal.setPortrayalForClass(ISEA2_PCell.class,polarizedCellPortrayal);
    suspensionPortrayal.setPortrayalForClass(FreeSpace.class,lumenPortrayal);
    suspensionPortrayal.setPortrayalForClass(Matrix.class,matrixPortrayal);
    
    overlayPortrayal.setField(((Culture)state).overlayGrid);
    overlayPortrayal.setPortrayalForClass(ISEA1_Cell.class,cellPortrayal);
    overlayPortrayal.setPortrayalForClass(ISEA1_PCell.class,polarizedCellPortrayal);
    overlayPortrayal.setPortrayalForClass(ISEA2_Cell.class,cellPortrayal);
    overlayPortrayal.setPortrayalForClass(ISEA2_PCell.class,polarizedCellPortrayal);
    overlayPortrayal.setPortrayalForClass(FreeSpace.class,lumenPortrayal);
    overlayPortrayal.setPortrayalForClass(Matrix.class,matrixPortrayal);
    
    surfacePortrayal.setField(((Culture)state).surfaceGrid);
    surfacePortrayal.setPortrayalForClass(ISEA1_Cell.class,cellPortrayal);
    surfacePortrayal.setPortrayalForClass(ISEA1_PCell.class,polarizedCellPortrayal);
    surfacePortrayal.setPortrayalForClass(ISEA2_Cell.class,cellPortrayal);
    surfacePortrayal.setPortrayalForClass(ISEA2_PCell.class,polarizedCellPortrayal);
    surfacePortrayal.setPortrayalForClass(FreeSpace.class,lumenPortrayal);
    surfacePortrayal.setPortrayalForClass(Matrix.class,matrixPortrayal);
    
    embeddedDisplay.reset();
    embeddedDisplay.repaint();
    suspensionDisplay.reset();
    suspensionDisplay.repaint();
    surfaceDisplay.reset();
    surfaceDisplay.repaint();
    overlayDisplay.reset();
    overlayDisplay.repaint();
  } // end setupPortrayals()
  
  public void init(Controller c) {
    super.init(c);
    embeddedDisplay = new Display2D(400,400,this,1);
    embeddedFrame = embeddedDisplay.createFrame();
    c.registerFrame(embeddedFrame);
    embeddedFrame.setVisible(show_embedded);
    embeddedDisplay.attach(embeddedPortrayal,"embedded");
    embeddedDisplay.setBackdrop(java.awt.Color.white);
    embeddedFrame.setLocation(300,0);
    
    suspensionDisplay = new Display2D(400,400,this,1);
    suspensionFrame = suspensionDisplay.createFrame();
    c.registerFrame(suspensionFrame);
    suspensionFrame.setVisible(show_suspension);
    suspensionDisplay.attach(suspensionPortrayal,"suspension");
    suspensionDisplay.setBackdrop(java.awt.Color.black);
    suspensionFrame.setLocation(0,300);
    
    surfaceDisplay = new Display2D(400,400,this,1);
    surfaceFrame = surfaceDisplay.createFrame();
    c.registerFrame(surfaceFrame);
    surfaceFrame.setVisible(show_surface);
    surfaceDisplay.attach(surfacePortrayal,"surface");
    surfaceDisplay.setBackdrop(java.awt.Color.white);
    surfaceFrame.setLocation(600,0);
    
    overlayDisplay = new Display2D(400,400,this,1);
    overlayFrame = overlayDisplay.createFrame();
    c.registerFrame(overlayFrame);
    overlayFrame.setVisible(show_overlay);
    overlayDisplay.attach(overlayPortrayal,"overlay");
    overlayDisplay.setBackdrop(java.awt.Color.white);
    overlayFrame.setLocation(300,300);
  } // end init()
  
  public void quit() {
    super.quit();
    if(embeddedFrame != null) {
      embeddedFrame.dispose();
    }
    embeddedFrame = null;
    embeddedDisplay = null;
    if(surfaceFrame != null) {
      surfaceFrame.dispose();
    }
    surfaceFrame = null;
    surfaceDisplay = null;
    if(suspensionFrame != null) {
      suspensionFrame.dispose();
    }
    suspensionFrame = null;
    suspensionDisplay = null;
    if(overlayFrame != null) {
      overlayFrame.dispose();
    }
    overlayFrame = null;
    overlayDisplay = null;
  } // end quit()
}
