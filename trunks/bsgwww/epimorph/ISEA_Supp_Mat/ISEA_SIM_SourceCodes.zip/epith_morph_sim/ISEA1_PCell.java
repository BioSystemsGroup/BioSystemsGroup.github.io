package epith_morph_sim;

import sim.engine.SimState;
import sim.field.grid.ObjectGrid2D;
import sim.util.Properties;
import sim.util.*;
import ec.util.*;
import java.io.*;

public class ISEA1_PCell extends ISEA1_Cell {
  
  public ISEA1_PCell(int x, int y, ObjectGrid2D grid) {
    super(x, y, grid);
  }
  
  public ISEA1_PCell(int x, int y, ObjectGrid2D grid, ParameterDatabase params) {
    super(x, y, grid);
    this.paramDB = params;
    this.loadParams();
  }
  
  public void step(SimState s) {
    if (culture_type < ExpManager.EMBEDDED || culture_type > ExpManager.OVERLAY) {
      this.identifyCultureType();
    }
    if (depolarizingEnvironment()) {
      Culture.updateAxiomUsage(culture_type, 18);
      ISEA1_Cell newCell = new ISEA1_Cell(this.x,this.y, this.grid, paramDB);
      newCell.setCultureType(culture_type);
      grid.set(this.x, this.y, newCell);
      newCell.step(s);
    }
    else {
      IntBag xPositions = new IntBag();
      IntBag yPositions = new IntBag();
      Bag neighbors = new Bag();
      Bag matrixNeighbors = new Bag();
      Bag lumenNeighbors = new Bag();
      Bag cellNeighbors = new Bag();

      grid.getNeighborsHexagonalDistance
              (this.x, this.y, radius, ExpManager.TOROIDAL, neighbors, xPositions, yPositions);
      neighbors.remove(this);
      
      for (int i = 0; i < neighbors.numObjs; i++) {
        Agent neighbor = (Agent) neighbors.get(i);
        if (neighbor instanceof ISEA1_Cell) {
          cellNeighbors.add(neighbor);
        }
        else if (neighbor instanceof Matrix) {
          matrixNeighbors.add(neighbor);
        }
        else if (neighbor instanceof FreeSpace) {
          lumenNeighbors.add(neighbor);
        }
      }
      
      //reschedule self
      s.schedule.scheduleOnce(this);
    }
  } // end step()

} // end class PCell
