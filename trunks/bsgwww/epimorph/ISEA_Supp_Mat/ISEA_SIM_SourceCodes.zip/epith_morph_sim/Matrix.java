
package epith_morph_sim;

import sim.engine.SimState;
import sim.field.grid.ObjectGrid2D;

public class Matrix extends Agent {

	public Matrix(int x, int y,ObjectGrid2D grid) {
super(x,y,grid);
	}
	/* (non-Javadoc)
	 * @see sim.engine.Steppable#step(sim.engine.SimState)
	 */
	public void step(SimState state) {
		// TODO Auto-generated method stub

	}

}
