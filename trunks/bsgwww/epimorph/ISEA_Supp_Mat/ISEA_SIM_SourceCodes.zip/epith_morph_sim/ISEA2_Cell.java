package epith_morph_sim;

import java.io.*;
import sim.engine.*;
import sim.util.*;
import sim.field.grid.ObjectGrid2D;
import ec.util.*;

public class ISEA2_Cell extends Cell {
  
  int culture_type = 0;
  boolean dead = false;
  int age = 0;
  int divisionNum = 0;
  public static final int radius = 1;
  
  // 1->divide to any non-cell space; 2->any free space; 3->free space next to matrix; 4->any matrix
  int axiom_008_var = 3;
  
  double axiom001_prob = 1.0;
  double axiom002_prob = 1.0;
  double axiom003_prob = 1.0;
  double axiom004_prob = 1.0;
  double axiom005_prob = 1.0;
  double axiom006_prob = 1.0;
  double axiom007_prob = 1.0;
  double axiom008_prob = 1.0;
  double axiom009_prob = 1.0;
  double axiom010_prob = 1.0;
  double axiom011_prob = 1.0;
  double axiom012_prob = 1.0;

  
  MersenneTwisterFast random_func = null;
  
  public void setCultureType(int type) {
    culture_type = type;
  }
  public int getCultureType() {
    return culture_type;
  }
  
  public int getDivisionNum () {
    return divisionNum;
  }
  
  public void die() {
    this.dead = true;
  }

  // parameterization items (setters/getters and more)
  ParameterDatabase paramDB = null;
  public double getAxiom001Prob() { return axiom001_prob; }
  public void setAxiom001Prob ( double prob ) { if( prob >= 0.0 ) axiom001_prob = prob; }
  public double getAxiom002Prob() { return axiom002_prob; }
  public void setAxiom002Prob ( double prob ) { if( prob >= 0.0 ) axiom002_prob = prob; }
  public double getAxiom003Prob() { return axiom003_prob; }
  public void setAxiom003Prob ( double prob ) { if( prob >= 0.0 ) axiom003_prob = prob; }
  public double getAxiom004Prob() { return axiom004_prob; }
  public void setAxiom004Prob ( double prob ) { if( prob >= 0.0 ) axiom004_prob = prob; }
  public double getAxiom005Prob() { return axiom005_prob; }
  public void setAxiom005Prob ( double prob ) { if( prob >= 0.0 ) axiom005_prob = prob; }
  public double getAxiom006Prob() { return axiom006_prob; }
  public void setAxiom006Prob ( double prob ) { if( prob >= 0.0 ) axiom006_prob = prob; }
  public double getAxiom007Prob() { return axiom007_prob; }
  public void setAxiom007Prob ( double prob ) { if( prob >= 0.0 ) axiom007_prob = prob; }
  public double getAxiom008Prob() { return axiom008_prob; }
  public void setAxiom008Prob ( double prob ) { if( prob >= 0.0 ) axiom008_prob = prob; }
  public double getAxiom009Prob() { return axiom009_prob; }
  public void setAxiom009Prob ( double prob ) { if( prob >= 0.0 ) axiom009_prob = prob; }
  public double getAxiom010Prob() { return axiom010_prob; }
  public void setAxiom010Prob ( double prob ) { if( prob >= 0.0 ) axiom010_prob = prob; }
  public double getAxiom011Prob() { return axiom011_prob; }
  public void setAxiom011Prob ( double prob ) { if( prob >= 0.0 ) axiom011_prob = prob; }
  public double getAxiom012Prob() { return axiom012_prob; }
  public void setAxiom012Prob ( double prob ) { if( prob <= 0.0 ) axiom012_prob = prob; }
  
  void loadParams() {
    if(paramDB == null)
      return;
    Parameter param;
    long seed;
    String s = paramDB.getString(param = new Parameter(ExpManager.P_SEED), null);
    if (s.equalsIgnoreCase(ExpManager.V_TIME)) { seed = System.currentTimeMillis(); }
    else { seed = paramDB.getLong(param); }
    random_func.setSeed(seed);
    
    Properties p = Properties.getProperties(this,false,true,false);
    for(int i=0; i< p.numProperties(); i++) {
      if (p.isReadWrite(i) && !p.isComposite(i) && paramDB.exists(new Parameter(p.getName(i)))) {
        Parameter pa = new Parameter(p.getName(i));
        String value = paramDB.getString(pa,null);
        p.setValue(i,value);
      }
    }
  } // end loadParams()
  
  public ISEA2_Cell(int x, int y, ObjectGrid2D grid) {
    super(x, y, grid);
    divisionNum = 0;
    random_func = new MersenneTwisterFast(System.currentTimeMillis());
  }
  
  public ISEA2_Cell(int x, int y, ObjectGrid2D grid, ParameterDatabase params) {
    super(x, y, grid);
    random_func = new MersenneTwisterFast(System.currentTimeMillis());
    this.paramDB = params;
    divisionNum = 0;
    loadParams();
  }
  
  public void step(SimState state) {
    if (!this.dead) {
      if (culture_type < ExpManager.EMBEDDED || culture_type > ExpManager.OVERLAY) {
        this.identifyCultureType();
      }
      /*
      System.out.println(axiom001_prob + "  " + axiom002_prob + "  "
                 + axiom003_prob + "  " + axiom004_prob + "  " 
                 + axiom005_prob + "  " + axiom006_prob + "  "
                 + axiom007_prob + "  " + axiom008_prob);
      */
      
      Culture model = (Culture) state;
      IntBag xPositions = new IntBag();
      IntBag yPositions = new IntBag();
      Bag neighbors = new Bag();
      Bag matrixNeighbors = new Bag();
      Bag lumenNeighbors = new Bag();
      Bag cellNeighbors = new Bag();

      // Generate a random number from [0.0, 1.0)
      double random_val = random_func.nextDouble();
            
      grid.getNeighborsHexagonalDistance
              (this.x, this.y, radius, ExpManager.TOROIDAL, neighbors, xPositions, yPositions);
      neighbors.remove(this);

      for (int i = 0; i < neighbors.numObjs; i++) {
        Agent neighbor = (Agent) neighbors.get(i);
        if (neighbor instanceof ISEA2_Cell) {
          cellNeighbors.add(neighbor);
        }
        else if (neighbor instanceof Matrix) {
          matrixNeighbors.add(neighbor);
        }
        else if (neighbor instanceof FreeSpace) {
          lumenNeighbors.add(neighbor);
        }
      }
      
      // AXIOM 001
      if (matrixNeighbors.numObjs == 0 && lumenNeighbors.numObjs == 0) {
        //cell only
        Culture.updateAxiomUsage(culture_type, 0);
        if (axiom001_prob > random_val) {
          Culture.updateAxiomUsage(culture_type, 1);
          this.dead = true;
          grid.set(this.x, this.y, new FreeSpace(this.x, this.y, grid));
        }
      }
      // AXIOM 002
      else if (cellNeighbors.numObjs == 0 && matrixNeighbors.numObjs == 0) {
        //lumen only
        Culture.updateAxiomUsage(culture_type, 2);
        if (axiom002_prob > random_val) {
          Culture.updateAxiomUsage(culture_type, 3);
          this.dead = true;
          grid.set(this.x, this.y, new FreeSpace(this.x, this.y, grid));
        }
      }
      // AXIOM 003
      else if (cellNeighbors.numObjs == 0 && lumenNeighbors.numObjs == 0) {
        //matrix only
        Culture.updateAxiomUsage(culture_type, 4);
        if (axiom003_prob > random_val) {
          Culture.updateAxiomUsage(culture_type, 5);
          int r = model.random.nextInt(neighbors.numObjs);
          Agent neighbor = (Agent) neighbors.get(r);
          ISEA2_Cell newCell = new ISEA2_Cell(neighbor.x, neighbor.y, grid, paramDB);
          newCell.setCultureType(culture_type);
          model.schedule.scheduleOnce(newCell);
          grid.set(neighbor.x, neighbor.y, newCell);
          divisionNum++;
        }
      }
      // AXIOM 004 and AXIOM 005
      else if (matrixNeighbors.numObjs == 0 && cellNeighbors.numObjs > 0 && lumenNeighbors.numObjs > 0) {
        // cell + lumen
        // AXIOM 004
        if (cellNeighbors.numObjs == 1) {
          Culture.updateAxiomUsage(culture_type, 6);
          if (axiom004_prob > random_val) {
            Culture.updateAxiomUsage(culture_type, 7);
            Matrix m = new Matrix(this.x, this.y, grid);
            grid.set(m.x, m.y, m);
            ISEA2_Cell neighborCell = (ISEA2_Cell) cellNeighbors.get(0);
            int xDiff = neighborCell.x - this.x;
            int yDiff = neighborCell.y - this.y;
            int newX = -xDiff + this.x;
            int newY = -yDiff + this.y;
            int finalX = grid.tx(newX);
            int finalY = grid.ty(newY);
            grid.set(finalX, finalY, this);
            this.x = finalX;
            this.y = finalY;
          }
        }
        // AXIOM 005
        else {
          Culture.updateAxiomUsage(culture_type, 8);
          if (axiom005_prob > random_val) {
            Culture.updateAxiomUsage(culture_type, 9);
            this.dead = true;
            FreeSpace newLumen = new FreeSpace(this.x, this.y, grid);
            grid.set(this.x, this.y, newLumen);
          }
        }
      }
      // AXIOM 006
      else if (lumenNeighbors.numObjs == 0 && cellNeighbors.numObjs > 0 && matrixNeighbors.numObjs > 0) {
        // cell + matrix
        Culture.updateAxiomUsage(culture_type, 10);
        if (axiom006_prob > random_val) {
          Culture.updateAxiomUsage(culture_type, 11);
          Bag bestMatrixNeighbors = new Bag();
          int bestCellNeighborCount = 0;
          for (int i = 0; i < matrixNeighbors.numObjs; i++) {
            Matrix matrixAgent = (Matrix) matrixNeighbors.get(i);
            int cellNeighborCount = 0;
            for (int j = 0; j < cellNeighbors.numObjs; j++) {
              ISEA2_Cell cellNeighbor = (ISEA2_Cell) cellNeighbors.get(j);
              if (areNeighbors(cellNeighbor, matrixAgent)) {
                cellNeighborCount += 1;
              }
            }
            if (cellNeighborCount > bestCellNeighborCount) {
              bestCellNeighborCount = cellNeighborCount;
              bestMatrixNeighbors = new Bag();
              bestMatrixNeighbors.add(matrixAgent);
            }
            else if (cellNeighborCount == bestCellNeighborCount) {
              bestMatrixNeighbors.add(matrixAgent);
            }
          }
          //replace the best matrix found with the daughter cell
          int r = model.random.nextInt(bestMatrixNeighbors.numObjs);
          Matrix m = (Matrix) bestMatrixNeighbors.get(r);
          ISEA2_Cell newCell = new ISEA2_Cell(m.x, m.y, grid, paramDB);
          newCell.setCultureType(culture_type);
          model.schedule.scheduleOnce(newCell);
          grid.set(m.x, m.y, newCell);
          divisionNum++;
        }
        else {
          /* place a daughter in a random matrix neighbor */
          int r = model.random.nextInt(matrixNeighbors.numObjs);
          Matrix m = (Matrix) matrixNeighbors.get(r);
          ISEA2_Cell newCell = new ISEA2_Cell(m.x, m.y, grid, paramDB);
          newCell.setCultureType(culture_type);
          model.schedule.scheduleOnce(newCell);
          grid.set(m.x, m.y, newCell);
          divisionNum++;
        }
      }
      // AXIOM 007*
      else if (cellNeighbors.numObjs == 0 && matrixNeighbors.numObjs > 0 && lumenNeighbors.numObjs > 0) {
        // matrix + lumen
        // AXIOM 011
        // do nothing; the cell doesn't want to replace its
        // lumen neighbor with a cell as it needs 3 surfaces
        if (lumenNeighbors.numObjs == 1) {
          Culture.updateAxiomUsage(culture_type, 22);
          if (axiom011_prob <= random_val) {
            // malfunction of AXIOM 011
          }
        }
        // AXIOM 007
        else {
          Culture.updateAxiomUsage(culture_type, 12);
          if (axiom007_prob > random_val) {
            Culture.updateAxiomUsage(culture_type, 13);
            //choose a lumen position that has a matrix neighbor
            Bag acceptableLumens = new Bag();
            for (int i = 0; i < lumenNeighbors.numObjs; i++) {
              FreeSpace l = (FreeSpace) lumenNeighbors.get(i);
              //find out if this Lumen has a matrix neighbor
              for (int j = 0; j < matrixNeighbors.numObjs; j++) {
                Matrix m = (Matrix) matrixNeighbors.get(j);
                if (areNeighbors(l, m)) {
                  acceptableLumens.add(l);
                }
              }
            }
            if (acceptableLumens.numObjs > 0) {
              int r = model.random.nextInt(acceptableLumens.numObjs);
              FreeSpace acceptableLumen = (FreeSpace) acceptableLumens.get(r);
              ISEA2_Cell newCell = new ISEA2_Cell(acceptableLumen.x, acceptableLumen.y, grid, paramDB);
              newCell.setCultureType(culture_type);
              model.schedule.scheduleOnce(newCell);
              grid.set(acceptableLumen.x, acceptableLumen.y, newCell);
              divisionNum++;
            }
          }
        }
      }
      // AXIOM 009
      else if (polarizingEnvironment()) {
        Culture.updateAxiomUsage(culture_type, 16);
        if (axiom009_prob > random_val) {
          Culture.updateAxiomUsage(culture_type, 17);
          ISEA2_PCell pCell = new ISEA2_PCell(this.x,this.y,this.grid, paramDB);
          pCell.setCultureType(culture_type);
          this.grid.set(pCell.x,pCell.y,pCell);
          this.dead = true; // taken out of schedule
          pCell.step(state);
        }
      }
      // AXIOM 008 and AXIOM 011
      else { //three component types are present.
             //place the daughter cell at a lumen location where it too
             //will have all three surfaces satisfied, but only if
             //it doesn't eliminate the current cell's only lumenal
             //surfaces. If neither of these is possible, don't divide.
        Bag acceptableNeighbors = new Bag();
        for (int k = 0; k < lumenNeighbors.numObjs; k++) {
          FreeSpace lumenNeighbor = (FreeSpace) lumenNeighbors.get(k);
          boolean hasMatrixNeighbor = false;
          boolean hasLumenNeighbor = false;
          for (int l = 0; l < matrixNeighbors.numObjs; l++) {
            Matrix matrixNeighbor = (Matrix) matrixNeighbors.get(l);
            if (areNeighbors(lumenNeighbor, matrixNeighbor)) {
              hasMatrixNeighbor = true;
            }
          }
          for (int l = 0; l < lumenNeighbors.numObjs; l++) {
            FreeSpace otherLumenNeighbor = (FreeSpace) lumenNeighbors.get(l);
            if (areNeighbors(lumenNeighbor, otherLumenNeighbor)) {
              hasLumenNeighbor = true;
            }
          }
          if (hasMatrixNeighbor && hasLumenNeighbor) {
            acceptableNeighbors.add(lumenNeighbor);
          }
        }
        // AXIOM 008
        if (acceptableNeighbors.numObjs > 0) {
          Culture.updateAxiomUsage(culture_type, 14);
          if (axiom008_prob > random_val) {
            Culture.updateAxiomUsage(culture_type, 15);
            int r = state.random.nextInt(acceptableNeighbors.numObjs);
            Agent agent = (Agent) acceptableNeighbors.get(r);
            ISEA2_Cell newCell = new ISEA2_Cell(agent.x, agent.y, grid, paramDB);
            newCell.setCultureType(culture_type);
            model.schedule.scheduleOnce(newCell);
            grid.set(agent.x, agent.y, newCell);
            divisionNum++;
          }
          else {
            // state.schedule.scheduleOnce(this);
            // abiotic default: do nothing
            if (axiom_008_var == 1) {
              // nothing done
            }
            // divide and place child in any FREE SPACE
            if (axiom_008_var == 2) {
              if (lumenNeighbors.numObjs > 0) {
                int r = state.random.nextInt(lumenNeighbors.numObjs);
                Agent agent = (Agent) lumenNeighbors.get(r);
                ISEA2_Cell child = new ISEA2_Cell(agent.x, agent.y, grid, paramDB);
                child.setCultureType(culture_type);
                model.schedule.scheduleOnce(child);
                grid.set(agent.x, agent.y, child);
                divisionNum++;
              }
            }
            // divide and place child in a FREE SPACE with MATRIX neighbor
            if (axiom_008_var == 3) {
              acceptableNeighbors = new Bag();
              for (int k = 0; k < lumenNeighbors.numObjs; k++) {
                Bag extendedNeighbors = new Bag();
                IntBag xPos = new IntBag();
                IntBag yPos = new IntBag();
                FreeSpace lum = (FreeSpace) lumenNeighbors.get(k);
                this.grid.getNeighborsHexagonalDistance
                         (lum.x, lum.y, radius, ExpManager.TOROIDAL, extendedNeighbors, xPos, yPos);
                extendedNeighbors.remove(lum);
                for (int n = 0; n < extendedNeighbors.numObjs; n++) {
                  Agent agt = (Agent) extendedNeighbors.get(n);
                  if (agt instanceof Matrix) {
                    acceptableNeighbors.add(lum);
                    break;
                  }
                }
              }
              if (acceptableNeighbors.numObjs > 0) {
                int r = state.random.nextInt(acceptableNeighbors.numObjs);
                Agent agent = (Agent) acceptableNeighbors.get(r);
                ISEA2_Cell child = new ISEA2_Cell(agent.x, agent.y, grid, paramDB);
                child.setCultureType(culture_type);
                model.schedule.scheduleOnce(child);
                grid.set(agent.x, agent.y, child);
                divisionNum++;
              }
            }
            // divide and place child in any MATRIX
            if (axiom_008_var == 4) {
              if (matrixNeighbors.numObjs > 0) {
                int r = state.random.nextInt(matrixNeighbors.numObjs);
                Agent agent = (Agent) matrixNeighbors.get(r);
                ISEA2_Cell child = new ISEA2_Cell(agent.x, agent.y, grid, paramDB);
                child.setCultureType(culture_type);
                model.schedule.scheduleOnce(child);
                grid.set(agent.x, agent.y, child);
                divisionNum++;
              }
            }
          }
        } // end AXIOM 008
        // AXIOM 011
        else {
          // DO NOTHING
          Culture.updateAxiomUsage(culture_type, 21);
          if (axiom011_prob <= random_val) {
            // malfunction of AXIOM 011
          }
        }
        
      }
      this.age++;
      model.schedule.scheduleOnce(this);
    }
  } // end step()
  
  public void identifyCultureType() {
    if (grid instanceof EmbeddedGrid) { culture_type = ExpManager.EMBEDDED; }
    else if (grid instanceof SuspensionGrid) { culture_type = ExpManager.SUSPENSION; }
    else if (grid instanceof SurfaceGrid) { culture_type = ExpManager.SURFACE; }
    else if (grid instanceof OverlayGrid) { culture_type = ExpManager.OVERLAY; }
    else {
      System.out.println("ERROR in Cell::identifyCultureType() no matching type");
    }
  }
  
  public int determineSurroundingMorphology() {
    if (culture_type < ExpManager.EMBEDDED || culture_type > ExpManager.OVERLAY) {
      this.identifyCultureType();
    }
    int level01 = 1;
    int level02 = 2;
    int level03 = 3;
    int morphologyLevel = 0;
    IntBag xPositions = new IntBag();
    IntBag yPositions = new IntBag();
    Bag neighbors = new Bag();
    Bag matrixNeighbors = new Bag();
    Bag lumenNeighbors = new Bag();
    Bag cellNeighbors = new Bag();
    grid.getNeighborsHexagonalDistance
              (this.x, this.y, radius, ExpManager.TOROIDAL, neighbors, xPositions, yPositions);
    neighbors.remove(this);
    for (int i = 0; i < neighbors.numObjs; i++) {
      Agent neighbor = (Agent) neighbors.get(i);
      if (neighbor instanceof Cell) {
        cellNeighbors.add(neighbor);
      }
      else if (neighbor instanceof Matrix) {
        matrixNeighbors.add(neighbor);
      }
      else if (neighbor instanceof FreeSpace) {
        lumenNeighbors.add(neighbor);
      }
    }
    // Now determine morphology type and disruption level
    if (cellNeighbors.numObjs != 0 && matrixNeighbors.numObjs != 0 && lumenNeighbors.numObjs != 0) {
      // ALL THREE TYPES (CELL + MATRIX + LUMEN)
      boolean separatedSurfaces = true;
      for (int matId = 0; matId < matrixNeighbors.numObjs; matId++) {
        Matrix curMatrix = (Matrix) matrixNeighbors.get(matId);
        for (int lumId = 0; lumId < lumenNeighbors.numObjs; lumId++) {
          FreeSpace curLumen = (FreeSpace) lumenNeighbors.get(lumId);
          if (areNeighbors(curMatrix, curLumen)) {
            separatedSurfaces = false;
            break;
          }
        }
      }
      if (!separatedSurfaces) {
        morphologyLevel = level03;
      }
      else {
        if (cellNeighbors.numObjs == 2) {
          morphologyLevel = level01; // NORMAL
        }
        else if (cellNeighbors.numObjs == 3) {
          boolean connected = false;
          for (int i = 0; i < cellNeighbors.numObjs; i++) {
            for (int j = i+1; j < cellNeighbors.numObjs; j++) {
              if (areNeighbors((Cell)cellNeighbors.get(i), (Cell)cellNeighbors.get(j))) {
                connected = true;
                break;
              }
            }
            if (connected) { break; }
          }
          if (connected) {
            morphologyLevel = level02;
          }
          else {
            morphologyLevel = level03;
          }
        }
        else {
          morphologyLevel = level02;
        }
      }
    }
    else if (cellNeighbors.numObjs != 0 && matrixNeighbors.numObjs != 0) {
      // CELL + MATRIX only
      if (cellNeighbors.numObjs == 1 || cellNeighbors.numObjs == 5) {
        morphologyLevel = level02;
      }
      else if (cellNeighbors.numObjs == 4) {
        if (areNeighbors((Matrix)matrixNeighbors.get(0), (Matrix)matrixNeighbors.get(1))) {
          morphologyLevel = level02;
        }
        else {
          morphologyLevel = level03;
        }
      }
      else {
        boolean separatedSurfaces = true;
        for (int i = 0; i < cellNeighbors.numObjs; i++) {
          Cell curCell = (Cell) cellNeighbors.get(i);
          boolean connected = false;
          for (int j = i+1; j < cellNeighbors.numObjs; j++) {
            if (areNeighbors(curCell, (Cell)cellNeighbors.get(j))) {
              connected = true;
              break;
            }
          }
          if (!connected) {
            separatedSurfaces = false;
            break;
          }
        }
        if (separatedSurfaces) {
          morphologyLevel = level02;
        }
        else {
          morphologyLevel = level03;
        }
      }
    }
    else if (cellNeighbors.numObjs != 0 && lumenNeighbors.numObjs != 0) {
      // CELL + LUMEN only
      if (cellNeighbors.numObjs == 1 || cellNeighbors.numObjs == 5) {
        morphologyLevel = level02;
      }
      else if (cellNeighbors.numObjs == 4) {
        if (areNeighbors((FreeSpace)lumenNeighbors.get(0), (FreeSpace)lumenNeighbors.get(1))) {
          morphologyLevel = level02;
        }
        else {
          morphologyLevel = level03;
        }
      }
      else {
        boolean separatedSurfaces = true;
        for (int i = 0; i < cellNeighbors.numObjs; i++) {
          Cell curCell = (Cell) cellNeighbors.get(i);
          boolean connected = false;
          for (int j = i+1; j < cellNeighbors.numObjs; j++) {
            if (areNeighbors(curCell, (Cell)cellNeighbors.get(j))) {
              connected = true;
              break;
            }
          }
          if (!connected) {
            separatedSurfaces = false;
            break;
          }
        }
        if (separatedSurfaces) {
          morphologyLevel = level02;
        }
        else {
          morphologyLevel = level03;
        }
      }
    }
    else if (matrixNeighbors.numObjs != 0 && lumenNeighbors.numObjs != 0) {
      // MATRIX + LUMEN only
      if (matrixNeighbors.numObjs == 1 || matrixNeighbors.numObjs == 5) {
        morphologyLevel = level02;
      }
      else if (matrixNeighbors.numObjs == 4) {
        if (areNeighbors((FreeSpace)lumenNeighbors.get(0), (FreeSpace)lumenNeighbors.get(1))) {
          morphologyLevel = level02;
        }
        else {
          morphologyLevel = level03;
        }
      }
      else {
        boolean separatedSurfaces = true;
        for (int i = 0; i < matrixNeighbors.numObjs; i++) {
          Matrix curMatrix = (Matrix) matrixNeighbors.get(i);
          boolean connected = false;
          for (int j = i+1; j < matrixNeighbors.numObjs; j++) {
            if (areNeighbors(curMatrix, (Matrix)matrixNeighbors.get(j))) {
              connected = true;
              break;
            }
          }
          if (!connected) {
            separatedSurfaces = false;
            break;
          }
        }
        if (separatedSurfaces) {
          morphologyLevel = level02;
        }
        else {
          morphologyLevel = level03;
        }
      }
    }
    else {
      // ONE TYPE ONLY
      morphologyLevel = level02;
    }
    
    return morphologyLevel;
  } // end determineSurroundingMorphology()
  
}
