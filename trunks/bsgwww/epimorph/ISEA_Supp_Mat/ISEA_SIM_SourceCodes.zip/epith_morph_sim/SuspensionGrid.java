
package epith_morph_sim;

import sim.field.grid.ObjectGrid2D;

public class SuspensionGrid extends ObjectGrid2D {

	/**
	 * 
	 */
	public SuspensionGrid(int x, int y) {
		super(x,y);

		//populate the suspension grid
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				this.set(i, j, new FreeSpace(i, j, this));
			}
		}
		// TODO Auto-generated constructor stub
	}

}
