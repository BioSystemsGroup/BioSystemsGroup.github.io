/*
 * @author Jonathan Tang
 */
package src.ligand;

import uchicago.src.sim.util.Random;
import src.model.Constants;
import src.model.ISWBC;

/* PSGL1 represents a group of psgl-1 adhesion molecules
 */
public class Grp_PSGL1 extends Grp_AdhesMolecules 
	implements Constants{

	/* Create a PSGL1 object for this ISWBC
	 */
	public Grp_PSGL1(ISWBC lam){
		super(lam);
		myAdhMolNum = Constants.PSGL1;
		this.setName("PSGL1");
		Random.createNormal(lam.getDensity_PSGL1_Mean(),lam.getDensity_PSGL1_STDev());
		double num = Random.normal.nextInt();
		this.setCountMatrix(new double[][]{{0,num},{0,0}});
		
		
		bindingConstants = new double[Constants.TOTNUM_GRP_ADHMOLS];
		dissocConstants = new double[Constants.TOTNUM_GRP_ADHMOLS][2];
		
		for (int i = 0; i < Constants.TOTNUM_GRP_ADHMOLS; i++){
			bindingConstants[i] = 0.0;
			for (int j = 0; j < 2; j++){
				dissocConstants[i][j] = 0.0;
			}
		}
		bindingConstants[Constants.PSELECTIN] = lam.getPSelectin_PSGL1_Pon();
		dissocConstants[Constants.PSELECTIN][0] = lam.getPSelectin_PSGL1_B0_DissConst();
		dissocConstants[Constants.PSELECTIN][1] = lam.getPSelectin_PSGL1_B1_DissConst();
		}
}
