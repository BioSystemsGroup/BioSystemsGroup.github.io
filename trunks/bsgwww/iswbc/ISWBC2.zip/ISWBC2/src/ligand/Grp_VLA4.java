package src.ligand;
/*
 * @author Jonathan Tang
 */

import uchicago.src.sim.util.Random;
import src.model.*;

/* VLA4 represents a group of VLA-4 (alpha4,beta1) integrins.
 */
public class Grp_VLA4 
	extends Grp_Integrins 
	implements Constants{
	


	/* Create a VLA4 Object for this ISWBC
	 */
	public Grp_VLA4(ISWBC lam){
		super(lam);
			
	
		this.setName("VLA4");
		Random.createNormal(lam.getDensity_VLA4_Mean(),lam.getDensity_VLA4_STDev());
		double num = Random.normal.nextInt();
		this.setCountMatrix(new double[][]{{0,num},{0,0}});
		
		myAdhMolNum = Constants.VLA4;
		bindingConstants = new double[Constants.TOTNUM_GRP_ADHMOLS];
		dissocConstants = new double[Constants.TOTNUM_GRP_ADHMOLS][2];
		
		for (int i = 0; i < Constants.TOTNUM_GRP_ADHMOLS; i++){
			bindingConstants[i] = 0.0;
			for (int j = 0; j < 2; j++){
				dissocConstants[i][j] = 0.0;
			}
		}

		//major ligand
		bindingConstants[Constants.VCAM1] = lam.getVCAM1_VLA4_Low_Pon();
		dissocConstants[Constants.VCAM1][0] = lam.getVCAM1_VLA4_LowAff_B0_DissConst();
		dissocConstants[Constants.VCAM1][1] = lam.getVCAM1_VLA4_LowAff_B1_DissConst();
	
		//Integrin constants
		this.setHighAffinityPOn(lam.getVCAM1_VLA4_High_Pon());
		this.setHighAffinityB1(lam.getVCAM1_VLA4_HighAff_B1_DissConst());
		this.setHighAffinityB0(lam.getVCAM1_VLA4_HighAff_B0_DissConst());
		this.setHighAffinityB1Limit(lam.getVCAM1_VLA4_HighAff_B1_Limit());
	}
	/*
	 * Returns the type of AdhesMolecule
	 */
	public String getType(){
		return new String("VLA4");
	}
	
	
	protected void signal(){
		
	}
	
	
}

