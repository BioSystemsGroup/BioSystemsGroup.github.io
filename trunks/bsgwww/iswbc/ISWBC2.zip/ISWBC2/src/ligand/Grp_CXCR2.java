/*
 * @author Jonathan Tang
 */
package src.ligand;

import src.model.Constants;
import src.model.ISWBC;

/* CXCR2 represents a group of CXCR2 chemokine receptors
 */
public class Grp_CXCR2 extends Grp_ChemokReceptors{
	
	/* Create a CXCR2 ChemokReceptor for this ISWBC
	 */
	public Grp_CXCR2(ISWBC lam){
		super(lam);
		this.setName("CXCR2");
		
		//Set Affinity Values
		bindingConstants = new double[Constants.TOTNUMCHEMOKS];
		dissocConstants = new double[Constants.TOTNUMCHEMOKS][2];	
		for (int i = 0; i < Constants.TOTNUMCHEMOKS; i++){
			bindingConstants[i] = 0.0;
			for (int j = 0; j < 2; j++){
				dissocConstants[i][0] = 0.0;
				dissocConstants[i][1] = 0.0;				
			}
		}

		bindingConstants[Constants.GROA] = 1.0;
		dissocConstants[Constants.GROA][0] = 1.0;
		dissocConstants[Constants.GROA][1] = 1.0;
	}
}

