package src.ligand;
/*
 * @author Jonathan Tang
 */

import uchicago.src.sim.util.Random;
import src.model.Constants;
import src.flowchamber.SurfaceUnit;
import src.model.ISWBC;




/* AdhesMolecule agents represent multiple adhesion molecules.  They can withstand
 * a certain amount of force before dissociating bonds with its Ligand
 */
public class Grp_AdhesMolecules extends Ligand implements Constants{
	protected int myAdhMolNum; //constant determining adhMol type
	protected double totalNumber;
	protected double[][] countMatrix;//[affinity]/[0-bound|1-unbound]

	/* Create an AdhesMolecule for this ISWBC
	 */
	public Grp_AdhesMolecules(ISWBC lam) {
		super(lam);
	}

	/*
	 * set the count Matrix 
	 * [affinity]/[0-bound|1-unbound]
	 */
	public void setCountMatrix(double[][] matrix){
		countMatrix = matrix;
	}
	
	/*
	 * Get the count Matrix 
	 * [affinity]/[0-bound|1-unbound]
	 */
	public double[][] getCountMatrix(){
		return countMatrix;
	}
	
	/* Return the number of bonds with ligand-binding partner 
	 */
	public double getNumBonds(){
		double num = 0.0;
		int length = countMatrix.length;
		for (int i = 0; i < length; i++){
			num = num + countMatrix[i][0];	
		}
		return num;
	}
	
	/* Return the total number this agent represents
	 */
	public double getTotalNumber(){
		double num = 0.0;
		int length = countMatrix.length;
		for (int i = 0; i < length; i++){
			int width = countMatrix[i].length;
			for (int j = 0; j < width; j++){
				num = num + countMatrix[i][j];
			}
		}
		return num;
	}
	
	/* Returns the number of free high affinity adhesion molecules
	 */
	public double getNumFreeHighAffMols(){
		double num = 0.0;
		int length = countMatrix.length;
		if (length > 0){
			num = countMatrix[1][1];
		}
		
		return num;
	}
	
	/*
	 * Returns the number of low affinity free molecules
	 */
	public double getNumFreeLowAffMols(){
		double num = 0.0;
		num = countMatrix[0][1];
		
		return num;
	}

	/*
	 * Returns the number of high affinity molecules
	 */
	public double getNumTotHighAffMols(){
		double num = 0.0;
		int length = countMatrix.length;
		if (length > 0){
			num = countMatrix[1][1]+countMatrix[1][0];
		}
		return num;
	}
	
	/*
	 * gets the number of bound low affinity molecules
	 */
	public double getNumBoundLowAffMols(){
		return countMatrix[0][0];
	}
	
	/*
	 * gets the number of high affinity bound molecules
	 */
	public double getNumBoundHighAffMols(){
		int length = countMatrix.length;
		if (length>0){
			return countMatrix[1][0];
		} else {
			return 0;
		}
	}
	
	
	/* Get this AdhesMolecule's ligand, as a AdhesMolecule object
	*/
	public Grp_AdhesMolecules getAdhesMoleculeLigand(){
		Grp_AdhesMolecules temp = (Grp_AdhesMolecules)this.getMyLigand();
		return temp;
	}
	
	/* Form a number of bonds with the given AdhesMolecule agent
	 */
	private void bindLigand(Grp_AdhesMolecules adhMol, double[][] newCountMatrix){
		countMatrix = newCountMatrix;
		super.bindLigand(adhMol);
	}
	
	/* Dissociate from Ligand it is currently bound to
	 */
	public void dissociate(){
		int length = countMatrix.length;
		for (int i = 0; i < length; i++){
			countMatrix[i][1] = countMatrix[i][1]+countMatrix[i][0];
			countMatrix[i][0] = 0;
		}
		
		super.dissociate();
	}
	
	/* Interact with SurfaceUnit
	 */
	public void ligInteractWithSurfaceUnit(SurfaceUnit plateSection){
		if (plateSection != null){
			int bestLigandNum = Constants.TOTNUM_GRP_ADHMOLS;
			
			if (this.isBound()){
				Grp_AdhesMolecules a = this.getAdhesMoleculeLigand();
				bestLigandNum = a.getAdhMolNum();
				//this.attemptDissociate();
			} else {
					
				//	Find best Ligand for this AdhesMolecule
				double bestProbability = 0;
				double currProbability = 0;
			
				//Examine each AdhMolecule for SurfaceUnit
				int ligNum = 0;
				
				while (ligNum < Constants.TOTNUM_GRP_ADHMOLS){
					
					Grp_AdhesMolecules ligand = plateSection.myAdhMols[ligNum];
					
					//Examine only exposed ligands on other MemSection
					if (ligand != null) {
						
						double affinityForAdhMol = ligand.getAffinityValue(this.getAdhMolNum());
						double affinityForLigand = this.getAffinityValue(ligNum);
											
						//Look at only ligand pairs and calculate binding probability
						if ((affinityForAdhMol != 0) && (affinityForLigand != 0)){
								
							currProbability = affinityForLigand;
							
							
							//look for ligand with best binding probability
							if (currProbability >= bestProbability){
								bestProbability = currProbability;
								bestLigandNum = ligNum;
								ligNum = Constants.TOTNUM_GRP_ADHMOLS;
									
							} else {
								ligNum++;
							}
						} else {
							ligNum++;	
						}
					} else {
						ligNum++;
					}
				} // found best ligand for adhesmolecule 
			}
			
				//attempt to form a bond with best ligand		
			if  (bestLigandNum != Constants.TOTNUM_GRP_ADHMOLS){
				Grp_AdhesMolecules ligand = plateSection.myAdhMols[bestLigandNum];
				
				Random.createUniform();
				
				double[][] ligandMatrix = ligand.getCountMatrix();
				double[][] myMatrix = this.getCountMatrix();
				
				
				if (this instanceof Grp_Integrins){
					Grp_Integrins integ = (Grp_Integrins)this;
						//form high Aff bonds
					double numPossibleHighAffBonds = 0;
					double numHighAffBonds = 0;
					if (ligandMatrix[0][1]>myMatrix[1][1]){
						numPossibleHighAffBonds = myMatrix[1][1];							
					} else {
						numPossibleHighAffBonds = ligandMatrix[0][1];
					}
					
					double aff = integ.getHighAffinityPOn();
					for (int i = 0; i < numPossibleHighAffBonds; i++){
						double pBind = Random.uniform.nextDoubleFromTo(0.0,1.0);
						if (pBind <= aff){
								numHighAffBonds = numHighAffBonds + 1.0;
		
						} 
					}
				
					myMatrix[1][0] = myMatrix[1][0] + numHighAffBonds;
					myMatrix[1][1] = myMatrix[1][1] - numHighAffBonds;
					ligandMatrix[0][0] = ligandMatrix[0][0] + numHighAffBonds;
					ligandMatrix[0][1] = ligandMatrix[0][1] - numHighAffBonds;
				
					
					//form low affinity bonds
					double numPossibleLowAffBonds = 0;
					double numLowAffBonds = 0;
					if (ligandMatrix[0][1]>myMatrix[0][1]){
						numPossibleLowAffBonds = myMatrix[0][1];							
					} else {
						numPossibleLowAffBonds = ligandMatrix[0][1];
					}
					
					for (int i=0; i<numPossibleLowAffBonds;i++){
						double pBind = Random.uniform.nextDoubleFromTo(0.0,1.0);
						
						double lowAff = this.getAffinityValue(bestLigandNum);
						if (pBind <= lowAff){
							numLowAffBonds = numLowAffBonds + 1.0;
						}
					}
					
					myMatrix[0][0] = myMatrix[0][0] + numLowAffBonds;
					myMatrix[0][1] = myMatrix[0][1] - numLowAffBonds;
					ligandMatrix[0][0] = ligandMatrix[0][0] + numLowAffBonds;
					ligandMatrix[0][1] = ligandMatrix[0][1] - numLowAffBonds;
				
					if (numLowAffBonds + numHighAffBonds > 0){//send message to form bonds
						this.bindLigand(plateSection.myAdhMols[bestLigandNum], myMatrix);
						plateSection.myAdhMols[bestLigandNum].bindLigand(this, ligandMatrix);
						log("Bonds formed (low/high): "+numLowAffBonds+"/"+numHighAffBonds,2);
					}
					
				} else { //not an integrin
					//	form low affinity bonds
					double numPossibleLowAffBonds = 0;
					double numLowAffBonds = 0;
					if (ligandMatrix[0][1]>myMatrix[0][1]){
						numPossibleLowAffBonds = myMatrix[0][1];							
					} else {
						numPossibleLowAffBonds = ligandMatrix[0][1];
					}
					
					for (int i=0; i<numPossibleLowAffBonds;i++){
						double pBind = Random.uniform.nextDoubleFromTo(0.0,1.0);
						
						double aff = this.getAffinityValue(bestLigandNum);
						if (pBind <= aff){
							numLowAffBonds = numLowAffBonds + 1.0;
						}
					}
					
					myMatrix[0][0] = myMatrix[0][0] + numLowAffBonds;
					myMatrix[0][1] = myMatrix[0][1] - numLowAffBonds;
					ligandMatrix[0][0] = ligandMatrix[0][0] + numLowAffBonds;
					ligandMatrix[0][1] = ligandMatrix[0][1] - numLowAffBonds;
					
					if (numLowAffBonds > 0){//send message to form bonds
						this.bindLigand(plateSection.myAdhMols[bestLigandNum], myMatrix);
						plateSection.myAdhMols[bestLigandNum].bindLigand(this, ligandMatrix);
						log("Bonds formed: "+numLowAffBonds,2);
					}
				}
			}
		}	
	}

	/* Experience a certain amount of force
	 */
	public void experienceForce(double force){
		log("+ExperienceForce("+force+")",2);
		Grp_AdhesMolecules myLigand = this.getAdhesMoleculeLigand();
		double numTotalBonds = this.getNumBonds();
		log("Num of total bonds for this Grp_AdhesMolecule: "+numTotalBonds,3);
		
		if(myLigand == null){
		}else{
			
			if (numTotalBonds > 0){
				
			
				double[][] ligandMatrix = myLigand.getCountMatrix();
				double[][] myMatrix = this.getCountMatrix();
				if (this instanceof Grp_Integrins){ //INTEGRIN
					
					//HIGH AFFINITY BONDS
					Random.createUniform();
					Grp_Integrins integ = (Grp_Integrins)this;
					double numHighAffBonds = myMatrix[1][0];
					double myHighAffB1 = integ.getHighAffinityB1();
					double myHighAffB0 = integ.getHighAffinityB0();

					for (double i = 0; i < numHighAffBonds; i++){
						double p = Random.uniform.nextDoubleFromTo(0.0,1.0);
						double highDissocProb = myHighAffB0 + (myHighAffB1*force);
				
						if (highDissocProb >= 1.0){
							highDissocProb = 1.0;
						} else if (force >= integ.getHighAffinityB1Limit()){
							highDissocProb = 1.0;
						}
					
						log("Dissociation try #"+i+", random: "+p+", dissoc prob: "+highDissocProb,3);
						if (p < highDissocProb){
							myMatrix[1][0] = myMatrix[1][0]-1;
							myMatrix[1][1] = myMatrix[1][1]+1;
							ligandMatrix[0][0] = ligandMatrix[0][0]-1;
							ligandMatrix[0][1] = ligandMatrix[0][1]+1;
							log("broke a strong bond",2);
						}
					}
				
					//LOW AFFINITY BONDS
					double numLowAffBonds = myMatrix[0][0];
					double myLowAffB1 = this.getDissocConstantB1(myLigand.getAdhMolNum());
					double myLowAffB0 = this.getDissocConstantB0(myLigand.getAdhMolNum());

				
					for (double j = 0; j < numLowAffBonds; j++){
						double p = Random.uniform.nextDoubleFromTo(0.0,1.0);
						double lowDissocProb = myLowAffB0 + (myLowAffB1*force);
						log("Dissociation constants - b0: "+myLowAffB0+" / b1: "+myLowAffB1,3);
						if (lowDissocProb >= 1.0){
							lowDissocProb = 1.0;
						} else if (force > 1.0){
							lowDissocProb = 1.0;
						}
						log("Dissocation try #"+j+", random: "+p+", dissoc prob: "+lowDissocProb,3);
						if (p <= lowDissocProb){
							myMatrix[0][0] = myMatrix[0][0]-1;
							myMatrix[0][1] = myMatrix[0][1]+1;
							ligandMatrix[0][0] = ligandMatrix[0][0]-1;
							ligandMatrix[0][1] = ligandMatrix[0][1]+1;
							log("broke a weak bond",2);
						}
					}
					this.setCountMatrix(myMatrix);
					myLigand.setCountMatrix(ligandMatrix);
				
				} else { //not an integrin
					double numOfBonds = myMatrix[0][0];
					double myLowAffB1 = this.getDissocConstantB1(myLigand.getAdhMolNum());
					double myLowAffB0 = this.getDissocConstantB0(myLigand.getAdhMolNum());

					for (double j = 0; j < numOfBonds; j++){
					
						double p = Random.uniform.nextDoubleFromTo(0.0,1.0);
						double lowDissocProb = (myLowAffB0 + (myLowAffB1*force));

						if (lowDissocProb >= 1.0){
							lowDissocProb = 1.0;
						}else if (force > 1.0){
							lowDissocProb = 1.0;
						}
						
						if (p <= lowDissocProb){
							myMatrix[0][0] = myMatrix[0][0]-1;
							myMatrix[0][1] = myMatrix[0][1]+1;
							ligandMatrix[0][0] = ligandMatrix[0][0]-1;
							ligandMatrix[0][1] = ligandMatrix[0][1]+1;
						}
					}
					this.setCountMatrix(myMatrix);
					myLigand.setCountMatrix(ligandMatrix);
				}
				
				if (this.getNumBonds() <= 0){
					this.dissociate();
			
				}
			}
			
		}
		log("-Ending experienceForce()",2);
	}	

	/*
	 * Returns the int that represents the type of AdhesMolecule
	 * this object represents.
	 */
	public int getAdhMolNum(){
		return myAdhMolNum;
	}
	
	/* Returns true if this AdhesMolecule is bound
	 */
	public boolean isBound(){
		return super.isBound();
	}
	
	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */	
	private void log(String s, int debugType){
		if (myISWBC.getDebugging() >= debugType){
			System.out.println("AdhesMolecule: "+s);
		}
	}
}
