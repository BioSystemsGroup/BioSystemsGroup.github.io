/*
 * @author Jonathan Tang
 */
package src.ligand;


import uchicago.src.sim.util.Random;
import src.model.Constants;
import src.model.ISWBC;

/* Represents a group of GRO-alpha/CXCL1 Chemokines
 */
public class Grp_GROA extends Grp_Chemoks {
	
	/* Creates a GROA for this ISWBC 
	 */
	public Grp_GROA(ISWBC lam) {
		super(lam);
		
		this.setName("GROA");
		
		Random.createNormal(lam.getDensity_GROA_Mean(),lam.getDensity_GROA_STDev());
		double num = Random.normal.nextInt();
		this.setTotalNumber(num);
		
		bindingConstants = new double[Constants.TOTNUMCHEMOKRECEPS];
		dissocConstants = new double[Constants.TOTNUMCHEMOKRECEPS][2];
			
		for (int i = 0; i < Constants.TOTNUMCHEMOKRECEPS; i++){
			bindingConstants[i] = 0.0;
			for (int j = 0; j < 2; j++){
				dissocConstants[i][0] = 0.0;
				dissocConstants[i][1] = 0.0;
			}
		}
		bindingConstants[Constants.CXCR2] = 1.0;
		dissocConstants[Constants.CXCR2][0] = 1.0;
		dissocConstants[Constants.CXCR2][1] = 1.0;
	}
}
