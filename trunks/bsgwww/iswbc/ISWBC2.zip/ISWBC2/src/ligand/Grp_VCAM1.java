package src.ligand;
/*
 * @author Jonathan Tang
 */
import uchicago.src.sim.util.Random;
import src.model.*;

/* Represents a group of VCAM-1 adhesion molecules
 */
public class Grp_VCAM1 	extends Grp_AdhesMolecules 
implements Constants{

	/* Creates a VCAM1 object for this ISWBC
	 */
	public Grp_VCAM1(ISWBC lam){
		super(lam);
		
	
		myAdhMolNum = Constants.VCAM1;
		this.setName("VCAM1");
		
		Random.createNormal(lam.getDensity_VCAM1_Mean(),lam.getDensity_VCAM1_STDev());
		double num = Random.normal.nextInt();
		this.setCountMatrix(new double[][]{{0,num},{0,0}});
		
		bindingConstants = new double[Constants.TOTNUM_GRP_ADHMOLS];
		dissocConstants = new double[Constants.TOTNUM_GRP_ADHMOLS][2];
			
		for (int i = 0; i < Constants.TOTNUM_GRP_ADHMOLS; i++){
			bindingConstants[i] = 0.0;
			for (int j = 0; j < 2; j++){
				dissocConstants[i][j] = 0.0;	
			}
		}

		bindingConstants[Constants.VLA4] = lam.getVCAM1_VLA4_Low_Pon();
		dissocConstants[Constants.VLA4][0] = lam.getVCAM1_VLA4_LowAff_B0_DissConst();
		dissocConstants[Constants.VLA4][1] = lam.getVCAM1_VLA4_LowAff_B1_DissConst();
		}

	/*
	 * Return the type of AdhesMolecule
	 */
	public String getType(){
		return new String("VCAM1");
	}
	
	
	protected void signal(){
		
	}
}
