/*
 * @author Jonathan Tang
 */
package src.ligand;
import src.model.ISWBC;

/* Chemoks represent groups of Chemokines
 * 
 */
public abstract class Grp_Chemoks extends Ligand {

	Grp_ChemokReceptors myLigand;
	protected double myTotalNumber;
	

	/* Create a Chemok for this LeukocyteAdhesionModel
	 */		
	public Grp_Chemoks(ISWBC lam) {
		super(lam);
	}

	/*
	 * Returns the number of chemokines that this represents
	 */
	public double getTotalNumber(){
		return myTotalNumber;
	}
	
	/*
	 * Sets the number of chemokines that this agent represents
	 */
	public void setTotalNumber(double num){
		myTotalNumber = num;
	}
	

}