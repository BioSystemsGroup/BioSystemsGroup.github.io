package src.ligand;

import src.model.ISWBC;

/*
 * Represents an individual adhesion molecule
 */
public class Ind_AdhesMolecule extends Ligand{

	protected int myAdhMolNum; //constant determining adhMol type
	private int myMicroX;		//the x coordinates on the LFA1Grid or ICAM1Grid (micro)
	private int myMicroY;		//the y coordinates on the LFA1Grid or ICAm1Grid (micro)
	private int immobileDiffusionDistance; //distance to move by diffusion when immobile
	private int mobileDiffusionDistance;	//distance to move by diffusion when mobile
	private int timeBound;					//tracking time bound
	private boolean cytoskeletalBound;		//whether it is bound to cytoskeleton
	private boolean boundBefore;			//Previously bound before

	/*
	 * Creates an Ind_AdhesMolecule for this ISWBC at coordinates
	 * @param lam is the ISWBC
	 * @param xMicro is the micro coordinates on the LFA1Grid or ICAM1Grid
	 * @param yMicro is the micro coordinates on the LFA1Grid or ICAM1Grid
	 */
	public Ind_AdhesMolecule(ISWBC lam, int xMicro, int yMicro) {
		super(lam);
		myMicroX = xMicro;
		myMicroY = yMicro;
		timeBound = 0;
		cytoskeletalBound = true;
		boundBefore = false;
		// TODO Auto-generated constructor stub
	}
	
	/*
	 * Returns the move distance during diffusion based on whether cytoskeletal bound
	 */
	public int getCurrDiffusionDistance(){
		if (cytoskeletalBound){
			return immobileDiffusionDistance;
		} else {
			return mobileDiffusionDistance;
		}
	}
	
	/*
	 *Set the diffusion distance for when immobile 
	 */
	public void setImmobileDiffusionDistance(int mD){
		immobileDiffusionDistance = mD;
	}
	
	/*
	 *Set the diffusion distance for when mobile 
	 */
	public void setMobileDiffusionDistance(int mD){
		mobileDiffusionDistance = mD;
	}
	
	/*
	 * release from cytoskelon
	 */
	public void cytoskeletalRelease(){
		cytoskeletalBound = false;
	}
	
	/*
	 * bind to cytoskeleton
	 */
	public void cytoskeletalBind(){
		cytoskeletalBound = true;
	}
	
	/*
	 * Get the time bound
	 */
	public int getTimeBound(){
		return timeBound;
	}
	
	/*
	 * moves this Ind_AdhesMolecule to new coordinates on the micro grid (LFA1Grid or ICAM1Grid)
	 */
	public void move(int micX, int micY){
		myMicroX = micX;
		myMicroY = micY;
	}
	
	/*
	 * Gets x position on the LFA1Grid or ICAM1Grid
	 */
	public int getMicroX(){
		return myMicroX;
	}

	/* return y position on the LFA1Grid or ICAM1Grid
	 */
	public int getMicroY(){
		return myMicroY;
	}
	
	/*
	 * Set the micro coordinates 
	 * @param x is the x coordinate
	 * @param y is the y coordinate
	 */
	public void setMicroCoords(int x, int y){
		myMicroX = x;
		myMicroY = y;
	}
	
	/*
	 * Get this molecules number type
	 */
	public int getAdhMolNum(){
		return myAdhMolNum;
	}

	/* Get this AdhesMolecule's ligand, as a AdhesMolecule object
	*/
	public Ind_AdhesMolecule getAdhesMoleculeLigand(){
		Ligand lig = this.getMyLigand();
		if (lig instanceof Ind_AdhesMolecule){
			Ind_AdhesMolecule temp = (Ind_AdhesMolecule)this.getMyLigand();
			return temp;
		} else {
			myISWBC.log("Not instance of adhesmolecule",0);
			return null;
		}
	}
	
	/*
	 * Set BoundBefore
	 * @param b if this Ind_AdhesMolecule was bound before
	 */
	public void setBoundBefore(boolean b){
		boundBefore = b;
	}
	
	/*
	 * Return boundBefore
	 */
	public boolean getBoundBefore(){
		return boundBefore;
	}

	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
	private void log(String s, int debugType){
		if (myISWBC.getDebugging() >= debugType){
			System.out.println("Ind_AdhesMolecule: "+s);
		}
	}
}
