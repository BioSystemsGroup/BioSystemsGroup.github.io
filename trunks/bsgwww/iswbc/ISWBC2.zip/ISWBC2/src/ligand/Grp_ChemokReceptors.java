/*
 * @author Jonathan Tang
 */
package src.ligand;

import src.model.ISWBC;
import src.membrane.MemUnit;
import src.model.Constants;
import src.flowchamber.SurfaceUnit;

/* ChemokReceptors represent a group of Chemokine Receptors
 */
public abstract class Grp_ChemokReceptors extends Ligand 
	implements Constants{
	
	protected int myChemRecNum;
	protected MemUnit myMemUnit; //MemUnit ChemokReceptor is located on
	
	/* Create a ChemokReceptor for this ISWBC
	 */
	public Grp_ChemokReceptors(ISWBC lam) {
		super(lam);
	}
	
	/* Search this SurfaceUnit for it's correct Chemok Ligand.
	 * Interact with any Chemok ligands found.
	 */
	public void interactWithSurfaceUnit(SurfaceUnit plateSect){
		for (int chemokNum = 0; chemokNum < Constants.TOTNUMCHEMOKS; chemokNum++){
		
			Grp_Chemoks chemok = plateSect.myChemoks[chemokNum];
			if (chemok != null){
				
				double affinityForChemRec = chemok.getAffinityValue(this.getChemRecNum());
				double affinityForChem = this.getAffinityValue(chemokNum);
				
				//check for affinity
				if ((affinityForChemRec > 0) && (affinityForChem > 0)){
					log("Chemok Detected",2);
					MemUnit m = this.getMemUnit();
					
					//Activate Integrins
					if (m instanceof MemUnit){
						((MemUnit)m).activateViaCXCR2(chemok.getTotalNumber());
						
					}
				}
			}
		}
	}

	/*
	 * Gets the Chemokin Receptor Number
	 */
	public int getChemRecNum(){
		return myChemRecNum;
	}
	
	/*Sets the Membrane Unit for this Chemokine Receptor 
	 */
	public void setMemUnit(MemUnit m){
		myMemUnit = m;
	}
	
	/* Gets the MemUnit for this Chemokine Receptor
	 */
	public MemUnit getMemUnit(){
		return myMemUnit;
	}
	
	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
	public void log(String s, int debugType){
		if (myISWBC.getDebugging() >= debugType){
			System.out.println("ChemokReceptor: "+s);
		}
	}
	

}