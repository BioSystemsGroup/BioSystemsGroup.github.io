/*
 * @author Jonathan Tang
 */

package src.ligand;
import src.model.ISWBC;

/* Abstract Class that represents any binding molecule
 */
public abstract class Ligand {
	
	//protected double avidityValue;
	protected double[] bindingConstants;
	protected double[][] dissocConstants;
	
	protected String myName; //my name
	protected Ligand myLigand; //Ligand-binding partner
	private int xPos; //x position on surface
	private int yPos; //y position on surface
	protected double numBonds;
	protected ISWBC myISWBC;
	
	/* Create a Ligand for this LeukocyteAdhesionModel
	 */
	public Ligand(ISWBC lam) {
		super();
		myISWBC = lam;
		numBonds = 0.0;
	}
	
	/* Set the position coordinates for this ligand on macro surfaces (Surface, Membrane)
	 */
	public void setMacroCoords(int x, int y){
		xPos = x;
		yPos = y;
	}

	/* Return the affinity value for adhesMolecule i
	 */
	public double getAffinityValue(int ligandNumber){
		return bindingConstants[ligandNumber];
	}

	/* Return b1 dissociation value for adhesMolecule i
	 */
	public double getDissocConstantB1(int ligandNumber){
		return dissocConstants[ligandNumber][1];
	}
	
	/* Return b0 dissociation value for adhesMolecule i
	 */
	public double getDissocConstantB0(int ligandNumber){
		return dissocConstants[ligandNumber][0];
	}

	
	/* return the name of this Ligand
	 */
	public String getName(){
		return myName;
	}
	
	/* form bonds a certain number of bonds with this ligand-binding partner
	 */
	public void bindLigand(Ligand lig){
		myLigand = lig;
		lig.setMyLigand(this);
	}
		
	
	/* Dissociate from ligand-binding partner
	 */
	protected void dissociate(){
		
		if (this.getMyLigand() == null){
			//Should not get here
			log("Error - dissociate: null AbstractLigand",0);
		}
		
		this.getMyLigand().setMyLigand(null);
		myLigand = null;
		
		log("Dissociated from: "+myLigand,2);
	}
	
	/* Returns true if this Ligand is bound to ligand-binding partner
	 */
	public boolean isBound(){
		return (this.getMyLigand()!=null);
	}
		

	/* Return ligand-binding partner
	 */
	public Ligand getMyLigand() {
		return myLigand;
	}
		
	/* Set ligand-binding partner
	 */
	protected void setMyLigand(Ligand lig){
		myLigand = lig;
	}

	/* Set my name
	 */
	protected void setName(String name){
		myName = name;
	}

	/* return x position on surface/membrane
	 */
	public int getMacroX(){
		return xPos;
	}

	/* return y position on surface/membrane
	 */
	public int getMacroY(){
		return yPos;
	}
	
	/* Return my ISWBC
	 */
	public ISWBC getMyLAM(){
		return myISWBC;
	}
		
	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
	private void log(String s, int debugType){
		if (myISWBC.getDebugging() >= debugType){
			System.out.println("Ligand: "+s);
		}
	}

}

