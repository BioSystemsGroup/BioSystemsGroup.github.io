package src.ligand;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import src.membrane.LFA1Grid;
import src.model.ISWBC;
import src.model.Constants;
import uchicago.src.sim.util.Random;
/*
 * This class represents an individual LFA-1 molecule that can have different affinity states,
 * cluster, diffuse, and bind to ICAM1 objects
 */
public class Ind_LFA1 extends Ind_AdhesMolecule implements Constants{

	private double[][] integrinAffinityConstants;
	
	private final int POn = 0;
	private final int B0_off = 1;
	private final int B1_off = 2;
	private final int B1_limit = 3;
	private int affinityState;
	private int lfa1ID;
	private String status;
	private LFA1Grid myLFA1Grid;
	private double randDissocRate;
	private int bondDuration;
	
	/*
	 * Create an Ind_LFA1 object for this ISWBC, grid, at a certain position
	 * @param myISWBC is the ISWBC
	 * @param lgrid is the LFA1Grid that this LFA1 agent resides on
	 * @param xMic is the micro x coordinates on the LFA1Grid
	 * @param yMic is the micro y coordinates on the LFA1Grid
	 * @param id is the id of this LFA1 object
	 */
	public Ind_LFA1(ISWBC myISWBC, LFA1Grid lgrid, int xMic, int yMic, int id){
		super(myISWBC, xMic, yMic);
		status = "o";			//default status
		myLFA1Grid = lgrid;		//my grid
		this.setName("LFA1");	//my name
		lfa1ID = id;			//my ID
		randDissocRate = 0.00;	//my random dissociation value
		affinityState = Constants.LOW_AFFINITY;
		bondDuration = 0;
		
		integrinAffinityConstants = new double[2][4];
		for (int a = 0; a < 2; a++){
			for (int i = 0; i < 4; i++){
				integrinAffinityConstants[a][i] = 0.0;
			}
		}
		
		//Integrin constants
		this.setAffinityPOn(Constants.HIGH_AFFINITY,myISWBC.getICAM1_LFA1_High_Pon());
		this.setAffinityB1(Constants.HIGH_AFFINITY,myISWBC.getICAM1_LFA1_HighAff_B1_DissConst());
		this.setAffinityB0(Constants.HIGH_AFFINITY,myISWBC.getICAM1_LFA1_HighAff_B0_DissConst());
		this.setAffinityB1Limit(Constants.HIGH_AFFINITY,myISWBC.getICAM1_LFA1_HighAff_B1_Limit());

		this.setAffinityPOn(Constants.LOW_AFFINITY,myISWBC.getICAM1_LFA1_Low_Pon());
		this.setAffinityB1(Constants.LOW_AFFINITY,myISWBC.getICAM1_LFA1_LowAff_B1_DissConst());
		this.setAffinityB0(Constants.LOW_AFFINITY,myISWBC.getICAM1_LFA1_LowAff_B0_DissConst());
		this.setAffinityB1Limit(Constants.LOW_AFFINITY,myISWBC.getICAM1_LFA1_LowAff_B1_Limit());
	
		this.setImmobileDiffusionDistance(myISWBC.getDiffusionImmobile());
		this.setMobileDiffusionDistance(myISWBC.getDiffusionMobile());
	}
	
	/*
	 * Interact with ICAM1 ligand
	 * @param is the number of the LFA1 object
	 */
	public void interactWithLigand(int myNum, Ind_ICAM1 icam1){
		Random.createUniform(0,1.0);
		double p = Random.uniform.nextDoubleFromTo(0.0,1.0);
		double aff;
		String type = null;
		
		if (this.getAffinityState() == Constants.HIGH_AFFINITY){
			aff = this.getAffinityPOn(Constants.HIGH_AFFINITY);
			type = "high";
		} else {
			aff = this.getAffinityPOn(Constants.LOW_AFFINITY);
			type = "low";
		}
		log("P:"+p+", affinity"+aff,2);
		if (p <= aff){
			
			// form a bond here
			log("LFA1 Bond: M:("+this.getMacroX()+","+this.getMacroY()+") | LFA1:("+this.getMicroX()+","+this.getMicroY()+") | ICAM1:("+icam1.getMicroX()+","+icam1.getMicroY()+")" ,2);
			this.bindLigand((Ligand)icam1);
			icam1.bindLigand((Ligand)this);
	
			//Determine if dimerically bound
			if (this.isDimericICAM1Bound()){
				int neighborX = myLFA1Grid.getNeighboringX(icam1.getDimerDirection(), icam1.getMicroX(), icam1.getMicroY());
				int neighborY = myLFA1Grid.getNeighboringY(icam1.getDimerDirection(), icam1.getMicroX(), icam1.getMicroY());
				this.log("Found Dimeric bond: ("+this.getMicroX()+","+this.getMicroY()+")|("+neighborX+","+neighborY+")",2);
				this.outsideInSignal();		
				//icam1.signal();
		
			}	
			try
			{
				if ((myISWBC.getPrintLFA1Data() == 1) || (myISWBC.getPrintICAM1Data() == 1)){
					String filename = new String(myLFA1Grid.getDirectoryName()+"/BondFile.txt");
					FileWriter fw = new FileWriter(filename,true);
			 		PrintWriter pw = new PrintWriter(fw,true);
					if (this.isDimericICAM1Bound()){
						pw.println("t: "+myISWBC.getStepNumber()+" (D)(LFA# "+myNum+"):"+this.getMicroX()+","+this.getMicroY()+","+type);					
					} else {
						pw.println("t: "+myISWBC.getStepNumber()+" (M)(LFA# "+myNum+"):"+this.getMicroX()+","+this.getMicroY()+","+type);
					}
					fw.close();
				}		    
			} catch(IOException ioe) {
			    System.err.println("IOException: " + ioe.getMessage());
			}
		}
		
	}
	
	/*
	 * Returns true if this LFA1 is bound to a dimerically bound ICAM1
	 */
	public boolean isDimericICAM1Bound(){
	boolean dimericBond = false;
		if(this.isBound()){
			Ind_ICAM1 icam1 = (Ind_ICAM1)this.getMyLigand();
			if (icam1.getMyDimer() != null){
				int neighborX = myLFA1Grid.getNeighboringX(icam1.getDimerDirection(), icam1.getMicroX(), icam1.getMicroY());
				int neighborY = myLFA1Grid.getNeighboringY(icam1.getDimerDirection(), icam1.getMicroX(), icam1.getMicroY());
				if (myLFA1Grid.isLFA1BondAt(neighborX, neighborY)){
					dimericBond = true;
				}
			}
		} 
		return dimericBond;
	}
	/* Experience a certain amount of force
	 */
	public void experienceForce(double force){
		log("+ExperienceForce("+force+") for LFA1",2);
		
		if(this.isBound()){		
			Random.createUniform();
			double p = Random.uniform.nextDoubleFromTo(0.0,1.0);
					
			double myAffB1 = this.getAffinityB1(this.getAffinityState());
			double myAffB0 = this.getAffinityB0(this.getAffinityState());
							
			double dissocProb = myAffB0 + (myAffB1*force);
				
			if (dissocProb >= 1.0){
				dissocProb = 1.0;
			} else if (force >= this.getAffinityB1Limit(this.getAffinityState())){
				dissocProb = 1.0;	
			}
				
			if (p < dissocProb){
				this.dissociate();
				
				try
				{
					if (myISWBC.getPrintBondFile() == Constants.TRUE){
						//this.myLFA1Grid.getMyMemUnit().getLeukMem().getStatus().equals();
						String filename = new String("./"+"/BondsFile.txt");
						FileWriter fw = new FileWriter(filename,true);
						PrintWriter pw = new PrintWriter(fw,true);
						pw.println(bondDuration);
						fw.close();
					}
				
				} catch(IOException ioe) {
					System.err.println("IOException: " + ioe.getMessage());
				}
				bondDuration = 0;
			}
		}
		//log("-Ending experienceForce()",2);
	}
	
	/*
	 * Increment the bond duration count
	 */
	public void incrementBondDuration(){
		bondDuration++;
	}
	
	/* (EXPERIMENTAL)
	 * random dissocation
	 */
	public void randomDissociation(double prob){
		if (prob <= randDissocRate){
			this.dissociate();
		}
	}
	
	/*
	 * Signals that get sent to the Leukocyte when 2 LFA1 bind to a dimeric ICAM1
	 */
	public void outsideInSignal(){	
		myLFA1Grid.outsideInActivatedSpreading();
	}
	
	/*
	 * Signals sent from CXCR2 when it detects CXCL1/GROA
	 */
	public void activateViaCXCR2(){
		setAffinityState(Constants.HIGH_AFFINITY);
	}
	
	/*
	 * Return to low affinity state
	 */
	public void deactivate(){
		setAffinityState(Constants.LOW_AFFINITY);
	}
	
	/*
	 * Change affinity state
	 * @param state is the value to change the affinity state to
	 */
	public void setAffinityState(int state){
		affinityState = state;
	}
	
	/*
	 * Get the affinity state for this LFA1 object
	 */
	public int getAffinityState(){
		return affinityState;
	}

	
	/* Set the high affinity binding value
	 */
	public void setAffinityPOn(int state, double d){
		integrinAffinityConstants[state][POn] = d;
	}
	
	/* Set the high affinity B1 dissociation value
	 */
	public void setAffinityB1(int state, double d){
		integrinAffinityConstants[state][B1_off] = d;
	}
	
	/* Set the high affinity B0 dissociation value
	 */
	public void setAffinityB0(int state, double d){
		integrinAffinityConstants[state][B0_off] = d;
	}
	
	/* Set the high affinity dissociation limit
	 */
	public void setAffinityB1Limit(int state, double d){
		integrinAffinityConstants[state][B1_limit] = d;
	}
	
	/* Return the high affinity B0 dissociation value
	 */
	public double getAffinityB0(int state){
		return integrinAffinityConstants[state][B0_off];
	}	
	
	/* Return the high affinity dissociation value
	 */
	public double getAffinityPOn(int state){
		return integrinAffinityConstants[state][POn];
	}
	
	/* Return the high affinity B1 dissociation value
	 */
	public double getAffinityB1(int state){
		return integrinAffinityConstants[state][B1_off];
	}
	
	/* Return the high affinity dissociation limit
	 */
	public double getAffinityB1Limit(int state){
		return integrinAffinityConstants[state][B1_limit];
	}
	
	/*
	 * Returns the status of this Ind_LFA1 object
	 * X = high affinity bound
	 * O = high affinity unbound
	 * x = low affinity bound
	 * o = low affinity unbound
	 */
	public String getStatus(){
		if (this.getAffinityState() == Constants.HIGH_AFFINITY){
			if (this.isBound()){
				status = "X";
			} else {
				status = "O";
			}
		} else {
			if (this.isBound()){
				status = "x";
			} else {
				status = "o";
			}
		}
		return status;
	}
	
	/*
	 * returns the id number for this LFA1
	 */
	public int getID(){
		return lfa1ID;
	}
	
	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
	private void log(String s, int debugType){
		if (myISWBC.getDebugging() >= debugType){
			System.out.println("Ind_LFA1: "+s);
		}
	}
}
