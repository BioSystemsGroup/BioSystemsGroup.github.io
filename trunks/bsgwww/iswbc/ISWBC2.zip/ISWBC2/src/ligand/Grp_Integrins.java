/*
 * @author Jonathan Tang
 */
package src.ligand;

import src.model.Constants;
import src.model.ISWBC;

/* Integrin represents a group of integrin adhesion molecules.
 * This object is characterized by having different affinity
 * states for it's ligand-binding partner.
 */
public class Grp_Integrins extends Grp_AdhesMolecules 
	implements Constants{

	private double[][] highAffinityConstants;
	private final int POn = 0;
	private final int B0_off = 1;
	private final int B1_off = 2;
	private final int B1_limit = 3;
	private boolean maxActivation;
	
	protected double percentActivated;
	protected double activationFactor;
	
	/* Create an Integrin object for this ISWBC
	 */
	public Grp_Integrins(ISWBC lam){
		super(lam);
		maxActivation = false;
		highAffinityConstants = new double[1][4];
		for (int i = 0; i < 4; i++){
			highAffinityConstants[0][i] = 0.0;
		}
	}
	
	/* Activate this integrin based on how many Chemok objects were detected 
	 */
	public void activateViaCXCR2(double chemokNumber){
		
		if (!maxActivation){
			double[][] myMatrix = this.getCountMatrix();
			double numAvailable = myMatrix[0][1];
			if (numAvailable >= chemokNumber){
				myMatrix[0][1]=myMatrix[0][1]-chemokNumber;
				myMatrix[1][1]=myMatrix[1][1]+chemokNumber;
			} else {
				myMatrix[0][1]=myMatrix[0][1]-numAvailable;
				myMatrix[1][1]=myMatrix[1][1]+numAvailable;
			}
		} else {
			
		}
	}
	
	/*
	 * Sets the maximum percent allowed to be activated
	 */
	public void setMaxActivation(boolean maxReached){
		maxActivation = maxReached;
	}
	
	/*
	 * halts integrin activation
	 */
	public void haltIntegrinActivation(){
		setMaxActivation(true);
	}

	/* Set the high affinity binding value
	 */
	public void setHighAffinityPOn(double d){
		highAffinityConstants[0][POn] = d;
	}
	
	/* Set the high affinity dissociation value
	 */
	public void setHighAffinityB1(double d){
		highAffinityConstants[0][B1_off] = d;
	}
	
	/* Set the high affinity dissociation value
	 */
	public void setHighAffinityB0(double d){
		highAffinityConstants[0][B0_off] = d;
	}
	
	/* Set the high affinity dissociation limit
	 */
	public void setHighAffinityB1Limit(double d){
		highAffinityConstants[0][B1_limit] = d;
	}
	
	/* Return the high affinity dissociation value
	 */
	public double getHighAffinityB0(){
		return highAffinityConstants[0][B0_off];
	}	
	
	/* Return the high affinity dissociation value
	 */
	public double getHighAffinityPOn(){
		return highAffinityConstants[0][POn];
	}
	
	/* Return the high affinity dissociation value
	 */
	public double getHighAffinityB1(){
		return highAffinityConstants[0][B1_off];
	}
	
	/* Return the high affinity dissociation limit
	 */
	public double getHighAffinityB1Limit(){
		return highAffinityConstants[0][B1_limit];
	}
	
	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
	public void log(String s, int debugType){
		if (myISWBC.getDebugging() >= debugType){
			System.out.println("Integrin: "+s);
		}
	}
	
}
