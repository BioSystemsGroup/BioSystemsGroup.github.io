package src.ligand;

import src.flowchamber.ICAM1Grid;
import src.model.Constants;
import src.model.ISWBC;
/*
 * This class represents an individual ICAM1 molecule. In vivo, it exists primarily in dimeric form.
 * It has the ability to form linear tetramers
 */
public class Ind_ICAM1 extends Ind_AdhesMolecule implements Constants{

	private Ind_ICAM1 myDimer;
	private int dimerDirection;
	private ICAM1Grid myICAM1Grid;
	private int icam1ID;
	private Ind_ICAM1 myTetramer;
	private boolean topOfTetramer;
	private boolean mobile;
	private Ind_ICAM1 myTrimer;
	private boolean trimerHead;
	
	/*
	 * Creates an Ind_ICAM1 molecule for this ISWBC
	 * @param myISWBC is the current ISWBC
	 * @param igrid is the ICAM1Grid in which it resides
	 * @param x is the micro coordinates on the ICAM1Grid
	 * @param y is the micro coordinates on the ICAM1Grid
	 */
	public Ind_ICAM1(ISWBC myISWBC, ICAM1Grid igrid, int x, int y, int id){
		super(myISWBC,x,y);
		myAdhMolNum = Constants.ICAM1;
		myDimer = null; 			//can form Dimers
		dimerDirection = 0; 		//the direction of the second ICAM1 in a dimer
		myICAM1Grid = igrid;		//the grid for this ICAM1
		icam1ID = id;				//my ID
		myTetramer = null;			//pointer to it's tetramer partner
		topOfTetramer = false;		//If Tetrameric, is this the head (main) ICAM1 agent?
		mobile = true;				//lateral mobility	
		trimerHead = false;			//If Preclustered, is this the head (main) ICAM1 agent?
	
		
		bindingConstants = new double[Constants.TOTNUM_IND_ADHMOLS];
		dissocConstants = new double[Constants.TOTNUM_IND_ADHMOLS][2];
		
		for (int i = 0; i < Constants.TOTNUM_IND_ADHMOLS; i++){
			bindingConstants[i] = 0.0;
			for (int j = 0; j < 2; j++){
				dissocConstants[i][j] = 0.0;
			}
		}

		//major ligand
		bindingConstants[Constants.LFA1] = myISWBC.getICAM1_LFA1_Low_Pon();
		dissocConstants[Constants.LFA1][0] = myISWBC.getICAM1_LFA1_LowAff_B0_DissConst();
		dissocConstants[Constants.LFA1][1] = myISWBC.getICAM1_LFA1_LowAff_B1_DissConst();
		this.setImmobileDiffusionDistance(myISWBC.getICAM1_Move());
	}
	
//	public void signal(){
		//myICAM1Grid.dimericBondInitiatedClustering(this.getMicroX(),this.getMicroY(),myISWBC.getICAM1ClusterRadius());
		
//	}

	/*
	 * Sets the dimer for this ICAM1
	 * @param icam1 is the dimer
	 * @param direction is the direction that the second ICAM1 is with respect to this ICAM1
	 */
	public void setMyDimer(Ind_ICAM1 icam1, int direction){
		myDimer = icam1;
		dimerDirection = direction;
	}
	/*
	 * Returns the second ICAM1 for this ICAM1
	 * returns null if not dimeric
	 */
	public Ind_ICAM1 getMyDimer(){
		return myDimer;
	}
	/*
	 * Returns true if this is the main ICAM1 in a tetramer
	 */
	public boolean isTetramerHead(){
		return topOfTetramer;
	}
	
	/*
	 * Returns the head of the tetramer
	 */
	public Ind_ICAM1 getTetramerHead(){
		if (topOfTetramer == true){
			return this;
		} else {
			return myTetramer;
		}
	}
	
	/*
	 * Forms a tetramer with another ICAM1 Dimer
	 * @param icam3 is the head of the second dimer
	 */
	public void formTetramerWith(Ind_ICAM1 icam3){
		topOfTetramer = true;
		myTetramer = icam3;
		Ind_ICAM1 icam2 = this.getMyDimer();
		Ind_ICAM1 icam4 = icam3.getMyDimer();
		icam2.setMyTetramer(this);
		icam3.setMyTetramer(this);
		icam4.setMyTetramer(this);
		
	}
	
	/*
	 * Sets the head ICAM1 when forming a tetramer
	 * @param is the head icam1 for the tetramer
	 */
	public void setMyTetramer(Ind_ICAM1 icam1){
		myTetramer = icam1;
	}
	
	/*
	 * Gets the head for this tetramer
	 */
	public Ind_ICAM1 getMyTetramer(){
		return myTetramer;
	}
	
	/*
	 * Get Mobility status
	 */
	public boolean getMobility(){
		return mobile;
	}
	
	/*
	 * Set mobility status
	 * @param m mobility status
	 */
	private void setMobility(boolean m){
		mobile = m;
	}
	
	/*
	 * Make immobile
	 */
	public void setImmobile(){
		mobile = false;
		if (this.isTetrameric()){
			Ind_ICAM1 icam1 = this.getTetramerHead();
			Ind_ICAM1 icam2 = icam1.getMyDimer();
			Ind_ICAM1 icam3 = icam1.getMyTetramer();
			Ind_ICAM1 icam4 = icam3.getMyDimer();
			
			icam1.setMobility(false);
			icam2.setMobility(false);
			icam3.setMobility(false);
			icam4.setMobility(false);
		} else if (this.isTrimeric()){
			Ind_ICAM1 icam1 = this;
			Ind_ICAM1 icam2 = this.getMyTrimer();
			Ind_ICAM1 icam3 = icam2.getMyTrimer();
			
			icam1.setMobility(false);
			icam2.setMobility(false);
			icam3.setMobility(false);
		} else if (this.isDimeric()){
			Ind_ICAM1 icam1 = this;
			Ind_ICAM1 icam2 = this.myDimer;
			
			icam1.setMobility(false);
			icam2.setMobility(false);
		}
	}
	
	/*
	 * determines if this is a tetramer
	 */
	public boolean isTetrameric(){
		boolean tetrameric = (myTetramer != null) ? true : false;
		return tetrameric;
	}
	
	/*
	 * Determines if this is dimeric
	 */
	public boolean isDimeric(){
		boolean dimeric = (myDimer != null) ? true : false;
		return dimeric;
	}
	
	/*
	 * Sets the parter in this trimer
	 */
	public void setMyTrimer(Ind_ICAM1 trim){
		myTrimer = trim;
	}
	
	/*
	 * Sets this Ind_ICAM1 as the head of the trimer
	 */
	public void setTrimerHead(){
		trimerHead = true;
	}
	
	/*
	 * Returns the trimer partner
	 */
	public Ind_ICAM1 getMyTrimer(){
		return myTrimer;
	}
	
	/*
	 * Returns the head (main ligand) of the trimer
	 */
	public Ind_ICAM1 getTrimerHead(){
		boolean found = false;
		Ind_ICAM1 head = null;
		Ind_ICAM1 icam = this;

		while (!found){
			if (icam.isTrimerHead()){
				head = icam;
				found = true;
			} else {
				Ind_ICAM1 icam2 = icam.getMyTrimer();
				icam = icam2;
			}
		}
		return head;
	}
	
	/*
	 * Determines if this is the head (main ligand) of the trimer
	 */
	public boolean isTrimerHead(){
		return trimerHead;
	}
	
	/*
	 * Determines if this ICAM1 is in a trimer (Precluster)
	 */
	public boolean isTrimeric(){
		boolean trimeric = (myTrimer != null) ? true : false;
		return trimeric;
	}
	
	/*
	 * Gets the direction of the dimer
	 */
	public int getDimerDirection(){
		return dimerDirection;
	}
	
	
	/*
	 * Gets the status. x if bound, o if unbound
	 */
	public String getStatus(){
		if (this.isBound()){
			return "x";
		} else {
			return "o";
		}
	}
	/*
	 * Returns the ID number for this ICAM1 on this ICAM1Grid
	 */
	public int getID(){
		return icam1ID;
	}

}
