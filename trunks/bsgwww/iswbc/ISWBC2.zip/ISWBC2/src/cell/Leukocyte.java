package src.cell;

import src.membrane.LeukMem;
import src.model.ISWBC;
/*
 * Class representing a Leukocyte object
 */
public class Leukocyte {
	
 	private ISWBC myModel;
 	private LeukMem myLeukMem; //Leukocyte Membrane for this Leukocyte object
	
 	public Leukocyte(ISWBC lam){
		
		myModel = lam;
		myLeukMem = new LeukMem(this, lam);	
	}
 	
	/*
	 *Function to step through during each simulation cycle 
	 */
	public void play(){
		LeukMem leukMembrane = this.getLeukMem();
		leukMembrane.play();
	}
	
	/*
	 * Tells LeukMem to record LFA1Data
	 */
	public void recordLFA1Data(){
		myLeukMem.recordLFA1Data();
	}
	
	/*
	 * Returns the ISWBC for this Leukocyte
	 * @return the ISWBC for this Leukocyte
	 */
 	public ISWBC getModel(){
 		return myModel;
 	}
 	
 	/*
 	 * Returns the LeukMem for this Leukocyte
 	 * @returns the LeukMem for this Leukocyte
 	 */
 	public LeukMem getLeukMem(){
 		return myLeukMem;
 	}
 	
 	/*
 	 * Sets the LeukMem for this Leukocyte
 	 * @param lm is the LeukMem for this Leukocyte
 	 */
 	public void setLeukMem(LeukMem lm){
 		myLeukMem = lm;
 	}
 	
 	
 	
}
