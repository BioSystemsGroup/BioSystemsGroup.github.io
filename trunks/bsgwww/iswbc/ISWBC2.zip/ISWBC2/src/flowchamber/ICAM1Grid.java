package src.flowchamber;


import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import src.ligand.Ind_ICAM1;
import src.model.Constants;
import src.model.ISWBC;
import uchicago.src.sim.space.Object2DHexagonalGrid;
/*
 * A 2D toroidal hexagonal grid for Ind_ICAM1 agents to diffuse
 */
public class ICAM1Grid extends Object2DHexagonalGrid {

	private ISWBC myISWBC;
	private int mySize;
	private String directoryName;
	private int[] xEAP; //xPositions of EAP clusters (top-left corner) //Experimental
	private int[] yEAP; //yPositions of EAP clusters (top-left corner) //Experimental
	int lengthEAP;
	private int currNumEAPs; //current number of icam1 clusters
	private int maxNumEAPsAllowed; //maximum number of icam1 clusters allowed

	/*
	 * Creates an ICAM1Grid
	 * @param size is the size in x and y direction
	 * @iswbc is the current ISWBC 
	 * @directoryN is the directory Name to store data files
	 */
	public ICAM1Grid(int size, ISWBC iswbc, String directoryN) {
		super(size, size);
		mySize = size;
		myISWBC = iswbc;
		Double d = iswbc.getDensity_dICAM1_Mean();
		maxNumEAPsAllowed = d.intValue()/2; //max number of Endothelial Adhesive Platforms
		currNumEAPs = 0;
		
		xEAP = new int[maxNumEAPsAllowed];
		yEAP = new int[maxNumEAPsAllowed];
		lengthEAP = myISWBC.getEAPDiameter();
		for (int a = 0; a < maxNumEAPsAllowed; a++){
			xEAP[a] = -1; //default values
			yEAP[a] = -1; //default values
		}
		
		if (myISWBC.getPrintICAM1Data() == Constants.TRUE){
			directoryName = directoryN;		
		}
		
		
		
	}
	/*
	 * puts Ind_ICAM1 objects at location
	 * @param x is the x location
	 * @param y is the y location
	 * @param object is the Object to place
	 */
	public void putICAM1At(int x, int y, Object object){
		this.putObjectAt(x%mySize, y%mySize, object);
	}
	
	/*
	 * Gets the Ind_ICAM1 object at specified location
	 * @param x is the x location
	 * @param y is the y location 
	 * @returns the Ind_ICAM1 at the location
	 */
	public Ind_ICAM1 getICAM1At(int x, int y){
		return (Ind_ICAM1)this.getObjectAt(x,y);
	}

	/*
	 * Determines if there is an Ind_ICAM1 object at this location
	 * @param x is the x coordinate in question
	 * @param y is the y coordinate in question
	 * @returns true if it contains an object within this location
	 */
	public boolean containsICAM1At(int x, int y){
		return (this.getObjectAt(x,y) != null); 
	}
	
	/*
	 * Determines if there is an Ind_ICAM1 object at any of the locations on the ICAM1Grid
	 * @param x is an array of x coordinates
	 * @param y is an array of y coordinates
	 * @returns true if it contains an ICAM1 at any of the specified locations
	 */
	public boolean containsICAM1At(int[] x, int[] y){
		boolean empty = true;
		for(int a = 0; a < x.length; a++){
			if (this.containsICAM1At(x[a],y[a])){
				empty &= false;
			}
		}
		
		return empty;
	}
	
	/*
	 * Returns the DirectoryName for outputting data
	 * @returns the directory name to store output data
	 */
	private String getDirectoryName(){
		return directoryName;
	}

	/* (EXPERIMENTAL)
	 * Form the cluster ideally at x, y, with specified length
	 * Clusters cannot be split when located on edges of the toroidal LFA1Grid.  
	 * Instead, they are moved so that they lie on the edges.
	 * @param x is the ideal x position on the LFA1Grid
	 * @param y is the ideal y position on the LFA1Grid
	 * @param length is the length of the cluster
	 */
	public void formEAP(int x, int y){
		int idealX = x - (lengthEAP/2);
		int idealY = y - (lengthEAP/2);
		
		if (this.myISWBC.getEAPClusteringAllowed() == 1){
			if (currNumEAPs < maxNumEAPsAllowed){
				if (!this.withinEAP(idealX,idealY)){
					if (idealX < 0){
						xEAP[currNumEAPs] = 0;
					} else if (idealX >= mySize - lengthEAP){
						xEAP[currNumEAPs] = mySize - lengthEAP;
					} else {
						xEAP[currNumEAPs] = idealX;
					}
		
					if (idealY < 0){
						yEAP[currNumEAPs] = 0;
					} else if (idealY >= mySize - lengthEAP){
						yEAP[currNumEAPs] = mySize - lengthEAP;
					} else {
						yEAP[currNumEAPs] = idealY;
					}
					
					try
					{
						if ((myISWBC.getPrintLFA1Data() == Constants.TRUE) || (myISWBC.getPrintICAM1Data() == 1)){
							String filename = new String(this.getDirectoryName()+"/ClusterFile.txt");
							FileWriter fw = new FileWriter(filename,true);
							PrintWriter pw = new PrintWriter(fw,true);
							pw.println(myISWBC.getStepNumber()+",(#"+currNumEAPs+" ICAM1 EAP Formed):"+this.xEAP[currNumEAPs]+","+this.yEAP[currNumEAPs]);
							fw.close();
						}
					
					} catch(IOException ioe) {
						System.err.println("IOException: " + ioe.getMessage());
					}
					currNumEAPs++;
				}
			} else {
				log("Too many ICAM1 EAPs exist",1);
			}
		}	
		
	}
	
	/* (Experimental)
	 * Determines if this position on the LFA1Grid is within any of the clusters
	 * @param x is the x coordinate in question
	 * @param y is the y coordinate in question
	 * @returns true if this x,y position is within a cluster
	 */
	public boolean withinEAP(int x, int y){
		boolean outside = true;
		for (int a = 0; a < currNumEAPs; a++){
			if ((x < xEAP[a] + lengthEAP) && (x >= xEAP[a]) && (y < yEAP[a] + lengthEAP) && (y >= yEAP[a])){
				outside &= false;
			}
		}
		return !outside;				
	}
	
	/* (Experimental)
	 * returns the number of clusters in this LFA1Grid
	 * @return the number of clusters
	 */
	public int getNumEAPs(){
		return currNumEAPs;
	}
	/*
	 *Attempts to move an object on the ICAM1Grid in the specified direction, if empty
	 *@param object is the object to move
	 *@param direction is the direction to move defined by Constants 
	 */
	public void attemptMicroDiffusion(Object object, int direction){
		Ind_ICAM1 icam1 = (Ind_ICAM1)object;
		int oldX1 = icam1.getMicroX();
		int oldY1 = icam1.getMicroY();
		int newX1 = this.getNeighboringX(direction,oldX1,oldY1);
		int newY1 = this.getNeighboringY(direction,oldX1,oldY1);
		
		if (!this.containsICAM1At(newX1, newY1)){
			this.moveICAM1At(object, newX1, newY1);
		}
	}
	
	/*
	 * Attempts to move a tetramer (2 dimeric Ind_ICAM1 objects) in a direction, if empty
	 * @param object is the object in question
	 * @param direction is the direction to move defined by Constants
	 */
	public void attemptTrimerMicroDiffusion(Object object, int direction){
		Ind_ICAM1 icam1 = (Ind_ICAM1)object;
		Ind_ICAM1 icam2 = icam1.getMyDimer();
		Ind_ICAM1 icam3 = icam1.getMyTrimer();
		
		int oldX1 = icam1.getMicroX();
		int oldY1 = icam1.getMicroY();
		int oldX2 = icam2.getMicroX();
		int oldY2 = icam2.getMicroY(); 
		int oldX3 = icam3.getMicroX();
		int oldY3 = icam3.getMicroY();
		int newX1 = this.getNeighboringX(direction,oldX1,oldY1);
		int newY1 = this.getNeighboringY(direction,oldX1,oldY1);
		int newX2 = this.getNeighboringX(direction,oldX2,oldY2);			
		int newY2 = this.getNeighboringY(direction,oldX2,oldY2);
		int newX3 = this.getNeighboringX(direction,oldX3,oldY3);
		int newY3 = this.getNeighboringY(direction,oldX3,oldY3);
		
		if(((!this.containsICAM1At(newX1,newY1))||(this.getICAM1At(newX1,newY1)==icam2)||(this.getICAM1At(newX1,newY1)==icam3))&&
				((!this.containsICAM1At(newX2,newY2))||(this.getICAM1At(newX2,newY2)==icam1)||(this.getICAM1At(newX2,newY2)==icam3))&&
				((!this.containsICAM1At(newX3,newY3))||(this.getICAM1At(newX3,newY3)==icam1)||(this.getICAM1At(newX3,newY3)==icam2))){
			this.moveICAM1At(icam1, newX1, newY1);
			this.moveICAM1At(icam2, newX2, newY2);
			this.moveICAM1At(icam3, newX3, newY3);
		}	
	}
	
	
	/*
	 * Attempts to move a tetramer (2 dimeric Ind_ICAM1 objects) in a direction, if empty
	 * @param object is the object in question
	 * @param direction is the direction to move defined by Constants
	 */
	public void attemptTetramerMicroDiffusion(Object object, int direction){
		Ind_ICAM1 icam1 = (Ind_ICAM1)object;
		Ind_ICAM1 icam2 = icam1.getMyDimer();
		Ind_ICAM1 tetramer1 = icam1.getMyTetramer();
		Ind_ICAM1 tetramer2 = tetramer1.getMyDimer();
		
		int oldX1 = icam1.getMicroX();
		int oldY1 = icam1.getMicroY();
		int oldX2 = icam2.getMicroX();
		int oldY2 = icam2.getMicroY(); 
		int oldX3 = tetramer1.getMicroX();
		int oldY3 = tetramer1.getMicroY();
		int oldX4 = tetramer2.getMicroX();
		int oldY4 = tetramer2.getMicroY(); 
		int newX1 = this.getNeighboringX(direction,oldX1,oldY1);
		int newY1 = this.getNeighboringY(direction,oldX1,oldY1);
		int newX2 = this.getNeighboringX(direction,oldX2,oldY2);			
		int newY2 = this.getNeighboringY(direction,oldX2,oldY2);
		int newX3 = this.getNeighboringX(direction,oldX3,oldY3);
		int newY3 = this.getNeighboringY(direction,oldX3,oldY3);
		int newX4 = this.getNeighboringX(direction,oldX4,oldY4);			
		int newY4 = this.getNeighboringY(direction,oldX4,oldY4);
		
		if((!this.containsICAM1At(newX1,newY1))&&(!this.containsICAM1At(newX2,newY2))&&(!this.containsICAM1At(newX3,newY3))&&(!this.containsICAM1At(newX4,newY4)) ){
			this.moveICAM1At(icam1, newX1, newY1);
			this.moveICAM1At(icam2, newX2, newY2);
			this.moveICAM1At(tetramer1, newX3, newY3);
			this.moveICAM1At(tetramer2, newX4, newY4);
		}	
	}
	
	/*
	 * Determines if an object is within a certain distance in the -x, +x, -y, and +y direction of another coordinate
	 * @param x1 is the first x coordinate in question
	 * @param y1 is the first y coordinate in question
	 * @param dist is the distance in all directions to search
	 * @param xC is the second x coordinate in question
	 * @param yC is the second y coordinate in question
	 * @returns true if they are within a certain distance of each other 
	 */
	public boolean withinDistance(int x1, int y1, int dist, int xC, int yC){
		boolean inside = false;
		if ((x1 >= xC-dist) && (x1 <= xC+dist) && (y1 >= yC-dist) && (y1 <= yC+dist)){
			inside = true;
		}
		return inside;
	}
	
	/*
	 * Attempts to move a Dimer (2 Ind_ICAM1 objects) in a specified direction, if empty
	 * @param object is the Ind_ICAM1 object in question
	 * @param direction is the direction to attempt move specified by Constants
	 */
	public void attemptDimerMicroDiffusion(Object object, int direction){
		Ind_ICAM1 icam1 = (Ind_ICAM1)object;
		Ind_ICAM1 icam2 = icam1.getMyDimer();
		
		int oldX1 = icam1.getMicroX();
		int oldY1 = icam1.getMicroY();
		int oldX2 = icam2.getMicroX();
		int oldY2 = icam2.getMicroY(); 
		int newX1 = this.getNeighboringX(direction,oldX1,oldY1);
		int newY1 = this.getNeighboringY(direction,oldX1,oldY1);
		int newX2 = this.getNeighboringX(direction,oldX2,oldY2);			
		int newY2 = this.getNeighboringY(direction,oldX2,oldY2);
		if (myISWBC.getEAPClusteringAllowed()==1){
			if ((this.withinEAP(oldX1,oldY1)) && (this.withinEAP(newX1,newY1))){
				if((!this.containsICAM1At(newX1,newY1))&&(!this.containsICAM1At(newX2,newY2))){
					this.moveICAM1At(object, newX1, newY1);
					this.moveICAM1At(icam2, newX2, newY2);
				}
			} else if ((!this.withinEAP(oldX1,oldY1)) && (!this.withinEAP(newX1,newY1))){
				if((!this.containsICAM1At(newX1,newY1))&&(!this.containsICAM1At(newX2,newY2))){
					this.moveICAM1At(object, newX1, newY1);
					this.moveICAM1At(icam2, newX2, newY2);
				}
			}
		}else {
			if((!this.containsICAM1At(newX1,newY1))&&(!this.containsICAM1At(newX2,newY2))){
		
				this.moveICAM1At(object, newX1, newY1);
				this.moveICAM1At(icam2, newX2, newY2);
			}
		}
	}
	
	/*
	 * Attempts to move an Ind_ICAM1 objects in a specified direction, if empty
	 * @param object is the Ind_ICAM1 object in question
	 * @param direction is the direction to attempt move specified by Constants
	 */
	public void moveICAM1At(Object object, int newX, int newY){
		
		Ind_ICAM1 icam1 = (Ind_ICAM1)object;
		int oldX = icam1.getMicroX();
		int oldY = icam1.getMicroY();
		
		this.putObjectAt(newX,newY,icam1);
		this.putObjectAt(oldX,oldY,null);
		
		icam1.move(newX, newY);	
	}
	
	/* Gets the x coordinate of the neighboring position of (x,y) in the specified 
	 * direction on the hexagonal ICAM1Grid.  ICAM1Grid is implemented as toroidal. 
	 * @param direction is the direction from the (x,y) coordinates (defined by Constants)
	 * @param xPos is the x coordinate 
	 * @param yPos is the y coordinate
	 * @return the x coordinate of the neighboring position from x,y in the specified direction
	 */
	public int getNeighboringX(int direction, int xPos, int yPos){
		int newX=xPos;
		if (direction == Constants.SAME){
			newX = xPos;
		}
		
		if ((direction == Constants.NORTHEAST)||
				(direction == Constants.SOUTHEAST)){
			newX = xPos+1;
		}
		if ((direction == Constants.SOUTHWEST)||
				(direction == Constants.NORTHWEST)){
			newX = xPos-1;
		}
		
		if (newX == this.mySize){
			newX = 0; 
		}
		if (newX == -1){
			newX = this.mySize-1;
		}
		
		return newX;
	}
	
	/* Gets the y coordinate of the neighboring position of (x,y) in the specified 
	 * direction on the hexagonal ICAM1Grid.  ICAM1Grid is implemented as toroidal. 
	 * @param direction is the direction from the (x,y) coordinates (defined by Constants)
	 * @param xPos is the x coordinate 
	 * @param yPos is the y coordinate
	 * @return the y coordinate of the neighboring position from x,y in the specified direction
	 */
	public int getNeighboringY(int direction, int xPos, int yPos){
		
		int newY=yPos;
		if (direction == Constants.SAME){
			newY = yPos;
		}
		
		if ((direction == Constants.SOUTH)||
				((direction == Constants.SOUTHEAST)&&(xPos %2==0))||
				((direction == Constants.SOUTHWEST)&&(xPos %2==0))){
					newY = yPos+1;
			}
			if ((direction == Constants.NORTH)||
					((direction == Constants.NORTHEAST)&&(xPos %2==1))||
					((direction == Constants.NORTHWEST)&&(xPos %2==1))){
						newY = yPos-1;
			}
		
		if (newY == this.mySize){
			newY = 0; 
		}
		if (newY == -1){
			newY = this.mySize-1;
		}
		return newY;
	}
	
	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
	private void log(String s, int debugType){
		if (myISWBC.getDebugging() >= debugType){
			System.out.println("ICAM1Grid: "+s);
		}
	}
	
}