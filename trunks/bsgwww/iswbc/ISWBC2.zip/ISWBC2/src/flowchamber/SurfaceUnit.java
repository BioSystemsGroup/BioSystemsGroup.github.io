/*
 * @author Jonathan Tang
 */
package src.flowchamber;
import java.awt.Color;

import uchicago.src.sim.gui.*;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import src.model.ISWBC;
import uchicago.src.sim.gui.DisplayConstants;
import uchicago.src.sim.gui.SimGraphics;
import uchicago.src.sim.util.Random;
import src.ligand.Grp_AdhesMolecules;
import src.ligand.Ind_ICAM1;
import src.ligand.Grp_Chemoks;
import src.model.Constants;
import src.membrane.MemUnit;
import src.ligand.Grp_GROA;
import src.ligand.Grp_VCAM1;
import src.ligand.Grp_PSelectin;

/*
 * Represents a functional unit of the Surface
 */
public class SurfaceUnit implements Constants, Drawable{

	private boolean containsICAM1;		//contains ICAM1
	private int membraneType;			//for display purposes
	private MemUnit myMemUnit;			//the MemUnit that is interacting with this SurfUnit
	
	public Grp_AdhesMolecules[] myAdhMols;	//My Group Adhesion Molecules
	public Grp_Chemoks[] myChemoks;			//My Group chemokine receptors
	private int xPos; 						//x position on the surface
	private int yPos; 						//y position on the surface
	private Surface mySurfaceSpace;			//My surface
	private ICAM1Grid myICAM1Grid; 			//ICAM1Grid if contains ICAM1
	private ArrayList<Ind_ICAM1> icam1AgentList;	//List of ICAM1 Agents
	private ISWBC myISWBC;
	
	/*
	 * Creates a SurfaceUnit at position x,y on the Surface.  It only creates Surface Units when
	 * necessary for each Leukocyte Membrane Unit that is placed on the Surface.
	 * @param x is the x position on the surface
	 * @param y is the y position on the surface
	 * @param mu is the membrane unit that is interacting with the surface unit
	 * @param icam1Grid is a boolean determining if it should create an icam1Grid based on whether the
	 * LeukMem has an LFA1Grid
	 */
	protected SurfaceUnit(int x, int y, Surface ss, MemUnit mu, boolean icam1grid){
		xPos = x;
		yPos = y;
		mySurfaceSpace = ss;
		containsICAM1 = icam1grid;

		myChemoks = new Grp_Chemoks[Constants.TOTNUMCHEMOKS];		
		myAdhMols = new Grp_AdhesMolecules[Constants.TOTNUM_GRP_ADHMOLS];
		myMemUnit = mu;		
		
		for (int i = 0; i < Constants.TOTNUM_GRP_ADHMOLS; i++)
			myAdhMols[i] = null;
		for (int i = 0; i < Constants.TOTNUMCHEMOKS; i++)
			myChemoks[i] = null;
		
		myISWBC = mySurfaceSpace.getISWBC();
		Random.createUniform();
		
		double pVcam1 = Random.uniform.nextDoubleFromTo(0.0,1.0);
		double pKc = Random.uniform.nextDoubleFromTo(0.0,1.0);
		double pPselectin = Random.uniform.nextDoubleFromTo(0.0,1.0);
		
		if (pVcam1 <= myISWBC.getDensity_VCAM1_Mean()){
			myAdhMols[Constants.VCAM1] = new Grp_VCAM1(myISWBC);
		}
		if (pKc <= myISWBC.getDensity_GROA_Mean()){		
			myChemoks[Constants.GROA] = new Grp_GROA(myISWBC);
		}
		if (pPselectin <= myISWBC.getDensity_PSELECTIN_Mean()){
			myAdhMols[Constants.PSELECTIN] = new Grp_PSelectin(myISWBC);
		}

		if(containsICAM1){
			createICAM1();
		}
	}
	
	/*
	 * Create ICAM1Grid for this SurfaceUnit
	 */
	public void createICAM1(){
		ISWBC myISWBC = mySurfaceSpace.getISWBC();
		
		if(containsICAM1){
			myICAM1Grid = new ICAM1Grid(myISWBC.getLFA1GridSize(),myISWBC, myMemUnit.getLFA1Grid().getDirectoryName());
			Random.createUniform();
			
			//monomeric ICAM1
			if (myISWBC.getICAM1NativeSize() == 1){
				Random.createNormal(myISWBC.getDensity_ICAM1_Mean(),myISWBC.getDensity_ICAM1_STDev());
				int numOfICAM1 = Random.normal.nextInt();
				double icam1num = (double)numOfICAM1;
				double numOfSpaces = myISWBC.getLFA1GridSize()*myISWBC.getLFA1GridSize();
				double P_icam1 = icam1num/numOfSpaces;
			

				if (numOfICAM1 > 0){
					icam1AgentList = new ArrayList<Ind_ICAM1>(numOfICAM1);
					int ICAM1counter = 0;
					StringBuffer sb = new StringBuffer();
					int a = 0;
					int b = 0;
					while (ICAM1counter < numOfICAM1){
			
						Random.createUniform();
						double p = Random.uniform.nextDoubleFromTo(0.0,1.0);
						if (p <= P_icam1){
							ICAM1counter++;				
							Ind_ICAM1 icam = new Ind_ICAM1(myISWBC, myICAM1Grid, a, b, ICAM1counter);
							myICAM1Grid.putICAM1At(a,b,icam);
							icam1AgentList.add((Ind_ICAM1)icam);
							sb.append(""+ICAM1counter+":("+a+","+b+")\n");
						}
						a++;
						if (a >= myISWBC.getLFA1GridSize()){
							a=0;
							b++;
						}
						if (b >= myISWBC.getLFA1GridSize()){
							b=0;
						}		
					}
					log(""+icam1AgentList.size()+" ICAM1 agents created for SurfUnit ("+xPos+","+yPos+")",1);
				} else {
					numOfICAM1 = 0;	
					icam1AgentList = new ArrayList<Ind_ICAM1>(numOfICAM1);
				}
				//dimeric ICAM1
			} else if (myISWBC.getICAM1NativeSize() == 2){
				Random.createNormal(myISWBC.getDensity_dICAM1_Mean(),myISWBC.getDensity_dICAM1_STDev());
				int numOfdICAM1 = Random.normal.nextInt();
				double dIcam1num = (double)numOfdICAM1;
				double numOfSpaces = 0.5*myISWBC.getLFA1GridSize()*myISWBC.getLFA1GridSize();
				double P_dIcam1 = dIcam1num/numOfSpaces;
			
				if (numOfdICAM1 > 0){
					
					icam1AgentList = new ArrayList<Ind_ICAM1>(numOfdICAM1);
					int dICAM1counter = 0;
					StringBuffer sb = new StringBuffer();
					int x1 = 0;
					int y1 = 0;
					while (dICAM1counter < numOfdICAM1){
						Random.createUniform();
						double p = Random.uniform.nextDoubleFromTo(0.0,1.0);		
						if (p <= P_dIcam1){
							int x2 = myICAM1Grid.getNeighboringX(Constants.SOUTH, x1, y1);
							int y2 = myICAM1Grid.getNeighboringY(Constants.SOUTH, x1, y1);
							if((!myICAM1Grid.containsICAM1At(x1, y1)) && 
								(!myICAM1Grid.containsICAM1At(x2, y2))){
								dICAM1counter++;
								Ind_ICAM1 icam1 = new Ind_ICAM1(myISWBC, myICAM1Grid, x1, y1, dICAM1counter);
								dICAM1counter++;
								Ind_ICAM1 icam2 = new Ind_ICAM1(myISWBC, myICAM1Grid, x2, y2, dICAM1counter);
								myICAM1Grid.putICAM1At(x1,y1,icam1);
								myICAM1Grid.putICAM1At(x2, y2, icam2);
								icam1.setMyDimer(icam2, Constants.SOUTH);
								icam2.setMyDimer(icam1, Constants.NORTH);
								icam1AgentList.add(icam1);
								sb.append(""+dICAM1counter+":("+x1+","+y1+")-("+x2+","+y2+")\n");
								
							}
							
						}
						x1++;
						if (x1 >= myISWBC.getLFA1GridSize()){
							x1=0;
							y1++;
							
						}
						if (y1 >= myISWBC.getLFA1GridSize()){
							y1=0;
						}					
					}
					log(""+icam1AgentList.size()+" dICAM1 agents created for SurfUnit ("+xPos+","+yPos+")",1);
					
				} else {
					numOfdICAM1 = 0;
					icam1AgentList = new ArrayList<Ind_ICAM1>(numOfdICAM1);
				}

			//trimeric - PreClustered ICAM1
			} else if((myISWBC.getICAM1NativeSize() == 3) || (myISWBC.getICAM1PreClusteredAllowed() == 1)) {
				
				Random.createNormal(myISWBC.getDensity_ICAM1_Mean(),myISWBC.getDensity_ICAM1_STDev());
				int numOfICAM1 = Random.normal.nextInt();
				double icam1num = (double)numOfICAM1;
				double numOfSpaces = 0.333*myISWBC.getLFA1GridSize()*myISWBC.getLFA1GridSize();
				double P_icam1 = icam1num/numOfSpaces;
                if (numOfICAM1 < 0){
                        numOfICAM1 = 0;
                }
                icam1AgentList = new ArrayList<Ind_ICAM1>(numOfICAM1);

                if (numOfICAM1 > 0){

                	int ICAM1counter = 0;
                	StringBuffer sb = new StringBuffer();
                	for (int x1 = 0; x1 < myISWBC.getLFA1GridSize(); x1++){
                		for (int y1 = 0; y1 < myISWBC.getLFA1GridSize(); y1++){
                			
                			Random.createUniform();
                			double p = Random.uniform.nextDoubleFromTo(0.0,1.0);
                			
                			if (p <= P_icam1){

                				int icam2x = myICAM1Grid.getNeighboringX(Constants.SOUTH, x1, y1);
                				int icam2y = myICAM1Grid.getNeighboringY(Constants.SOUTH, x1, y1);
                				int icam3x = myICAM1Grid.getNeighboringX(Constants.NORTHEAST,icam2x,icam2y);
                				int icam3y = myICAM1Grid.getNeighboringY(Constants.NORTHEAST,icam2x,icam2y);
                				if((!myICAM1Grid.containsICAM1At(x1, y1)) &&
                						(!myICAM1Grid.containsICAM1At(icam2x, icam2y)) &&
                						(!myICAM1Grid.containsICAM1At(icam3x,icam3y))){

                					ICAM1counter++;
                					Ind_ICAM1 icam1 = new Ind_ICAM1(myISWBC, myICAM1Grid, x1, y1,ICAM1counter);	
                					ICAM1counter++;	
                					Ind_ICAM1 icam2 = new Ind_ICAM1(myISWBC, myICAM1Grid, icam2x, icam2y, ICAM1counter);
                					ICAM1counter++;
                					Ind_ICAM1 icam3 = new Ind_ICAM1(myISWBC, myICAM1Grid, icam3x,icam3y, ICAM1counter);
                					
                					myICAM1Grid.putICAM1At(x1,y1,icam1);	
                					myICAM1Grid.putICAM1At(icam2x,icam2y, icam2);
                					icam1.setMyDimer(icam2, Constants.SOUTH);
                					icam2.setMyDimer(icam1, Constants.NORTH);
                					icam1AgentList.add(icam1);
                					
                					myICAM1Grid.putICAM1At(icam3x,icam3y,icam3);
                					icam3.setMyTrimer(icam1);
                					icam1.setMyTrimer(icam2);
                					icam2.setMyTrimer(icam3);
                					icam1.setTrimerHead();
                					
                				}
                			}
                		}
                	}
                }
                //EXPERIMENTAL - preformed W-tetramers
			} else if(myISWBC.getICAM1NativeSize() == 4){
				
                Random.createNormal(myISWBC.getDensity_dICAM1_Mean(),myISWBC.getDensity_dICAM1_STDev());
                int numOfdICAM1 = Random.normal.nextInt();
                double dIcam1num = (double)numOfdICAM1;
                double numOfSpaces = 0.25*myISWBC.getLFA1GridSize()*myISWBC.getLFA1GridSize();
                double P_dIcam1 = dIcam1num/numOfSpaces;
                if (numOfdICAM1 < 0){
                        numOfdICAM1 = 0;
                }
                icam1AgentList = new ArrayList<Ind_ICAM1>(numOfdICAM1);

                if (numOfdICAM1 > 0){

                	int dICAM1counter = 0;
                	StringBuffer sb = new StringBuffer();
                	for (int x1 = 0; x1 < myISWBC.getLFA1GridSize(); x1++){
                		for (int y1 = 0; y1 < myISWBC.getLFA1GridSize(); y1++){
                			
                			Random.createUniform();
                			double p = Random.uniform.nextDoubleFromTo(0.0,1.0);
                			
                			if (p <= P_dIcam1){

                				int icam2x = myICAM1Grid.getNeighboringX(Constants.SOUTH, x1, y1);
                				int icam2y = myICAM1Grid.getNeighboringY(Constants.SOUTH, x1, y1);
                				int icam3x = myICAM1Grid.getNeighboringX(Constants.SOUTH,icam2x,icam2y);
                				int icam3y = myICAM1Grid.getNeighboringY(Constants.SOUTH,icam2x,icam2y);
                				int icam4x = myICAM1Grid.getNeighboringX(Constants.SOUTH,icam3x,icam3y);
                				int icam4y = myICAM1Grid.getNeighboringY(Constants.SOUTH,icam3x,icam3y);
                				if((!myICAM1Grid.containsICAM1At(x1, y1)) &&
                						(!myICAM1Grid.containsICAM1At(icam2x, icam2y)) &&
                						(!myICAM1Grid.containsICAM1At(icam3x,icam3y)) &&
                						(!myICAM1Grid.containsICAM1At(icam4x,icam4y))){

                					dICAM1counter++;
                					Ind_ICAM1 icam1 = new Ind_ICAM1(myISWBC, myICAM1Grid, x1, y1,dICAM1counter);	
                					dICAM1counter++;	
                					Ind_ICAM1 icam2 = new Ind_ICAM1(myISWBC, myICAM1Grid, icam2x, icam2y, dICAM1counter);
                					dICAM1counter++;
                					Ind_ICAM1 icam3 = new Ind_ICAM1(myISWBC, myICAM1Grid, icam3x,icam3y, dICAM1counter);
                					dICAM1counter++;
                					Ind_ICAM1 icam4 = new Ind_ICAM1(myISWBC, myICAM1Grid, icam4x,icam4y, dICAM1counter);
                					
                					myICAM1Grid.putICAM1At(x1,y1,icam1);	
                					myICAM1Grid.putICAM1At(icam2x,icam2y, icam2);
                					icam1.setMyDimer(icam2, Constants.SOUTH);
                					icam2.setMyDimer(icam1, Constants.NORTH);
                					icam1AgentList.add(icam1);
                					
                					myICAM1Grid.putICAM1At(icam3x,icam3y,icam3);
                					myICAM1Grid.putICAM1At(icam4x,icam4y,icam4);
                					icam3.setMyDimer(icam4, Constants.SOUTH);
                					icam4.setMyDimer(icam3, Constants.NORTH);
                					icam1.formTetramerWith(icam3);
                				}
                			}
                		}
                	}
                }
			}
				
		}	
	}
	
	/* (EXPERIMENTAL)
	 * Dynamically create an ICAM1Grid if it did not before.
	 */
	public void exposeICAM1(){
		containsICAM1 = true;
		createICAM1();
	}
	
	/*
	 * Step function for SurfaceUnit
	 */
	public void play(){
		if (this.containsICAM1){
		   
			for(int a=0; a<icam1AgentList.size();a++){
				Ind_ICAM1 currICAM1 = (Ind_ICAM1) icam1AgentList.get(a);
				int icam1x = currICAM1.getMicroX();
				int icam1y = currICAM1.getMicroY();
				
				//TETRAMER FORMATION upon BINDING
				if (myISWBC.getICAM1WTetramerAllowed() == 1){
					if (!currICAM1.isTetrameric()){
						if (currICAM1.isDimeric()){
							Ind_ICAM1 icam2 = currICAM1.getMyDimer();
							if ((currICAM1.isBound() || icam2.isBound())){
								boolean done = false;
								int n = 0;
								while (!done){
									if (n != a){
										Ind_ICAM1 icam3 = (Ind_ICAM1) icam1AgentList.get(n);
										Ind_ICAM1 icam4 = icam3.getMyDimer();
										if (myICAM1Grid.withinDistance(icam3.getMicroX(),icam3.getMicroY(),myISWBC.getICAM1ClusterSearchDistance(),icam1x,icam1y)){
											if ((!icam3.isBound()) && (!icam4.isBound())){
												int icam2x = icam2.getMicroX();
												int icam2y = icam2.getMicroY();
												int icam3x = myICAM1Grid.getNeighboringX(Constants.SOUTH,icam2x,icam2y);
												int icam3y = myICAM1Grid.getNeighboringY(Constants.SOUTH,icam2x,icam2y);
												int icam4x = myICAM1Grid.getNeighboringX(Constants.SOUTH,icam3x,icam3y);
												int icam4y = myICAM1Grid.getNeighboringY(Constants.SOUTH,icam3x,icam3y);
												if ((!myICAM1Grid.containsICAM1At(icam3x,icam3y)) && (!myICAM1Grid.containsICAM1At(icam4x,icam4y))){
													myICAM1Grid.putICAM1At(icam3x,icam3y,icam3);
													myICAM1Grid.putICAM1At(icam4x,icam4y,icam4);
													icam3.setMicroCoords(icam3x,icam3y);
													icam4.setMicroCoords(icam4x,icam4y);
													currICAM1.formTetramerWith(icam3);
													done = true;
													try
													{
														if ((myISWBC.getPrintLFA1Data() == Constants.TRUE) || (myISWBC.getPrintICAM1Data() == Constants.TRUE)){
														
															String filename = new String(myMemUnit.getLFA1Grid().getDirectoryName()+"/ClusterFile.txt");
															FileWriter fw = new FileWriter(filename,true);
															PrintWriter pw = new PrintWriter(fw,true);
															pw.println(myISWBC.getStepNumber()+",(ICAM1 W-Cluster Formed):"+icam1x+","+icam1y);
															fw.close();
														}
													
													} catch(IOException ioe) {
														System.err.println("IOException: " + ioe.getMessage());
													}
												}
												
											}
												
										}
									}
									n++;
									if (n >= icam1AgentList.size()){
										done = true;
									}
								}
							}
						}
					}
				}
				//ICAM1 DIFFUSION				
				Random.createUniform();
				if (currICAM1.getMobility() == true){
					//Tetrameric
					if (currICAM1.isTetrameric()){
						if (currICAM1.isTetramerHead()){
							Ind_ICAM1 tetramer1 = currICAM1.getMyTetramer();
							Ind_ICAM1 tetramer2 = tetramer1.getMyDimer();
							Ind_ICAM1 dimer = currICAM1.getMyDimer();
							if ((!currICAM1.isBound()) && (!dimer.isBound()) && (!tetramer1.isBound()) && (!tetramer2.isBound())){
						
								int numMoves = currICAM1.getCurrDiffusionDistance();
						
								for (int moveNum = 0; moveNum < numMoves; moveNum++){
									int dir = Constants.SAME;
									double pDirection = Random.uniform.nextDoubleFromTo(0.0,1.0);
									if (pDirection <= (0.1667)){		
										dir = Constants.NORTH;
									} else if (pDirection <= (0.3333)){
										dir = Constants.NORTHEAST;
									} else if (pDirection <= (0.5)){
										dir = Constants.SOUTHEAST;
									} else if (pDirection <= (0.6667)){
										dir = Constants.SOUTH;
									} else if (pDirection <= (0.8333)){
										dir = Constants.SOUTHWEST;
									} else {
										dir = Constants.NORTHWEST;
									}
								
									myICAM1Grid.attemptTetramerMicroDiffusion(currICAM1,dir);
								}
							}
						}	
						//Trimeric
					} else if (currICAM1.isTrimeric()){
						
						Ind_ICAM1 dimer = currICAM1.getMyDimer();
						Ind_ICAM1 trimer = currICAM1.getMyTrimer();
						if ((!currICAM1.isBound()) && (!dimer.isBound())&& (!trimer.isBound())){
							
							int numMoves = currICAM1.getCurrDiffusionDistance();
						
							for (int moveNum = 0; moveNum < numMoves; moveNum++){

								double pDirection = Random.uniform.nextDoubleFromTo(0.0,1.0);
								if (pDirection <= (0.1667)){		
									myICAM1Grid.attemptTrimerMicroDiffusion(currICAM1, Constants.NORTH);
								} else if (pDirection <= (0.3333)){
									myICAM1Grid.attemptTrimerMicroDiffusion(currICAM1, Constants.NORTHEAST);
								} else if (pDirection <= (0.5)){
									myICAM1Grid.attemptTrimerMicroDiffusion(currICAM1, Constants.SOUTHEAST);
								} else if (pDirection <= (0.6667)){
									myICAM1Grid.attemptTrimerMicroDiffusion(currICAM1, Constants.SOUTH);
								} else if (pDirection <= (0.8333)){
									myICAM1Grid.attemptTrimerMicroDiffusion(currICAM1, Constants.SOUTHWEST);
								} else {
									myICAM1Grid.attemptTrimerMicroDiffusion(currICAM1, Constants.NORTHWEST);
								}		
							}
						} 
						//Dimeric
					} else if (currICAM1.isDimeric()){
						
						Ind_ICAM1 dimer = currICAM1.getMyDimer();
						if ((!currICAM1.isBound()) && (!dimer.isBound())){
							
							int numMoves = currICAM1.getCurrDiffusionDistance();
						
							for (int moveNum = 0; moveNum < numMoves; moveNum++){

								double pDirection = Random.uniform.nextDoubleFromTo(0.0,1.0);
								if (pDirection <= (0.1667)){		
									myICAM1Grid.attemptDimerMicroDiffusion(currICAM1, Constants.NORTH);
								} else if (pDirection <= (0.3333)){
									myICAM1Grid.attemptDimerMicroDiffusion(currICAM1, Constants.NORTHEAST);
								} else if (pDirection <= (0.5)){
									myICAM1Grid.attemptDimerMicroDiffusion(currICAM1, Constants.SOUTHEAST);
								} else if (pDirection <= (0.6667)){
									myICAM1Grid.attemptDimerMicroDiffusion(currICAM1, Constants.SOUTH);
								} else if (pDirection <= (0.8333)){
									myICAM1Grid.attemptDimerMicroDiffusion(currICAM1, Constants.SOUTHWEST);
								} else {
									myICAM1Grid.attemptDimerMicroDiffusion(currICAM1, Constants.NORTHWEST);
								}		
							}
						} 
						//Monomeric
					} else {	
						if(!currICAM1.isBound()){	
							int numMoves = currICAM1.getCurrDiffusionDistance();
					
							for (int moveNum = 0; moveNum < numMoves; moveNum++){
								
								double pDirection = Random.uniform.nextDoubleFromTo(0.0,1.0);
								if (pDirection <= (0.1667)){		
									myICAM1Grid.attemptMicroDiffusion(currICAM1, Constants.NORTH);
								} else if (pDirection <= (0.3333)){
									myICAM1Grid.attemptMicroDiffusion(currICAM1, Constants.NORTHEAST);
								} else if (pDirection <= (0.5)){
									myICAM1Grid.attemptMicroDiffusion(currICAM1, Constants.SOUTHEAST);
								} else if (pDirection <= (0.6667)){
									myICAM1Grid.attemptMicroDiffusion(currICAM1, Constants.SOUTH);
								} else if (pDirection <= (0.8333)){
									myICAM1Grid.attemptMicroDiffusion(currICAM1, Constants.SOUTHWEST);
								} else {
									myICAM1Grid.attemptMicroDiffusion(currICAM1, Constants.NORTHWEST);
								}		
							}
						}
					}
				}
			}	
			
		}
		
		this.updateStatus();
	}
	
	/*
	 * Record ICAM1 Data 
	 */
	public void recordICAM1Data(){
		
		if (this.containsICAM1){
			try{
				ISWBC myISWBC = mySurfaceSpace.getISWBC();
				for (int i = 0; i < icam1AgentList.size(); i++){
				

					if (myMemUnit != null){
						Ind_ICAM1 ii = (Ind_ICAM1)icam1AgentList.get(i);
						Double t = new Double(myISWBC.getTickCount());
						StringBuffer sb = new StringBuffer();
						StringBuffer sb2 = new StringBuffer();
						if (ii.isDimeric()){
							//First
							String filename = myMemUnit.getLFA1Grid().getDirectoryName()+"/ICAM1_"+"0"+2*i+".txt";
							BufferedWriter out = new BufferedWriter(new FileWriter(filename, true));
							sb.append(t+","+ii.getMicroX()+","+ii.getMicroY()+"|"+ii.getStatus()+"\n");
							out.write(sb.toString());
							out.close();
							
							//Dimer
							int num = (2*i)+1;
							Ind_ICAM1 ii2 = ii.getMyDimer();
							String filename2 = myMemUnit.getLFA1Grid().getDirectoryName()+"/ICAM1_"+"0"+num+".txt";
							BufferedWriter out2 = new BufferedWriter(new FileWriter(filename2, true));
							sb2.append(t+","+ii2.getMicroX()+","+ii2.getMicroY()+"|"+ii2.getStatus()+"\n");
							out2.write(sb2.toString());
							out2.close();
						
							
						} else if (ii.isTrimeric()){ 
						 
							
							
						} else {
							String filename = myMemUnit.getLFA1Grid().getDirectoryName()+"/ICAM1_"+"0"+i+".txt";
							BufferedWriter out = new BufferedWriter(new FileWriter(filename, true));
			     
								sb.append(t+","+ii.getMicroX()+","+ii.getMicroY()+"|"+ii.getStatus()+"\n");
							out.write(sb.toString());
							out.close();
						}
					} else {
						myISWBC.log("No MemUnit for SU:"+this.getX()+","+this.getY(),0);
					}
				}
			
			} catch (IOException e){
				System.out.println("Error in printing ICAM1Grid");
			}
		}
	}
	
	/*
	 * Returns true if this Surface Unit has an ICAM1Grid
	 */
	public boolean containsICAM1At(int MicroX, int MicroY){
		boolean contains = false;
		if(containsICAM1){
			if (myICAM1Grid.containsICAM1At(MicroX, MicroY)){
				contains = true;
			}
		}
		return contains;
	}
	
	/*
	 * Sets the Membrane Unit for this Surface Unit
	 * @param mu is the Membrane Unit 
	 */
	public void setMyMemUnit(MemUnit mu){
		myMemUnit = mu;
	}
	
	/*
	 * Gets the Membrane Unit for the Surface Unit
	 */
	public MemUnit getMyMemUnit(){
		return myMemUnit;
	}
		
	/*
	 * Gets the ICAM1Grid for this SurfUnit
	 */
	public ICAM1Grid getICAM1Grid(){
		return myICAM1Grid;
	}
	
	/*
	 * Sets the Surface for this Surface unit
	 * @param s is the Surface
	 */
	public void setSurfaceSpace(Surface s){
		mySurfaceSpace = s;
	}
	
	/* Gets the Surface for this SurfaceUnit
	 * @return the Surface 
	 */
	public Surface getSurfaceSpace(){
		return mySurfaceSpace;
	}

	/*
	 * Returns the x position on the cell membrane 
	 */
	public int getX(){
		return xPos;
	}
		
	/*
	 * Returns the y position on the cell membrane
	 */
	public int getY(){
		return yPos;
	}

	/*
	 * Sets the x,y position on the Surface
	 */
	public void setPosition(int x, int y){
		xPos = x;
		yPos = y;
	}
		
	/*
	 * Returns true if this MemUnit contains a bound AdhesMolecule
	 */
	public boolean isBound(){
		boolean bound = (this.getNumBonds() > 0.0);
		return bound;
	}
	
	/*
	 * Returns true if the LeukMem is in contact with this SurfaceUnit
	 * (not indicative if bound to this SurfaceUnit)
	 */
	public boolean isCovered(){
		
		return (myMemUnit != null);
	
	}	
	
	/*
	 * Returns the number of bonds between the LeukMem and this SurfaceUnit
	 */
	public double getNumBonds(){
		double numOfBonds = 0;
		
		for (int i = 0; i < Constants.TOTNUM_GRP_ADHMOLS; i ++){
			if (myAdhMols[i] != null){
				if (myAdhMols[i].isBound()){
					Grp_AdhesMolecules abL = (Grp_AdhesMolecules)myAdhMols[i];
				
					numOfBonds = numOfBonds + abL.getNumBonds();
				}
					
			}
		}
		return numOfBonds;
	}

	/*
	 * Returns the total number of Adhesion Molecules in this SurfaceUnit
	 */
	public double getTotNumAdhMols(){
		double totNum = 0;
		
		for (int i = 0; i < Constants.TOTNUM_GRP_ADHMOLS; i ++){
			if (myAdhMols[i] != null){
				Grp_AdhesMolecules abL = (Grp_AdhesMolecules)myAdhMols[i];
				totNum += abL.getTotalNumber();
				
			}
		}	
		return totNum;
	}
	
	/*
	 * Specifies how SurfaceUnit is to be displayed on DisplaySurface
	 */
	public void draw(SimGraphics g){
		g.setDrawingParameters(DisplayConstants.CELL_WIDTH*4/5,
		DisplayConstants.CELL_HEIGHT*4/5,
		DisplayConstants.CELL_DEPTH*4/5);
		
		if (this.isCovered()){
			Surface sSpace = this.getSurfaceSpace();
			MemUnit leukMemS = 
				sSpace.getLeukMemUnitAt(this.getX(),this.getY());
		
			if (this.membraneType == Constants.NO_LIGANDS ||
				this.membraneType == Constants.ONLY_CHEMOKS){
				if(leukMemS.isActivated()){
					g.drawFastRoundRect(Color.GREEN);
				} else {
					g.drawFastRoundRect(Color.PINK);
				}
			} else if (this.isBound()){
				if (leukMemS.isActivated()){
					g.drawFastRoundRect(Color.RED);
				}else{
					g.drawFastRoundRect(Color.RED);
				}
			} else if (this.membraneType == Constants.ONLY_ADHESMOLS_CHEMOKS ||
					this.membraneType == Constants.ONLY_ADHESMOLS){
				g.drawFastRoundRect(Color.PINK);
			} else {
				log("Error: SHOULD NOT GO HERE",0);
				g.drawFastRoundRect(Color.YELLOW);
			}
		} else {
			if (this.membraneType == Constants.NO_LIGANDS){
				g.drawFastRoundRect(Color.BLACK);
			} else if (this.membraneType == Constants.ONLY_ADHESMOLS){
				g.drawFastRoundRect(Color.RED);
			} else if (this.membraneType == Constants.ONLY_CHEMOKS ||
					this.membraneType == Constants.ONLY_ADHESMOLS_CHEMOKS){
				g.drawFastRoundRect(Color.GREEN);
			} else {		 
				log("Error: SHOULD NOT GO HERE",0);
			}
		}
	}	
	
	/*
	 * Updates the bound and covered booleans so that they are displayed
	 * correctly on the DisplaySurface
	 */
	public void updateStatus(){
			if (this.isCovered()){
			log("ECELLMEM COVERED: "+this.getX()+" "+this.getY(),2);
		}
		
		if (this.isBound()){
			log("ECELLMEM BOUND: "+this.getX()+" "+this.getY(),2);
		}
	}
	
	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
	private void log(String s, int debugType){
		
		if (this.mySurfaceSpace.getISWBC().getDebugging() >= debugType){
			System.out.println("SurfaceUnit: "+s);
		}
	}
}