package src.flowchamber;

import src.model.ISWBC;
import src.flowchamber.FlowChamber;
import src.model.*;
/*
 * Constructs a RearForceController object for this ISWBC and FlowChamber
 * This controls the RearForce at each time point
 */
public class RearForceController {
	
	ISWBC myLAM;
	FlowChamber myFlowChamber;
	//RearForce values when simulating experiments with increasing shear
	double rearForce1, rearForce2, rearForce3, rearForce4, rearForce; 
	
	int experimentType;//defined by Constants 
	/*
	 * Creates a RearForceController
	 * @param lam is the ISWBC
	 * @param fc is the FlowChamber
	 */
	public RearForceController(ISWBC lam, FlowChamber fc){
		myLAM = lam;
		myFlowChamber = fc;
		experimentType = myLAM.getExpCondition();
	}
	
	/*
	 * get the RearForce for the timeStep 
	 * @param timeStep is the simulation time
	 * @return the rearForce value at that timeStep
	 */
	public double getRearForce(int timeStep){
		if (experimentType == Constants.INCREASING_SHEAR){
			if ((timeStep > 0) && (timeStep <= 100)){
				return myLAM.getRearForce1();
			} else if ((timeStep > 100) && (timeStep <= 400)){
				return myLAM.getRearForce2();
			} else if ((timeStep > 400) && (timeStep <= 550)){
				return myLAM.getRearForce3();
			} else {
				return myLAM.getRearForce4();
			}		
		} else {
			return myLAM.getRearForce0();
		}
	}
	
	
}
