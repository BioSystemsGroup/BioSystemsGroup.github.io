/*
 * @author Jonathan Tang
 */

package src.flowchamber;
import uchicago.src.sim.space.OrderedMulti2DTorus;

import java.util.HashMap;

import src.cell.*;
import src.membrane.LeukMem;
import src.membrane.MemUnit;
import src.model.ISWBC;

/* A SurfaceSpace represents the bottom surface of the parallel plate
 * flow chamber or endothelial Surface.  It is a 2D multi-level array.  The bottom level 
 * contains SurfaceUnits, and the second layer contains LeukMemUnits if any.
 */
public class Surface extends OrderedMulti2DTorus{
	
	private FlowChamber myFlowChamber;
	private ISWBC myISWBC;
	private int ICAM1participants; //number of ICAM1 objects that have participated in bonding.
	private int ICAM1RebindingEvents;
	/* Creates a SurfaceSpace of size xSize by ySize for FlowChamber fc and ISWBC lam
	 * @param xSize is the size in the x dimension
	 * @param ySize is the size in the y dimension
	 * @param fc is the FlowChamber for this Surface
	 * @param lam is the ISWBC for this experiment
	 */
	public Surface(int xSize, int ySize, FlowChamber fc, ISWBC lam){
		super(xSize, ySize, true);
		myFlowChamber = fc;
		myISWBC = lam;
		ICAM1participants = 0;
		ICAM1RebindingEvents = 0;
	}
	
	/* Returns the ISWBC for this SurfaceSpace
	 * @returns the ISWBC for this Surface
	 */
	public ISWBC getISWBC(){
		return myISWBC;
	}
	
	/* 
	 * @param x is the x coordinate at which to put the SurfaceUnit object
	 * @param y is the y coordinate at which to put the SurfaceUnit object
	 * @param object is the object
	 */
	public void putSurfaceUnitAt(int x, int y, Object object){
		this.putObjectAt(x%xSize, y%ySize, 0, object);
	}
	
	/* Gets the SurfaceUnit at a coordinate
	 * @param x is the x coordinate
	 * @param y is the y coordinate
	 * @returns a SurfaceUnit at a coordinate
	 */
	public SurfaceUnit getSurfaceUnitAt(int x, int y){
		return (SurfaceUnit)this.getObjectAt(x%xSize, y%ySize, 0);
	}
	
	/*
	 * Removes the SurfaceUnit at a coordinate
	 * @param x is the x coordinate
	 * @param y is the y coordinate
	 */
	public SurfaceUnit removeSurfaceUnitAt(int x, int y){
		return (SurfaceUnit)this.removeObjectAt(x%xSize, y%ySize, 0);
	}
	
	/*Puts a LeukMemUnit on the Surface at a coordinate
	 * @param x is the x coordinate to put the LeukMemUnit
	 * @param y is the y coordinate to put the LeukMemUnit
	 * @param object is the LeukMemUnit to insert 
	 */
	public void putLeukMemUnitAt(int x, int y, Object object){
		if (object instanceof MemUnit){
			SurfaceUnit su = this.getSurfaceUnitAt(x%xSize, y%ySize);
			su.setMyMemUnit((MemUnit)object);
		} else {
			log("Error: -putLeukMemUnitAt: not a MemUnit",0);
		}
	}
	
	/*Gets a LeukMemUnit at a coordinate x, y
	 * @param x is the x coordinate
	 * @param y is the y coordinate
	 * @returns the MemUnit if it exists. Returns null if nonexistent
	 * 
	 */
	public MemUnit getLeukMemUnitAt(int x, int y){
		MemUnit mu; 
		SurfaceUnit su = (SurfaceUnit)this.getObjectAt(x%xSize, y%ySize, 0);
		if (su == null){
			mu = null;
		} else {
			mu = su.getMyMemUnit();
		}
		
		return mu;
	}
	
	/*Removes a LeukMemUnit from the Surface
	 * @param x is the x coordinate of the LeukMemUnit to remove
	 * @param y is the y coordinate of the LeukMemUnit to remove
	 * @returns the MemUnit that was removed, if it exists 
	 */
	public MemUnit removeLeukMemUnitAt(int x, int y){
		if (containsLeukMemUnitAt(x,y)){
			SurfaceUnit su = (SurfaceUnit)this.getObjectAt(x%xSize, y%ySize, 0);
			MemUnit mu = su.getMyMemUnit();
			su.setMyMemUnit(null);
			return mu;
		} else {
			return null;
		}
	}
	
	/* Determines if there is a LeukMemUnit at a location on the Surface
	 * @param x is the x coordinate
	 * @param y is the y coordinate
	 * @returns whether there is a LeukMemUnit at coordinates x,y on the Surface
	 */
	public boolean containsLeukMemUnitAt(int x, int y){
		MemUnit leukMem = getLeukMemUnitAt(x,y);
		return (leukMem != null);
	}
	/* Determines if there is a SurfaceUnit at a location on the Surface
	 * @param x is the x coordinate
	 * @param y is the y coordinate
	 * @returns whether there is a SurfaceUnit at coordinates x,y on the Surface
	 */
	public boolean containsSurfUnitAt(int x, int y){
		SurfaceUnit su = getSurfaceUnitAt(x,y);
		return (su != null);
	}
	
	/*
	 * Allows a Leukocyte to attach to the surface at y=0
	 * @param leuk is the Leukocyte to attach
	 */
	public void insertLeuk(Leukocyte leuk){
		int y = 0;
		log("INSERTING LEUK at 0, "+y,2);
		this.tetherLeuk(leuk,0,y);
		
	}
	
	/*
	 * Attaches Leukocyte to the Surface at coordinates x,y
	 * @param leuk is the leukocyte
	 * @param x is the x coordinate to attach to
	 * @param y is the y coordinate to attach to
	 */
	public void tetherLeuk(Leukocyte leuk, int x, int y){
		LeukMem leukMem = leuk.getLeukMem();
		leukMem.tetherToSurface(this,x,y);

		int expLength = leukMem.getExposureLength();
		for (int colNum = 0; colNum < expLength; colNum++){
			this.insertLeukMemUnitColumn(leukMem,colNum);
		}		
		leukMem.interactWithEnvironment();

		if (leukMem.bound()){
			while (leukMem.trailingEdgeFree()){
				leukMem.roll();
			}
		} else {
			this.detachLeukMem(leukMem);	
		}
	}
	
	/* Inserts a column of the LeukMem onto the Surface (the length of the column is predefined)
	 * This action occurs during ROLLING
	 * @param leukMem is the membrane to insert
	 * @param colNum is the number of the column of the LeukMem to insert
	 */
	public void insertLeukMemUnitColumn(LeukMem leukMem, int colNum){
		int bottomEdge = leukMem.getBottomEdge();
		int topEdge = leukMem.getTopEdge();
		int x = leukMem.findXPosOnSurfSpace(colNum);
		log("Bottom/Top Edge: "+bottomEdge+"/"+topEdge,3);
		if (bottomEdge < topEdge){
			for (int row = bottomEdge; row <= topEdge; row++){
				int y = leukMem.findYPosOnSurfSpace(row);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(colNum,row);
				this.insertLeukMemUnit(lms,x,y);
				log("1)INSERTING LEUKMEMUNIT -> SSPACE:"+colNum+" "+row+" -> "+x+" "+y,3);	
			}
		} else {
			for (int row = 0; row <= topEdge; row++){
				int y = leukMem.findYPosOnSurfSpace(row);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(colNum,row);
				this.insertLeukMemUnit(lms,x,y);
				log("2)INSERTING LEUKMEMUNIT -> SSPACE:"+colNum+" "+row+" -> "+x+" "+y,3);	
			}
			for (int row = bottomEdge; row < leukMem.getWidth(); row++){
				int y = leukMem.findYPosOnSurfSpace(row);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(colNum,row);
				this.insertLeukMemUnit(lms,x,y);
				log("3)INSERTING LEUKMEMUNIT -> SSPACE:"+colNum+" "+row+" -> "+x+" "+y,3);	
			}
			
		}
	}
	
	/* Inserts a row of the LeukMem onto the Surface (the length of the row is predefined)
	 * This action occurs during FLATTENING or lateral movement perpendicular to flow
	 * @param leukMem is the membrane to insert
	 * @param rowNum is the number of the row of the LeukMem to insert
	 */
	public void insertLeukMemUnitRow(LeukMem leukMem, int rowNum){
		int y = leukMem.findYPosOnSurfSpace(rowNum);
		int leadingEdge = leukMem.getLeadingEdge();
		int trailingEdge = leukMem.getTrailingEdge();
		
		if (trailingEdge < leadingEdge){
			for (int col = trailingEdge; col <= leadingEdge; col++){
				int x = leukMem.findXPosOnSurfSpace(col);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(col,rowNum);
				this.insertLeukMemUnit(lms,x,y);
				log("INSERTING LEUKMEMUNIT -> SSPACE:"+col+" "+rowNum,3);
			}
		} else {
			for (int col = 0; col <= leadingEdge; col++){
				int x = leukMem.findXPosOnSurfSpace(col);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(col,rowNum);
				this.insertLeukMemUnit(lms,x,y);
				log("INSERTING LEUKMEMUNIT -> SSPACE:"+col+" "+rowNum,3);
			}
			for (int col = trailingEdge; col < leukMem.getLength(); col++){
				int x = leukMem.findXPosOnSurfSpace(col);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(col,rowNum);
				this.insertLeukMemUnit(lms,x,y);
				log("INSERTING LEUKMEMUNIT -> SSPACE:"+col+" "+rowNum,3);
			}
			
			
		}
	}
	/* Inserts a LeukMemUnit onto the Surface
	 * @param leukMemSect is the membraneUnit to insert
	 * @param x is the x coordinate to insert into
	 * @param y is the y coordinate to insert into
	 */
	public void insertLeukMemUnit(MemUnit leukMemSect, int x, int y){
		if(this.containsLeukMemUnitAt(x,y)){
			log("insertLeukMemUnit: LeukMemUnit already exists there!"+x+","+y,0);
		}
		
		
		SurfaceUnit pObject = new SurfaceUnit(x,y,this, leukMemSect, leukMemSect.containsLFA1());
		this.putSurfaceUnitAt(x,y,pObject);	
		this.putLeukMemUnitAt(x,y,leukMemSect);
		leukMemSect.setSurfaceSpace(this);
	
		HashMap<Integer, HashMap<Integer, SurfaceUnit>> hmx = myISWBC.getSurfUnitXHash();
		HashMap<Integer, SurfaceUnit> hmy;
		if (hmx.containsKey(x)){
			hmy = (HashMap)hmx.get(x);
		} else {
			hmy = new HashMap<Integer, SurfaceUnit>(15);
		}
		hmy.put(y,pObject);
		hmx.put(x,hmy);
		log("insertLeukMemUnit: "+hmy.containsValue(pObject),3);
		log("INSERTING LEUKMEMUNIT IN SSPACE: "+x+" "+y,3);
		
	}
	/*
	 * Removes LeukMem from Surface
	 * @param leukMem is the Membrane to remove
	 */
	public void detachLeukMem(LeukMem leukMem){
		int len = this.xSize;
		int wid = this.ySize;
		for (int i = 0; i < len; i++){
			for (int j = 0; j < wid; j++){
				this.removeLeukMemUnitAt(i,j);
			}
		}
		
		
		myISWBC.setSurfUnitXHash(null);
	}
	
	/*
	 * Removes a Column of the LeukMembrane from the Surface, during Rolling
	 * @param leukMem is the leukocyte Membrane
	 * @param colNum is the column number
	 */
	public void removeLeukMemUnitColumn(LeukMem leukMem, int colNum){
	
		int bottomEdge = leukMem.getBottomEdge();
		int topEdge = leukMem.getTopEdge();
		int x = leukMem.findXPosOnSurfSpace(colNum);
		log("Bottom/Top Edge: "+bottomEdge+"/"+topEdge,3);
		if (bottomEdge < topEdge){
			for (int row = bottomEdge; row <= topEdge; row++){
				int y = leukMem.findYPosOnSurfSpace(row);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(colNum,row);
				this.removeLeukMemUnit(lms,x,y);
				log("Removing LEUKMEMUNIT -> SSPACE:"+colNum+" "+row+" -> "+x+" "+y,2);	
			}
		} else {
			for (int row = 0; row <= topEdge; row++){
				int y = leukMem.findYPosOnSurfSpace(row);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(colNum,row);
				this.removeLeukMemUnit(lms,x,y);
				log("Removing LEUKMEMUNIT -> SSPACE:"+colNum+" "+row+" -> "+x+" "+y,2);	
			}
			for (int row = bottomEdge; row < leukMem.getWidth(); row++){
				int y = leukMem.findYPosOnSurfSpace(row);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(colNum,row);
				this.removeLeukMemUnit(lms,x,y);
				log("Removing LEUKMEMUNIT -> SSPACE:"+colNum+" "+row+" -> "+x+" "+y,2);	
			}
			
		}
		HashMap<Integer, HashMap<Integer, SurfaceUnit>> hmx = myISWBC.getSurfUnitXHash();
		HashMap hmy = (HashMap)hmx.get(x);
		if (hmy.isEmpty()){
			hmx.remove(x);
		}
		
		
	}
	

	/*
	 * Removes a Row of the LeukMembrane from the Surface, during lateral movement up/down
	 * @param leukMem is the leukocyte Membrane
	 * @param rowNum is the row number
	 */
	public void removeLeukMemUnitRow(LeukMem leukMem, int rowNum){

		int y = leukMem.findYPosOnSurfSpace(rowNum);
		int leadingEdge = leukMem.getLeadingEdge();
		int trailingEdge = leukMem.getTrailingEdge();
		
		if (trailingEdge < leadingEdge){
			for (int col = trailingEdge; col <= leadingEdge; col++){
				int x = leukMem.findXPosOnSurfSpace(col);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(col,rowNum);
				this.removeLeukMemUnit(lms,x,y);
				log("Removing LEUKMEMUNIT -> SSPACE:"+col+" "+rowNum,3);
			}
		} else {
			for (int col = 0; col <= leadingEdge; col++){
				int x = leukMem.findXPosOnSurfSpace(col);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(col,rowNum);
				this.removeLeukMemUnit(lms,x,y);
				log("Removing LEUKMEMUNIT -> SSPACE:"+col+" "+rowNum,3);
			}
			for (int col = trailingEdge; col < leukMem.getLength(); col++){
				int x = leukMem.findXPosOnSurfSpace(col);
				MemUnit lms = (MemUnit)leukMem.getMemUnit(col,rowNum);
				this.removeLeukMemUnit(lms,x,y);
				log("Removing LEUKMEMUNIT -> SSPACE:"+col+" "+rowNum,3);
			}
		}
	}
	
	/*
	 * Removes a LeukMem unit from the Surface at coordinate x,y
	 * @param leukMemSect is the membrane Unit to remove
	 * @param x is the x coordinate on the Surface
	 * @param y is the y coordinate on the Surface
	 */
	public void removeLeukMemUnit(MemUnit leukMemSect, int x, int y){	
		this.removeLeukMemUnitAt(x,y);

		HashMap<Integer, HashMap<Integer, SurfaceUnit>> hmx = myISWBC.getSurfUnitXHash();
		if (!hmx.containsKey(x)){
			myISWBC.log("Error: -removeLeukMemUnit: Error - unknown hasmap at x,y="+x+","+y,0);
			
		}
		HashMap hmy = (HashMap)hmx.get(x);
		if (hmy.containsKey(y)){
			hmy.remove(y);
		} else {
			log("Surface: -removeLeukMemUnit:Error: unknwon hashmap entry",3);
		}
		
		this.removeSurfaceUnitAt(x,y);

		log("REMOVING LEUKMEMSECT AT:"+x+" "+y,3);
		leukMemSect.setSurfaceSpace(null);
	}
	
	/* Increments the number of ICAM1 that have
	 * participated in binding
	 */
	public void incrementICAM1participants(){
		ICAM1participants++;
	}
	
	/* Get the total number of ICAM1 that have
	 * participated in binding
	 */ 
	public int getICAM1participants(){
		return ICAM1participants;
	}
	
	/* Increments the number of ICAM1 Rebinding events
	 */
	public void incrementICAM1RebindingEvents(){
		ICAM1RebindingEvents++;
	}
	
	/* Get the total number of ICAM1 Rebinding events
	 */ 
	public int getICAM1RebindingEvents(){
		return ICAM1RebindingEvents;
	}
	
	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
	public void log(String s, int debugType){
		if (myISWBC.getDebugging() >= debugType){
			System.out.println("Surface: "+s);
		}
		
	}
}
