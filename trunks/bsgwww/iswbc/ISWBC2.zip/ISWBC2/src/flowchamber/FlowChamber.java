/*
 * @author Jonathan Tang
 */
package src.flowchamber;

import src.cell.*;
import src.membrane.*;
import src.model.Constants;
import src.model.ISWBC;
import java.util.HashMap;
/*
 * This Class represents a flow chamber that contains a surface for Leukocyte objects to interact
 */
public class FlowChamber implements Constants{
	
	private RearForceController myRearForceController;
	private Surface mySurfSpace;
	private ISWBC myISWBC;
	private double rearForce;  //representative of shear
		
	/*
	 * Creates a FlowChamber with properties specified by the
	 * ISWBC
	 * @param myModel ISWBC
	 */
	public FlowChamber(ISWBC myModel){
		myISWBC = myModel;
		int surfaceSpace_XSize = myISWBC.getSurfaceSpace_XSize();
		int surfaceSpace_YSize = myISWBC.getSurfaceSpace_YSize();
		HashMap hm = new HashMap(15);
		myISWBC.setSurfUnitXHash(hm);
				
		mySurfSpace = new Surface(surfaceSpace_XSize,surfaceSpace_YSize,this, myModel);		
		myISWBC.setMySurfaceSpace(mySurfSpace);
	}
	
	/*
	 * Sets the RearForceController for this FlowChamber
	 * @param rfc	RearForceController to be set for this FlowChamber
	 */
	public void setRearForceController(RearForceController rfc){
		myRearForceController = rfc;
	}
	
	/*
	 * Gets the RearForceController for this FlowChamber
	 * @return 	the RearForceController for this FlowChamber
	 */
	public RearForceController getRearForceController(){
		return myRearForceController;
	}
	
	/*
	 * Inserts Leukocytes into the FlowChamber
	 * @param leukAgents ArrayList of Leukocyte objects to be entered
	 */
	public void insertLeukocyte(Leukocyte leuk){
		LeukMem lMem = (LeukMem)leuk.getLeukMem();
		lMem.setSurfaceSpace(mySurfSpace);
		lMem.setFlowChamber(this);
		mySurfSpace.insertLeuk(leuk);
	 }
	
	/*
	 * Sets RearForce
	 * @param rf RearForce value to be set
	 */
	public void setRearForce(double rf){
		rearForce = rf;
	}
	
	/*
	 * Gets the RearForce
	 * @return the RearForce value
	 */
	public double getRearForce(){
		return rearForce;
	}
	
	/*
	 * Gets the ISWBC for this FlowChamber
	 * @return the ISWBC for this FlowChamber
	 */
	public ISWBC getModel(){
		return myISWBC;
	}
}
