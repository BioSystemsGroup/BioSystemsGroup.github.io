
/*
 * @author Jonathan Tang
 */
package src.model;

public interface Constants {
	
	//Types of MemUnits - for Display purposes
	public final static int NO_LIGANDS = 0; //no Ligands exposed
	public final static int ONLY_ADHESMOLS_CHEMOKS = 1; //chemoks & adhesMolecules
	public final static int ONLY_ADHESMOLS_CHEMOKRECEPS = 2; //chemokreceptors and adhesmolecules
	public final static int ONLY_CHEMOKS = 3; //only chemoks exposed
	public final static int ONLY_ADHESMOLS = 4; //only adhesMolecules exposed
	public final static int ONLY_CHEMOKRECEPS = 5; //only chemokreceptors exposed

	//Types of Grp_AdhesMolecules
	public static final int PSGL1 = 0;
	public static final int PSELECTIN = 1;
	public static final int VLA4 = 2;
	public static final int VCAM1 = 3;
	public static final int TOTNUM_GRP_ADHMOLS = 4;
	
	//Types of Ind_AdhesMolecules
	public static final int LFA1 = 0;
	public static final int ICAM1 = 1;
	public static final int TOTNUM_IND_ADHMOLS = 2;
	
	//Types of Chemoks
	public static final int GROA = 0;
	public static final int TOTNUMCHEMOKS = 1;
	
	//Types of ChemokReceptors
	public static final int CXCR2 = 0;
	public static final int TOTNUMCHEMOKRECEPS = 1;
	
	//Direction of movement on square lattice grid
	public static final int UP = 1;
	public static final int NEUTRAL = 0;
	public static final int DOWN = -1;
	
	//Direction of movement on hexagonal grid
	//	1
	//6	  2
	//	0
	//5	  3
	//	4
	public static final int SAME = 0;
	public static final int NORTH = 1;
	public static final int NORTHEAST = 2;
	public static final int SOUTHEAST = 3;
	public static final int SOUTH = 4;
	public static final int SOUTHWEST = 5;
	public static final int NORTHWEST = 6;

	

	//Integrin Affinity Values
	public static final int LOW_AFFINITY = 0;
	public static final int HIGH_AFFINITY = 1;
	
	//Experimental Conditions
	public static final int CONSTANT_SHEAR = 0;
	public static final int INCREASING_SHEAR = 1;
	public static final int IN_VIVO = 2;
	
	//Printing data
	public static final int TRUE = 1;
	public static final int FALSE = 0;

}
