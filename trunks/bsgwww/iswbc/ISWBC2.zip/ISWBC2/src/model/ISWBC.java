package src.model;

import java.util.HashMap;
import java.util.Date;
import java.util.Set;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import src.cell.Leukocyte;
import src.flowchamber.FlowChamber;
import src.flowchamber.RearForceController;
import src.flowchamber.Surface;
import src.flowchamber.SurfaceUnit;
import src.membrane.LeukMem;
import uchicago.src.sim.analysis.DataRecorder;
import uchicago.src.sim.analysis.DataSource;
import uchicago.src.sim.analysis.OpenSequenceGraph;
import uchicago.src.sim.analysis.Sequence;
import uchicago.src.sim.engine.AbstractGUIController;
import uchicago.src.sim.engine.BasicAction;
import uchicago.src.sim.engine.Schedule;
import uchicago.src.sim.engine.SimInit;
import uchicago.src.sim.engine.SimModelImpl;
import uchicago.src.sim.gui.DisplayConstants;
import uchicago.src.sim.gui.DisplaySurface;
import uchicago.src.sim.gui.Object2DDisplay;
/*
 * Class that represents an in silico analogue of the wet-lab experiments (in vitro, ex vivo, in vivo)
 * to study leukocyte (white blood cell) rolling and adhesion during inflammation under different
 * experimental conditions (shear) and combination of substrate molecules.
 */
public class ISWBC extends SimModelImpl  {
	
	private String fileDirectoryName;
	private int expCondition;			//0=constant RearForce, 1=increasing RearForce, 2=in vivo
	private double rearForce1;			//rearForce at tstep = 0  when expCondition = 1
	private double rearForce2;			//rearForce at tstep >= 100 when expCondition = 1
	private double rearForce3;			//rearForce at tstep >= 400 when expCondition = 1
	private double rearForce4;			//rearForce at tstep >= 550 when expCondition = 1

	private int Debugging;				//prints out debugging info if > 0
	public int GUI_Display;				//shows display if > 0

	private double Flattening_Time;		//time until it
	private double rearForce0;			//RearForce when expCondition = 0 or 2
	private double MaxPercActiveVLA4;	//max percentage of high affinity VLA4
	private int SurfaceSpace_XSize;		//size in x direction of SurfaceSpace
	private int SurfaceSpace_YSize;		//size in y direction of SurfaceSpace
	private int LFA1GridSize;			//size in x-y direction of LFA1Grid (and ICAM1Grid)
	private int PrintLFA1Data; 			//0-false, 1-true - print out LFA1 data
	private int PrintICAM1Data;			//0-false, 1-true - print out ICAM1 data
	private int PrintIntervalData;		//0-false, 1-true - print out Interval Data
	private int PrintBondFile;
	private int PrintBond50sIntervalFile; //0-false, 1-true - print out Bond 50s Interval Data
	private int PrintAllData;			//0-false, 1-true - print out all data
	private double CXCR2_P_Internalize; //internalization probability
	
	private int Leuk_ExposedWidth;		//size in y direction of contact zone
	private int Leuk_ExposedLength;		//size in x direction of contact zone
	private int Leuk_TotalWidth;		//size in y direction of LeukMembrane
	private int Leuk_TotalLength;		//size in x direction of LeukMembrane	
	private int End_Time;				//end time of the run

	private double Density_VCAM1_Mean;		//Mean Density of VCAM1
	private double Density_VLA4_Mean;		//Mean Density of VLA4
	private double Density_PSGL1_Mean;		//Mean Density of PSGL1
	private double Density_PSELECTIN_Mean;	//Mean Density of PSELECTIN
	private double Density_CXCR2_Mean;		//Mean Density of CXCR2
	private double Density_GROA_Mean;		//Mean Density of GROA
	private double Density_LFA1_Mean;		//Mean Density of LFA1
	private double Density_LFA1Grid_Mean;	//Mean Density of LFA1Grid
	private double Density_ICAM1_Mean;		//Mean Density of LFA1
	private double Density_dICAM1_Mean;		//Mean Density of divalent ICAM1

	
	
	private int NumLFA1Clusters; 			//Number of LFA1 Clusters/LFA1Grid
	private int LFA1ClusterDiameter;		//Diameter of the LFA1Cluster in both directions
	private int ICAM1ClusterSearchDistance; //Distance to search for dICAM1 partner 
	private int ICAM1NativeSize;			//1-monomeric, 2-dimeric, 3-preclustered
	private double Rate_LFA1GridIncrease;	//Rate of LFA1Grid Exposure Increase during spreading
	private int LFA1ClusteringAllowed;		//0-false, 1-true = LFA1 Clustering mechanism allowed
	private int ICAM1WTetramerAllowed;		//0-false, 1-true = ICAM1 W-Clustering mechanism allowed
	private int ICAM1PreClusteredAllowed;	//0-false, 1-true = ICAM1 PreClustered mechanism allowed
	private int EAPClusteringAllowed;		//EXPERIMENTAL
	private int EAPDiameter;				//EXPERIMENTAL
	private int PI3KPresent;				//EXPERIMENTAL
	private double PCluster1;				//EXPERIMENTAL
	private double PCluster2;				//EXPERIMENTAL
	private int SpreadingAllowed;			//EXPERIMENTAL
	
	private double Density_PSGL1_STDev;		//StDev Density of PSGL1
	private double Density_VLA4_STDev;		//StDev Density of VLA4	
	private double Density_PSELECTIN_STDev;	//StDev Density of PSELECTIN
	private double Density_VCAM1_STDev;		//StDev Density of VCAM1
	private double Density_CXCR2_STDev;		//StDev Density of CXCR2
	private double Density_GROA_STDev;		//StDev Density of GROA
	private double Density_LFA1_STDev;		//StDev Density of LFA1
	private double Density_LFA1Grid_STDev;	//StDev Density of LFA1Grid
	private double Density_ICAM1_STDev;		//StDev Density of LFA1
	private double Density_dICAM1_STDev;	//StDev Density of dICAM1
	
	//Ligand binding parameters for Receptors
	private double PSelectin_PSGL1_Pon;		
	private double PSelectin_PSGL1_B1_DissConst;
	private double PSelectin_PSGL1_B0_DissConst;
	private double VCAM1_VLA4_Low_Pon;
	private double VCAM1_VLA4_LowAff_B1_DissConst;
	private double VCAM1_VLA4_LowAff_B0_DissConst;
	private double VCAM1_VLA4_High_Pon;
	private double VCAM1_VLA4_HighAff_B1_DissConst;
	private double VCAM1_VLA4_HighAff_B0_DissConst;
	private double VCAM1_VLA4_HighAff_B1_Limit;
	private double ICAM1_LFA1_Low_Pon;
	private double ICAM1_LFA1_LowAff_B1_DissConst;
	private double ICAM1_LFA1_LowAff_B0_DissConst;
	private double ICAM1_LFA1_LowAff_B1_Limit;
	private double ICAM1_LFA1_High_Pon;
	private double ICAM1_LFA1_HighAff_B1_DissConst;
	private double ICAM1_LFA1_HighAff_B0_DissConst;
	private double ICAM1_LFA1_HighAff_B1_Limit;
	
	private int DiffusionMobile;  			//Number of move tries for "Mobile" LFA1 during difusion
	private int DiffusionImmobile;			//number of move tries for "Immobile" LFA1 during diffusion (still mobile)
	private int ICAM1_Move;					//Number of moves for ICAM1 to try during diffusion
	private double LFA1_PRemoval;			//Rate of removal of LFA1 from system

	//SurfUnitXHash		(key (int: x coord), value (HashMap: surfUnitYHash))
	//SurfUnitYHash 	(key (int: y coord), value (SurfUnit)
	private HashMap surfUnitXHash;			//HashMap of HashMaps of SurfUnits
	
	private Schedule schedule;				//Schedule
	protected Surface mySurfaceSpace; 		//The Surface Space
	private Leukocyte myLeukocyte;			//The Leukocyte
	private FlowChamber myFlowChamber;		//Flow Chamber for the experiment
	private RearForceController myRearForceController;	//Controls the RearForce (Shear)
	private OpenSequenceGraph leukPositionGraph;		//Graph plotting displacement of Leukocyte vs time
	private DataRecorder allDataRecorder;	 			//Records All Data
	private DataRecorder intervalDataRecorder;			//Records status of Leukocyte at 30 second intervals for comparison to in vitro data
	private DataRecorder outcomeRecorder;				//Records the final outcome of the Leukocyte at the end for comparison to in vitro data
	private int stepNumber;
		
	/* @see uchicago.src.sim.engine.SimModel#setup()
	 * Interface required method
	 */
	public void setup(){
		schedule = new Schedule(1);
		DisplayConstants.CELL_DEPTH = 10;
		DisplayConstants.CELL_WIDTH = 10;	
		DisplayConstants.CELL_HEIGHT = 10;
		AbstractGUIController.CONSOLE_ERR = false;
		AbstractGUIController.CONSOLE_OUT = false;
		Debugging = this.getDebugging();			
		log("FINISHED SETUP",1);
	}
	
	/* Main program 
	 */	
	public static void main(String[] args) {
		SimInit init = new SimInit();
		ISWBC lam = new ISWBC();
		init.loadModel(lam,null,false);
	}
	
	/* @see uchicago.src.sim.engine.SimModel#begin()
	 * * Interface required method
	 */	
	public void begin(){
		log("BEGIN",1);
		buildModel();
		buildSchedule();
		if (this.getGUI_Display()>0){
			buildDisplay();
			leukPositionGraph.display();
		}	
		log("END BEGIN",1);
	}
		
	public void endAbruptly(){
		log("Ending Abruptly",0);
		this.stop();
	}
	
	/* Create the objects for this ISWBC
	 */
	public void buildModel(){	
		if ((this.getPrintLFA1Data() == Constants.TRUE) || (this.getPrintICAM1Data() == Constants.TRUE)){    
			String name = new String("./"+getDateTime());
			File f = new File(name);
			f.mkdir();
			setFileDirectoryName(name);	
		}
			
		//Build Leukocytes (currently only 1 Leukocyte/Run)
		myLeukocyte = new Leukocyte(this);
		log("CREATED Leukocyte",1);
		stepNumber = 1;
			
		if (this.getPrintAllData() == Constants.TRUE){
			allDataRecorder = new DataRecorder("_AllData.txt",this);
			StringBuffer titleSB = new StringBuffer("Position|\t");	
			titleSB.append("All_Bonds\tRear_Bonds\tPSGL1_PSelectin\t|");
			titleSB.append("HighLFA1\tNumLFA1Grids\tNumLFA1Clusters\t|");
			titleSB.append("LFA1Bonds\tDimericLFA1Bonds\tLFA1GridsBound\t|");
			titleSB.append("RearLFA1\tRearLFA1Clusters\tRearLFA1Bonds\tnumRearLFA1GridsBound");
			allDataRecorder.addObjectDataSource(titleSB.toString(),new AllDataSource());
		}
		
		outcomeRecorder = new DataRecorder("_Outcome.txt",this);
		outcomeRecorder.addObjectDataSource("Outcome, Time",new OutcomeDataSource());
		
		if (this.getPrintIntervalData() == Constants.TRUE){	
			intervalDataRecorder = new DataRecorder("_Interval.txt",this);
			intervalDataRecorder.addObjectDataSource("Status",new IntervalDataSource());
		}
		
		//Build Flow Chamber
		myFlowChamber = new FlowChamber(this);
		myFlowChamber.insertLeukocyte(myLeukocyte);
		myRearForceController = new RearForceController(this, myFlowChamber);
		myFlowChamber.setRearForceController(myRearForceController);
			
		log("FINISHED BUILDMODEL",1);
	}
		
	/* Schedule of events
	 */
	public void buildSchedule(){
		log("START Build Schedule",1);
			
		class LAMRunner extends BasicAction{
			ISWBC myLAM;
			private StringBuffer lfa1Participants50sIntervalData;
			private StringBuffer icam1Participants50sIntervalData;
			private StringBuffer lfa1RebindingEventsData;
			private StringBuffer icam1RebindingEventsData;
			private StringBuffer lfa1icam1Bond50sIntervalData;
			private StringBuffer multimericLfa1Icam150sIntervalData;
			
			public LAMRunner(ISWBC lam){
				super();
				myLAM = lam;		
				lfa1Participants50sIntervalData = new StringBuffer("0");
				lfa1RebindingEventsData = new StringBuffer("0");
				icam1Participants50sIntervalData = new StringBuffer("0");
				icam1RebindingEventsData = new StringBuffer("0");
				lfa1icam1Bond50sIntervalData = new StringBuffer("0");
				multimericLfa1Icam150sIntervalData = new StringBuffer("0");
			}
				
			public void execute(){
				log("STEP NUMBER: "+myLAM.stepNumber,2);	
				
				FlowChamber fc = myLAM.getFlowChamber();
				RearForceController rfc = fc.getRearForceController();
				double rearForce = rfc.getRearForce(myLAM.stepNumber);
				fc.setRearForce(rearForce);
					
				//If simulating blood vessels, then Surface is active
				if (myLAM.getExpCondition() == Constants.IN_VIVO){
					if (surfUnitXHash != null){
				
						Set surfSetX = surfUnitXHash.keySet();
						Object[] surfArrayX = surfSetX.toArray();
						int numX = surfArrayX.length;
					
						for (int a = 0; a < numX; a++){
							Integer xa = (Integer) surfArrayX[a];
							int xa2 = xa.intValue();
							HashMap hmY = (HashMap)surfUnitXHash.get(xa2);
					
							Set surfSetY = hmY.keySet();
							Object[] surfArrayY = surfSetY.toArray();
							int numY = surfArrayY.length;
							for (int b = 0; b < numY; b++){
								Integer ya = (Integer) surfArrayY[b];
								int ya2 = ya.intValue();
								SurfaceUnit su = (SurfaceUnit)hmY.get(ya2);
								su.play(); //surface Unit plays
							}
						}
					}
				}
					
				//Leukocyte is active
				myLeukocyte.play(); 
					
				//Output ICAM1 data if simulating Ex Vivo conditions, and ICAM1 Data is desired
				if ((myLAM.getExpCondition() == Constants.IN_VIVO)&&
						(myLAM.PrintICAM1Data == Constants.TRUE)){
					if (surfUnitXHash != null){
						Set surfSetX = surfUnitXHash.keySet();
						Object[] surfArrayX = surfSetX.toArray();
						int numX = surfArrayX.length;
					
						for (int a = 0; a < numX; a++){
							Integer xa = (Integer) surfArrayX[a];
							int xa2 = xa.intValue();
							HashMap hmY = (HashMap)surfUnitXHash.get(xa2);
						
							Set surfSetY = hmY.keySet();
							Object[] surfArrayY = surfSetY.toArray();
							int numY = surfArrayY.length;
							for (int b = 0; b < numY; b++){
								Integer ya = (Integer) surfArrayY[b];
								int ya2 = ya.intValue();
								SurfaceUnit su = (SurfaceUnit)hmY.get(ya2);
								su.recordICAM1Data(); //get Data
							}
						}
					}
				}
				//Output LFA1 Data 
				if 	(myLAM.PrintLFA1Data == Constants.TRUE){
					myLeukocyte.recordLFA1Data();
				}
					
				//Only update the display if show_Display preference on
				if (myLAM.getGUI_Display() == Constants.TRUE){
					leukPositionGraph.step();
				}
					
				//Record all data
				if (myLAM.getPrintAllData() == Constants.TRUE){
					allDataRecorder.record();
				}
				
				//If simulating ex vivo conditions, output interval data
				if (myLAM.getExpCondition()==Constants.IN_VIVO){
					if (myLAM.getPrintIntervalData() == Constants.TRUE){
						if (myLAM.stepNumber%50 == 0){
							intervalDataRecorder.record();
						}
					}
				}
				
//				Updates bond interval time files at every 50 simulation cycles
				if (myLAM.getPrintBond50sIntervalFile()==Constants.TRUE){
					if (myLAM.stepNumber%50 == 0){
						lfa1Participants50sIntervalData.append(","+myLeukocyte.getLeukMem().getLFA1participants());
						lfa1RebindingEventsData.append(","+myLeukocyte.getLeukMem().getLFA1RebindingEvents());
						icam1Participants50sIntervalData.append(","+mySurfaceSpace.getICAM1participants());
						icam1RebindingEventsData.append(","+mySurfaceSpace.getICAM1RebindingEvents());
						lfa1icam1Bond50sIntervalData.append(","+myLeukocyte.getLeukMem().getLFA1ICAMCumulativeBonds());
						multimericLfa1Icam150sIntervalData.append(","+myLeukocyte.getLeukMem().getMultimericLFA1ICAMBonds());
					}
				}
				
					
				if (myLAM.stepNumber==myLAM.getEnd_Time()){
					outcomeRecorder.record();	
					System.out.println(myLeukocyte.getLeukMem().getStatus());
					
					if (myLAM.getPrintBond50sIntervalFile() == Constants.TRUE){
						
						try
						{
						
							String filename = new String("./"+"/LFA1Participants50sInt.txt");
							FileWriter fw = new FileWriter(filename,true);
							PrintWriter pw = new PrintWriter(fw,true);
							pw.println(lfa1Participants50sIntervalData.toString());
							fw.close();
						
					
						} catch(IOException ioe) {
							System.err.println("IOException: " + ioe.getMessage());
						}
						try
						{
						
							String filename = new String("./"+"/LFA1Rebinds50sInt.txt");
							FileWriter fw = new FileWriter(filename,true);
							PrintWriter pw = new PrintWriter(fw,true);
							pw.println(lfa1RebindingEventsData.toString());
							fw.close();
						
					
						} catch(IOException ioe) {
							System.err.println("IOException: " + ioe.getMessage());
						}	
						
						try
						{
							
							String filename = new String("./"+"/ICAM1Participants50sInterval.txt");
							FileWriter fw = new FileWriter(filename,true);
							PrintWriter pw = new PrintWriter(fw,true);
							pw.println(icam1Participants50sIntervalData.toString());
							fw.close();
						
					
						} catch(IOException ioe) {
							System.err.println("IOException: " + ioe.getMessage());
						}
						try
						{
						
							String filename = new String("./"+"/ICAM1Rebinds50sInt.txt");
							FileWriter fw = new FileWriter(filename,true);
							PrintWriter pw = new PrintWriter(fw,true);
							pw.println(icam1RebindingEventsData.toString());
							fw.close();
						
					
						} catch(IOException ioe) {
							System.err.println("IOException: " + ioe.getMessage());
						}	
						try
						{
						
							String filename = new String("./"+"/Lfa1Icam1Bonds50sInt.txt");
							FileWriter fw = new FileWriter(filename,true);
							PrintWriter pw = new PrintWriter(fw,true);
							pw.println(lfa1icam1Bond50sIntervalData.toString());
							fw.close();
						
					
						} catch(IOException ioe) {
							System.err.println("IOException: " + ioe.getMessage());
						}	
						
						try
						{
						
							String filename = new String("./"+"/multiLfa1Icam150sInt.txt");
							FileWriter fw = new FileWriter(filename,true);
							PrintWriter pw = new PrintWriter(fw,true);
							pw.println(multimericLfa1Icam150sIntervalData.toString());
							fw.close();
						
					
						} catch(IOException ioe) {
							System.err.println("IOException: " + ioe.getMessage());
						}	
					}
					try
					{
						if (myLAM.getPrintBondFile() == Constants.TRUE){
						
							String filename = new String("./"+"/BondsFile.txt");
							FileWriter fw = new FileWriter(filename,true);
							PrintWriter pw = new PrintWriter(fw,true);
							LeukMem leukMembrane = myLeukocyte.getLeukMem();
							pw.println("--"+leukMembrane.getStatus()+"--> ICAM1 participants:"+mySurfaceSpace.getICAM1participants()+"--> LFA1 participants:"+leukMembrane.getLFA1participants());
							fw.close();
						}
					
					} catch(IOException ioe) {
						System.err.println("IOException: " + ioe.getMessage());
					}
					
				} 
					
				myLAM.stepNumber = myLAM.stepNumber+1;
			}			
		};
			
		//Schedule actions
		schedule.scheduleActionBeginning(0, new LAMRunner(this));
		schedule.scheduleActionBeginning(this.getEnd_Time(), this, "stop");

		//Write Data to Files	
		if (this.getPrintAllData() == Constants.TRUE){
			schedule.scheduleActionAtEnd(allDataRecorder,"writeToFile");
		}
		schedule.scheduleActionAtEnd(outcomeRecorder,"writeToFile");
		
		
		//Write interval data for ex vivo conditions
		if (this.getExpCondition()==Constants.IN_VIVO){
			if (this.getPrintIntervalData() == Constants.TRUE){
				schedule.scheduleActionAtEnd(intervalDataRecorder,"writeToFile");
			}
		}
		log("END BUILD SCHEDULE",1);
	}
		
	
	
	/* Gets the data for All Data file
	 */
	public class AllDataSource implements DataSource {
	    public Object execute() {
	    	LeukMem lm = myLeukocyte.getLeukMem();
	    	StringBuffer sb = new StringBuffer(lm.getXPos()+"|");
	    	sb.append(lm.numInteractions()+","+lm.numInteractionsAtRear()+","+lm.num_PSGL1_Interactions()+"|");
	    	sb.append(lm.numTotalHighLFA1()+","+lm.numVisibleLFA1Grids()+","+lm.numLFA1Clusters()+"|");
	    	sb.append(lm.numHighAff_LFA1_Interactions()+","+lm.numDimericLFA1Bonds()+","+lm.numBoundLFA1Grids()+"|");
	    	sb.append(lm.numRearLFA1()+","+lm.numRearVisibleLFA1Clusters()+","+lm.numRearLFA1Bonds()+","+lm.numRearLFA1GridsBound());
	    	return sb.toString();
		}
	}
		
	/* Gets the data for interval data file
	 */
	public class IntervalDataSource implements DataSource {
		public Object execute() {
			LeukMem lm = myLeukocyte.getLeukMem();
			return lm.getTransientStatus();
		
		}
	}
		
	/* Gets the data for the outcome data file
	 */
	public class OutcomeDataSource implements DataSource {
		public Object execute() {
		   	LeukMem lm = myLeukocyte.getLeukMem();
	    	return lm.getStatus();
		}
	}
	
	/* Builds a display if GUI_Display = TRUE
	 */
	public void buildDisplay(){
		log("STARTED BUILDDisplay",1);
		if (this.getGUI_Display() == Constants.TRUE){
			//Leukocyte Position vs timestep graph
			leukPositionGraph = new OpenSequenceGraph("Leukocyte Position vs. Time", this);
			leukPositionGraph.setXRange(0, 200);
			leukPositionGraph.setYRange(0, 200);
			leukPositionGraph.setAxisTitles("time", "leukocyte position");
			leukPositionGraph.addSequence("Leukocyte 1", new LeukPos());
			log("FINISHED BUILDDisplay",1);
		}			
	}
		
	/* Sequence of Leukocyte positions to be plotted on graph 
	 */
	class LeukPos implements Sequence {
		 public double getSValue() {
		 	LeukMem nm = myLeukocyte.getLeukMem();
		    return nm.getXPos();
		  }
	}
	
	/*
	 * Returns the time that the simulation starts
	 */
	private String getDateTime() {
        DateFormat dateFormat = new SimpleDateFormat("yy_MM_dd-HH_mm_s_ms");
        Date date = new Date();
	    return dateFormat.format(date);
	}
		
	/* Gets the file directory name for storing data files
	 */
	public String getFileDirectoryName(){
		return fileDirectoryName;
	}
		
	/* sets the file directory name for storing data files
	 */
	public void setFileDirectoryName(String name){
		fileDirectoryName = name;
	}
	
	/*
	 * Gets the current step number in the simulation
	 */
	public int getStepNumber(){
		return stepNumber;
	}
	
	/*
	 * Gets the FlowChamber for this experiment
	 */
	public FlowChamber getFlowChamber(){
		return myFlowChamber;
	}
	
	/*
	 * @see uchicago.src.sim.engine.SimModel#getName()
	 * * Interface required method
	 */
	public String getName(){
		return new String("");
	}
	
	/*
	 * @see uchicago.src.sim.engine.SimModel#getSchedule()
	 * * Interface required method
	 */
	public Schedule getSchedule(){
		return schedule;
	}

	/*
	 * String[] of parameters for the model, for batch runs
	 * * Interface required method
	 */
	public String[] getInitParam(){
		String[] params = {
			"ExpCondition",
			"RearForce1",
			"RearForce2",
			"RearForce3",
			"RearForce4",
			"Debugging",
			"Density_CXCR2_Mean",
			"Density_CXCR2_STDev",
			"Density_VCAM1_Mean",
			"Density_VCAM1_STDev",
			"Density_GROA_Mean",
			"Density_GROA_STDev",
			"Density_VLA4_Mean",
			"Density_VLA4_STDev",
			"Density_PSELECTIN_Mean",
			"Density_PSELECTIN_STDev",
			"Density_PSGL1_Mean",
			"Density_PSGL1_STDev",
			"Density_LFA1_STDev",
			"Density_LFA1_Mean",
			"Density_dICAM1_Mean",
			"Density_dICAM1_STDev",
			"Density_ICAM1_STDev",
			"Density_ICAM1_Mean",
			"Density_LFA1Grid_STDev",
			"Density_LFA1Grid_Mean",
			"End_Time",
			"Flattening_Time",
			"GUI_Display",
			"Leuk_ExposedWidth",
			"Leuk_ExposedLength",
			"Leuk_TotalWidth",
			"Leuk_TotalLength",
			"MaxPercActiveVLA4",
			"RearForce0",
			"SurfaceSpace_XSize",
			"SurfaceSpace_YSize",
			"LFA1GridSize",
			"PrintLFA1Data",
			"PrintICAM1Data",
			"PrintAllData",
			"PrintIntervalData",
			"PrintBondFile",
			"PrintBond50sIntervalFile",
			"PI3KPresent",
			"PCluster1",
			"PCluster2",
			"NumLFA1Clusters",
			"LFA1ClusterDiameter",
			"ICAM1NativeSize",
			"ICAM1ClusterSearchDistance",
			"LFA1ClusteringAllowed",
			"ICAM1WTetramerAllowed",
			"ICAM1PreClusteredAllowed",
			"EAPClusteringAllowed",
			"EAPDiameter",
			"SpreadingAllowed",
			"PSelectin_PSGL1_Pon",
			"PSelectin_PSGL1_B0_DissConst",
			"PSelectin_PSGL1_B1_DissConst",
			"VCAM1_VLA4_Low_Pon",
			"VCAM1_VLA4_LowAff_B0_DissConst",
			"VCAM1_VLA4_LowAff_B1_DissConst",
			"VCAM1_VLA4_High_Pon",
			"VCAM1_VLA4_HighAff_B0_DissConst",
			"VCAM1_VLA4_HighAff_B1_DissConst",
			"VCAM1_VLA4_HighAff_B1_Limit",
			"ICAM1_LFA1_Low_Pon",
			"ICAM1_LFA1_LowAff_B1_DissConst",
			"ICAM1_LFA1_LowAff_B0_DissConst",
			"ICAM1_LFA1_LowAff_B1_Limit",
			"ICAM1_LFA1_High_Pon",
			"ICAM1_LFA1_HighAff_B1_DissConst",
			"ICAM1_LFA1_HighAff_B0_DissConst",
			"ICAM1_LFA1_HighAff_B1_Limit",
			"DiffusionMobile",
			"DiffusionImmobile",
			"ICAM1_Move",
			"CXCR2_P_Internalize",
			"LFA1_PRemoval",
			"Rate_LFA1GridIncrease"
			};
		return params;
	}
	
	/* (EXPERIMENTAL)
	 * Get the rate of LFA1Grid Density increase
	 */
	public double getRate_LFA1GridIncrease(){
		return Rate_LFA1GridIncrease;
	}
	
	/* (EXPERIMENTAL)
	 * Set the rate of LFA1Grid Density increase
	 */
	public void setRate_LFA1GridIncrease(double d){
		Rate_LFA1GridIncrease = d;
	}
	
	/* 
	 * Get the rate of LFA1 Removal
	 */
	public double getLFA1_PRemoval(){
		return LFA1_PRemoval;
	}
	
	/*
	 * Set the rate of LFA1 Removal
	 */
	public void setLFA1_PRemoval(double d){
		LFA1_PRemoval = d;
	}

	/* (EXPERIMENTAL)
	 * Get the rate of CXCR2 internalization
	 */
	public double getCXCR2_P_Internalize(){
		return CXCR2_P_Internalize;
	}
	
	/* (EXPERIMENTAL)
	 * Set the rate of CXCR2 internalization
	 */
	public void setCXCR2_P_Internalize(double d){
		CXCR2_P_Internalize = d;
	}

	/*	 (EXPERIMENTAL)
	 * Get PI3Kpresent value
	 */
	public int getPI3KPresent(){
		return PI3KPresent;
	}
	
	/* (EXPERIMENTAL)
	 * Set PI3Kpresent value
	 */
	public void setPI3KPresent(int present){
		PI3KPresent = present;
	}
	
	/*
	 * Get ICAM1PreClusteredAllowed
	 */
	public int getICAM1PreClusteredAllowed(){
		return ICAM1PreClusteredAllowed;
	}
	
	/*
	 * Set ICAM1PreClusteredAllowed
	 */
	public void setICAM1PreClusteredAllowed(int clustering){
		ICAM1PreClusteredAllowed = clustering;
	}
	

	
	/*
	 * Get LFA1ClusteringAllowed
	 */
	public int getLFA1ClusteringAllowed(){
		return LFA1ClusteringAllowed;
	}
	
	/*
	 * Set LFA1ClusteringAllowed
	 */
	public void setLFA1ClusteringAllowed(int clustering){
		LFA1ClusteringAllowed = clustering;
	}
	
	/*
	 * Get ICAM1ClusteringAllowed
	 */
	public int getICAM1WTetramerAllowed(){
		return ICAM1WTetramerAllowed;
	}

	/*
	 * Set ICAM1ClusteringAllowed
	 */
	public void setICAM1WTetramerAllowed(int clustering){
		ICAM1WTetramerAllowed = clustering;
	}
	
	/* (EXPERIMENTAL)
	 * Get EAPClusteringAllowed
	 */
	public int getEAPClusteringAllowed(){
		return EAPClusteringAllowed;
	}
	
	/* (EXPERIMENTAL)
	 * Set EAPClusteringAllowed
	 */
	public void setEAPClusteringAllowed(int clustering){
		EAPClusteringAllowed = clustering;
	}
	
	/* (EXPERIMENTAL)
	 * Get SpreadingAllowed
	 */
	public int getSpreadingAllowed(){
		return SpreadingAllowed;
	}
	
	/* (EXPERIMENTAL)
	 * Set SpreadingAllowed
	 */
	public void setSpreadingAllowed(int s){
		SpreadingAllowed = s;
	}
	
	/* Return the rear_Force value
	 */
	public double getRearForce0(){
		return rearForce0;
	}
	
	/* Set the rear_Force value
	 */
	public void setRearForce0(double sf){
		rearForce0 = sf;
	}

	/* Return the end_time for the simulation
	 */
	public int getEnd_Time(){
		return End_Time;
	}
	
	/* Set the end_time for the simulation
	 */
	public void setEnd_Time(int eTime){
		End_Time = eTime;
	}
	
	/* Set the SurfaceSpace x value size
	 */
	public void setSurfaceSpace_XSize(int size){
		SurfaceSpace_XSize = size;
	}
	
	/* Get the SurfaceSpace x value size
	 */
	public int getSurfaceSpace_XSize(){
		return SurfaceSpace_XSize;
	}
	
	/* Set the SurfaceSpace y value size
	 */
	public void setSurfaceSpace_YSize(int size){
		SurfaceSpace_YSize = size;
	}
	
	/* Get the SurfaceSpace y value size
	 */
	public int getSurfaceSpace_YSize(){
		return SurfaceSpace_YSize;
	}
	
	/* Sets the Surface for the simulation
	 */
	public void setMySurfaceSpace(Surface ss){
		mySurfaceSpace = ss;
	}
	
	/* Print out the Surface Space to System.out
	 */
	public void printSurfHash(){
		StringBuffer sb = new StringBuffer();
	
		for (int x = 0; x < 350; x++){
			HashMap hmx = this.surfUnitXHash;
			if(hmx.containsKey(x)){
				HashMap hmy = (HashMap)hmx.get(x);
				sb.append(x+"-");
				for (int y = 0; y < 350; y++){
					if(hmy.containsKey(y)){
						sb.append(y+",");
					}
				}
				sb.append("\n");
			}
			
		}
		System.out.println(sb.toString());
	}
	/*
	 * Set the LFA1Grid Size and ICAM1Grid (length, width)
	 */
	public void setLFA1GridSize(int n){
		LFA1GridSize = n;
	}
	
	/*
	 * Get the I1Grid Size and ICAM1Grid (length, width)
	 */
	public int getLFA1GridSize(){
		return LFA1GridSize;
	}
	
	/*
	 * Set the LFA1Grid density mean
	 */
	public void setDensity_LFA1Grid_Mean(double n){
		Density_LFA1Grid_Mean = n;
	}
	
	/*
	 * Get the LFA1Grid density mean
	 */
	public double getDensity_LFA1Grid_Mean(){
		return Density_LFA1Grid_Mean;
	}
	/*
	 * Set the LFA1Grid density std
	 */
	public void setDensity_LFA1Grid_STDev(double n){
		Density_LFA1Grid_STDev = n;
	}
	
	/*
	 * Get the LFA1Grid density std
	 */
	public double getDensity_LFA1Grid_STDev(){
		return Density_LFA1Grid_STDev;
	}

	/*
	 * Get the HashMap containing Surf Units
	 */
	public HashMap getSurfUnitXHash(){
		return surfUnitXHash;
	}

	/*
	 * Set the HashMap containing Surf Units
	 */
	public void setSurfUnitXHash(HashMap h){
		surfUnitXHash = h;
	}

	/*
	 * Set the exposed width of LeukMem on Surface
	 */
	public void setLeuk_ExposedWidth(int size){
		Leuk_ExposedWidth = size;
	}

	/*
	 * Get the exposed width of LeukMem on Surface
	 */
	public int getLeuk_ExposedWidth(){
		return Leuk_ExposedWidth;
	}
	

	/*
	 * Set the exposed length of LeukMem on Surface
	 */
	public void setLeuk_ExposedLength(int size){
		Leuk_ExposedLength = size;
	}
	

	/*
	 * Get the exposed length of LeukMem on Surface
	 */
	public int getLeuk_ExposedLength(){
		return Leuk_ExposedLength;
	}
	

	/*
	 * Set the total width of LeukMem on Surface
	 */
	public void setLeuk_TotalWidth(int size){
		Leuk_TotalWidth = size;
	}
	
	/*
	 * Get the total width of LeukMem on Surface
	 */
	public int getLeuk_TotalWidth(){
		return Leuk_TotalWidth;
	}
	
	/*
	 * Set the total length of LeukMem on Surface
	 */
	public void setLeuk_TotalLength(int size){
		Leuk_TotalLength = size;
	}
	
	/*
	 * Get the total length of LeukMem on Surface
	 */
	public int getLeuk_TotalLength(){
		return Leuk_TotalLength;
	}
	
	/*
	 * Get the Pon Binding affinity parameter for PSGL1/PSelectin
	 */
	public double getPSelectin_PSGL1_Pon(){
		return PSelectin_PSGL1_Pon;
	}

	/*
	 * Set the Pon Binding affinity parameter for PSGL1/PSelectin
	 */
	public void setPSelectin_PSGL1_Pon(double kon){
		PSelectin_PSGL1_Pon = kon;
	}

	/*
	 * Get the B1 Dissociation affinity parameter for PSGL1/PSelectin
	 */
	public double getPSelectin_PSGL1_B1_DissConst(){
		return PSelectin_PSGL1_B1_DissConst;
	}
	
	/*
	 * Set the B1 Dissociation affinity parameter for PSGL1/PSelectin
	 */
	public void setPSelectin_PSGL1_B1_DissConst(double koff){
		PSelectin_PSGL1_B1_DissConst = koff;
	}
	
	/*
	 * Get the B0 Dissociation affinity parameter for PSGL1/PSelectin
	 */
	public double getPSelectin_PSGL1_B0_DissConst(){
		return PSelectin_PSGL1_B0_DissConst;
	}
	
	/*
	 * Set the B0 Dissociation affinity parameter for PSGL1/PSelectin
	 */
	public void setPSelectin_PSGL1_B0_DissConst(double koff){
		PSelectin_PSGL1_B0_DissConst = koff;
	}
	
	/*
	 * Get the B1 Dissociation affinity parameter for low affinity LFA1/ICAM1
	 */
	public double getICAM1_LFA1_LowAff_B1_DissConst(){
		return ICAM1_LFA1_LowAff_B1_DissConst;
	}
	
	/*
	 * Set the B1 Dissociation affinity parameter for low affinity LFA1/ICAM1
	 */
	public void setICAM1_LFA1_LowAff_B1_DissConst(double koff){
		ICAM1_LFA1_LowAff_B1_DissConst = koff;
	}
	
	/*
	 * Get the B0 Dissociation affinity parameter for low affinity LFA1/ICAM1
	 */
	public double getICAM1_LFA1_LowAff_B0_DissConst(){
		return ICAM1_LFA1_LowAff_B0_DissConst;
	}
	
	/*
	 * Set the B0 Dissociation affinity parameter for low affinity LFA1/ICAM1
	 */
	public void setICAM1_LFA1_LowAff_B0_DissConst(double koff){
		ICAM1_LFA1_LowAff_B0_DissConst = koff;
	}
	
	/*
	 * Get the B1 Dissociation affinity parameter for high affinity LFA1/ICAM1
	 */
	public double getICAM1_LFA1_HighAff_B1_DissConst(){
		return ICAM1_LFA1_HighAff_B1_DissConst;
	}
	
	/*
	 * Set the B1 Dissociation affinity parameter for high affinity LFA1/ICAM1
	 */
	public void setICAM1_LFA1_HighAff_B1_DissConst(double koff){
		ICAM1_LFA1_HighAff_B1_DissConst = koff;
	}
	
	/*
	 * Get the B1 Dissociation affinity limit parameter for high affinity LFA1/ICAM1
	 */
	public double getICAM1_LFA1_HighAff_B1_Limit(){
		return ICAM1_LFA1_HighAff_B1_Limit;
	}
	
	/*
	 * Set the B1 Dissociation affinity limit parameter for high affinity LFA1/ICAM1
	 */
	public void setICAM1_LFA1_HighAff_B1_Limit(double limit){
		ICAM1_LFA1_HighAff_B1_Limit = limit;
	}
	
	/*
	 * Get the B1 Dissociation affinity limit parameter for low affinity LFA1/ICAM1
	 */
	public double getICAM1_LFA1_LowAff_B1_Limit(){
		return ICAM1_LFA1_LowAff_B1_Limit;
	}
	
	/*
	 * Set the B1 Dissociation affinity limit parameter for low affinity LFA1/ICAM1
	 */
	public void setICAM1_LFA1_LowAff_B1_Limit(double limit){
		ICAM1_LFA1_LowAff_B1_Limit = limit;
	}
	
	/*
	 * Get the B0 Dissociation affinity  parameter for high affinity LFA1/ICAM1
	 */
	public double getICAM1_LFA1_HighAff_B0_DissConst(){
		return ICAM1_LFA1_HighAff_B0_DissConst;
	}
	

	/*
	 * Set the B0 Dissociation affinity  parameter for high affinity LFA1/ICAM1
	 */
	public void setICAM1_LFA1_HighAff_B0_DissConst(double koff){
		ICAM1_LFA1_HighAff_B0_DissConst = koff;
	}
	

	/*
	 * Get the binding affinity parameter pon for low affinity LFA1/ICAM1
	 */
	public double getICAM1_LFA1_Low_Pon(){
		return ICAM1_LFA1_Low_Pon;
	}
	
	/*
	 * Set the binding affinity parameter pon for low affinity LFA1/ICAM1
	 */
	public void setICAM1_LFA1_Low_Pon(double kon){
		ICAM1_LFA1_Low_Pon = kon;
	}
	
	/*
	 * Get the binding affinity parameter pon for high affinity LFA1/ICAM1
	 */
	public double getICAM1_LFA1_High_Pon(){
		return ICAM1_LFA1_High_Pon;
	}
	
	/*
	 * Set the binding affinity parameter pon for low affinity LFA1/ICAM1
	 */
	public void setICAM1_LFA1_High_Pon(double kon){
		ICAM1_LFA1_High_Pon = kon;
	}
	
	/*
	 * Get the B1 dissociation parameter for low affinity VLA4/VCAM1
	 */
	public double getVCAM1_VLA4_LowAff_B1_DissConst(){
		return VCAM1_VLA4_LowAff_B1_DissConst;
	}
	
	/*
	 * Set the B1 dissociation parameter for low affinity VLA4/VCAM1
	 */
	public void setVCAM1_VLA4_LowAff_B1_DissConst(double koff){
		VCAM1_VLA4_LowAff_B1_DissConst = koff;
	}
	
	/*
	 * Get the B0 dissociation parameter for low affinity VLA4/VCAM1
	 */
	public double getVCAM1_VLA4_LowAff_B0_DissConst(){
		return VCAM1_VLA4_LowAff_B0_DissConst;
	}
	
	/*
	 * Set the B0 dissociation parameter for low affinity VLA4/VCAM1
	 */
	public void setVCAM1_VLA4_LowAff_B0_DissConst(double koff){
		VCAM1_VLA4_LowAff_B0_DissConst = koff;
	}
	
	/*
	 * Get the B1 dissociation parameter for high affinity VLA4/VCAM1
	 */
	public double getVCAM1_VLA4_HighAff_B1_DissConst(){
		return VCAM1_VLA4_HighAff_B1_DissConst;
	}
	
	/*
	 * Set the B1 dissociation parameter for high affinity VLA4/VCAM1
	 */
	public void setVCAM1_VLA4_HighAff_B1_DissConst(double koff){
		VCAM1_VLA4_HighAff_B1_DissConst = koff;
	}
	
	/*
	 * Get the B1 dissociation parameter limit for high affinity VLA4/VCAM1
	 */
	public double getVCAM1_VLA4_HighAff_B1_Limit(){
		return VCAM1_VLA4_HighAff_B1_Limit;
	}
	
	/*
	 * Set the B1 dissociation parameter limit for high affinity VLA4/VCAM1
	 */
	public void setVCAM1_VLA4_HighAff_B1_Limit(double limit){
		VCAM1_VLA4_HighAff_B1_Limit = limit;
	}
	
	/*
	 * Get the B0 dissociation parameter for high affinity VLA4/VCAM1
	 */
	public double getVCAM1_VLA4_HighAff_B0_DissConst(){
		return VCAM1_VLA4_HighAff_B0_DissConst;
	}
	
	/*
	 * Set the B0 dissociation parameter for high affinity VLA4/VCAM1
	 */
	public void setVCAM1_VLA4_HighAff_B0_DissConst(double koff){
		VCAM1_VLA4_HighAff_B0_DissConst = koff;
	}
	
	/*
	 * Get the binding affinity parameter Pon for low affinity VLA4/VCAM1
	 */
	public double getVCAM1_VLA4_Low_Pon(){
		return VCAM1_VLA4_Low_Pon;
	}
	
	/*
	 * Set the binding affinity parameter Pon for low affinity VLA4/VCAM1
	 */
	public void setVCAM1_VLA4_Low_Pon(double kon){
		VCAM1_VLA4_Low_Pon = kon;
	}
	
	/*
	 * Get the binding affinity parameter Pon for high affinity VLA4/VCAM1
	 */
	public double getVCAM1_VLA4_High_Pon(){
		return VCAM1_VLA4_High_Pon;
	}
	
	/*
	 * Set the binding affinity parameter Pon for high affinity VLA4/VCAM1
	 */
	public void setVCAM1_VLA4_High_Pon(double kon){
		VCAM1_VLA4_High_Pon = kon;
	}
	
	/*
	 * Get the mean density for PSGL1
	 */
	public double getDensity_PSGL1_Mean(){
		return Density_PSGL1_Mean;
	}
	
	/*
	 * Set the mean density for PSGL1
	 */
	public void setDensity_PSGL1_Mean(double d){
		Density_PSGL1_Mean = d;
	}
	
	/*
	 * Get the std density for PSGL1
	 */
	public double getDensity_PSGL1_STDev(){
		return  Density_PSGL1_STDev;
	}
	
	/*
	 * Set the std density for PSGL1
	 */
	public void setDensity_PSGL1_STDev(double d){
		Density_PSGL1_STDev = d;
	}
	
	/*
	 * Get the mean density for PSelectin 
	 */
	public double getDensity_PSELECTIN_Mean(){
		return Density_PSELECTIN_Mean;
	}
	
	/*
	 * Set the mean density for PSelectin 
	 */
	public void setDensity_PSELECTIN_Mean(double d){
		Density_PSELECTIN_Mean = d;
	}
	
	/*
	 * Get the stdev density for PSelectin 
	 */
	public double getDensity_PSELECTIN_STDev(){
		return Density_PSELECTIN_STDev;
	}
	
	/*
	 * Set the stdev density for PSelectin 
	 */
	public void setDensity_PSELECTIN_STDev(double d){
		Density_PSELECTIN_STDev = d;
	}
	
	/*
	 * Get the mean density for VCAM1
	 */
	public double getDensity_VCAM1_Mean(){
		return Density_VCAM1_Mean;
	}
	
	/*
	 * Set the mean density for VCAM1
	 */
	public void setDensity_VCAM1_Mean(double d){
		Density_VCAM1_Mean = d;
	}
	
	/* Get the std density for VCAM1
	 */
	public double getDensity_VCAM1_STDev(){
		return Density_VCAM1_STDev;
	}
	
	/*Set the std density for VCAM1
	 */
	public void setDensity_VCAM1_STDev(double std){
		Density_VCAM1_STDev = std;
	}
	
	/* Get the mean density for ICAM1
	 */
	public double getDensity_ICAM1_Mean(){
		return Density_ICAM1_Mean;
	}

	/* Set the mean density for ICAM1
	 */
	public void setDensity_ICAM1_Mean(double d){
		Density_ICAM1_Mean = d;
	}
	
	/* Get the std density for ICAM1
	 */
	public double getDensity_ICAM1_STDev(){
		return Density_ICAM1_STDev;
	}

	/* Set the std density for ICAM1
	 */
	public void setDensity_ICAM1_STDev(double std){
		Density_ICAM1_STDev = std;
	}

	/* Get the mean density for VLA4
	 */
	public double getDensity_VLA4_Mean(){
		return Density_VLA4_Mean;
	}
	
	/* Set the mean density for VLA4
	 */
	public void setDensity_VLA4_Mean(double d){
		Density_VLA4_Mean = d;
	}
	
	/* Get the stdev density for VLA4
	 */
	public double getDensity_VLA4_STDev(){
		return Density_VLA4_STDev;
	}
	
	/* Set the stdev density for VLA4
	 */
	public void setDensity_VLA4_STDev(double d){
		Density_VLA4_STDev = d;
	}
	
	/* Get the mean density for divalent ICAM1
	 */
	public double getDensity_dICAM1_Mean(){
		return Density_dICAM1_Mean;
	}
	
	/* Set the mean density for divalent ICAM1
	 */
	public void setDensity_dICAM1_Mean(double d){
		Density_dICAM1_Mean = d;
	}
	
	/* Get the stdev density for divalent ICAM1
	 */
	public double getDensity_dICAM1_STDev(){
		return Density_dICAM1_STDev;
	}
	
	/* Set the stdev density for divalent ICAM1
	 */
	public void setDensity_dICAM1_STDev(double d){
		Density_dICAM1_STDev = d;
	}
	
	/* Get the mean density for LFA1
	 */
	public double getDensity_LFA1_Mean(){
		return Density_LFA1_Mean;
	}
	
	/* Set the mean density for LFA1
	 */
	public void setDensity_LFA1_Mean(double d){
		Density_LFA1_Mean = d;
	}
	
	/* Get the stdev density for LFA1
	 */
	public double getDensity_LFA1_STDev(){
		return Density_LFA1_STDev;
	}
	
	/* Set the stdev density for LFA1
	 */
	public void setDensity_LFA1_STDev(double std){
		Density_LFA1_STDev = std;
	}
	
	/* Get the mean density for CXCR2
	 */
	public double getDensity_CXCR2_Mean(){
		return Density_CXCR2_Mean;
	}
	
	/* Set the mean density for CXCR2
	 */
	public void setDensity_CXCR2_Mean(double d){
		Density_CXCR2_Mean = d;
	}
	
	/* Get the stdev density for CXCR2
	 */
	public double getDensity_CXCR2_STDev(){
		return Density_CXCR2_STDev;
	}
	
	/* Set the stdev density for CXCR2
	 */
	public void setDensity_CXCR2_STDev(double d){
		Density_CXCR2_STDev = d;
	}
	
	/* Get the mean density for GROA/CXCL1
	 */
	public double getDensity_GROA_Mean(){
		return Density_GROA_Mean;
	}
	
	/* Set the mean density for GROA/CXCL1
	 */
	public void setDensity_GROA_Mean(double d){
		Density_GROA_Mean = d;
	}
	
	/* Get the stdev density for GROA/CXCL1
	 */
	public double getDensity_GROA_STDev(){
		return Density_GROA_STDev;
	}
	
	/* Set the stdev density for GROA/CXCL1
	 */
	public void setDensity_GROA_STDev(double std){
		Density_GROA_STDev = std;
	}
	
	/* Set the max percent active for VLA4
	 */
	public void setMaxPercActiveVLA4(double perc){
		MaxPercActiveVLA4 = perc;
	}
	
	/* Get the max percent active for VLA4
	 */
	public double getMaxPercActiveVLA4(){
		return MaxPercActiveVLA4;
	}
	
	/* Get the flattening Time
	 */
	public double getFlattening_Time(){
		return Flattening_Time;
	}
	
	/* Set the flattening Time
	 */
	public void setFlattening_Time(double time){
		Flattening_Time = time;
	}
	
	/* Set the debugging level
	 */
	public void setDebugging(int debug){
		Debugging = debug;
	}

	/* Get the debugging level
	 */
	public int getDebugging(){
		return Debugging;
	}
	
	/* Get the GUI Display level
	 */
	public int getGUI_Display(){
		return GUI_Display;
	}
	
	/* Set the GUI Display level
	 */
	public void setGUI_Display(int displayOn){
		GUI_Display = displayOn;
	}
	
	/* Get the initial RearForce value for experiments when  
	 * RearForce is increasing (Constants.INCREASING_SHEAR conditions)
	 * Timesteps: 0 < t <= 100
	 */
	public double getRearForce1(){
		return rearForce1;
	}
	
	/* Set the initial RearForce value for experiments when  
	 * RearForce is increasing (Constants.INCREASING_SHEAR conditions)
	 * Timesteps: 0 < t <= 100
	 */
	public void setRearForce1(double rear1){
		rearForce1 = rear1;
	}
	
	/* Get the RearForce2 value for experiments when  
	 * RearForce is increasing (Constants.INCREASING_SHEAR conditions)
	 * Timesteps:  100 < t <= 400 
	 */
	public double getRearForce2(){
		return rearForce2;
	}
	
	/* Set the RearForce2 value for experiments when  
	 * RearForce is increasing (Constants.INCREASING_SHEAR conditions)
	 * Timesteps:  100 < t <= 400 
	 */
	public void setRearForce2(double rear2){
		rearForce2 = rear2;
	}
	
	/* Get the RearForce3 value for experiments when  
	 * RearForce is increasing (Constants.INCREASING_SHEAR conditions)
	 * Timesteps:  400 < t <= 550 
	 */
	public double getRearForce3(){
		return rearForce3;
	}
	/* Set the RearForce3 value for experiments when  
	 * RearForce is increasing (Constants.INCREASING_SHEAR conditions)
	 * Timesteps:  400 < t <= 550 
	 */
	public void setRearForce3(double rear3){
		rearForce3 = rear3;
	}
	
	/* Get the RearForce4 value for experiments when  
	 * RearForce is increasing (Constants.INCREASING_SHEAR conditions)
	 * Timesteps:  550 < t  
	 */
	public double getRearForce4(){
		return rearForce4;
	}
	
	/* Set the RearForce4 value for experiments when  
	 * RearForce is increasing (Constants.INCREASING_SHEAR conditions)
	 * Timesteps:  550 < t  
	 */
	public void setRearForce4(double rear4){
		rearForce4 = rear4;
	}
	
	/* Get the experimental condition being simulated (defined in Constants)  
	 */
	public int getExpCondition(){
		return expCondition;
	}
	
	/* Set the experimental condition being simulated (defined in Constants)  
	 */
	public void setExpCondition(int condition){
		expCondition = condition;
	}
	
	/* Set number of moves for mobile agents during diffusion
	 */
	public void setDiffusionMobile(int a){
		DiffusionMobile = a;
	}
	
	/* Get number of moves for mobile agents during diffusion
	 */
	public int getDiffusionMobile(){
		return DiffusionMobile;
	}
	
	/* Set number of moves for "immobile" agents during diffusion
	 */
	public void setDiffusionImmobile(int a){
		DiffusionImmobile = a;
	}
	
	/* Get number of moves for "immobile" agents during diffusion
	 */
	public int getDiffusionImmobile(){
		return DiffusionImmobile;
	}

	/* Set number of moves for ICAM1 agents during diffusion
	 */
	public void setICAM1_Move(int a){
		ICAM1_Move = a;
	}

	/* Get number of moves for ICAM1 agents during diffusion
	 */
	public int getICAM1_Move(){
		return ICAM1_Move;
	}
	
	/* Get value of whether LFA1 data should be outputted (0-1: defined in Constants)
	 */
	public int getPrintLFA1Data(){
		return PrintLFA1Data;
	}
	
	/* Set value of whether LFA1 data should be outputted (0-1: defined in Constants)
	 */
	public void setPrintLFA1Data(int n){
		PrintLFA1Data = n;
	}
	
	/* Get value of whether all data should be outputted (0-1: defined in Constants)
	 */
	public int getPrintAllData(){
		return PrintAllData;
	}
	
	/* Set value of whether all data should be outputted (0-1: defined in Constants)
	 */
	public void setPrintAllData(int n){
		PrintAllData = n;
	}
	
	/* Get value of whether interval data should be outputted (0-1: defined in Constants)
	 */
	public int getPrintIntervalData(){
		return PrintIntervalData;
	}
	
	/* Set value of whether interval data should be outputted (0-1: defined in Constants)
	 */
	public void setPrintIntervalData(int n){
		PrintIntervalData = n;
	}

	/* Get value of whether interval data should be outputted (0-1: defined in Constants)
	 */
	public int getPrintBondFile(){
		return PrintBondFile;
	}
	
	/* Set value of whether interval data should be outputted (0-1: defined in Constants)
	 */
	public void setPrintBondFile(int n){
		PrintBondFile = n;
	}
	
	/* Get value of whether Bond 50s interval data should be outputted (0-1: defined in Constants)
	 */
	public int getPrintBond50sIntervalFile(){
		return PrintBond50sIntervalFile;
	}
	
	/* Set value of whether Bond 50s interval data should be outputted (0-1: defined in Constants)
	 */
	public void setPrintBond50sIntervalFile(int n){
		PrintBond50sIntervalFile = n;
	}
	
	
	
	/* Get value of whether ICAM1 data should be outputted (0-1: defined in Constants)
	 */
	public int getPrintICAM1Data(){
		return PrintICAM1Data;
	}

	/* Set value of whether ICAM1 data should be outputted (0-1: defined in Constants)
	 */
	public void setPrintICAM1Data(int n){
		PrintICAM1Data = n;
	}
	
	/* (EXPERIMENTAL)
	 * Set PCluster1
	 */
	public void setPCluster1(double d){
		PCluster1 = d;
	}

	/* (EXPERIMENTAL)
	 * get PCluster1
	 */
	public double getPCluster1(){
		return PCluster1;
	}
	
	/* (EXPERIMENTAL)
	 * Set PCluster2
	 */
	public void setPCluster2(double d){
		PCluster2 = d;
	}
	
	/* (EXPERIMENTAL)
	 * get PCluster2
	 */
	public double getPCluster2(){
		return PCluster2;
	}
	
	/* Set ICAM1NativeSize
	 */
	public void setICAM1NativeSize(int n){
		ICAM1NativeSize = n;
	}
	
	/* Get ICAM1NativeSize
	 */
	public int getICAM1NativeSize(){
		return ICAM1NativeSize;
	}
	
	/* Set value of the diameter of an LFA1 Cluster
	 */
	public void setLFA1ClusterDiameter(int d){
		LFA1ClusterDiameter = d;
	}
	
	/* Get value of the diameter of an LFA1 Cluster
	 */
	public int getLFA1ClusterDiameter(){
		return LFA1ClusterDiameter;
	}
	
	/* (EXPERIMENTAL)
	 * Set EAPDiameter
	 */
	public void setEAPDiameter(int d){
		EAPDiameter = d;
	}
	
	/* (EXPERIMENTAL)
	 * Get EAPDiameter
	 */
	public int getEAPDiameter(){
		return EAPDiameter;
	}
	
	/* Set value of the search radius to form an ICAM1 Cluster
	 */
	public void setICAM1ClusterSearchDistance(int d){
		ICAM1ClusterSearchDistance = d;
	}
	
	/* Get value of the search radius to form an ICAM1 Cluster
	 */
	public int getICAM1ClusterSearchDistance(){
		return ICAM1ClusterSearchDistance;
	}
	
	/* Set max number of LFA1 Clusters / LFA1Grid
	 */
	public void setNumLFA1Clusters(int r){
		NumLFA1Clusters = r;
	}
	
	/* Get max number of LFA1 Clusters / LFA1Grid
	 */
	public int getNumLFA1Clusters(){
		return NumLFA1Clusters;
	}
	
	
	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
	public void log(String s, int debugType){
		if (this.getDebugging() >= debugType){
			System.out.println("ISWBC: "+s);
		}
	}

}
