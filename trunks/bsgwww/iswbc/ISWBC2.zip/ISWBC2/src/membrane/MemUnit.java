/*
 * @author Jonathan Tang
 */
package src.membrane;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import uchicago.src.sim.util.Random;
import src.model.ISWBC;
import src.flowchamber.Surface;
import src.ligand.Grp_AdhesMolecules;
import src.ligand.Grp_CXCR2;
import src.ligand.Ind_ICAM1;
import src.ligand.Ind_LFA1;
import src.ligand.Grp_Integrins;
import src.ligand.Grp_ChemokReceptors;
import src.ligand.Grp_PSGL1;
import src.ligand.Grp_VLA4;
import src.model.Constants;
import src.flowchamber.SurfaceUnit;

/* This class represents a functional unit of membrane
 */
public class MemUnit implements Constants{

	public Grp_AdhesMolecules[] myGrp_AdhMols;			//My group adhesion molecules	
	public Grp_ChemokReceptors[] myChemokReceps;		//my chemokine receptors
	private int numClustersAllowed;						//number of clusters allowed
	
	private LFA1Grid myLFA1Grid;						//My LFA1Grid
	private ArrayList<Ind_LFA1> lfa1AgentList;			//List of Ind_LFA1 agents
	private boolean containslfa1;						//contains Ind_LFA1s and LFA1Grid?
	
	private int xPosOnMembrane; 						//x position on the cell Membrane
	private int yPosOnMembrane; 						//y position on the cell membrane
	private Surface mySurfaceSpace;						//Surface this membrane unit interacts with
	private ISWBC myISWBC;								//ISWBC for this experiment
	private LeukMem myLeukMem;							//Membrane for this Membrane unit
	
	protected boolean bound;							
	private boolean activatedSection;					//activated by chemokines?

	/* Create a MemUnit object for Membrane
	 * @param x is the x coordinate on the Membrane
	 * @param y is the y coordinate on the Membrane
	 * @param lm is the Leukocyte Membrane this Membrane Unit belongs to
	 * @param lam is the iswbc
	 * @param lfa1 is true if this MemUnit contains LFA1 agents and an LFA1Grid should be made
	 */
	protected MemUnit(int x, int y, LeukMem lm, ISWBC lam, boolean lfa1){
		xPosOnMembrane = x;
		yPosOnMembrane = y;
		myLeukMem = lm;
		myISWBC = lam;
		
		containslfa1 = lfa1;
		activatedSection = false;
		numClustersAllowed = lam.getNumLFA1Clusters();
		
		mySurfaceSpace = null;
		bound = false;
		
		myChemokReceps = new Grp_ChemokReceptors[Constants.TOTNUMCHEMOKRECEPS];		
		myGrp_AdhMols = new Grp_AdhesMolecules[Constants.TOTNUM_GRP_ADHMOLS];
		
		//	initialize 	
		for (int i = 0; i < Constants.TOTNUM_GRP_ADHMOLS; i++)
			myGrp_AdhMols[i] = null;
		for (int i = 0; i < Constants.TOTNUMCHEMOKRECEPS; i++)
			myChemokReceps[i] = null;
		
		myGrp_AdhMols[VLA4] = new Grp_VLA4(myISWBC);
		myGrp_AdhMols[PSGL1] = new Grp_PSGL1(myISWBC);
		myChemokReceps[Constants.CXCR2] = new Grp_CXCR2(myISWBC);
		myChemokReceps[Constants.CXCR2].setMemUnit(this);

		//Create LFA1Grid with LFA1 objects
		if(containslfa1){
			createLFA1();
		}
	}
	
	/*
	 * Creates LFA1 Agents or this MemUnit
	 */
	public void createLFA1(){
		myLFA1Grid = new LFA1Grid(myISWBC.getLFA1GridSize(), this, myISWBC);
		Random.createNormal(myISWBC.getDensity_LFA1_Mean(),myISWBC.getDensity_LFA1_STDev());
		int numOfLFA1 = Random.normal.nextInt();
		double lfa1num = (double)numOfLFA1;
		double numOfSpaces = myISWBC.getLFA1GridSize()*myISWBC.getLFA1GridSize();
		double P_lfa1 = lfa1num/numOfSpaces;
			
		if (numOfLFA1 < 0){
			numOfLFA1 = 0;
		}
		lfa1AgentList = new ArrayList<Ind_LFA1>(numOfLFA1);
		int LFA1counter = 0;
		int y =0;
		int x =0;
		while (LFA1counter < numOfLFA1){
					
			Random.createUniform();
			double p = Random.uniform.nextDoubleFromTo(0.0,1.0);
					
			if (p <= P_lfa1){
				LFA1counter++;
					
				Ind_LFA1 lfa = new Ind_LFA1(myISWBC, myLFA1Grid, x, y, LFA1counter);
				myLFA1Grid.putLFA1At(x,y,lfa);
				lfa1AgentList.add(lfa);
			}
			y++;
			
			if (y>=myISWBC.getLFA1GridSize()){
				y=0;
				x++;
			}
			if (x>=myISWBC.getLFA1GridSize()){
				x=0;
			}
		}	
		myLeukMem.addLFA1Grid(myLFA1Grid);
	}
	
	/*
	 * Create LFA1Grid with LFA1 agents to be exposed to the surface
	 */
	public void exposeLFA1(){
		containslfa1 = true;
		createLFA1();
	}
	
	/*
	 * Contains exposed LFA1 Grid and agents
	 */
	public boolean containsLFA1At(int x, int y){
		if (myLFA1Grid.emptyAt(x,y)){
			return false;
		} else {
			return true;
		}
	}
	
	
	/*
	 * The function to be played at each time step
	 */
	public void play(SurfaceUnit surfSection, double force){
		if (surfSection != null){
			if (containslfa1){
				
				for (int a = 0; a < lfa1AgentList.size(); a++){
					Ind_LFA1 currLFA1 = (Ind_LFA1)lfa1AgentList.get(a);
					if (currLFA1 != null){
						//EXPERIENCE FORCE
						if (currLFA1.isBound()){//Bound
							log("Force on LFA1Bond: "+force,2);
							currLFA1.incrementBondDuration();
							currLFA1.experienceForce(force);
			
						} 
						if (!currLFA1.isBound()){
						//LFA1 DIFFUSION					
							int numMoves = currLFA1.getCurrDiffusionDistance();
							for (int mNum = 0; mNum < numMoves; mNum++){
								double pDirection = Random.uniform.nextDoubleFromTo(0.0,1.0);
								if (pDirection <= (0.1667)){		
									myLFA1Grid.attemptMicroDiffusion(currLFA1, Constants.NORTH);
								} else if (pDirection <= (0.3333)){
									myLFA1Grid.attemptMicroDiffusion(currLFA1, Constants.NORTHEAST);
								} else if (pDirection <= (0.5)){
									myLFA1Grid.attemptMicroDiffusion(currLFA1, Constants.SOUTHEAST);	
								} else if (pDirection <= (0.6667)){
									myLFA1Grid.attemptMicroDiffusion(currLFA1, Constants.SOUTH);
								} else if (pDirection <= (0.8333)){
									myLFA1Grid.attemptMicroDiffusion(currLFA1, Constants.SOUTHWEST);
								} else {
									myLFA1Grid.attemptMicroDiffusion(currLFA1, Constants.NORTHWEST);
								}
							}
							log("Finished Diffusion of LFA1",2);
						}			
						//CREATE BONDS
						if (!currLFA1.isBound()){	
							int xLFA1 = currLFA1.getMicroX();
							int yLFA1 = currLFA1.getMicroY();
						
							
								if (surfSection.containsICAM1At(xLFA1,yLFA1)){
								log("Found an ICAM at ("+surfSection.getX()+","+surfSection.getY()+")|"+"LFA1("+xLFA1+","+yLFA1+")",2);
								Ind_ICAM1 icam = surfSection.getICAM1Grid().getICAM1At(xLFA1,yLFA1);
								currLFA1.interactWithLigand(a,icam);
								if (myISWBC.getExpCondition() == 2){//if in vivo
									icam.setImmobile(); //bound ICAM1 remains bound
								}		
								
								//Increment LFA1 participants counter
								if (currLFA1.isBound()){
									this.getLeukMem().incrementLFA1ICAMCumulativeBonds();
									if (currLFA1.getBoundBefore() == false){
										currLFA1.setBoundBefore(true);
										this.getLeukMem().incrementLFA1participants();
									} else {
										this.getLeukMem().incrementLFA1RebindingEvents();
									}
								}
								
								//Increment ICAM1 participants counter
								if (currLFA1.isBound()){
									Ind_ICAM1 lig = (Ind_ICAM1)currLFA1.getMyLigand();
									Surface s = surfSection.getSurfaceSpace();
									if (lig.getBoundBefore() == false){
										lig.setBoundBefore(true);
										
										s.incrementICAM1participants();
									} else {
										s.incrementICAM1RebindingEvents();
									}
								}
								//CHECK FOR Outside-In Signaling
								if (currLFA1.isBound()){
									Ind_ICAM1 lig = (Ind_ICAM1)currLFA1.getMyLigand();
									if (lig.isDimeric()){
										Ind_ICAM1 dim = lig.getMyDimer();
										if (dim.isBound()){
											initiateClustering();
											this.getLeukMem().incrementMultimericLFA1ICAMBonds();
										}
									}
									if (lig.isTrimeric()){
										Ind_ICAM1 lig1 = lig.getTrimerHead();
										Ind_ICAM1 lig2 = lig1.getMyTrimer();
										Ind_ICAM1 lig3 = lig2.getMyTrimer();
																	
										int bondCount = 0;
										if (lig1.isBound()){
											bondCount++;
										}
										if (lig2.isBound()){
											bondCount++;
										}

										if (lig3.isBound()){
											bondCount++;
										} 
										
										if (bondCount >= 2){
											initiateClustering();
											this.getLeukMem().incrementMultimericLFA1ICAMBonds();
										}
								
									}
									
									if (lig.isTetrameric()){
										int bondCount = 0;
										Ind_ICAM1 head = lig.getTetramerHead();
										if (head.isBound()){
											bondCount++;
										}
										if (head.getMyDimer().isBound()){
											bondCount++;
										}
										if (head.getMyTetramer().isBound()){
											bondCount++;
										} 
										if (head.getMyTetramer().getMyDimer().isBound()){
											bondCount++;
										}
										if (bondCount >= 2){
											initiateClustering();
											this.getLeukMem().incrementMultimericLFA1ICAMBonds();
										}
									}
								}
							
							} 
						}

						//Random Breaking of LFA1				
						if (currLFA1.isBound()){
							double pbreak = Random.uniform.nextDoubleFromTo(0.0,1.0);
							currLFA1.randomDissociation(pbreak);
						}
					}
				}
				//MOVE unbound clusters
				myLFA1Grid.moveUnboundLFA1Clusters();

			}
			if (isActivated()){
				this.activate();
			}
			//Group adhesion molecules create and break bonds
			this.interactWithSurfaceUnit(surfSection);
			this.forcedDissociation(force);
		}
		
		//	Random Removal of LFA1 agents				
		if (containslfa1){
				
			for (int a = 0; a < lfa1AgentList.size(); a++){
				Ind_LFA1 currLFA1 = (Ind_LFA1)lfa1AgentList.get(a);
				if (currLFA1 != null){
					if (!currLFA1.isBound()){	
						double pRemoval = Random.uniform.nextDoubleFromTo(0.0,1.0);
						if (pRemoval <= myISWBC.getLFA1_PRemoval()){
							log("Rand:"+pRemoval+" pRemove:"+myISWBC.getLFA1_PRemoval(),2);
							removeLFA1(a);
						}
					}
				}
			}
		}
		
	}

	/*
	 * Number of clusters for this membrane unit
	 */
	public int numOfClusters(){
		if(containslfa1){
			return myLFA1Grid.getNumClusters();
		} else {
			return 0;
		}
	}

	/*
	 * initiates outside in spreading of the membrane
	 */
	public void outsideInActivatedSpreading(){
		myLeukMem.activateSpreading();
	}

	/*
	 * initiates clustering of the LFA1 on the LFA1Grid for this MemUnit
	 * chooses random positions to create lfa1 clusters
	 */
	public void initiateClustering(){
		
		if (this.containsLFA1()){
			if (this.numOfClusters() == 0){
				for (int n = 0; n < numClustersAllowed; n++){
					Ind_LFA1 mlfa = null;
		
					for (int a = 0; a < lfa1AgentList.size(); a++){
						Ind_LFA1 currlfa = (Ind_LFA1)lfa1AgentList.get(a);
						if (currlfa != null){
							if (currlfa.isBound()){		
								mlfa = currlfa;
							}
						}
					}
			
					if (mlfa != null){
						myLFA1Grid.formCluster(mlfa.getMicroX(),mlfa.getMicroY(),myISWBC.getLFA1ClusterDiameter());	
					} else {
						Random.createUniform();
						int nx = Random.uniform.nextIntFromTo(0,myISWBC.getLFA1GridSize()-1);
						int	ny = Random.uniform.nextIntFromTo(0,myISWBC.getLFA1GridSize()-1);
						myLFA1Grid.formCluster(nx,ny,myISWBC.getLFA1ClusterDiameter());
					}
				}
				this.fillClusters();
			}
		
		}
	}
	
	/*
	 * equally fills the clusters with all unbound LFA1 in memunit. 
	 */
	public void fillClusters(){
		if (this.containsLFA1()){
			if (this.numOfClusters() != 0){	
				myLFA1Grid.fillClustersWithLFA1(lfa1AgentList);
			}
		}
	}
	
	/*
	 * remove an LFA1 object 
	 */
	public void removeLFA1(int num){
		Ind_LFA1 lfa1 = (Ind_LFA1) lfa1AgentList.get(num);
		lfa1AgentList.set(num,null);
	}
	/*
	 * print information for this membrane unit
	 */
	public void printInfo(){
		myISWBC.log("t:"+this.getNumBonds()+"| PS:"+this.getNumPSGL1Bonds()+"| LFA1(b):"+this.getNumLFA1Bonds()+"| LFA1(tot):"+this.getNumLFA1Total(),2);
	}
	
	/*
	 * interact with a surface unit
	 * @param surfsection is the surf unit to interact with.  
	 */
	public void interactWithSurfaceUnit(SurfaceUnit surfSection){
		
		//only search if there is a Memunit in immediate environment
		if (surfSection != null){	
			
			//Examine each Grp_AdhMolecules for this memSection
			for (int adhMolNum = 0; 
				adhMolNum < Constants.TOTNUM_GRP_ADHMOLS; adhMolNum++){
							
				//Examine only exposed AdhMolecules
				if (myGrp_AdhMols[adhMolNum] != null){
					myGrp_AdhMols[adhMolNum].ligInteractWithSurfaceUnit(surfSection);
				}
			}
		
			//Examine each ChemokReceptor
			for (int chemRecNum = 0; 
				chemRecNum < Constants.TOTNUMCHEMOKRECEPS; chemRecNum++){
				if (myChemokReceps[chemRecNum] != null){
					myChemokReceps[chemRecNum].interactWithSurfaceUnit(surfSection);
					
				}			
			}
			log("Done interactingWithSurfUnit",2);	
			
		}
	}
	
	/*
	 * Bonds in this Membrane Unit experience a force
	 * @param force is the force each bond experiences
	 */
	public void forcedDissociation(double force){
		for (int adhNum = 0; adhNum < Constants.TOTNUM_GRP_ADHMOLS; adhNum++){
			//AdhesMolecule adhMol = myAdhMols[adhNum];
			if (myGrp_AdhMols[adhNum] != null){
				log("+--forcedDissociation (Force: "+force+") of LeukMem at "+this.getXPosOnMembrane()+", "+this.getYPosOnMembrane(),1);
				myGrp_AdhMols[adhNum].experienceForce(force);
			}
		}
	}
	
	/*
	 * get An LFA1 object from the list
	 * @param n is the id number of the LFA1 
	 */
	public Ind_LFA1 getLFA1fromList(int n){
		return (Ind_LFA1)lfa1AgentList.get(n);
	}
	
	/*
	 * get the LFA1Grid for this MemUnit
	 */
	public LFA1Grid getLFA1Grid(){
		return myLFA1Grid;
	}
	
	public void setSurfaceSpace(Surface s){
		mySurfaceSpace = s;
	}
	
	public Surface getSurfaceSpace(){
		return mySurfaceSpace;
	}
	
	/* Get the LeukMem for this LeukMemUnit
	 */
	protected LeukMem getLeukMem(){
		return myLeukMem;
	}

	/*
	 * Returns the x position on the cell membrane 
	 */
	public int getXPosOnMembrane(){
		return xPosOnMembrane;
	}
	
	/*
	 * Returns the y position on the cell membrane
	 */
	public int getYPosOnMembrane(){
		return yPosOnMembrane;
	}

	/*
	 * Set the position of this Membrane Unit on the Membrane
	 * @param x is the x coordinate on the membrane
	 * @param y is the y coordinate on the membrane
	 */
	public void setPosition(int x, int y){
		xPosOnMembrane = x;
		yPosOnMembrane = y;
	}
	
	/*
	 * Returns true if this MemUnit contains a bound AdhesMolecule
	 */
	public boolean isBound(){
		boolean bound = (this.getNumBonds() > 0.0);
		
		return bound;
	}
	
	/*
	 * Returns true if this MemUnit contains LFA1
	 */
	public boolean containsLFA1(){
		return containslfa1;
	}
	
	/*
	 * Returns the size of LFA1Agent List
	 */
	public int getLFA1AgentListSize(){
		return lfa1AgentList.size();
	}

	/*
	 * Returns the number of non-null LFA1 Agents
	 */
	public int getNumLFA1Total(){
		int count = 0;
		if (this.containsLFA1()){
			for (int a = 0; a < lfa1AgentList.size(); a++){
				if (lfa1AgentList.get(a) != null){
					count++;
				}
			}
		}
		return count;
	}
	/*
	 * gets the total number of hgh affinity LFA1 objects in this MemUnit
	 */
	
	public double getNumHighLFA1Total(){
		double count = 0;
		if (this.containsLFA1()){
			for (int a = 0; a < lfa1AgentList.size(); a++){
				Ind_LFA1 lfa = (Ind_LFA1)lfa1AgentList.get(a);
				if ((lfa != null) && (lfa.getAffinityState()>0)){
					count++;
				}
			}
		}
		return count;
	}
	
	/*
	 * Gets the number of LFA1 bonds
	 */
	public double getNumLFA1Bonds(){
		double bonds = 0;
		if (this.containsLFA1()){	
			for (int a = 0; a < lfa1AgentList.size(); a++){
				Ind_LFA1 lfa = (Ind_LFA1)lfa1AgentList.get(a);
				if (lfa != null){
					if (lfa.isBound()){
						bonds++;
					}
				}
			}
			
		} else {
			bonds = 0;
		}
		return bonds;
	}
	
	/*
	 * Gets the number of PSGL1 bonds
	 */
	public double getNumPSGL1Bonds(){
		return myGrp_AdhMols[Constants.PSGL1].getNumBonds();
	}
	
	/*
	 * Gets the number of dimeric bonds
	 */
	public double getNumDimericLFA1Bonds(){
		
		double bonds = 0;
		if (this.containsLFA1()){	
			for (int a = 0; a < lfa1AgentList.size(); a++){
				Ind_LFA1 lfa = (Ind_LFA1)lfa1AgentList.get(a);
				if (lfa != null){
					if (lfa.isBound()){
						Ind_ICAM1 i = (Ind_ICAM1)lfa.getMyLigand();
						if (i.isDimeric()){
							Ind_ICAM1 i2 = i.getMyDimer();
							if (i2.isBound()){
								bonds++;
							}
						}
					}
				}
			}	
		} else {
			bonds = 0;
		}
			return (0.5*bonds);
	}
	
	
	/*
	 * Gets the total number of bonds on this MemUnit
	 */
	public double getNumBonds(){
		double numOfBonds = 0;
		for (int i = 0; i < Constants.TOTNUM_GRP_ADHMOLS; i ++){
			if (myGrp_AdhMols[i] != null){
				if (myGrp_AdhMols[i].isBound()){
					Grp_AdhesMolecules abL = (Grp_AdhesMolecules)myGrp_AdhMols[i];
				
					numOfBonds = numOfBonds + abL.getNumBonds();
					log("*****\nMemUnit.isBound() -> "+this.getXPosOnMembrane()+" "+this.getYPosOnMembrane(),2);
					log(numOfBonds+"bonds between "+myGrp_AdhMols[i].getName()+" to "+myGrp_AdhMols[i].getMyLigand().getName(),2);
				}
					
			}
		}
		if (this.containsLFA1()){
			
			numOfBonds += this.getNumLFA1Bonds();
		}
		return numOfBonds;
	}
	
	/*
	 * Gets the number of free low affinity VLA4
	 */
	public double getNumFreeLowVLA4(){
		double tot = 0.0;
		if (myGrp_AdhMols[Constants.VLA4] != null){
			tot = myGrp_AdhMols[Constants.VLA4].getNumFreeLowAffMols();	
		}
		return tot;
	}
	/*
	 * Gets the number of free high affinity VLA4
	 */
	public double getNumFreeHighAffVLA4Mols(){
		double tot = 0.0;
		if (myGrp_AdhMols[Constants.VLA4] != null){
			tot = myGrp_AdhMols[Constants.VLA4].getNumFreeHighAffMols();	
			
		}
		return tot;
	}
	
	/*
	 * Gets the number of total high affinity VLA4
	 */
	public double getNumTotHighAffVLA4Mols(){
		return myGrp_AdhMols[Constants.VLA4].getNumTotHighAffMols();
	}
	
	/*
	 * Activate section via CXCR2
	 */
	public void activateViaCXCR2(double chemokNum){
		activatedSection = true;
	}
	
	/*
	 * Activate section
	 */
	public void activate(){
		log("ActivateViaCXCR2",2);
		if (activatedSection){
			for (int i = 0; i < Constants.TOTNUM_GRP_ADHMOLS; i++){
				if (this.myGrp_AdhMols[i] instanceof Grp_Integrins){
					((Grp_Integrins)this.myGrp_AdhMols[i]).activateViaCXCR2(1);
				}
			}
		
			if (this.containsLFA1()){
				int max = lfa1AgentList.size();
				Random.createUniform();
			
				for (int a = 0; a < max; a++){
					//int num = Random.uniform.nextIntFromTo(0,max-1);
					Ind_LFA1 lfa1 = (Ind_LFA1)lfa1AgentList.get(a);
					if (lfa1 != null){
						lfa1.activateViaCXCR2();
					}
				}
			}
		
//			this.initiateClustering();
			myLeukMem.activate();
		}
	
	}
	
	/* Returns if this LeukMemUnit is Activated
	 */
	public boolean isActivated(){
		return activatedSection;
	}
	
	/*
	 * Stop VLA4 integrin activation
	 */
	public void haltIntegrinActivation(){
		Grp_Integrins integ = (Grp_Integrins)myGrp_AdhMols[Constants.VLA4];
		integ.haltIntegrinActivation();
		// Halt individual integrin activation
	}
	
	/*
	 * Record LFA1 Data
	 */
	public void recordLFA1Data(){
		
		if (this.containslfa1){
			try{
				
				for (int i = 0; i < lfa1AgentList.size(); i++){
					Ind_LFA1 lfa = (Ind_LFA1)lfa1AgentList.get(i);
					if (lfa != null){
						Double t = new Double(myISWBC.getTickCount());
						int time = (int)myISWBC.getTickCount();
						StringBuffer sb = new StringBuffer();
						StringBuffer sb2 = new StringBuffer();
						
						String filename = myLFA1Grid.getDirectoryName()+"/LFA1_"+"0"+i+".txt";
						BufferedWriter out = new BufferedWriter(new FileWriter(filename, true));
					
						sb.append(t+","+lfa.getMicroX()+","+lfa.getMicroY()+"|"+lfa.getStatus()+"\n");
						out.write(sb.toString());
						out.close();
					}
				}	
			
			} catch (IOException e){
				System.out.println("Error in printing LFA1Grid");
			}
			
			try{
				String filename = myLFA1Grid.getDirectoryName()+"/BondFile2.txt";
				BufferedWriter out = new BufferedWriter(new FileWriter(filename, true));
			
				for (int i = 0; i < lfa1AgentList.size(); i++){
					Ind_LFA1 lfa = (Ind_LFA1)lfa1AgentList.get(i);
					if (lfa != null){
						Double t = new Double(myISWBC.getTickCount());
						int time = (int)myISWBC.getTickCount();
						StringBuffer sb = new StringBuffer();
						
						if (lfa.isBound()){
							Ind_ICAM1 icam = (Ind_ICAM1)lfa.getMyLigand();
							sb.append(time+"|LFA1ID:"+lfa.getID()+"\t-\tICAM1ID:"+icam.getID()+"\n");
							out.write(sb.toString());						
						}
					}
				}	
				out.close();	
			} catch (IOException e){
				System.out.println("Error in printing LFA1Grid");
			}
		}		
	}
	
	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
	private void log(String s, int debugType){
		if (myISWBC.getDebugging() >= debugType){
			System.out.println("MemUnit: "+s);
		}
	}
	


}
