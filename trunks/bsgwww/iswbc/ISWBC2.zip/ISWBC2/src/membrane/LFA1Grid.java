package src.membrane;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import src.model.ISWBC;
import src.ligand.Ind_LFA1;
import src.model.Constants;
import uchicago.src.sim.space.Object2DHexagonalGrid;
import uchicago.src.sim.util.Random;

/*
 * LFA1Grid is a 2D toroidal hexagonal grid where Ind_LFA1 agents move and cluster.
 */
public class LFA1Grid extends Object2DHexagonalGrid {
	
	private ISWBC myISWBC;	
	private int mySize; // total length and width of the LFA1Grid
	private MemUnit myMemUnit; //the MemUnit the LFA1Grid belongs to
	private String directoryName; //directory name for outputing data for this LFA1Grid
	private int[] xCluster; //xPositions of clusters (top-left corner)
	private int[] yCluster; //yPositions of clusters (top-left corner)
	private int[] lCluster; //length of cluster in x and y direction
	private int currNumClusters; //current number of lfa1 clusters
	private int maxNumClustersAllowed; //maximum number of lfa1 clusters allowed
	
	/*
	 * Create and initialize the LFA1Grid
	 * @param size is the size in the x and y direction of the grid
	 * @param mu is the MembraneUnit that contains this Grid
	 * @param iswbc is the ISWBC
	 */
	public LFA1Grid(int size, MemUnit mu, ISWBC iswbc) {
		super(size, size);
		
		mySize = size;
		myMemUnit = mu;
		myISWBC = iswbc;
		maxNumClustersAllowed = iswbc.getNumLFA1Clusters();
		currNumClusters = 0;
		
		
		xCluster = new int[maxNumClustersAllowed];
		yCluster = new int[maxNumClustersAllowed];
		lCluster = new int[maxNumClustersAllowed];
		for (int a = 0; a < maxNumClustersAllowed; a++){
			xCluster[a] = -1; //default values
			yCluster[a] = -1; //default values
			lCluster[a] = 0; // default values
		}
		
		//Set directory for Printing out LFA1Grid Data
		if (myISWBC.getPrintLFA1Data()==Constants.TRUE){
			int lfa1GridNum = mu.getLeukMem().getnumLFA1Grids(); //get current number of LFA1Grids created
			int xP = mu.getXPosOnMembrane(); //x position of LFA1Grid (MemUnit) on the LeukMembrane
			int yP = mu.getYPosOnMembrane(); //y position of LFA1Grid (MemUnit) on the LeukMembrane

			directoryName = new String(myISWBC.getFileDirectoryName()+"/LFA1Grid_0"+lfa1GridNum+"_("+xP+","+yP+")");
			File f2 = new File(directoryName);
			f2.mkdir();
		}
	}
	/*
	 * Get the MemUnit that contains this LFA1Grid
	 * @return MemUnit for this LFA1Grid
	 */
	public MemUnit getMyMemUnit(){
		return myMemUnit;
	}
	
	/*
	 * Insert Ind_LFA1 object at LFA1Grid position (x,y)
	 * @param x is the x location on the LFA1Grid
	 * @param y is the y location on the LFA1Grid
	 * @param object is the Ind_LFA1 object to place
	 */
	public void putLFA1At(int x, int y, Object object){
		this.putObjectAt(x%mySize, y%mySize, object);
	}
	
	/*
	 * Get the Ind_LFA1 object at this grid section
	 * @param x is the x location on the LFA1Grid
	 * @param y is the y location on the lFA1Grid
	 * @return the Ind_LFA1 object at those coordinates
	 */
	public Ind_LFA1 getLFA1At(int x, int y){
		return (Ind_LFA1)this.getObjectAt(x,y);
	}
	
	/*	True if no Ind_LFA1 agent at coordinates
	 * @return true if LFA1Grid position is empty
	 * @param x is the x coordinate
	 * @param y is the y coordinate
	 */
	public boolean emptyAt(int x, int y){
		return (this.getLFA1At(x, y) == null);
	}
	
	/*
	 * Move Ind_LFA1 object to new (x,y) position
	 * @param object is the object to move
	 * @param newX is the new x coordinate
	 * @param newY is the new y coordinate
	 */
	public void moveLFA1At(Object object, int newX, int newY){
	
		Ind_LFA1 lfa1 = (Ind_LFA1)object;
		int oldX = lfa1.getMicroX();
		int oldY = lfa1.getMicroY();
		
		this.putObjectAt(newX,newY,lfa1);
		this.putObjectAt(oldX,oldY,null);
		
		lfa1.move(newX, newY);
	}
	
	/*
	 * Return true if there is an LFA1 bond at this (x,y) position on the LFA1Grid
	 * @param xPos is the x Position to look at on the LFA1Grid
	 * @param yPos is the y Position to look at on the LFA1Grid
	 * @return true if there is a bond at the coordinates
	 */
	public boolean isLFA1BondAt(int xPos, int yPos){
		boolean bound = false;
		Ind_LFA1 lfa1 = this.getLFA1At(xPos, yPos);
		if (lfa1 != null){
			bound = (lfa1.isBound()) ? true : false;
		}
		return bound;
	}
	
	/*length of the cluster 
	 * @param num is the cluster number
	 * @return the cluster length for that cluster
	 */
	public int getLCluster(int num){
		return lCluster[num];
	}
	
	/*
	 *xPosition of cluster number, num
	 *@param num is the cluster number
	 *@return the x position of the cluster
	 */
	public int getXCluster(int num){
		return xCluster[num];
	}

	/*
	 * yPosition of cluster number, num
	 * @param num is the cluster number
	 * @return the y position of the cluster
	 */
	public int getYCluster(int num){
		return yCluster[num];
	}
	
	/*
	 * Fill clustes with LFA1 from lfa1ArrayList lfa1ArrayL
	 * @param lfa1ArrayL is the ArrayList of Ind_LFA1 agents
	 */
	public void fillClustersWithLFA1(ArrayList<Ind_LFA1> lfa1ArrayL){
		int clusterNum = 0;
		Random.createUniform();
		
		
		for (int a = 0; a < lfa1ArrayL.size(); a++){
			Ind_LFA1 currlfa = (Ind_LFA1)lfa1ArrayL.get(a);
			if ((currlfa != null) && (!currlfa.isBound())){
				int cx = this.getXCluster(clusterNum); 
				int cy = this.getYCluster(clusterNum);
				int cl = this.getLCluster(clusterNum);
				boolean done = false;
				while(!done){
				
					int nx = Random.uniform.nextIntFromTo(cx,cx+cl-1);
					int	ny = Random.uniform.nextIntFromTo(cy,cy+cl-1);
					if (this.withinCluster(nx,ny) && (this.emptyAt(nx, ny))){
						done = true;
						this.moveLFA1At(currlfa, nx, ny);
					}
					if (this.clusterFull(clusterNum)){
						done = true;
					}
				}
				clusterNum++;
				//Equally distribute among all clusters -> go back to cluster 0;
				if (clusterNum >= this.maxNumClustersAllowed){
					clusterNum = 0;
				}
				
			}
		}
	}
	
	/*
	 * Determines if the cluster completely filled with Ind_LFA1
	 * @param cNum is the cluster number
	 * @return if the cluster is completely full of Ind_LFA1
	 */
	public boolean clusterFull(int cNum){
		boolean full = true;
		for (int a = xCluster[cNum]; a < xCluster[cNum]+lCluster[cNum]; a++){
			for (int b = yCluster[cNum]; b < yCluster[cNum]+lCluster[cNum]; b++){
				if (this.emptyAt(a,b)){
					full &= false;
				}
			}
		}
		return full;		
	}
	
	/*
	 * Form the cluster ideally at x, y, with specified length
	 * Clusters cannot be split when located on edges of the toroidal LFA1Grid.  
	 * Instead, they are moved so that they lie on the edges.
	 * @param x is the ideal x position on the LFA1Grid
	 * @param y is the ideal y position on the LFA1Grid
	 * @param length is the length of the cluster
	 */
	public void formCluster(int x, int y, int length){
		int halfLength = length/2;
		int idealX = x - halfLength;
		int idealY = y - halfLength;
		
		if (this.myISWBC.getLFA1ClusteringAllowed() == 1){
			if (currNumClusters < maxNumClustersAllowed){
				if (idealX < 0){
					xCluster[currNumClusters] = 0;
				} else if (idealX >= mySize - length){
					xCluster[currNumClusters] = mySize - length;
				} else {
					xCluster[currNumClusters] = idealX;
				}
		
				if (idealY < 0){
					yCluster[currNumClusters] = 0;
				} else if (idealY >= mySize - length){
					yCluster[currNumClusters] = mySize - length;
				} else {
					yCluster[currNumClusters] = idealY;
				}
				lCluster[currNumClusters] = length;
			
				try
				{
					if ((myISWBC.getPrintLFA1Data() == Constants.TRUE) || (myISWBC.getPrintICAM1Data() == 1)){
						String filename = new String(this.getDirectoryName()+"/ClusterFile.txt");
						FileWriter fw = new FileWriter(filename,true);
						PrintWriter pw = new PrintWriter(fw,true);
						pw.println(myISWBC.getStepNumber()+",(#"+currNumClusters+" LFA1 Cluster Formed):"+this.xCluster[currNumClusters]+","+this.yCluster[currNumClusters]+"|"+length);
						fw.close();
					}
					
				} catch(IOException ioe) {
					System.err.println("IOException: " + ioe.getMessage());
				}
				currNumClusters++;
				
			} else {
				log("This LFA1Grid has already been clustered",1);
			}
		}	
		
	}
	
	/*
	 * Allow all unbound LFA1 Clusters to translocate
	 */
	public void moveUnboundLFA1Clusters(){
		for (int a = 0; a < currNumClusters; a++){
			Random.createUniform();
			if (!clusterBound(a)){
				int newx = Random.uniform.nextIntFromTo(0,mySize);
				int	newy = Random.uniform.nextIntFromTo(0,mySize);
				moveLFA1Cluster(a,newx,newy);
			}
		}
	}
	
	/*
	 * Moves a single cluster and all of the Ind_LFA1 agents within to a new location, 
	 * if that new location is empty
	 * @param cNum is the cluster Number
	 * @param newx is the new x position on the LFA1Grid
	 * @param newy is the new y position on the LFA1Grid
	 */
	private void moveLFA1Cluster(int cNum, int newx, int newy){
		if (!this.withinCluster(newx, newy)){
			
				
			int oldx = xCluster[cNum];
			int oldy = yCluster[cNum];
			int length = lCluster[cNum];
			int halfLength = length/2;
			int idealX = newx - halfLength;
			int idealY = newy - halfLength;
			int proposedX;
			int proposedY;
			
			if (idealX < 0){
				proposedX = 0;
			} else if (idealX >= mySize - length){
				proposedX = mySize - length;
			} else {
				proposedX = idealX;
			}
	
			if (idealY < 0){
				proposedY = 0;
			} else if (idealY >= mySize - length){
				proposedY = mySize - length;
			} else {
				proposedY = idealY;
			}
			
			boolean allEmpty = true;
			for (int a = proposedX; a < proposedX+length; a++){
				for (int b = proposedY; b < proposedY+length; b++){
					if (!this.emptyAt(a,b)){
						allEmpty &= false;
					}
				}
			}
			
			if (allEmpty){
				for (int a = oldx; a < oldx+length; a++){
					for (int b = oldy; b < oldy+length; b++){
					
						Ind_LFA1 lfa = (Ind_LFA1)this.getLFA1At(a, b);
						if(lfa != null){
							int xdiff = oldx - lfa.getMicroX();
							int ydiff = oldy - lfa.getMicroY();
							int nLFAX = proposedX - xdiff;
							int nLFAY = proposedY - ydiff;
							this.moveLFA1At(lfa, nLFAX, nLFAY);
							
						}
					}
				}
				xCluster[cNum] = proposedX;
				yCluster[cNum] = proposedY;
			}
		}
	}
	
	/*
	 * Determines if there is at least one bond within a cluster
	 * @param cNum is the cluster number
	 * @return true if the cluster has at least 1 bound Ind_LFA1
	 */
	public boolean clusterBound(int cNum){
		boolean unbound = true;
		for (int a = xCluster[cNum]; a < xCluster[cNum]+lCluster[cNum]; a++){
			for (int b = yCluster[cNum]; b < yCluster[cNum]+lCluster[cNum]; b++){
				if (this.isLFA1BondAt(a, b)){
					unbound &= false;
				}
			}
		}
		return !unbound;
	}
	
	/*
	 * Determines if this position on the LFA1Grid is within any of the clusters
	 * @param x is the x coordinate in question
	 * @param y is the y coordinate in question
	 * @returns true if this x,y position is within a cluster
	 */
	public boolean withinCluster(int x, int y){
		boolean outside = true;
		for (int a = 0; a < currNumClusters; a++){
			if ((x < xCluster[a] + lCluster[a]) && (x >= xCluster[a]) && (y < yCluster[a] + lCluster[a]) && (y >= yCluster[a])){
				outside &= false;
			}
		}
		return !outside;				
	}
	
	/*
	 * returns the number of clusters in this LFA1Grid
	 * @return the number of clusters
	 */
	public int getNumClusters(){
		return currNumClusters;
	}
	
	/*
	 * Attempts to move Ind_LFA1 agents to an empty, neighboring spot, in a specified direction
	 * @param object is the object in question
	 * @direction is the direction (defined by the Constants class)
	 */																							
	public void attemptMicroDiffusion(Object object, int direction){
		Ind_LFA1 lfa = (Ind_LFA1)object;
		int oldX = lfa.getMicroX();
		int oldY = lfa.getMicroY();
		int newX = this.getNeighboringX(direction,oldX,oldY);
		int newY = this.getNeighboringY(direction,oldX,oldY);
		if (currNumClusters > 0){//Clustered so, LFA1 must stay within clusters
			if(this.withinCluster(oldX,oldY)){
				if(this.withinCluster(newX,newY)){
					if (this.emptyAt(newX, newY)){
						this.moveLFA1At(object, newX, newY);
					}
				} 
			} else {//Ind_LFA1 wasn't in cluster before so can freely diffuse
				if (this.emptyAt(newX, newY)){
					this.moveLFA1At(object, newX, newY);
				}
			}
		} else {//Unclustered - free diffusion on LFA1Grid
			if (this.emptyAt(newX, newY)){
				this.moveLFA1At(object, newX, newY);
			}
		}
	}

	/*
	 *	Sends signal to MemUnit for outside-in signaling activation 
	 */
	public void outsideInActivatedSpreading(){
		myMemUnit.outsideInActivatedSpreading();
	}

	
	/*
	 * Set the directoryName for outputing data for this LFA1Grid.
	 * @param directoryName for outputing data for this LFA1Grid
	 */
	public void setDirectoryName(String name){
		directoryName = name;
	}
	
	/* Returns the directoryName for this LFA1Grid for outputting data
	 * @returns the directoryName for outputing data for this LFA1Grid
	 */
	public String getDirectoryName(){
		return directoryName;
	}
	
	/*	Gets the opposite direction of that specified
	 * 	@param direction is the direction value
	 * 	@return the value of the opposite direction
	 */
	public int getOppositeDirection(int direction){
		int oppDirection = 6;
		switch (direction){
			case Constants.NORTH:	oppDirection = Constants.SOUTH; break;
			case Constants.NORTHEAST: oppDirection = Constants.SOUTHWEST; break;
			case Constants.SOUTHEAST: oppDirection = Constants.NORTHWEST; break;
			case Constants.SOUTH: oppDirection = Constants.NORTH; break;
			case Constants.SOUTHWEST: oppDirection = Constants.NORTHEAST; break;
			case Constants.NORTHWEST: oppDirection = Constants.SOUTHEAST; break;
		}
		return oppDirection;
		
	}
	
	/* Gets the x coordinate of the neighboring position of (x,y) in the specified 
	 * direction on the hexagonal LFA1Grid.  LFA1Grid is implemented as toroidal. 
	 * @param direction is the direction from the (x,y) coordinates (defined by Constants)
	 * @param xPos is the x coordinate 
	 * @param yPos is the y coordinate
	 * @return the y coordinate of the neighboring position from x,y in the specified direction
	 */
	public int getNeighboringX(int direction, int xPos, int yPos){
		int newX=xPos;
		if (direction == Constants.SAME){
			newX = xPos;
		}
		
		if ((direction == Constants.NORTHEAST)||
				(direction == Constants.SOUTHEAST)){
			newX = xPos+1;
		}
		if ((direction == Constants.SOUTHWEST)||
				(direction == Constants.NORTHWEST)){
			newX = xPos-1;
		}
		
		if (newX == this.mySize){
			newX = 0; 
		}
		if (newX == -1){
			newX = this.mySize-1; 
		}
		
		return newX;
	}
	
	/* Gets the y coordinate of the neighboring position of x,y in the specified 
	 * direction on the hexagonal LFA1Grid.  LFA1Grid is implemented as toroidal.
	 * @param direction is the direction from the (x,y) coordinates (defined by Constants)
	 * @param xPos is the x coordinate 
	 * @param yPos is the y coordinate
	 * @return the y coordinate of the neighboring position from x,y in the specified direction
	 */
	public int getNeighboringY(int direction, int xPos, int yPos){
		
		int newY=yPos;
		
		if (direction == Constants.SAME){
			newY = yPos;
		}
		if ((direction == Constants.SOUTH)||
			((direction == Constants.SOUTHEAST)&&(xPos %2==0))||
			((direction == Constants.SOUTHWEST)&&(xPos %2==0))){
				newY = yPos+1;
		}
		if ((direction == Constants.NORTH)||
				((direction == Constants.NORTHEAST)&&(xPos %2==1))||
				((direction == Constants.NORTHWEST)&&(xPos %2==1))){
					newY = yPos-1;
		}
		
		if (newY == this.mySize){
			newY = 0;
		}
		if (newY == -1){
			newY = this.mySize-1;
		}
		return newY;
	}
	
	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
	private void log(String s, int debugType){
		if (myISWBC.getDebugging() >= debugType){
			System.out.println("LFA1Grid: "+s);
		}
	}
}
