/*
  * @author Jonathan Tang
  */
 package src.membrane;

import java.util.ArrayList;

import src.flowchamber.Surface;
import src.flowchamber.FlowChamber;
import src.model.*;
import src.flowchamber.SurfaceUnit;
import src.cell.Leukocyte;
import uchicago.src.sim.util.Random;

/* LeukMem represents the membrane of a leukocyte.
 */
 public class LeukMem extends Membrane implements Constants{

 	private static int DEBUGGING; 
 	
 	private double timeToFlattenOut;  // amount of time before LeukMem begins to flatten
 	private double vla4MaxActive; // the maximum percentage of VLA-4 in high affinity state
 	private boolean originalSize = true;  //whether LeukMem is at its original size
 	private int adherenceCount;  //count of how many timesteps the leukMem has adhered
 	private boolean achievedAdhesion;
 	private boolean sustainedAdhesion;
 	private boolean transientAdhesion;
 	private boolean everAchievedTransientAdhesion;
 	private int longestAdherenceCount;
 	private boolean spreadingActivated;
 	private int spreadingCount;
 	
 	protected Leukocyte myLeuk; 
 	protected int trailingEdge; //left int position on LeukMem grid 
 	protected int leadingEdge; //right int position on LeukMem grid
 	protected int bottomEdge; //bottom int position on LeukMem grid
 	protected int topEdge; //top int position on LeukMem grid
 	protected int xPos; //x position on the SurfaceSpace
 	protected int yPos; //y position on the SurfaceSpace
 	
 	protected int exposureWidth; //amt exposed to surface during rolling
 	protected int exposureLength; //amt exposed to surface during rolling
 	
 	private Surface mySurfaceSpace; 
 	private FlowChamber myFlowChamber;
 	//private ISWBC myModel;
 	
	private int numLFA1Grids;
	private ArrayList<LFA1Grid> lfa1GridAgentList;
 	
 	private String myStatus;
 	private int	timeAttached;
 	private int timeActivated;
 	private boolean activated;
 	private int LFA1participants;
 	private int LFA1RebindingEvents;
 	private int MultimericLFA1ICAMBonds;
 	private int LFA1ICAMCumulativeBonds;
 	
 	/* Create a LeukMem for a Leuk and an ISWBC
 	 */
 	public LeukMem(Leukocyte leuk, ISWBC lam) {
 		super(lam);
		this.length = lam.getLeuk_TotalLength();
		this.width = lam.getLeuk_TotalWidth();
		this.exposureWidth = lam.getLeuk_ExposedWidth();
		this.exposureLength = lam.getLeuk_ExposedLength();
		trailingEdge = 0;
		leadingEdge = trailingEdge + exposureLength - 1;
 		bottomEdge = 0;
 		topEdge = bottomEdge+lam.getLeuk_ExposedWidth()-1;
 		myStatus = new String();
 		timeAttached = 0;
 		timeActivated = 0;
 		activated = false;
 		longestAdherenceCount = 0;
 		achievedAdhesion = false;//becomes true if achieves adhesion after 200 timesteps
 		sustainedAdhesion  = true;//becomes false if achievedAdhesion, but then starts rolling again
 		transientAdhesion = false;
 		everAchievedTransientAdhesion = false;
 		spreadingActivated = false;
 		spreadingCount = 0;
 		
 		LFA1participants = 0; 
 		LFA1RebindingEvents = 0;
 		MultimericLFA1ICAMBonds = 0;
 		LFA1ICAMCumulativeBonds = 0;
 		
 		myLeuk = leuk;
 		DEBUGGING = lam.getDebugging();
 		this.adherenceCount = 0;
 		double surfaceArea = this.length*this.width;
 		double vlaMaxPerSection = lam.getDensity_VLA4_Mean()*lam.getMaxPercActiveVLA4();
 		this.vla4MaxActive = surfaceArea*vlaMaxPerSection;

 		this.timeToFlattenOut = lam.getFlattening_Time();
		double lfa1GridDensity = lam.getDensity_LFA1Grid_Mean();
		
		Random.createUniform();
		myMemUnits = new MemUnit[lam.getLeuk_TotalLength()][lam.getLeuk_TotalWidth()];
		numLFA1Grids = 0;
			
		lfa1GridAgentList = new ArrayList<LFA1Grid>(this.length*this.width);
		
		for (int i = 0; i < length; i++){
			for (int j = 0; j < width; j++){
				double d = Random.uniform.nextDoubleFromTo(0.0,1.0);
				boolean lfa1Present = false;
				if (d <= lfa1GridDensity){
					lfa1Present = true;
					numLFA1Grids++;
				}
				myMemUnits[i][j] = new MemUnit(i, j, this, lam, lfa1Present);
			}
		}
 	}

 	
 	/* Stepping function to be called at each time step
 	 */
 	public void play(){
 		
 		if (this.bound()){
 			//Calculate Force at Rear for each AdhesMolecule
 			double numInteractions = this.numInteractionsAtRear();
 			double rearForce = this.getFlowChamber().getRearForce();
 			log("rearForce: "+rearForce,2);
 			double bondForce = rearForce/numInteractions;
 			log("Num of Bonds: "+numInteractions,2);
 			log("Bond Force: "+bondForce,2);

 			//MemUnits observe environment (environment, bondForce)
 			for (int a = 0; a < length; a++){
 				for (int b = 0; b < width; b++){
 					SurfaceUnit su = this.getEnvironmentSurfaceUnit(myMemUnits[a][b]);
 					double force = 0;
 					force = (a == trailingEdge) ? bondForce : 0;
 					myMemUnits[a][b].play(su, force);
 				}
 			}
 			
 			//Halt integrin activation at vla4MaxActive Percent
 			if (getTotNumHighAffIntegrins() >= vla4MaxActive){
					this.haltIntegrinActivation();
			}
 			
 			if (this.bound()){
 				adherenceCount++;
 				timeAttached++;
 				if (this.activated()){
 					timeActivated++;
 				}
 				log("Adherence Count: "+adherenceCount,2);
					
 				//Keep moving forward until bonds are at rear
 				if (trailingEdgeFree()){

 	 				adherenceCount = 0;
 					if (!originalSize){
 						shrinkToOriginalSize();	
 						originalSize = true;
 					}
 				
 					while (trailingEdgeFree()){
 	 					roll();
 					}
 					
 					sustainedAdhesion = (achievedAdhesion) ? false : sustainedAdhesion;
 				} else { 
 					if (this.getMyISWBC().getSpreadingAllowed()==1){
 						if (spreadingActivated){
 							spreadingCount++;
 							if (spreadingCount%(2*timeToFlattenOut) == 0){
 								this.flatten();			
 							}
 							if (spreadingCount%300 == 0){
 								this.increaseLFA1Exposure();
 							}
 						}
 					}
 					
 					transientAdhesion = (adherenceCount >= 50) ? true : false;
 					achievedAdhesion = (adherenceCount >= 300) ? true : achievedAdhesion;
 					
 					if (!everAchievedTransientAdhesion){
 						if (transientAdhesion){
 							everAchievedTransientAdhesion = true;
 						}
 					}
 					if (adherenceCount > longestAdherenceCount){
 						longestAdherenceCount = adherenceCount;
 					}
 	 			}
 			} else {
 				this.detachFromSurface();
 			}
 		} else {
 		 	//this.detachFromSurface();
 		 	xPos= xPos+100;
 		 	
 		}
 	}
 	/*
 	 * Increases the Exposure of LFA1 Grids to the environment
 	 */
 	public void increaseLFA1Exposure(){
 	
 		int count = 0;
 		int memTots = length*width;
 		int numLFA1GridsIncreased = (int) (memTots*this.getMyISWBC().getRate_LFA1GridIncrease());
 		while(count < numLFA1GridsIncreased){
 			int x = Random.uniform.nextIntFromTo(0,length-1);
 			int y = Random.uniform.nextIntFromTo(0,width-1);
 			
 			if (!myMemUnits[x][y].containsLFA1()){
 				myMemUnits[x][y].exposeLFA1();
 				count++;
 			}
 			
 			if (allLFAExposed()){
 				break;
 			}
 		}
 	
 	}
 	
 	/*
 	 * Determines if all LFA1Grids are exposed
 	 */
 	public boolean allLFAExposed(){
 		int nonexposedCount = 0;
 		for (int a = 0; a < length; a++){
 			for (int b = 0; b < width; b++){
 				if (!myMemUnits[a][b].containsLFA1()){
 					nonexposedCount++;
 				}
 			}
 		}
 		if (nonexposedCount > 0){
 			return false;
 		} else {
 			return true;
 		}
 	}
 	
 	/*
 	 * Get Transient Adhesion Status for output
 	 */
 	public String getTransientStatus(){
 		if (transientAdhesion){
 			return (new String("transient"));
 		} else {
 			return (new String("_"));
 		}
 	}
 	
 	/*
 	 * Return activation state of LeukMem
 	 */
 	public boolean activated(){
 		return activated;
 	}
 	
 	/*
 	 * Activate LeukMem
 	 */
 	public void activate(){
 		activated = true;
 	}
 	
 	/*
 	 * Return Status of LeukMem
 	 * Sustained_Adhesion = adhesion for the duration of the simulation
 	 * Initial_Adhesion = adhesion for at least 300 simulation cycles
 	 * Transient_Adhesion = adhesion for at least 50 simulation cycles
 	 * Rolled = attached for at least 10 simulation cycles
 	 * Detached = removed before 10 simulation cycles
 	 */
 	public String getStatus(){
 		if (timeAttached > 3){
 			if(achievedAdhesion){
 				if (sustainedAdhesion){
 					myStatus = new String("Sustained_Adhesion, "+longestAdherenceCount);
 				} else {
 					myStatus = new String("Initial_Adhesion, "+longestAdherenceCount);
 				}
 			} else {
 				if (everAchievedTransientAdhesion){
 					myStatus = new String("Transient_Adhesion, "+longestAdherenceCount);
 				} else {
 					myStatus = new String("Rolled, "+longestAdherenceCount);
 				}
 			}
 		} else {
 			myStatus = new String("Detached, "+timeAttached);
 		}
 		return myStatus;
 	}
 
 	/*
 	 * Output LFA1 Data
 	 */
 	public void recordLFA1Data(){
 		for (int i = 0; i < length; i++){
			for (int j = 0; j < width; j++){
				
				myMemUnits[i][j].recordLFA1Data();
				
			}
		}
 	}
 
 	/*
 	 * Number of LFA1 Clusters
 	 */
 	public int numLFA1Clusters(){
 		int num = 0;
 		for (int i = 0; i < length; i++){
			for (int j = 0; j < width; j++){
			
				num = num +	myMemUnits[i][j].numOfClusters();
			}
		}
 		return num;
 		
 	}
 	/*
 	 * get the Number of Visible LFA1 Clusters
 	 */
 	public int numVisibleLFA1Clusters(){
 		int num = 0;
 		for (int i = 0; i < length; i++){
			for (int j = 0; j < width; j++){
			
				num = num +	myMemUnits[i][j].numOfClusters();
			}
		}
 		return num;
 	}
 	
 	/*Activate spreading
 	 * 
 	 */
 	public void activateSpreading(){
 		if (this.getMyISWBC().getSpreadingAllowed() == 1){
 			if (!spreadingActivated){
 				spreadingActivated = true;
 				log("Activating Spreading",2);
 			}
 	 	}
 	}
 	
 	/*
 	 * Return spreading activation state
 	 */
 	public boolean spreadingActivated(){
 		return spreadingActivated;
 	}
 	
 	
 	
 	/* Attaches this LeukMem to the Surface ss at position (x,y)
 	 */
 	public void tetherToSurface(Surface ss, int x, int y){
		setSurfaceSpace(ss);
		this.setXPos(x);
		this.setYPos(y);
 	}
 	
 	/* Partially Rotates this membrane around its axis of rotation along
 	 * the venule in the direction of flow. 
 	 */
 	public void roll(){
 		
 		log("+Initiating roll()",1);
 		Surface ss = this.getSurfaceSpace();
 		int addedColumn = (leadingEdge+1) % length;
 		int removedColumn = trailingEdge;
 		ss.insertLeukMemUnitColumn(this,addedColumn);
 		ss.removeLeukMemUnitColumn(this,removedColumn);
 		
 		leadingEdge = addedColumn;
 		trailingEdge = (trailingEdge + 1) % length;
 		
 		xPos++; // move in direction of flow
 		log("-Ending roll()",1);
 	}
 	

 	/* Form interactions at the front
 	 */
 	public void formInteractionsAtFront(){
 		log("+Initiating formInteractionsAtFront()",1);
 		
 		for (int i = 0; i < width; i++){
 			//find appropriate SurfaceUnit (if any) to interact with
 			SurfaceUnit ps = this.getEnvironmentSurfaceUnit(myMemUnits[leadingEdge][i]);
 			
 			//attempt to interact with it
 			myMemUnits[leadingEdge][i].interactWithSurfaceUnit(ps);
 	 	}
 		log("+Ending formInteractionsAtFront()",1);
 	}
 	
 	
 	/* Detaches the LeukMem from the SurfaceSpace
 	 */
 	private void detachFromSurface(){
 		
 		this.mySurfaceSpace.detachLeukMem(this);
 	}
 	
 /*	
 	public void experienceEnvironment(double forceAtRear){
 		log("+Initiating interactWithEnvironment()",1);
 		Surface ss = this.getSurfaceSpace();
 		
 		double force = 0;
 		for (int i = 0; i < length; i++){
 			for (int j = 0; j < width; j++){
 				SurfaceUnit surfSection = this.getEnvironmentSurfaceUnit(myMemUnits[i][j]);
 				 
 				if (i == trailingEdge){
 					force = forceAtRear; 		 			
 				} else {
 					force = 0;
 				}
 				myMemUnits[i][j].play(surfSection, force);
 			}
 		}

 		log("-Ending experienceEnvironment()",1);
 	}
 	
	private void experienceForceAtRear(double force){
 		log("+Initiating ExperiencingForceAtRear("+force+")",1);
 		
 		for (int i = 0; i < width; i++){
 			if (this.trailingEdgeFree()){
 			} else {
 				myMemUnits[trailingEdge][i].forcedDissociation(force);	
 			}
 		}
 		log("-Ending ExperiencingForceAtRear",1);
 		
 	}
 	
 	private void interfaceBondBreaking(){
 		log("+Initiating InterfaceBondBreaking()",1);
 		for (int i = 0; i < length; i++){
 			for (int j = 0; j < width; j++){
 				if (i == trailingEdge){
 					//do nothing
 				} else if (this.bound()){
 					if (myMemUnits[i][j].isBound()){
 						myMemUnits[i][j].forcedDissociation(0);
 					}
 				} else {
 				}
 			}
 		}
 		log("+Ending InterfaceBondBreaking()",1);
 	}
 */	
 	/*
 	 * Allow leukocyte to interact with environment
 	 */
 	public void interactWithEnvironment(){
 		log("+Initiating interactWithEnvironment()",1);

 		//log("LEUK MEM->INTERACTING WITH ENVIRONMENT");
 		for (int col = 0; col < length; col++){
 			for (int row = 0; row < width; row++){
 				//log("interacting leukMem "+col+", "+row);
 				
 				//find appropriate MemUnit (if any) to interact with
 				SurfaceUnit ps = this.getEnvironmentSurfaceUnit(myMemUnits[col][row]);
		
 				//attempt to interact with it
 				myMemUnits[col][row].interactWithSurfaceUnit(ps);
 			}
 		}
 		log("-Ending interactWithEnvironment()",1);
 	}

 	/* Returns the number of bonds at the rear column of the LeukMem
 	 */
 	public double numInteractionsAtRear(){
 		double numBonds = 0;
 		for (int i = 0; i < this.width; i++){
 			if (myMemUnits[trailingEdge][i].isBound()){
 				numBonds = numBonds + 
					myMemUnits[trailingEdge][i].getNumBonds();
 			}
 		}
 		return numBonds;
 	}
 	
 	
 	
 	/* Returns the number of bonds between the LeukMem and the Surface
 	 */
 	public double numInteractions(){
 		double numBonds = 0;
 		for (int i = 0; i < this.length; i++){
 			for (int j = 0; j < this.width; j++){
 				if (myMemUnits[i][j].isBound()){
 	 				numBonds = numBonds + 
 						myMemUnits[i][j].getNumBonds();
 				}
 			}
 		}
 		return numBonds;
 	}
 	
 	/*
 	 * Number of PSGL1-P-selectin interactions
 	 */
 	public double num_PSGL1_Interactions(){
 		double numBonds = 0;
 		for (int i = 0; i < this.length; i++){
 			for (int j = 0; j < this.width; j++){
 				if (myMemUnits[i][j].isBound()){
 					double psgl1Bonds = myMemUnits[i][j].myGrp_AdhMols[Constants.PSGL1].getNumBonds();
 	 				numBonds = numBonds + psgl1Bonds;
 				}
 			}
 		}
 		return numBonds;
 	}
 	/*
 	 * Returns number of Low affinity VLA4 interactions
 	 */
 	public double numLowAff_VLA4_Interactions(){
 		double numBonds = 0;
 		for (int i = 0; i < this.length; i++){
 			for (int j = 0; j < this.width; j++){
 				if (myMemUnits[i][j].isBound()){
 					double lowAff_VLA4_Bonds = myMemUnits[i][j].myGrp_AdhMols[Constants.VLA4].getNumBoundLowAffMols();
 	 				numBonds = numBonds + lowAff_VLA4_Bonds;
 				}
 			}
 		}
 		return numBonds;
 	}
 	/*
 	 * Return number of High affinity VLA4 interactions
 	 */
 	public double numHighAff_VLA4_Interactions(){
 		double numBonds = 0;
 		for (int i = 0; i < this.length; i++){
 			for (int j = 0; j < this.width; j++){
 				if (myMemUnits[i][j].isBound()){
 					double highAff_VLA4_Bonds = myMemUnits[i][j].myGrp_AdhMols[Constants.VLA4].getNumBoundHighAffMols();
 	 				numBonds = numBonds + highAff_VLA4_Bonds;
 				}
 			}
 		}
 		return numBonds;
 	}
 
 	public double numTotalLFA1(){
 		double numLFA1 = 0;
 		for (int i = 0; i < this.length; i++){
 			for (int j = 0; j < this.width; j++){
 				double num = myMemUnits[i][j].getNumLFA1Total();
 				numLFA1 = numLFA1 + num;
 			}
 		}
 		return numLFA1;
 	}
 	
 	public double numTotalHighLFA1(){
 		double numLFA1 = 0;
 		for (int i = 0; i < this.length; i++){
 			for (int j = 0; j < this.width; j++){
 				double num = myMemUnits[i][j].getNumHighLFA1Total();
 				numLFA1 = numLFA1 + num;
 			}
 		}
 		return numLFA1;
 	}
 
 	public double numHighAff_LFA1_Interactions(){
 		double numBonds = 0;
 		for (int i = 0; i < this.length; i++){
 			for (int j = 0; j < this.width; j++){
 				if (myMemUnits[i][j].isBound()){
 					double highAff_LFA1_Bonds = myMemUnits[i][j].getNumLFA1Bonds();
 	 				numBonds = numBonds + highAff_LFA1_Bonds;
 				}
 			}
 		}
 		return numBonds;
 	}
 	
 	public double numRearLFA1Bonds(){
 		double numLFA1Bonds = 0;
 		for (int i = 0; i < this.width; i++){
 			if (myMemUnits[trailingEdge][i].isBound()){
 				numLFA1Bonds = numLFA1Bonds + 
					myMemUnits[trailingEdge][i].getNumLFA1Bonds();
 			}
 		}
 		return numLFA1Bonds;
 	}
 	 	
 	public double numDimericLFA1Bonds(){
 		double numDimericLFA1Bonds = 0;
 		for (int i = 0; i < this.length; i++){
 			for (int j = 0; j < this.width; j++){
 				if (myMemUnits[i][j].isBound()){
 					numDimericLFA1Bonds = numDimericLFA1Bonds + myMemUnits[i][j].getNumDimericLFA1Bonds();
 				}
 			}
 		}
 		return numDimericLFA1Bonds;
 	}
 	
 	public int numRearLFA1GridsBound(){
 		int numLFA1GridsBound = 0;
 		for (int i = 0; i < this.width; i++){
 			if (myMemUnits[trailingEdge][i].isBound()){
 				if (myMemUnits[trailingEdge][i].getNumLFA1Bonds() >0){
 					numLFA1GridsBound++;
 				}
 			}
 		}
 		return numLFA1GridsBound;
 
 	}
 	
 	public int numRearVisibleLFA1Clusters(){
 		int numLFA1Clusters = 0;
 		for (int i = 0; i < this.width; i++){
 			if (this.isYWithinContactZone(i)){
 				numLFA1Clusters = numLFA1Clusters + myMemUnits[trailingEdge][i].numOfClusters();
 			}
 		}
 		return numLFA1Clusters;
 	}
 	
 	public double numRearLFA1(){
 		double numLFA1 = 0;
 		for (int i = 0; i < this.width; i++){
 			if (this.isYWithinContactZone(i)){
 				numLFA1 = numLFA1 + myMemUnits[trailingEdge][i].getNumLFA1Total();
 			}
 		}
 		return numLFA1;
 	}
 	
 	public int numVisibleLFA1Grids(){
 		int num = 0;
 		for (int i = 0; i < this.length; i++){
 			for (int j = 0; j < this.width; j++){
 				if (myMemUnits[i][j].containsLFA1()){
 					num++;
 				}
 			}
 		}
 		return num;
 	}
 	
 	public int numBoundLFA1Grids(){
 		int num = 0;
 		for (int i = 0; i < this.length; i++){
 			for (int j = 0; j < this.width; j++){
 				if (myMemUnits[i][j].containsLFA1()){
 					if (myMemUnits[i][j].getNumLFA1Bonds() > 0){
 						num++;
 					}
 				}
 			}
 		}
 		
 		return num;
 	}
 	
 	public double numTethers(){
 		double numTethers = 0;
 		for (int i = 0; i < this.length; i++){
 			for (int j = 0; j < this.width; j++){
 				if (myMemUnits[i][j].isBound()){
 					numTethers=numTethers+1.0;
 				}
 			}
 		}
 		return numTethers;
 		
 	}
 	public double getTotNumHighAffIntegrins(){
 		double num = 0;
 		for (int i = 0; i < length; i++){
 			for (int j = 0; j < width; j++){
 				num = num+ myMemUnits[i][j].getNumTotHighAffVLA4Mols();	
 			}
 		}
 		
 		return num;
 	}
 	
 	public void haltIntegrinActivation(){
 		for(int i = 0; i < length; i++){
 			for (int j = 0; j < width; j++){
 				myMemUnits[i][j].haltIntegrinActivation();	
 			}
 		}
 	}
 	
 	public boolean isYWithinContactZone(int y){
 		boolean withinContactZone = false;
 		if ( //1 normal situation
 	 			((bottomEdge<topEdge) &&
 	 			(y <= topEdge) &&
 				(y >= bottomEdge ))||
 				
 	 			((bottomEdge>topEdge) &&
 	 			(y >= bottomEdge))||
 				
 				((bottomEdge>topEdge) &&
 				(y <= topEdge))){
 			withinContactZone= true;
 		}
 		return withinContactZone;
 	}
 	
 	/* Finds a SurfaceUnit (or null) from the environment 
 	 * corresponding to this Leuk MemUnit's position.
 	 */
 	private SurfaceUnit getEnvironmentSurfaceUnit(MemUnit leukMemSection){
 		SurfaceUnit env = null;
 		log("+Initiating getEnvironmentPlateSect()",2);
 		//If in the contact surface interface area, then search
 		if (((trailingEdge<leadingEdge)&& //1 normal situation
 			(bottomEdge<topEdge) &&
 			(leukMemSection.getXPosOnMembrane() >= trailingEdge) && 
 			(leukMemSection.getXPosOnMembrane() <= leadingEdge) &&
 			(leukMemSection.getYPosOnMembrane() <= topEdge) &&
			(leukMemSection.getYPosOnMembrane() >= bottomEdge ))||
			
			((trailingEdge>leadingEdge) && //2
			(bottomEdge<topEdge) &&
			(leukMemSection.getXPosOnMembrane() <= leadingEdge) &&
			(leukMemSection.getYPosOnMembrane() <= topEdge) &&
			(leukMemSection.getYPosOnMembrane() >= bottomEdge))||
			
			((trailingEdge>leadingEdge) && //3
			(bottomEdge<topEdge) &&
			(leukMemSection.getXPosOnMembrane() >= trailingEdge) &&
			(leukMemSection.getYPosOnMembrane() <= topEdge) &&
			(leukMemSection.getYPosOnMembrane() >= bottomEdge))||
 			
 			((trailingEdge<leadingEdge)&& //4
 			(bottomEdge>topEdge) &&
 			(leukMemSection.getXPosOnMembrane() >= trailingEdge) &&
			(leukMemSection.getXPosOnMembrane() <= leadingEdge) &&
			(leukMemSection.getYPosOnMembrane() >= bottomEdge))||
			
			((trailingEdge<leadingEdge)&& //5
		 	(bottomEdge>topEdge) &&
			(leukMemSection.getXPosOnMembrane() >= trailingEdge) &&
			(leukMemSection.getXPosOnMembrane() <= leadingEdge) &&
			(leukMemSection.getYPosOnMembrane() <= topEdge))||
			
			((trailingEdge>leadingEdge)&& //6
			(bottomEdge>topEdge) &&
			(leukMemSection.getXPosOnMembrane() <= leadingEdge)&&
			(leukMemSection.getYPosOnMembrane() >= bottomEdge))||

			((trailingEdge>leadingEdge)&& //7
			(bottomEdge>topEdge) &&
			(leukMemSection.getXPosOnMembrane() <= leadingEdge)&&
			(leukMemSection.getYPosOnMembrane() <= topEdge))||

			((trailingEdge>leadingEdge)&& //8
			(bottomEdge>topEdge) &&
			(leukMemSection.getXPosOnMembrane() >= trailingEdge)&&
			(leukMemSection.getYPosOnMembrane() >= bottomEdge))||
			
			((trailingEdge>leadingEdge)&& //9
			(bottomEdge>topEdge) &&
			(leukMemSection.getXPosOnMembrane() >= trailingEdge)&&
			(leukMemSection.getYPosOnMembrane() <= topEdge))){
			
 			
 			Surface mySurface = this.getSurfaceSpace();
 			//SurfaceSpace mySurface = leukMemSection.getSurfaceSpace();
 			int x = this.findXPosOnSurfSpace(leukMemSection.getXPosOnMembrane());
 			int y = this.findYPosOnSurfSpace(leukMemSection.getYPosOnMembrane());
 			log("LeukMem ("+leukMemSection.getXPosOnMembrane()+", "+leukMemSection.getYPosOnMembrane()+")"+"-- Found position on sspace: ("+x+", "+y+")",2);
 			
 			env = mySurface.getSurfaceUnitAt(x,y);
 			if (env == null){
 				log("ERROR NULL SURF UNIT",1);
 			}
 	 		log("-Ending getEnvironmentSurfaceUnit()",2);
 			return env;
 		} else { // no MemUnit in environment
 			return null;
 		}
 	}
 	
 	/* Determines if the given row of the LeukMem is free
 	 */
 	private boolean rowFree(int rowNum){
 		log("+Initiating rowFree("+rowNum+")",2);
 		boolean rowFree;
 		int numBoundMemSecs = 0;
 		for (int i=0; i<length; i++){
 			if (myMemUnits[i][rowNum].isBound()){
 				numBoundMemSecs++;
 			}
 		}
 		rowFree = (numBoundMemSecs > 0) ? false : true;
 		log("row: "+rowNum+" is "+rowFree,2);
 		log("+Ending rowFree()",2);
 		return rowFree;
 	}
 	 
 	/* Determines if the given column of the LeukMem is free
 	 */
 	private boolean columnFree(int columnNum){
 		boolean edgeFree;
 		int numBoundMemSecs = 0;
 		for (int i = 0; i < width; i++){
 			if (myMemUnits[columnNum][i].isBound()){
 				numBoundMemSecs++;
 			}
 		}
 		edgeFree = (numBoundMemSecs > 0) ? false : true;
 		//log("ColumnFree:"+columnNum+" "+edgeFree);
 		return edgeFree;
 	}
 	
 	/* Returns true if the membrane is bound (at least 1 adhMol attachment)
 	 * to the surface membrane
 	 */
 	public boolean bound(){
 		boolean free = true;
 		for (int col = 0; col < this.length; col++){
 			free &= this.columnFree(col);	
 		}	
 		return !free;	
 	}
 	
 	/* Returns true if there are no bonds formed at the trailing
 	 * edge of the contact zone
 	 */
 	public boolean trailingEdgeFree(){
 		boolean cfree = columnFree(trailingEdge);
 		return cfree;	
 	}
 	
 	/* Returns true if there are no bonds formed at the top row edge
 	 * of the contact zone
 	 */
 	public boolean topRowFree(){
 		return rowFree(topEdge);
 	}
 	
 	/* Returns true if there are no bonds formed at the bottom row edge
 	 * of the contact zone
 	 */
 	public boolean bottomRowFree(){
 		return rowFree(bottomEdge);
 	}
 	
 	/* Returns the row number of the Membrane that is at the bottom edge of
 	 * the contact zone
 	 */
 	public int getBottomEdge(){
 		return bottomEdge;
 	}
 	
	/* Returns the row number of the Membrane that is at the bottom edge of
 	 * the contact zone
 	 */
 	public int getTopEdge(){
 		return topEdge;
 	}
 	
	/* Returns the column number of the Membrane that is at the rear edge of
 	 * the contact zone
 	 */
 	public int getTrailingEdge(){
 		return trailingEdge;
 	}
 	
	/* Returns the column number of the Membrane that is at the front edge of
 	 * the contact zone
 	 */
 	public int getLeadingEdge(){
 		return leadingEdge;
 	}
 	
 	/*Sets the FlowChamber for this LeukMem
 	 */
 	public void setFlowChamber(FlowChamber fc){
 		myFlowChamber = fc;
 	}
 	
 	/*Gets the FlowChamber for this LeukMem
 	 */
 	public FlowChamber getFlowChamber(){
 		return myFlowChamber;
 	}

 	/* Get the X position of the left column of the interface on the surface
 	 */
 	public int getXPos() {
 		return xPos;
 	}

 	/* Get the Y position of the bottom row of the interface on the surface 
 	 */
 	public int getYPos() {
 		return yPos;
 	}

 	/* Set the x Position of the left column of the interface on the surface
 	 */
 	public void setXPos(int x) {
 		xPos = x;
 	}

 	/* Set the Y position of the bottom column of the interface on the surface
 	 */
 	public void setYPos(int y) {
 		yPos = y;
 	}

 	public String getCellType(){
 		return new String("Leuk");
 	}
 	
 	/*
  	* Returns the x Position coordinate on the SurfaceSpace for
  	* a LeukMemUnit with the input x coordinates on the LeukMembrane
  	*/
 	public int findXPosOnSurfSpace(int x){
 		Surface ss = this.getSurfaceSpace();
 			if (ss == null){
 				log(".findXPosOnSurfSpace: null surfacespace",2);
 			}
 		
 		if (x >= trailingEdge){
 			int temp = ((x-trailingEdge)+xPos);
 			return temp;
 		} else {
 			int temp = ((this.length-(trailingEdge-x))+xPos);
  			return temp;
 		}
 	}
 	
 	/*
  	* Returns the Y position coordinate on the SurfaceSpace for
  	* a LeukMemUnit with the input y coordinates on the LeukMembrane
  	*/
 	public int findYPosOnSurfSpace(int y){
 		
 		if(y >= bottomEdge){
 			int a =(y-bottomEdge)+yPos;
 			log("new YPos a: "+a,3);
 			
 			return (y-bottomEdge)+yPos;
 		} else {
 			int b = (this.width-(bottomEdge-y))+yPos;
 			log("new YPos b: "+b,3);
 			return ((this.width-(bottomEdge-y))+yPos);
 		}
 	}
 	
 	
 	/*Equivalent to rolling up*/
 	public void moveUp(){
 		log("topEdge: "+topEdge,3);

 		log("bottomEdge: "+bottomEdge,3);
 		
 		log("yPos: "+yPos,3);
 		Surface ss = this.getSurfaceSpace();
 		int addedRow = (topEdge+1) % width;
 		int removedRow = bottomEdge;


 		log("added r: "+addedRow,3);
 		log("removed r: "+removedRow,3);
 		
 		ss.removeLeukMemUnitRow(this,removedRow);
 		bottomEdge++;
		if (bottomEdge == width){
 			bottomEdge=0;
 		}

 		yPos++;
 		
 		ss.insertLeukMemUnitRow(this,addedRow);

 		topEdge++;
 		if (topEdge==width){
 			topEdge = 0;
 			
 		}  
 
 		log("topEdge: "+topEdge,3);
 		log("yPos: "+yPos,3);


 		log("Finished moveup",3);
 	}
 	
 	/*Equivalent to Rolling down*/
 	public void moveDown(){
 		log("Attempting movedown",3);
 		log("topEdge: "+topEdge,3);
 		log("bottomEdge: "+bottomEdge,3);
 		log("yPos: "+yPos,3);
 		
 		Surface ss = this.getSurfaceSpace();
 		int addedRow = (bottomEdge == 0) ? this.width-1 : bottomEdge-1;
 		int removedRow = topEdge;

 		log("added r: "+addedRow,3);
 		log("removed r: "+removedRow,3);
 		ss.removeLeukMemUnitRow(this,removedRow);
 		yPos--;
 		bottomEdge--;
 		if (bottomEdge == -1){
 			bottomEdge = width-1;
 		} 
 		ss.insertLeukMemUnitRow(this,addedRow);
 		topEdge--;
 		
 		if (topEdge == -1){
 			topEdge = width-1;
 		}

 		log("topEdge: "+topEdge,3);
 		log("bottomEdge: "+bottomEdge,3);
 		log("yPos: "+yPos,3);

 		
 		log("Finished movedown",3);
 	}
 	/*Increase exposure of LeukMem to Surface
 	 * 
 	 */
 	public void flatten(){
 		Surface ss = this.getSurfaceSpace();
 		int addedRow = (topEdge+1) % width;
 		ss.insertLeukMemUnitRow(this,addedRow);
 		topEdge = addedRow;
 		
 	
 		int addedColumn = (leadingEdge+1) % length;
 		ss.insertLeukMemUnitColumn(this,addedColumn);
 		leadingEdge = addedColumn;	
 	}
 	
 	/*
 	 * Shrink back to original size
 	 */
 	public void shrinkToOriginalSize(){
 		Surface ss = this.getSurfaceSpace();
 		int removedRow = topEdge;
 		ss.removeLeukMemUnitRow(this,removedRow);
 		topEdge = (topEdge+width-1)%width;
 	
 		int removedCol = leadingEdge;
 		ss.removeLeukMemUnitColumn(this,removedCol);
 		leadingEdge = (leadingEdge+length-1)%length;
 	}
 	
 	/*
 	 * Set the surfaceSpace
 	 */
 	public void setSurfaceSpace(Surface s){
 		mySurfaceSpace = s;

 		log("SURFACE SPACE SET IN LEUKMEM",2);
 		if (s == null){
 			log("BUT SURFACE IS NULL",2);
 		}
 	}
 	
 	/* Return the SurfaceSpace for this LeukMem
 	 */
 	public Surface getSurfaceSpace(){
 		return mySurfaceSpace;
 	}
 	
 	/* Indicates which sections of the LeukMem are interacting with 
 	 * the SurfaceSpace
 	 */
 	public void printSSpaceInfo(){
 		System.out.println("Printing SSpace info: ");
 		for (int i = 0; i < length; i++){
 			for (int j = 0; j < width; j++){
 				if (myMemUnits[i][j].getSurfaceSpace()==null){
 					System.out.print("0");
 				} else {
 					System.out.print("x");
 				}	
 			}	
 			System.out.println("");
 		}
 	}
 
 	/*
 	 * Get the LFA1Grid 
 	 * @param is the id number of the grid
 	 */
 	public LFA1Grid getLFA1Grid(int n){
 		return (LFA1Grid)lfa1GridAgentList.get(n);
 	}
 	
 	/*
 	 * Gets the current number of LFA1Grids
 	 */
 	public int getnumLFA1Grids(){
 		return lfa1GridAgentList.size();
 	}
 	
 	/*
 	 * Adds an LFA1Grid to the List
 	 */
 	public void addLFA1Grid(LFA1Grid lgrid){
 		lfa1GridAgentList.add(lgrid);
 	}
 	
 	/*
	 * Outputs to System.out when Debugging.
	 * @param debugType is the priority level of the statement. 
	 * @param String s is the statement to be printed only if the priority level specified during the 
	 * simulation (myISWBC.debugging) is greater than the priority of the statement.
	 */
 	private void log(String s, int debugType){
 		if (DEBUGGING >= debugType){
 			System.out.println("LeukMem: "+s);
 		}
 	}
 	
 	/* Return the exposure length of the interface with the surface
 	 */
 	public int getExposureLength(){
 		return exposureLength;
 	}
 	
 	/* Return the exposure width of the interface with the surface
 	 */
 	public int getExposureWidth(){
 		return exposureWidth;
 	}
 	
 	/* Return the ISWBC
 	 */
 	public ISWBC getModel(){
 		return myLeuk.getModel();
 	}
 	 	
 	/*
 	 * Increment the counter of LFA1 that have
 	 * participated in binding
 	 */
	public void incrementLFA1participants(){
		LFA1participants++;
	}
	
	/*
	 * Return the number of LFA1 that have participated
	 * in binding
	 */
	public int getLFA1participants(){
		return LFA1participants;
	}
	
	/*
 	 * Increment the counter of LFA1 Rebinding events
 	 */
	public void incrementLFA1RebindingEvents(){
		LFA1RebindingEvents++;
	}
	
	/*
	 * Return the number of LFA1 Rebinding events
	 */
	public int getLFA1RebindingEvents(){
		return LFA1RebindingEvents;
	}
	
	/*
 	 * Increment the counter of LFA1 Multimeric Bonds
 	 */
	public void incrementMultimericLFA1ICAMBonds(){
		MultimericLFA1ICAMBonds++;
	}
	
	/*
	 * Return the number of LFA1 Multimeric Bonds
	 */
	public int getMultimericLFA1ICAMBonds(){
		return MultimericLFA1ICAMBonds;
	}
	
	/*
 	 * Increment the counter of LFA1 Multimeric Bonds
 	 */
	public void incrementLFA1ICAMCumulativeBonds(){
		LFA1ICAMCumulativeBonds++;
	}
	
	/*
	 * Return the number of LFA1 Multimeric Bonds
	 */
	public int getLFA1ICAMCumulativeBonds(){
		return LFA1ICAMCumulativeBonds;
	}
	
 
 }
 
