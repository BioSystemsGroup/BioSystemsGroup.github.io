/*
 * @author Jonathan Tang
 */
package src.membrane;

import src.model.ISWBC;

/* Membrane represents a leukocyte membrane
 */
public abstract class Membrane{
	protected MemUnit[][] myMemUnits;
	protected int width;
	protected int length;
	private ISWBC myISWBC;
	

	/* Create a Membrane object for this ISWBC
	 * @param lam is the ISWBC
	 */
	public Membrane(ISWBC lam) {
		myISWBC = lam;
		
	}

	/* Returns the ISWBC
	 * @returns the ISWBC
	 */
	public ISWBC getMyISWBC(){
		return myISWBC;
	}
	
	/* Return the length of the Membrane
	 * @returns length
	 */
	public int getLength() {
		return length;
	}

	/* Return the width of the Membrane
	 * @returns width
	 */
	public int getWidth() {
		return width;
	}

	/*
	 * Gets the MemUnit at the
	 * given x and y coordinates of the Membrane.
	 * @returns the Membrane Unit at the x,y coordinates
	 */
	public MemUnit getMemUnit(int x, int y){
		if ((x >= 0) && (x < length) &&
			(y >= 0) && (y < width)){
			return myMemUnits[x][y];
		} else {
			int xPos=0;
			int yPos=0;
			if (x<0){
				xPos = x+length;
			} 
			if (x>=length){
				xPos = x-length;
			}
			if (y<0){
				yPos = y+width;
			}
			if (y>=width){
				yPos = y-width;
			} 
			return myMemUnits[xPos][yPos];
		}
	}

	
	

}
